#!/usr/bin/env python3
"""
Checker Framework - Output Builder Module

Converts FinalResult to CheckResult format compatible with existing output_formatter.

Design Principles:
- Fully compatible with existing output_formatter.CheckResult
- Auto-generate info_groups / error_groups / warn_groups
- Preserve line_number and file_path metadata

Author: Checker Framework Team
Date: 2026-02-04
"""

from typing import Dict, List, Any, Optional
from pathlib import Path
import sys

from .interfaces import FinalResult

# Try to import existing output_formatter
# If unavailable, define local alternatives
try:
    # Add common module path
    _FRAMEWORK_DIR = Path(__file__).resolve().parent
    _AGENTS_DIR = _FRAMEWORK_DIR.parent
    _CHECKLIST_DIR = _AGENTS_DIR.parent
    _COMMON_DIR = _CHECKLIST_DIR / 'Check_modules' / 'common'
    
    if str(_COMMON_DIR) not in sys.path:
        sys.path.insert(0, str(_COMMON_DIR))
    
    from output_formatter import CheckResult, DetailItem, Severity, ResultType, create_check_result
    HAS_OUTPUT_FORMATTER = True
except ImportError:
    HAS_OUTPUT_FORMATTER = False
    
    # Fallback definitions for Standalone Mode
    from dataclasses import dataclass, field
    from enum import Enum
    from typing import List, Any, Optional

    class Severity(Enum):
        INFO = "Info"
        WARN = "Warn"
        FAIL = "Fail"

    class ResultType(Enum):
        PASS_WITH_VALUES = 1
        FAIL_WITH_VALUES = 2
        PASS_WITHOUT_VALUES = 3
        INFO_ONLY = 4
        PASS_WITH_WAIVERS = 5
        FAIL_WITH_WAIVERS = 6
        FAIL_WITHOUT_CHECK_VALUES = 7
        PASS_WITH_FULL_WAIVERS = 8
        EXECUTION_ERROR = 9
        CONFIG_ERROR = 10

    @dataclass
    class DetailItem:
        severity: Severity
        name: str
        line_number: int
        file_path: str
        reason: str
        
        def __post_init__(self):
            if isinstance(self.severity, str):
                self.severity = Severity[self.severity.upper()]

    @dataclass
    class CheckResult:
        result_type: ResultType
        is_pass: bool
        value: Any
        has_pattern_items: bool = False
        has_waiver_value: bool = False
        details: List[DetailItem] = field(default_factory=list)
        error_groups: Optional[Dict] = None
        info_groups: Optional[Dict] = None
        warn_groups: Optional[Dict] = None
        info_message: Optional[str] = None
        basic_errors: Optional[List[str]] = None
        item_desc: Optional[str] = None
        default_group_desc: Optional[str] = None

    def create_check_result(
        value: Any,
        is_pass: bool,
        has_pattern_items: bool = False,
        has_waiver_value: bool = False,
        details: List[DetailItem] = None,
        item_desc: str = None,
        info_groups: Dict = None,
        error_groups: Dict = None,
        warn_groups: Dict = None,
        **kwargs
    ) -> CheckResult:
        """Create a CheckResult object (Fallback implementation)"""
        # Determine ResultType (simplified logic for fallback)
        if hasattr(value, 'upper') and value == 'N/A':
            r_type = ResultType.INFO_ONLY
        elif is_pass:
            r_type = ResultType.PASS_WITH_VALUES
        else:
            r_type = ResultType.FAIL_WITH_VALUES
            
        return CheckResult(
            result_type=r_type,
            is_pass=is_pass,
            value=value,
            has_pattern_items=has_pattern_items,
            has_waiver_value=has_waiver_value,
            details=details or [],
            item_desc=item_desc,
            info_groups=info_groups,
            error_groups=error_groups,
            warn_groups=warn_groups
        )


# ═══════════════════════════════════════════════════════════════════════════════
# Description Constants (can be overridden by Checker)
# ═══════════════════════════════════════════════════════════════════════════════

DEFAULT_DESCRIPTIONS = {
    'found_desc': "Items passed check",
    'missing_desc': "Items failed check",
    'extra_desc': "Unexpected items need review",
    'waived_desc': "Items waived",
    'unused_desc': "Unused waiver entries"
}

DEFAULT_REASONS = {
    'found_reason': "Item meets requirements",
    'missing_reason': "Item does not meet requirements",
    'extra_reason': "Item not in expected list",
    'waived_reason': "Item waived per configuration",
    'unused_reason': "Waiver entry not matched"
}


# ═══════════════════════════════════════════════════════════════════════════════
# OutputBuilder - Output Builder
# ═══════════════════════════════════════════════════════════════════════════════

class OutputBuilder:
    """
    Output Builder: Converts FinalResult to CheckResult
    
    Core methods:
    - build(): Build complete CheckResult
    """
    
    def __init__(
        self,
        item_desc: str = "",
        found_desc: str = None,
        missing_desc: str = None,
        extra_desc: str = None,
        waived_desc: str = None,
        unused_desc: str = None,
        found_reason: str = None,
        missing_reason: str = None,
        extra_reason: str = None,
        waived_reason: str = None,
        unused_reason: str = None
    ):
        """
        Initialize output builder
        
        Args:
            item_desc: Checker description (for report)
            *_desc: Group descriptions for each item type
            *_reason: Reason descriptions for each item type
        """
        self.item_desc = item_desc
        
        # Descriptions (for groups)
        self.found_desc = found_desc or DEFAULT_DESCRIPTIONS['found_desc']
        self.missing_desc = missing_desc or DEFAULT_DESCRIPTIONS['missing_desc']
        self.extra_desc = extra_desc or DEFAULT_DESCRIPTIONS['extra_desc']
        self.waived_desc = waived_desc or DEFAULT_DESCRIPTIONS['waived_desc']
        self.unused_desc = unused_desc or DEFAULT_DESCRIPTIONS['unused_desc']
        
        # Reasons (for details)
        self.found_reason = found_reason or DEFAULT_REASONS['found_reason']
        self.missing_reason = missing_reason or DEFAULT_REASONS['missing_reason']
        self.extra_reason = extra_reason or DEFAULT_REASONS['extra_reason']
        self.waived_reason = waived_reason or DEFAULT_REASONS['waived_reason']
        self.unused_reason = unused_reason or DEFAULT_REASONS['unused_reason']
    
    def build(
        self,
        result: FinalResult,
        has_pattern_items: bool = False,
        has_waiver_value: bool = False,
        convert_to_info: bool = False
    ) -> 'OutputCheckResult':
        """
        Build CheckResult
        
        Args:
            result: FinalResult object
            has_pattern_items: Whether has pattern_items (Type 2/3)
            has_waiver_value: Whether has waiver.value (Type 3/4)
            convert_to_info: Whether to convert FAIL to INFO (waiver.value=0)
            
        Returns:
            CheckResult compatible with existing output_formatter
        """
        # Check removed to support standalone mode with fallback definitions
        pass
        
        # Build details
        details = []
        
        # 0.5. Waive Info items (INFO with [WAIVED_INFO]) - INSERT FIRST
        # These come from waiver.value=0 mode and should appear before found items
        if result.waive_info_items:
            details.extend(self._build_details(
                items=result.waive_info_items,
                severity=Severity.INFO,
                reason=""  # Use item-specific reason (set in waiver_module)
            ))
            
        # 1. Found items (INFO)
        details.extend(self._build_details(
            items=result.found,
            severity=Severity.INFO,
            reason=self.found_reason
        ))
        
        # 2. Missing items (FAIL or INFO if convert_to_info)
        missing_severity = Severity.INFO if convert_to_info else Severity.FAIL
        missing_reason = self.missing_reason
        if convert_to_info:
            missing_reason += " [WAIVED_AS_INFO]"
        
        details.extend(self._build_details(
            items=result.missing,
            severity=missing_severity,
            reason=missing_reason
        ))
        
        # 3. Extra items (WARN or FAIL for Type 2/3)
        if result.extra:
            extra_severity = Severity.WARN if has_pattern_items else Severity.FAIL
            if convert_to_info:
                extra_severity = Severity.INFO
            details.extend(self._build_details(
                items=result.extra,
                severity=extra_severity,
                reason=self.extra_reason + (" [WAIVED_AS_INFO]" if convert_to_info else "")
            ))
        
        # 4. Waived items (INFO with [WAIVER] tag)
        if result.waived:
            details.extend(self._build_details(
                items=result.waived,
                severity=Severity.INFO,
                reason=self.waived_reason + " [WAIVER]"
            ))
        
        # 5. Unused waivers (WARN)
        if result.unused:
            details.extend(self._build_details(
                items=result.unused,
                severity=Severity.WARN,
                reason=self.unused_reason
            ))
        
        # Build groups
        info_groups = {}
        error_groups = {}
        warn_groups = {}
        
        # Found -> INFO
        found_keys = list(result.found.keys()) if result.found else []
        if result.waive_info_items:
            # Prepend waive info items to found items (match legacy order)
            found_keys = list(result.waive_info_items.keys()) + found_keys
        
        if found_keys:
            info_groups["INFO01"] = {
                "description": self.found_desc,
                "items": found_keys
            }
        
        # Waived -> INFO (with description)
        if result.waived:
            info_groups["INFO02"] = {
                "description": self.waived_desc,
                "items": list(result.waived.keys())
            }
        
        # Missing -> ERROR or INFO
        if result.missing:
            if convert_to_info:
                info_groups["INFO03"] = {
                    "description": self.missing_desc + " [WAIVED_AS_INFO]",
                    "items": list(result.missing.keys())
                }
            else:
                error_groups["ERROR01"] = {
                    "description": self.missing_desc,
                    "items": list(result.missing.keys())
                }
        
        # Extra -> ERROR or WARN
        if result.extra:
            if convert_to_info:
                info_groups["INFO04"] = {
                    "description": self.extra_desc + " [WAIVED_AS_INFO]",
                    "items": list(result.extra.keys())
                }
            else:
                error_groups["ERROR02"] = {
                    "description": self.extra_desc,
                    "items": list(result.extra.keys())
                }
        
        # Unused waivers -> WARN
        if result.unused:
            warn_groups["WARN01"] = {
                "description": self.unused_desc,
                "items": list(result.unused.keys())
            }
        
        # Calculate value
        value = len(result.found) if result.found else 0
        
        # Calculate is_pass
        is_pass = result.is_pass if not convert_to_info else True
        
        return create_check_result(
            value=value,
            is_pass=is_pass,
            has_pattern_items=has_pattern_items,
            has_waiver_value=has_waiver_value,
            details=details,
            item_desc=self.item_desc,
            info_groups=info_groups if info_groups else None,
            error_groups=error_groups if error_groups else None,
            warn_groups=warn_groups if warn_groups else None
        )
    
    def _build_details(
        self,
        items: Dict[str, Dict],
        severity: 'Severity',
        reason: str
    ) -> List['DetailItem']:
        """Build DetailItem list"""
        details = []
        
        for name, item_data in items.items():
            details.append(DetailItem(
                severity=severity,
                name=name,
                line_number=item_data.get('line_number', 0),
                file_path=item_data.get('file_path', 'N/A'),
                reason=reason if reason else item_data.get('reason', '')
            ))
        
        return details
