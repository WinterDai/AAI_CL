#!/usr/bin/env python3
"""
Checker Framework - 模块初始化

导出框架核心组件供外部使用。

使用示例:
    from Agents.Framework import UnifiedChecker
    
    class MyChecker(UnifiedChecker):
        def _parse_input_files(self, input_files):
            ...
        def _judge_item(self, item):
            ...
        def _build_vio_name(self, item):
            ...

Author: Checker Framework Team
Date: 2026-02-04
"""

# 核心数据类型
from .interfaces import (
    CheckResult,
    WaiverResult,
    FinalResult,
    LLMCodeInterface,
    JudgeFunc,
    VioNameFunc,
    MatchFunc
)

# 功能模块
from .check_module import (
    CheckModule,
    default_substring_match,
    default_pattern_match
)

from .waiver_module import (
    WaiverModule,
    parse_waive_items,
    default_waiver_match
)

from .output_builder import OutputBuilder

# 统一 Checker 基类
from .unified_checker import (
    UnifiedChecker,
    CheckerError,
    ConfigurationError,
    ParsingError,
    get_checker_type
)

# 版本信息
__version__ = "1.0.0"
__author__ = "Checker Framework Team"

# 公开接口
__all__ = [
    # 数据类型
    'CheckResult',
    'WaiverResult', 
    'FinalResult',
    'LLMCodeInterface',
    'JudgeFunc',
    'VioNameFunc',
    'MatchFunc',
    
    # 功能模块
    'CheckModule',
    'WaiverModule',
    'OutputBuilder',
    
    # 默认函数
    'default_substring_match',
    'default_pattern_match',
    'default_waiver_match',
    'parse_waive_items',
    
    # Checker 基类
    'UnifiedChecker',
    'CheckerError',
    'ConfigurationError',
    'ParsingError',
    'get_checker_type',
]
