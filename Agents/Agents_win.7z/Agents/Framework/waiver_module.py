#!/usr/bin/env python3
"""
Checker Framework - Waiver Processing Module

Implements waiver matching and application logic.

Design Principles:
- Support waiver.value=0 (waive all) and waiver.value>0 (match individually)
- Compatible with wildcard matching
- Track unused waiver entries

Author: Checker Framework Team
Date: 2026-02-04
"""

import fnmatch
from typing import Dict, List, Any, Callable, Optional, Tuple

from .interfaces import WaiverResult, MatchFunc, unified_pattern_match


# ═══════════════════════════════════════════════════════════════════════════════
# Waiver Parsing Utilities
# ═══════════════════════════════════════════════════════════════════════════════

def parse_waive_items(waive_items_raw: List[Any]) -> Dict[str, str]:
    """
    Parse waive_items configuration into {pattern: reason} dictionary
    
    Supported formats:
    - Simple list: ['pattern1', 'pattern2']
    - Dict list: [{'name': 'pattern', 'reason': 'explanation'}, ...]
    - With separator: ['pattern1 ; # reason', 'pattern2, # reason']
    
    Returns:
        Dict[pattern, reason]
    """
    result = {}
    
    for item in waive_items_raw:
        if isinstance(item, dict):
            # Dictionary format
            name = str(item.get('name', '')).strip()
            reason = str(item.get('reason', '')).strip()
            if name:
                result[name] = reason
        else:
            # String format
            item_str = str(item).strip()
            
            # Detect separator
            if ';' in item_str:
                parts = item_str.split(';', 1)
                name = parts[0].strip()
                reason = parts[1].strip().lstrip('#').strip()
            elif ',' in item_str and '#' in item_str:
                parts = item_str.split(',', 1)
                name = parts[0].strip()
                reason = parts[1].strip().lstrip('#').strip()
            else:
                name = item_str
                reason = ''
            
            if name:
                result[name] = reason
    
    return result


# Use unified_pattern_match from interfaces (backward compatibility alias)
default_waiver_match = unified_pattern_match


# ═══════════════════════════════════════════════════════════════════════════════
# WaiverModule - Waiver Processing Module
# ═══════════════════════════════════════════════════════════════════════════════

class WaiverModule:
    """
    Waiver Module: Handles violation waiver logic
    
    Core methods:
    - apply_waivers(): Apply waivers to violation items
    """
    
    @staticmethod
    def apply_waivers(
        violation_items: Dict[str, Dict],
        waiver_value: Any,
        waive_items: List[Any],
        match_func: MatchFunc = default_waiver_match
    ) -> WaiverResult:
        """
        Apply waiver logic to violation items
        
        Used for: Type 3 (on extra), Type 4 (on missing)
        
        Logic:
        1. waiver.value = 0: Waive all, return directly
        2. waiver.value > 0: Match waive_items individually
        
        Args:
            violation_items: Violation items to process {vio_name: item_dict}
            waiver_value: waiver.value (0, int, or 'N/A')
            waive_items: waiver.waive_items raw list
            match_func: Match function (default supports wildcards)
            
        Returns:
            WaiverResult:
            - unwaived: Violations not waived (still FAIL)
            - waived: Items that were waived
            - unused: Waiver entries that didn't match any violation
        """
        # Case 1: waiver.value = 0, waive all violations AND add waive_items as Info
        if waiver_value == 0 or waiver_value == '0':
            # Build waive_info_items from waive_items config
            waive_dict = parse_waive_items(waive_items)
            waive_info = {}
            for item_text, reason in waive_dict.items():
                # These will be output as Info with [WAIVED_INFO] suffix
                waive_info[item_text] = {
                    'name': item_text,
                    'reason': f"{item_text}[WAIVED_INFO]",
                    'line_number': 0,
                    'file_path': 'N/A'
                }
            
            return WaiverResult(
                unwaived={},
                waived=violation_items.copy(),
                unused={},
                waive_info_items=waive_info if waive_info else None
            )
        
        # Case 2: waiver.value > 0, match individually
        waive_dict = parse_waive_items(waive_items)
        
        waived = {}
        unwaived = {}
        used_patterns = set()
        
        for vio_name, item_data in violation_items.items():
            matched_pattern = None
            
            # Try each waiver pattern
            for pattern in waive_dict.keys():
                if match_func(vio_name, pattern):
                    matched_pattern = pattern
                    used_patterns.add(pattern)
                    break
            
            if matched_pattern:
                # Add waiver info to item
                waived_item = item_data.copy()
                waived_item['waiver_pattern'] = matched_pattern
                waived_item['waiver_reason'] = waive_dict.get(matched_pattern, '')
                waived[vio_name] = waived_item
            else:
                unwaived[vio_name] = item_data
        
        # Collect unused waiver entries
        unused = {}
        for pattern, reason in waive_dict.items():
            if pattern not in used_patterns:
                unused[pattern] = {
                    'name': pattern,
                    'reason': reason,
                    'line_number': 0,
                    'file_path': 'N/A'
                }
        
        return WaiverResult(unwaived=unwaived, waived=waived, unused=unused)
    
    @staticmethod
    def is_waiver_enabled(waiver_value: Any) -> bool:
        """Check if waiver processing is enabled"""
        return waiver_value not in [None, 'N/A']
    
    @staticmethod
    def is_global_waive(waiver_value: Any) -> bool:
        """Check if it's a global waive (waiver.value = 0)"""
        return waiver_value == 0 or waiver_value == '0'
