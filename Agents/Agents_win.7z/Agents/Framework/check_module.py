#!/usr/bin/env python3
"""
Checker Framework - Check Module

Implements Boolean and Pattern check logic.

Design Principles:
- Pure functional design, stateless
- Receives LLM-generated functions as parameters
- Returns standardized CheckResult

Author: Checker Framework Team
Date: 2026-02-04
"""

import fnmatch
from typing import Dict, List, Callable, Optional, Any

from .interfaces import ModuleCheckResult, JudgeFunc, VioNameFunc, MatchFunc, unified_pattern_match


# ═══════════════════════════════════════════════════════════════════════════════
# Default Match Functions
# ═══════════════════════════════════════════════════════════════════════════════

# Use unified_pattern_match from interfaces (backward compatibility aliases)
default_substring_match = unified_pattern_match
default_pattern_match = unified_pattern_match


# ═══════════════════════════════════════════════════════════════════════════════
# CheckModule - Check Logic Module
# ═══════════════════════════════════════════════════════════════════════════════

class CheckModule:
    """
    Check Module: Handles Boolean / Pattern check logic
    
    Core methods:
    - boolean_check(): Used for Type 1/4
    - pattern_check(): Used for Type 2/3
    """
    
    @staticmethod
    def boolean_check(
        parsed_items: List[Dict],
        judge_func: JudgeFunc,
        vio_name_func: VioNameFunc
    ) -> ModuleCheckResult:
        """
        Boolean Check: Determine PASS/FAIL for each item based on judge_func
        
        Used for: Type 1 (no waiver), Type 4 (with waiver)
        
        Args:
            parsed_items: Items list returned by LLM _parse_input_files
            judge_func: LLM _judge_item function
            vio_name_func: LLM _build_vio_name function
            
        Returns:
            ModuleCheckResult:
            - found: items where judge_func returns True
            - missing: items where judge_func returns False
        """
        found = {}
        missing = {}
        
        for item in parsed_items:
            vio_name = vio_name_func(item)
            item_with_name = {**item, 'name': vio_name}
            
            if judge_func(item):
                found[vio_name] = item_with_name
            else:
                missing[vio_name] = item_with_name
        
        return ModuleCheckResult(found=found, missing=missing)
    
    @staticmethod
    def pattern_check(
        parsed_items: List[Dict],
        pattern_items: List[str],
        judge_func: JudgeFunc,
        vio_name_func: VioNameFunc,
        match_func: MatchFunc = default_substring_match
    ) -> ModuleCheckResult:
        """
        Pattern Check: Match patterns specified in pattern_items
        
        Used for: Type 2 (no waiver), Type 3 (with waiver)
        
        Logic:
        1. Iterate pattern_items, find matching item for each pattern
        2. Match condition: judge_func(item) = True AND match_func(vio_name, pattern) = True
        3. Unmatched patterns -> missing
        4. Items not in pattern_items -> extra
        
        Args:
            parsed_items: Items list returned by LLM _parse_input_files
            pattern_items: Pattern list from requirements.pattern_items
            judge_func: LLM _judge_item function
            vio_name_func: LLM _build_vio_name function
            match_func: Match function (default uses substring matching)
            
        Returns:
            ModuleCheckResult:
            - found: items that matched a pattern
            - missing: patterns that were not matched
            - extra: items not in pattern_items
        """
        found = {}
        missing_patterns = []
        extra = {}
        matched_vio_names = set()
        
        # 1. Find matching item for each pattern
        for pattern in pattern_items:
            pattern_matched = False
            
            for item in parsed_items:
                vio_name = vio_name_func(item)
                
                # Already matched items can match other patterns again
                if judge_func(item) and match_func(vio_name, pattern):
                    item_with_name = {**item, 'name': vio_name}
                    found[vio_name] = item_with_name
                    matched_vio_names.add(vio_name)
                    pattern_matched = True
                    break  # One pattern only needs to match one item
            
            if not pattern_matched:
                missing_patterns.append(pattern)
        
        # 2. Collect extra items (not in pattern matches)
        for item in parsed_items:
            vio_name = vio_name_func(item)
            if vio_name not in matched_vio_names:
                item_with_name = {**item, 'name': vio_name}
                # Only collect FAIL items as extra
                if not judge_func(item):
                    extra[vio_name] = item_with_name
        
        # 3. Convert missing_patterns to dict format
        missing = {}
        for pattern in missing_patterns:
            missing[pattern] = {
                'name': pattern,
                'line_number': 0,
                'file_path': 'N/A',
                'reason': 'Pattern not found in input'
            }
        
        return ModuleCheckResult(found=found, missing=missing, extra=extra)
