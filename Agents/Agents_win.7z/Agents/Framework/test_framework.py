#!/usr/bin/env python3
"""
Test script for Framework verification.
Uses ExampleChecker (Type 3) to test the end-to-end flow.
"""

import sys
import os
from pathlib import Path
from pprint import pprint

# Add parent directory to path to allow importing Agents package
current_dir = Path(__file__).resolve().parent
agents_dir = current_dir.parent.parent
if str(agents_dir) not in sys.path:
    sys.path.insert(0, str(agents_dir))

from Agents.Framework.example_checker import ExampleChecker
from Agents.Framework import ConfigurationError

def create_dummy_report(filename):
    """Create a dummy timing report for testing (Matched to ExampleChecker parsing logic)."""
    # Format expected by ExampleChecker:
    # view group type WNS=xxx(count)
    content = """
    func_max clk_core setup WNS=-0.450(12)
    func_max clk_core hold  WNS=0.000(0)  
    func_min clk_io   hold  WNS=-0.050(3)
    """
    with open(filename, 'w') as f:
        f.write(content)
    return Path(filename).resolve()

def run_test():
    print("MATCHING LOGIC TEST:")
    print("====================")
    
    # 1. Setup
    report_file = create_dummy_report("dummy_timing.rpt")
    checker = ExampleChecker()
    
    # 2. Configure (simulate loading from item.yaml)
    checker.item_data = {
        'input_files': [str(report_file)],
        'requirements': {
            'value': 0,
            'pattern_items': [
                "View 'func_max' path_group 'clk_core' setup",  # Should FAIL (WNS=-0.450)
                "View 'func_max' path_group 'clk_core' hold",   # Missing
                "View 'func_min' path_group 'clk_io' hold"      # Should FAIL (WNS=-0.050)
            ]
        },
        'waivers': {
            'value': 1,
            'waive_items': [
                # Waive the func_min failure
                {'name': "*func_min*clk_io*", 'reason': 'Known hold issue'}
            ]
        }
    }
    
    print(f"Input file: {report_file}")
    print("Requirements patterns:", checker.item_data['requirements']['pattern_items'])
    print("Waiver patterns:", checker.item_data['waivers']['waive_items'])
    print("-" * 50)
    
    # 3. Execute
    try:
        result = checker.execute_check()
        
        print("\nEXECUTION RESULT:")
        print(f"Pass: {result.is_pass}")
        print(f"Value: {result.value}")
        
        print("\nDetails:")
        for detail in result.details:
            print(f"[{detail.severity.value}] {detail.name} -- {detail.reason}")
            
        print("\nGroups:")
        if result.info_groups:
            print("INFO Groups:", result.info_groups.keys())
        if result.error_groups:
            print("ERROR Groups:", result.error_groups.keys())
        if result.warn_groups:
            print("WARN Groups:", result.warn_groups.keys())
            
        # Clean up
        os.remove(report_file)
        
    except Exception as e:
        print(f"\nERROR: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    run_test()
