"""
Auditor Prompts - LLM Prompt 模板

定义 Auditor Agent 各阶段的 System/User Prompt
"""

# ═══════════════════════════════════════════════════════════════════════════════
# Phase 1: 分析阶段 (Analysis)
# ═══════════════════════════════════════════════════════════════════════════════

ANALYSIS_SYSTEM_PROMPT = """You are a Validation Agent analyzing checker code against specifications.

Your role is to:
1. Understand the FormatSpec requirements
2. Analyze the generated code implementation
3. Identify potential issues and mismatches
4. Recommend test scenarios

Be precise and focus on functional correctness, not style.
Always respond in the exact JSON format specified."""


ANALYSIS_USER_PROMPT = """## FormatSpec
{format_spec}

## Generated Code
```python
{code}
```

## Task
分析上述 FormatSpec 和代码，理解需求与实现的对应关系。

请返回以下 JSON 格式 (严格遵守):
```json
{{
  "spec_summary": "FormatSpec 的核心要求摘要 (2-3句话)",
  "code_summary": "代码实现的主要逻辑摘要 (2-3句话)",
  "potential_issues": [
    "可能的问题1: ...",
    "可能的问题2: ..."
  ],
  "test_recommendations": [
    "建议测试场景1: ...",
    "建议测试场景2: ..."
  ]
}}
```

注意:
- potential_issues 应聚焦于 spec 与 code 的不一致
- test_recommendations 应覆盖边界情况"""


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 2: 测试用例生成 (Test Generation)
# ═══════════════════════════════════════════════════════════════════════════════

TESTGEN_SYSTEM_PROMPT = """You are generating test cases for a checker validation.

Test case types:
- Type 1 (N/A, N/A): Pure boolean check
- Type 1 (N/A, 0): Boolean + global waive
- Type 2 (>0, N/A): Pattern matching with requirement
- Type 2 (>0, 0): Pattern + global waive
- Type 3 (>0, >0): Pattern + selective waive
- Type 4 (N/A, >0): Boolean + selective waive

Your goal is to generate comprehensive test cases that validate the checker's correctness.
Always respond in the exact JSON format specified."""


TESTGEN_USER_PROMPT = """## Analysis Summary
{analysis_summary}

## FormatSpec Details
{format_spec}

## Parsed Items (from sanity run)
{parsed_items}

## Available Violation Names
{vio_names}

## Task
基于上述信息，生成测试用例配置。

请返回以下 JSON 格式 (严格遵守):
```json
{{
  "test_cases": [
    {{
      "name": "test_type1_na",
      "type": "type1_na",
      "requirement": {{"value": "N/A", "pattern_items": []}},
      "waiver": {{"value": "N/A", "waive_items": []}},
      "rationale": "验证纯 Boolean 检查场景",
      "expected_result": true
    }},
    {{
      "name": "test_type2_pattern",
      "type": "type2_na",
      "requirement": {{"value": 3, "pattern_items": ["item1", "item2", "item3"]}},
      "waiver": {{"value": "N/A", "waive_items": []}},
      "rationale": "验证 pattern 匹配功能",
      "expected_result": true
    }},
    {{
      "name": "test_type3_waiver",
      "type": "type3",
      "requirement": {{"value": 5, "pattern_items": ["*"]}},
      "waiver": {{"value": 2, "waive_items": ["vio1", "vio2"]}},
      "rationale": "验证选择性 waive 功能",
      "expected_result": true
    }}
  ],
  "notes": "生成说明和覆盖情况"
}}
```

要求:
1. 至少生成 4 个不同类型的测试用例
2. 使用实际的 vio_names 填充 pattern_items 和 waive_items
3. 包含正向和边界测试"""


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 4: 评审阶段 (Review)
# ═══════════════════════════════════════════════════════════════════════════════

REVIEW_SYSTEM_PROMPT = """You are reviewing test results and generating feedback for the CodeGen Agent.

Your role is to:
1. Analyze test failures and identify root causes
2. Determine if the checker passes validation
3. Generate actionable feedback for code improvement

Decision criteria:
- pass: All tests passed or failures are acceptable
- retry: Fixable issues found, recommend CodeGen to regenerate
- abort: Fundamental issues, require human intervention

Be specific about what functions need fixing and how.
Always respond in the exact JSON format specified."""


REVIEW_USER_PROMPT = """## Test Results
{test_results}

## Original FormatSpec
{format_spec}

## Code Being Tested
```python
{code}
```

## Task
评审测试结果，分析失败原因，生成反馈。

请返回以下 JSON 格式 (严格遵守):
```json
{{
  "decision": "pass|retry|abort",
  "passed_count": N,
  "failed_count": N,
  "failure_analysis": [
    {{
      "test_name": "失败的测试名",
      "expected": "期望结果",
      "actual": "实际结果",
      "root_cause": "根因分析",
      "affected_function": "_parse_input_files|_judge_item|_build_vio_name",
      "severity": "low|medium|high",
      "suggested_fix": "具体修复建议"
    }}
  ],
  "recommendations": [
    "改进建议1",
    "改进建议2"
  ],
  "codegen_feedback": {{
    "issues": [
      {{"function": "_parse_input_files", "issue": "...", "severity": "high"}}
    ],
    "suggested_fixes": [
      "修复建议1: ..."
    ],
    "summary": "自然语言总结，描述主要问题和修复方向"
  }}
}}
```

注意:
- 如果所有测试通过，decision 为 "pass"，failure_analysis 为空
- 如果有可修复的失败，decision 为 "retry"
- 只有严重问题无法自动修复时，decision 才为 "abort"
- codegen_feedback.summary 应该清晰描述问题，便于 CodeGen 理解"""


# ═══════════════════════════════════════════════════════════════════════════════
# Helper Functions
# ═══════════════════════════════════════════════════════════════════════════════

def format_analysis_prompt(format_spec: str, code: str) -> tuple:
    """格式化分析阶段 Prompt"""
    return (
        ANALYSIS_SYSTEM_PROMPT,
        ANALYSIS_USER_PROMPT.format(format_spec=format_spec, code=code)
    )


def format_testgen_prompt(
    analysis_summary: str,
    format_spec: str,
    parsed_items: str,
    vio_names: str
) -> tuple:
    """格式化测试生成 Prompt"""
    return (
        TESTGEN_SYSTEM_PROMPT,
        TESTGEN_USER_PROMPT.format(
            analysis_summary=analysis_summary,
            format_spec=format_spec,
            parsed_items=parsed_items,
            vio_names=vio_names
        )
    )


def format_review_prompt(test_results: str, format_spec: str, code: str) -> tuple:
    """格式化评审 Prompt"""
    return (
        REVIEW_SYSTEM_PROMPT,
        REVIEW_USER_PROMPT.format(
            test_results=test_results,
            format_spec=format_spec,
            code=code
        )
    )


def extract_json_from_response(response: str) -> str:
    """从 LLM 响应中提取 JSON 部分"""
    import re
    
    # 尝试匹配 ```json ... ``` 块
    json_match = re.search(r'```json\s*(.*?)\s*```', response, re.DOTALL)
    if json_match:
        return json_match.group(1).strip()
    
    # 尝试匹配 { ... } (最外层)
    brace_match = re.search(r'\{.*\}', response, re.DOTALL)
    if brace_match:
        return brace_match.group(0).strip()
    
    return response
