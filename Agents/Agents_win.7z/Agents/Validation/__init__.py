"""
Validation Agent - 验证 CodeGen 生成的代码

按照架构文档 §B.2 和 §七 设计:
- validators/: 原子单元验证器
- generators/: 测试用例生成器
- executor.py: 测试执行器
- reviewer.py: 评审循环
- validator.py: 主入口
- auditor.py: Auditor Pattern 实现 (LLM 驱动)
"""

from .validator import Validator
from .auditor import AuditorAgent
from .schemas import AuditReport, AuditDecision, CodeGenFeedback

__all__ = ['Validator', 'AuditorAgent', 'AuditReport', 'AuditDecision', 'CodeGenFeedback']
