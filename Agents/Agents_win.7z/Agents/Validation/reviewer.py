"""
Reviewer - 评审循环与回退机制

基于架构文档 §B.2.c
"""

from typing import List, Dict, Optional, Callable, Any
from pathlib import Path
from dataclasses import dataclass, field
from enum import Enum
import json

from .executor import TestResult


class ReviewDecision(Enum):
    """评审决策"""
    PASS = "pass"           # 通过
    FAIL_RETRY = "retry"    # 失败，回退到 B.1 重新开发
    FAIL_ABORT = "abort"    # 失败，终止并请求人工介入


@dataclass
class ReviewResult:
    """评审结果"""
    decision: ReviewDecision
    passed_tests: int = 0
    failed_tests: int = 0
    total_tests: int = 0
    failure_reasons: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    
    @property
    def pass_rate(self) -> float:
        if self.total_tests == 0:
            return 0.0
        return self.passed_tests / self.total_tests


@dataclass
class ReviewCycle:
    """评审循环状态"""
    attempt: int = 0
    max_attempts: int = 2  # 最多 1 轮回退 (初始 + 1 次重试)
    history: List[ReviewResult] = field(default_factory=list)
    
    @property
    def can_retry(self) -> bool:
        return self.attempt < self.max_attempts - 1


class Reviewer:
    """
    评审循环实现
    
    流程 (架构 §B.2.c):
    1. 审核通过 → 生成 validation_report.md
    2. 审核失败 → 给出原因，回退到 B.1 重新开发
    3. 再次失败 → 报错终止，请求人工介入
    """
    
    def __init__(
        self,
        min_pass_rate: float = 1.0,  # 默认要求 100% 通过
        codegen_callback: Optional[Callable] = None  # 回退到 CodeGen 的回调
    ):
        self.min_pass_rate = min_pass_rate
        self.codegen_callback = codegen_callback
        self.cycle = ReviewCycle()
    
    def review(
        self,
        test_results: List[TestResult],
        itemspec: Optional[Dict] = None,
        formatspec: Optional[Dict] = None
    ) -> ReviewResult:
        """
        执行评审
        
        Args:
            test_results: 测试执行结果
            itemspec: ItemSpec 内容 (用于对比)
            formatspec: FormatSpec 内容 (用于对比)
            
        Returns:
            ReviewResult
        """
        result = ReviewResult(
            decision=ReviewDecision.PASS,
            total_tests=len(test_results)
        )
        
        # 统计通过/失败
        for test in test_results:
            if test.passed and test.is_pass is not None:
                result.passed_tests += 1
            else:
                result.failed_tests += 1
                result.failure_reasons.append(
                    f"Test '{test.test_name}': {test.error or 'is_pass=False'}"
                )
        
        # 判断是否通过
        if result.pass_rate >= self.min_pass_rate:
            result.decision = ReviewDecision.PASS
        elif self.cycle.can_retry:
            result.decision = ReviewDecision.FAIL_RETRY
            result.recommendations = self._generate_recommendations(test_results)
        else:
            result.decision = ReviewDecision.FAIL_ABORT
        
        # 记录历史
        self.cycle.attempt += 1
        self.cycle.history.append(result)
        
        return result
    
    def _generate_recommendations(self, test_results: List[TestResult]) -> List[str]:
        """生成改进建议"""
        recommendations = []
        
        # 分析失败的测试
        failed_types = set()
        for test in test_results:
            if not test.passed or test.is_pass is False:
                # 从测试名称提取 type
                if "type1" in test.test_name:
                    failed_types.add("Type 1 (Boolean)")
                elif "type2" in test.test_name:
                    failed_types.add("Type 2 (Pattern)")
                elif "type3" in test.test_name:
                    failed_types.add("Type 3 (Pattern+Waiver)")
                elif "type4" in test.test_name:
                    failed_types.add("Type 4 (Boolean+Waiver)")
        
        for t in failed_types:
            recommendations.append(f"检查 {t} 相关逻辑")
        
        if not recommendations:
            recommendations.append("请检查 _parse_input_files, _judge_item, _build_vio_name 函数实现")
        
        return recommendations
    
    def execute_review_cycle(
        self,
        run_tests: Callable[[], List[TestResult]],
        run_codegen: Optional[Callable[[], None]] = None
    ) -> ReviewResult:
        """
        执行完整评审循环
        
        Args:
            run_tests: 执行测试的函数
            run_codegen: 回退到 CodeGen 重新开发的函数
            
        Returns:
            最终的 ReviewResult
        """
        while True:
            # 执行测试
            test_results = run_tests()
            
            # 评审
            result = self.review(test_results)
            
            if result.decision == ReviewDecision.PASS:
                return result
            
            if result.decision == ReviewDecision.FAIL_RETRY:
                if run_codegen:
                    run_codegen()
                    continue
                else:
                    # 没有 codegen 回调，直接 abort
                    result.decision = ReviewDecision.FAIL_ABORT
                    return result
            
            if result.decision == ReviewDecision.FAIL_ABORT:
                return result
        
        return result
    
    def reset(self):
        """重置评审循环"""
        self.cycle = ReviewCycle()
