"""
Schemas - Auditor Agent 结构化输出定义

定义 LLM 输出和内部数据结构的 Schema
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from enum import Enum
import json


class AuditDecision(Enum):
    """审计决策"""
    PASS = "pass"        # 通过
    RETRY = "retry"      # 失败，回退到 CodeGen 重试
    ABORT = "abort"      # 失败，终止并请求人工介入


@dataclass
class AnalysisResult:
    """
    分析阶段输出 (Phase 1)
    
    LLM 分析 FormatSpec 和生成代码后的结构化输出
    """
    spec_summary: str = ""           # FormatSpec 要点摘要
    code_summary: str = ""           # 代码实现摘要
    potential_issues: List[str] = field(default_factory=list)  # 潜在问题
    test_recommendations: List[str] = field(default_factory=list)  # 测试建议
    raw_llm_response: str = ""       # 保留原始响应 (用于调试)
    
    @classmethod
    def from_json(cls, json_str: str) -> 'AnalysisResult':
        """从 LLM JSON 响应解析"""
        try:
            data = json.loads(json_str)
            return cls(
                spec_summary=data.get('spec_summary', ''),
                code_summary=data.get('code_summary', ''),
                potential_issues=data.get('potential_issues', []),
                test_recommendations=data.get('test_recommendations', []),
                raw_llm_response=json_str
            )
        except json.JSONDecodeError:
            return cls(raw_llm_response=json_str)
    
    def to_dict(self) -> Dict:
        return {
            'spec_summary': self.spec_summary,
            'code_summary': self.code_summary,
            'potential_issues': self.potential_issues,
            'test_recommendations': self.test_recommendations
        }


@dataclass
class TestCaseSpec:
    """
    测试用例规格 (Phase 2)
    
    LLM 生成的测试用例配置
    """
    name: str                        # 测试名称
    type_name: str                   # type1_na, type2_na, type3, type4
    requirement: Dict = field(default_factory=dict)  # {value: ..., pattern_items: [...]}
    waiver: Dict = field(default_factory=dict)       # {value: ..., waive_items: [...]}
    rationale: str = ""              # 为什么生成这个测试
    expected_result: Optional[bool] = None  # 预期结果 (PASS/FAIL)
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'TestCaseSpec':
        return cls(
            name=data.get('name', 'unnamed'),
            type_name=data.get('type', data.get('type_name', 'unknown')),
            requirement=data.get('requirement', {}),
            waiver=data.get('waiver', {}),
            rationale=data.get('rationale', ''),
            expected_result=data.get('expected_result')
        )
    
    def to_yaml_dict(self) -> Dict:
        """转换为 YAML 配置格式"""
        return {
            'description': self.rationale,
            'requirements': self.requirement,
            'waivers': self.waiver
        }


@dataclass
class TestCaseGenerationResult:
    """测试用例生成结果"""
    test_cases: List[TestCaseSpec] = field(default_factory=list)
    generation_notes: str = ""       # LLM 生成说明
    raw_llm_response: str = ""
    
    @classmethod
    def from_json(cls, json_str: str) -> 'TestCaseGenerationResult':
        """从 LLM JSON 响应解析"""
        try:
            data = json.loads(json_str)
            test_cases = [
                TestCaseSpec.from_dict(tc) 
                for tc in data.get('test_cases', [])
            ]
            return cls(
                test_cases=test_cases,
                generation_notes=data.get('notes', ''),
                raw_llm_response=json_str
            )
        except json.JSONDecodeError:
            return cls(raw_llm_response=json_str)


@dataclass
class FailureAnalysis:
    """
    失败分析 (Phase 4)
    
    单个测试失败的详细分析
    """
    test_name: str                   # 测试名称
    expected: Any = None             # 期望结果
    actual: Any = None               # 实际结果
    root_cause: str = ""             # 根因分析
    affected_function: str = ""      # 影响的函数 (_parse_input_files, _judge_item 等)
    severity: str = "medium"         # low, medium, high
    suggested_fix: str = ""          # 修复建议
    
    def to_dict(self) -> Dict:
        return {
            'test_name': self.test_name,
            'expected': self.expected,
            'actual': self.actual,
            'root_cause': self.root_cause,
            'affected_function': self.affected_function,
            'severity': self.severity,
            'suggested_fix': self.suggested_fix
        }


@dataclass
class CodeGenFeedback:
    """
    给 CodeGen 的反馈 (结构化 + 自然语言)
    
    用于回退到 CodeGen 重新开发时的输入
    """
    decision: AuditDecision = AuditDecision.PASS
    issues: List[Dict] = field(default_factory=list)  # [{function, issue, severity}]
    suggested_fixes: List[str] = field(default_factory=list)
    natural_language_summary: str = ""  # 自然语言描述
    
    def to_dict(self) -> Dict:
        return {
            'decision': self.decision.value,
            'issues': self.issues,
            'suggested_fixes': self.suggested_fixes,
            'summary': self.natural_language_summary
        }
    
    def to_markdown(self) -> str:
        """生成 Markdown 格式反馈"""
        lines = [
            f"# CodeGen Feedback",
            f"",
            f"**Decision**: {self.decision.value.upper()}",
            f"",
            f"## Summary",
            f"",
            self.natural_language_summary,
            f"",
        ]
        
        if self.issues:
            lines.extend([
                "## Issues Found",
                "",
                "| Function | Issue | Severity |",
                "|----------|-------|----------|",
            ])
            for issue in self.issues:
                lines.append(
                    f"| {issue.get('function', 'N/A')} | {issue.get('issue', '')} | {issue.get('severity', 'medium')} |"
                )
            lines.append("")
        
        if self.suggested_fixes:
            lines.extend([
                "## Suggested Fixes",
                "",
            ])
            for fix in self.suggested_fixes:
                lines.append(f"- {fix}")
            lines.append("")
        
        return "\n".join(lines)


@dataclass
class ReviewResult:
    """
    评审结果 (Phase 4)
    
    LLM 评审测试结果后的输出
    """
    decision: AuditDecision = AuditDecision.PASS
    passed_count: int = 0
    failed_count: int = 0
    total_count: int = 0
    failure_analyses: List[FailureAnalysis] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    codegen_feedback: Optional[CodeGenFeedback] = None
    raw_llm_response: str = ""
    
    @property
    def pass_rate(self) -> float:
        if self.total_count == 0:
            return 0.0
        return self.passed_count / self.total_count
    
    @classmethod
    def from_json(cls, json_str: str) -> 'ReviewResult':
        """从 LLM JSON 响应解析"""
        try:
            data = json.loads(json_str)
            
            # 解析决策
            decision_str = data.get('decision', 'pass').lower()
            decision = AuditDecision(decision_str) if decision_str in ['pass', 'retry', 'abort'] else AuditDecision.PASS
            
            # 解析失败分析
            failures = [
                FailureAnalysis(
                    test_name=f.get('test_name', ''),
                    expected=f.get('expected'),
                    actual=f.get('actual'),
                    root_cause=f.get('root_cause', ''),
                    affected_function=f.get('affected_function', ''),
                    severity=f.get('severity', 'medium'),
                    suggested_fix=f.get('suggested_fix', '')
                )
                for f in data.get('failure_analysis', data.get('failure_analyses', []))
            ]
            
            # 解析 CodeGen 反馈
            feedback_data = data.get('codegen_feedback', {})
            feedback = CodeGenFeedback(
                decision=decision,
                issues=feedback_data.get('issues', []),
                suggested_fixes=feedback_data.get('suggested_fixes', []),
                natural_language_summary=feedback_data.get('summary', data.get('summary', ''))
            ) if feedback_data or decision != AuditDecision.PASS else None
            
            return cls(
                decision=decision,
                passed_count=data.get('passed_count', 0),
                failed_count=data.get('failed_count', 0),
                total_count=data.get('passed_count', 0) + data.get('failed_count', 0),
                failure_analyses=failures,
                recommendations=data.get('recommendations', []),
                codegen_feedback=feedback,
                raw_llm_response=json_str
            )
        except json.JSONDecodeError:
            return cls(raw_llm_response=json_str)
    
    def to_dict(self) -> Dict:
        return {
            'decision': self.decision.value,
            'passed_count': self.passed_count,
            'failed_count': self.failed_count,
            'pass_rate': self.pass_rate,
            'failure_analyses': [f.to_dict() for f in self.failure_analyses],
            'recommendations': self.recommendations,
            'codegen_feedback': self.codegen_feedback.to_dict() if self.codegen_feedback else None
        }


@dataclass
class AuditReport:
    """
    完整审计报告
    
    Auditor Agent 的最终输出
    """
    item_id: str = ""
    timestamp: str = ""
    
    # 各阶段结果
    analysis: Optional[AnalysisResult] = None
    test_generation: Optional[TestCaseGenerationResult] = None
    test_results: List[Dict] = field(default_factory=list)  # from executor
    review: Optional[ReviewResult] = None
    
    # 最终输出
    codegen_feedback: Optional[CodeGenFeedback] = None
    
    @property
    def overall_passed(self) -> bool:
        if self.review:
            return self.review.decision == AuditDecision.PASS
        return False
    
    def to_dict(self) -> Dict:
        return {
            'item_id': self.item_id,
            'timestamp': self.timestamp,
            'overall_passed': self.overall_passed,
            'analysis': self.analysis.to_dict() if self.analysis else None,
            'test_count': len(self.test_results),
            'review': self.review.to_dict() if self.review else None,
            'codegen_feedback': self.codegen_feedback.to_dict() if self.codegen_feedback else None
        }
