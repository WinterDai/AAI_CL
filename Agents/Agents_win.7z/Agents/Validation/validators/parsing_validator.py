"""
Parsing Validator - 验证 _parse_input_files 函数

基于架构文档 §7.1 AtomicUnitValidator.validate_parse_input_files
"""

from typing import List, Dict, Callable, Any, Optional
from pathlib import Path
from dataclasses import dataclass, field
import traceback


@dataclass
class ParsingValidationResult:
    """Parsing 验证结果"""
    passed: bool = False
    items: List[Dict] = field(default_factory=list)
    item_count: int = 0
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


class ParsingValidator:
    """
    验证 _parse_input_files 函数
    
    验证点:
    1. 返回值是否为 list
    2. 每个 item 是否包含必需字段 (line_number, file_path)
    3. 字段类型是否正确
    """
    
    REQUIRED_FIELDS = ['line_number', 'file_path']
    
    def validate(
        self,
        parse_func: Callable,
        test_files: List[Path],
        context: Optional[Any] = None
    ) -> ParsingValidationResult:
        """
        验证 _parse_input_files 函数
        
        Args:
            parse_func: 要验证的函数
            test_files: 测试输入文件列表
            context: 可选的 self 上下文对象
            
        Returns:
            ParsingValidationResult
        """
        result = ParsingValidationResult()
        
        try:
            # 执行函数
            if context is not None:
                items = parse_func(context, test_files)
            else:
                items = parse_func(test_files)
            
            # 验证返回值类型
            if not isinstance(items, list):
                result.errors.append(f"返回值必须是 list，实际为 {type(items).__name__}")
                return result
            
            result.items = items
            result.item_count = len(items)
            
            # 验证每个 item
            for i, item in enumerate(items):
                if not isinstance(item, dict):
                    result.errors.append(f"items[{i}] 必须是 dict，实际为 {type(item).__name__}")
                    continue
                
                # 检查必需字段
                for field in self.REQUIRED_FIELDS:
                    if field not in item:
                        result.errors.append(f"items[{i}] 缺少必需字段: {field}")
                
                # 检查字段类型
                if 'line_number' in item:
                    if not isinstance(item['line_number'], int):
                        result.warnings.append(
                            f"items[{i}].line_number 应为 int，实际为 {type(item['line_number']).__name__}"
                        )
                
                if 'file_path' in item:
                    if not isinstance(item['file_path'], str):
                        result.warnings.append(
                            f"items[{i}].file_path 应为 str，实际为 {type(item['file_path']).__name__}"
                        )
            
            # 判断是否通过
            result.passed = len(result.errors) == 0
            
        except Exception as e:
            result.errors.append(f"执行异常: {str(e)}\n{traceback.format_exc()}")
        
        return result
    
    def validate_from_code(
        self,
        code: str,
        test_files: List[Path]
    ) -> ParsingValidationResult:
        """
        从代码字符串验证
        
        Args:
            code: 包含 _parse_input_files 函数的代码
            test_files: 测试输入文件列表
        """
        result = ParsingValidationResult()
        
        try:
            # 编译并执行代码
            namespace = {'Path': Path, 'List': List, 'Dict': Dict}
            exec(code, namespace)
            
            if '_parse_input_files' not in namespace:
                result.errors.append("代码中未找到 _parse_input_files 函数")
                return result
            
            parse_func = namespace['_parse_input_files']
            return self.validate(parse_func, test_files)
            
        except SyntaxError as e:
            result.errors.append(f"语法错误: {e}")
        except Exception as e:
            result.errors.append(f"代码执行错误: {str(e)}")
        
        return result
