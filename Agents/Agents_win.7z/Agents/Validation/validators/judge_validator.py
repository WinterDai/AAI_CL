"""
Judge Validator - 验证 _judge_item 函数

基于架构文档 §7.1 AtomicUnitValidator.validate_judge_item
"""

from typing import List, Dict, Callable, Any, Optional, Tuple
from dataclasses import dataclass, field
import traceback


@dataclass
class JudgeResult:
    """单个 item 的判断结果"""
    item: Dict
    expected: bool
    actual: bool
    passed: bool
    
    @property
    def match(self) -> str:
        if self.passed:
            return "✓"
        return f"✗ (expected={self.expected}, actual={self.actual})"


@dataclass
class JudgeValidationResult:
    """Judge 验证结果"""
    passed: bool = False
    total: int = 0
    matched: int = 0
    mismatched: int = 0
    results: List[JudgeResult] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    
    @property
    def accuracy(self) -> float:
        if self.total == 0:
            return 0.0
        return self.matched / self.total


class JudgeValidator:
    """
    验证 _judge_item 函数
    
    验证点:
    1. 返回值是否为 bool
    2. 判断结果是否与期望一致
    """
    
    def validate(
        self,
        judge_func: Callable,
        items: List[Dict],
        expected: List[bool],
        context: Optional[Any] = None
    ) -> JudgeValidationResult:
        """
        验证 _judge_item 函数
        
        Args:
            judge_func: 要验证的函数
            items: 测试 item 列表
            expected: 期望的判断结果列表
            context: 可选的 self 上下文对象
            
        Returns:
            JudgeValidationResult
        """
        result = JudgeValidationResult()
        result.total = len(items)
        
        if len(items) != len(expected):
            result.errors.append(
                f"items 和 expected 长度不匹配: {len(items)} vs {len(expected)}"
            )
            return result
        
        try:
            for item, exp in zip(items, expected):
                # 执行函数
                if context is not None:
                    actual = judge_func(context, item)
                else:
                    actual = judge_func(item)
                
                # 验证返回类型
                if not isinstance(actual, bool):
                    result.errors.append(
                        f"返回值必须是 bool，实际为 {type(actual).__name__}"
                    )
                    actual = bool(actual)  # 强制转换以继续测试
                
                # 记录结果
                is_match = (exp == actual)
                result.results.append(JudgeResult(
                    item=item,
                    expected=exp,
                    actual=actual,
                    passed=is_match
                ))
                
                if is_match:
                    result.matched += 1
                else:
                    result.mismatched += 1
            
            # 判断是否通过
            result.passed = (result.mismatched == 0 and len(result.errors) == 0)
            
        except Exception as e:
            result.errors.append(f"执行异常: {str(e)}\n{traceback.format_exc()}")
        
        return result
    
    def validate_from_code(
        self,
        code: str,
        items: List[Dict],
        expected: List[bool]
    ) -> JudgeValidationResult:
        """
        从代码字符串验证
        
        Args:
            code: 包含 _judge_item 函数的代码
            items: 测试 item 列表
            expected: 期望的判断结果列表
        """
        result = JudgeValidationResult()
        
        try:
            # 编译并执行代码
            namespace = {'Dict': Dict}
            exec(code, namespace)
            
            if '_judge_item' not in namespace:
                result.errors.append("代码中未找到 _judge_item 函数")
                return result
            
            judge_func = namespace['_judge_item']
            return self.validate(judge_func, items, expected)
            
        except SyntaxError as e:
            result.errors.append(f"语法错误: {e}")
        except Exception as e:
            result.errors.append(f"代码执行错误: {str(e)}")
        
        return result
    
    def generate_test_cases(
        self,
        items: List[Dict],
        judge_func: Callable,
        context: Optional[Any] = None
    ) -> List[Tuple[Dict, bool]]:
        """
        使用函数生成测试用例 (item → expected)
        
        用于在没有期望值时，先运行一次以生成基准
        """
        results = []
        for item in items:
            if context is not None:
                result = judge_func(context, item)
            else:
                result = judge_func(item)
            results.append((item, bool(result)))
        return results
