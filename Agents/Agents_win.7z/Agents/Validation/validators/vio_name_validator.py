"""
VioName Validator - 验证 _build_vio_name 函数

基于架构文档 §7.1 AtomicUnitValidator.validate_build_vio_name
"""

from typing import List, Dict, Callable, Any, Optional
from dataclasses import dataclass, field
import traceback
import re


@dataclass
class VioNameResult:
    """单个 item 的 vio_name 结果"""
    item: Dict
    vio_name: str
    valid: bool
    issues: List[str] = field(default_factory=list)


@dataclass
class VioNameValidationResult:
    """VioName 验证结果"""
    passed: bool = False
    total: int = 0
    valid: int = 0
    invalid: int = 0
    results: List[VioNameResult] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


class VioNameValidator:
    """
    验证 _build_vio_name 函数
    
    验证点:
    1. 返回值是否为 str
    2. 返回值是否非空
    3. 返回值格式是否合理 (可选)
    """
    
    def validate(
        self,
        vioname_func: Callable,
        items: List[Dict],
        context: Optional[Any] = None,
        expected_pattern: Optional[str] = None
    ) -> VioNameValidationResult:
        """
        验证 _build_vio_name 函数
        
        Args:
            vioname_func: 要验证的函数
            items: 测试 item 列表
            context: 可选的 self 上下文对象
            expected_pattern: 可选的期望格式正则表达式
            
        Returns:
            VioNameValidationResult
        """
        result = VioNameValidationResult()
        result.total = len(items)
        
        try:
            for item in items:
                issues = []
                
                # 执行函数
                if context is not None:
                    vio_name = vioname_func(context, item)
                else:
                    vio_name = vioname_func(item)
                
                # 验证返回类型
                if not isinstance(vio_name, str):
                    issues.append(f"返回值必须是 str，实际为 {type(vio_name).__name__}")
                    vio_name = str(vio_name)  # 强制转换以继续
                
                # 验证非空
                if len(vio_name.strip()) == 0:
                    issues.append("vio_name 不能为空")
                
                # 验证格式 (如果提供了 pattern)
                if expected_pattern and not re.match(expected_pattern, vio_name):
                    issues.append(f"vio_name 不匹配期望格式: {expected_pattern}")
                
                # 记录结果
                is_valid = len(issues) == 0
                result.results.append(VioNameResult(
                    item=item,
                    vio_name=vio_name,
                    valid=is_valid,
                    issues=issues
                ))
                
                if is_valid:
                    result.valid += 1
                else:
                    result.invalid += 1
            
            # 判断是否通过
            result.passed = (result.invalid == 0 and len(result.errors) == 0)
            
        except Exception as e:
            result.errors.append(f"执行异常: {str(e)}\n{traceback.format_exc()}")
        
        return result
    
    def validate_from_code(
        self,
        code: str,
        items: List[Dict],
        expected_pattern: Optional[str] = None
    ) -> VioNameValidationResult:
        """
        从代码字符串验证
        
        Args:
            code: 包含 _build_vio_name 函数的代码
            items: 测试 item 列表
            expected_pattern: 可选的期望格式正则表达式
        """
        result = VioNameValidationResult()
        
        try:
            # 编译并执行代码
            namespace = {'Dict': Dict}
            exec(code, namespace)
            
            if '_build_vio_name' not in namespace:
                result.errors.append("代码中未找到 _build_vio_name 函数")
                return result
            
            vioname_func = namespace['_build_vio_name']
            return self.validate(vioname_func, items, expected_pattern=expected_pattern)
            
        except SyntaxError as e:
            result.errors.append(f"语法错误: {e}")
        except Exception as e:
            result.errors.append(f"代码执行错误: {str(e)}")
        
        return result
    
    def check_uniqueness(
        self,
        vioname_func: Callable,
        items: List[Dict],
        context: Optional[Any] = None
    ) -> Dict[str, List[Dict]]:
        """
        检查 vio_name 的唯一性
        
        返回: {vio_name: [items]} 对于重复的 vio_names
        """
        vio_map = {}
        for item in items:
            if context is not None:
                vio_name = vioname_func(context, item)
            else:
                vio_name = vioname_func(item)
            
            if vio_name not in vio_map:
                vio_map[vio_name] = []
            vio_map[vio_name].append(item)
        
        # 返回重复的
        return {k: v for k, v in vio_map.items() if len(v) > 1}
