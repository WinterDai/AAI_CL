"""
Validator - Validation Agent 主入口

整合所有组件实现完整验证流程
基于架构文档 §B.2
"""

from typing import List, Dict, Optional, Any
from pathlib import Path
from dataclasses import dataclass, field
from datetime import datetime
import json

from .validators.parsing_validator import ParsingValidator, ParsingValidationResult
from .validators.judge_validator import JudgeValidator, JudgeValidationResult
from .validators.vio_name_validator import VioNameValidator, VioNameValidationResult
from .generators.test_case_generator import TestCaseGenerator, TestCase
from .executor import TestExecutor, TestResult
from .reviewer import Reviewer, ReviewResult, ReviewDecision


@dataclass
class ValidationReport:
    """完整验证报告"""
    item_id: str
    timestamp: str = ""
    
    # 原子单元验证结果
    parsing_result: Optional[ParsingValidationResult] = None
    judge_result: Optional[JudgeValidationResult] = None
    vioname_result: Optional[VioNameValidationResult] = None
    
    # 测试执行结果
    test_results: List[TestResult] = field(default_factory=list)
    
    # 评审结果
    review_result: Optional[ReviewResult] = None
    
    @property
    def overall_passed(self) -> bool:
        """总体是否通过"""
        if self.review_result:
            return self.review_result.decision == ReviewDecision.PASS
        return False
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            'item_id': self.item_id,
            'timestamp': self.timestamp,
            'overall_passed': self.overall_passed,
            'parsing': {
                'passed': self.parsing_result.passed if self.parsing_result else None,
                'item_count': self.parsing_result.item_count if self.parsing_result else 0,
                'errors': self.parsing_result.errors if self.parsing_result else []
            } if self.parsing_result else None,
            'judge': {
                'passed': self.judge_result.passed if self.judge_result else None,
                'accuracy': self.judge_result.accuracy if self.judge_result else 0
            } if self.judge_result else None,
            'vioname': {
                'passed': self.vioname_result.passed if self.vioname_result else None
            } if self.vioname_result else None,
            'tests': {
                'total': len(self.test_results),
                'passed': sum(1 for t in self.test_results if t.passed),
                'failed': sum(1 for t in self.test_results if not t.passed)
            },
            'review': {
                'decision': self.review_result.decision.value if self.review_result else None,
                'pass_rate': self.review_result.pass_rate if self.review_result else 0
            } if self.review_result else None
        }


class Validator:
    """
    Validation Agent 主类
    
    职责:
    - B.2.a 测试用例生成
    - B.2.b 执行测试
    - B.2.c 评审循环
    - 生成 validation_report.md
    """
    
    def __init__(
        self,
        checker_dir: Path,
        item_id: str = "UNKNOWN",
        item_desc: str = ""
    ):
        self.checker_dir = Path(checker_dir)
        self.item_id = item_id
        self.item_desc = item_desc
        
        # 初始化组件
        self.parsing_validator = ParsingValidator()
        self.judge_validator = JudgeValidator()
        self.vioname_validator = VioNameValidator()
        self.test_case_generator = TestCaseGenerator(item_id, item_desc)
        self.executor = TestExecutor(checker_dir)
        self.reviewer = Reviewer()
        
        # CodeGen 回调 (用于回退重新开发)
        self._codegen_callback = None
    
    @classmethod
    def from_specs(
        cls,
        checker_dir: Path,
        format_spec_path: Path,
        sanity_item_path: Optional[Path] = None
    ) -> 'Validator':
        """
        从 FormatSpec 和 sanity_item.yaml 创建 Validator
        
        架构 §B.2.a 要求的输入:
        - format_spec.md: 定义 waiver 模板格式
        - sanity_item.yaml: CodeGen 发布的基础配置
        """
        # 使用 TestCaseGenerator.from_format_spec 初始化
        generator = TestCaseGenerator.from_format_spec(
            format_spec_path=format_spec_path,
            sanity_item_path=sanity_item_path
        )
        
        validator = cls(
            checker_dir=checker_dir,
            item_id=generator.item_id,
            item_desc=generator.item_desc
        )
        validator.test_case_generator = generator
        
        return validator
    
    def set_codegen_callback(self, callback):
        """
        设置回退到 CodeGen 的回调函数
        
        架构 §B.2.c: 审核失败时回退到 B.1 重新开发
        
        Args:
            callback: 无参数函数，调用后触发 CodeGen 重新生成代码
        """
        self._codegen_callback = callback
        self.reviewer.codegen_callback = callback
    
    def validate_with_specs(
        self,
        format_spec_path: Path,
        test_files: Optional[List[Path]] = None,
        output_dir: Optional[Path] = None
    ) -> ValidationReport:
        """
        基于 FormatSpec 执行完整验证流程
        
        架构 §B.2 完整流程:
        1. B.2.a: 从 FormatSpec 生成测试用例
        2. B.2.b: 执行测试
        3. B.2.c: 评审循环 (失败时回退到 CodeGen)
        
        Args:
            format_spec_path: format_spec.md 路径
            test_files: 用于 parsing 验证的测试文件
            output_dir: 测试用例输出目录
        """
        report = ValidationReport(
            item_id=self.item_id,
            timestamp=datetime.now().isoformat()
        )
        
        # 解析 FormatSpec
        self.test_case_generator._parse_format_spec(format_spec_path)
        
        # 确定输出目录
        if output_dir is None:
            output_dir = self.checker_dir / "test_cases"
        
        # B.2.a: 生成测试用例
        test_configs = self.test_case_generator.save_test_cases(
            output_dir=output_dir,
            parsed_items=[],  # 如果没有 parsed_items，使用空列表
            vio_names=None
        )
        
        # B.2.b: 执行测试
        report.test_results = self.run_tests(test_configs)
        
        # B.2.c: 评审循环
        report.review_result = self.reviewer.review(report.test_results)
        
        # 如果失败且有回调，触发回退
        if report.review_result.decision == ReviewDecision.FAIL_RETRY:
            if self._codegen_callback:
                print("  🔄 审核失败，回退到 CodeGen 重新开发...")
                self._codegen_callback()
                
                # 重新执行验证
                report.test_results = self.run_tests(test_configs)
                report.review_result = self.reviewer.review(report.test_results)
        
        return report

    
    def validate_atomic_units(
        self,
        parse_code: str,
        judge_code: str,
        vioname_code: str,
        test_files: List[Path],
        expected_judge: Optional[List[bool]] = None
    ) -> Dict[str, Any]:
        """
        验证原子单元
        
        Returns:
            {'parsing': result, 'judge': result, 'vioname': result}
        """
        results = {}
        
        # 1. 验证 parsing
        results['parsing'] = self.parsing_validator.validate_from_code(
            parse_code, test_files
        )
        
        # 如果 parsing 通过，使用其结果验证 judge 和 vioname
        if results['parsing'].passed and results['parsing'].items:
            items = results['parsing'].items
            
            # 2. 验证 judge (如果有期望值)
            if expected_judge:
                results['judge'] = self.judge_validator.validate_from_code(
                    judge_code, items, expected_judge
                )
            else:
                # 没有期望值，只验证语法
                results['judge'] = JudgeValidationResult(passed=True)
            
            # 3. 验证 vioname
            results['vioname'] = self.vioname_validator.validate_from_code(
                vioname_code, items
            )
        else:
            results['judge'] = JudgeValidationResult(
                errors=["Skipped: parsing failed"]
            )
            results['vioname'] = VioNameValidationResult(
                errors=["Skipped: parsing failed"]
            )
        
        return results
    
    def generate_test_cases(
        self,
        output_dir: Path,
        parsed_items: List[Dict],
        vio_names: Optional[List[str]] = None
    ) -> List[Path]:
        """
        生成测试用例
        
        Returns:
            生成的测试配置文件路径列表
        """
        return self.test_case_generator.save_test_cases(
            output_dir, parsed_items, vio_names
        )
    
    def run_tests(self, test_configs: List[Path]) -> List[TestResult]:
        """
        执行测试
        
        Returns:
            TestResult 列表
        """
        return self.executor.run_all_tests(test_configs)
    
    def validate(
        self,
        test_configs: Optional[List[Path]] = None,
        test_dir: Optional[Path] = None
    ) -> ValidationReport:
        """
        执行完整验证流程
        
        Args:
            test_configs: 测试配置文件列表
            test_dir: 或者指定包含测试配置的目录
            
        Returns:
            ValidationReport
        """
        report = ValidationReport(
            item_id=self.item_id,
            timestamp=datetime.now().isoformat()
        )
        
        # 获取测试配置
        if test_configs is None and test_dir:
            test_configs = list(Path(test_dir).glob("*.yaml"))
        
        if not test_configs:
            report.review_result = ReviewResult(
                decision=ReviewDecision.FAIL_ABORT,
                failure_reasons=["No test configurations provided"]
            )
            return report
        
        # 执行测试
        report.test_results = self.run_tests(test_configs)
        
        # 评审
        report.review_result = self.reviewer.review(report.test_results)
        
        return report
    
    def generate_report_markdown(self, report: ValidationReport) -> str:
        """
        生成 validation_report.md
        
        Args:
            report: ValidationReport
            
        Returns:
            Markdown 格式的报告
        """
        lines = [
            f"# Validation Report: {report.item_id}",
            "",
            f"> Generated: {report.timestamp}",
            "",
            f"## Overall Status: {'✅ PASSED' if report.overall_passed else '❌ FAILED'}",
            "",
        ]
        
        # 测试结果汇总
        if report.test_results:
            passed = sum(1 for t in report.test_results if t.passed)
            total = len(report.test_results)
            lines.extend([
                "## Test Results",
                "",
                f"| Metric | Value |",
                f"|--------|-------|",
                f"| Total Tests | {total} |",
                f"| Passed | {passed} |",
                f"| Failed | {total - passed} |",
                f"| Pass Rate | {passed/total*100:.1f}% |",
                "",
            ])
            
            # 详细测试结果
            lines.extend([
                "### Test Details",
                "",
                "| Test Name | Status | Items |",
                "|-----------|--------|-------|",
            ])
            for test in report.test_results:
                status = "✅" if test.passed else "❌"
                lines.append(f"| {test.test_name} | {status} {test.status} | {test.value} |")
            lines.append("")
        
        # 评审结果
        if report.review_result:
            lines.extend([
                "## Review Result",
                "",
                f"**Decision**: {report.review_result.decision.value.upper()}",
                "",
            ])
            
            if report.review_result.failure_reasons:
                lines.extend([
                    "### Failure Reasons",
                    "",
                ])
                for reason in report.review_result.failure_reasons:
                    lines.append(f"- {reason}")
                lines.append("")
            
            if report.review_result.recommendations:
                lines.extend([
                    "### Recommendations",
                    "",
                ])
                for rec in report.review_result.recommendations:
                    lines.append(f"- {rec}")
                lines.append("")
        
        return "\n".join(lines)
    
    def save_report(
        self,
        report: ValidationReport,
        output_path: Path
    ):
        """
        保存验证报告
        
        Args:
            report: ValidationReport
            output_path: 输出路径
        """
        # 保存 Markdown 报告
        md_content = self.generate_report_markdown(report)
        output_path.write_text(md_content, encoding='utf-8')
        
        # 保存 JSON 结果
        json_path = output_path.with_suffix('.json')
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(report.to_dict(), f, indent=2, ensure_ascii=False)


# CLI 入口
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Validation Agent")
    parser.add_argument("checker_dir", help="Checker directory")
    parser.add_argument("--test-dir", help="Test configurations directory")
    parser.add_argument("--output", default="validation_report.md", help="Output report path")
    parser.add_argument("--item-id", default="UNKNOWN", help="Item ID")
    
    args = parser.parse_args()
    
    validator = Validator(
        checker_dir=Path(args.checker_dir),
        item_id=args.item_id
    )
    
    report = validator.validate(test_dir=Path(args.test_dir) if args.test_dir else None)
    validator.save_report(report, Path(args.output))
    
    print(f"Report saved to: {args.output}")
    print(f"Overall: {'PASSED' if report.overall_passed else 'FAILED'}")
