# Validation Skill

验证生成的 checker 是否符合预期行为。

## 目录结构

```
Validation/
├── README.md           # 本文件
├── test_configs/       # 测试配置模板
│   ├── type1_na.yaml   # Type 1 (waivers=N/A)
│   ├── type1_0.yaml    # Type 1 (waivers=0)
│   ├── type2_na.yaml   # Type 2 (waivers=N/A)
│   ├── type2_0.yaml    # Type 2 (waivers=0)
│   ├── type3.yaml      # Type 3
│   └── type4.yaml      # Type 4
├── expected/           # 预期结果模板
│   └── .gitkeep
└── run_validation.py   # 验证脚本 (待开发)
```

## 验证点

| 验证项 | 检查内容 | 预期结果 |
|--------|----------|----------|
| Parsing | 数据结构 | 包含所有预期字段 |
| Type 1 (N/A) | Boolean 检查 | PASS (存在即通过) |
| Type 1 (0) | + WAIVED_INFO | PASS + waive_items 显示 |
| Type 2 (N/A) | 严格模式匹配 | FAIL (模式不匹配) |
| Type 2 (0) | WAIVED_AS_INFO | PASS (转为 INFO) |
| Type 3 | Pattern + Waiver | FAIL + waived/unused |
| Type 4 | Boolean + Waiver | PASS + unused waivers |

## 使用方法

```bash
python3 run_validation.py --checker IMP-10-0-0-00 --module 10.0_STA_DCD_CHECK
```
