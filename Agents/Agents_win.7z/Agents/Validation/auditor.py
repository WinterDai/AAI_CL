"""
Auditor Agent - Auditor Pattern 实现

复用 LLMClient + validators + executor
新增 LLM 驱动的分析、测试生成、评审
"""

import sys
from typing import List, Dict, Optional, Any, Callable
from pathlib import Path
from datetime import datetime
import json
import yaml

# 添加 CodeGen 路径以复用 LLMClient
sys.path.insert(0, str(Path(__file__).parent.parent))
from CodeGen.llm_client import LLMClient, LLMMode, create_client

from .schemas import (
    AnalysisResult, TestCaseSpec, TestCaseGenerationResult,
    ReviewResult, AuditReport, AuditDecision, CodeGenFeedback
)
from .auditor_prompts import (
    format_analysis_prompt, format_testgen_prompt, format_review_prompt,
    extract_json_from_response
)
from .executor import TestExecutor, TestResult
from .validators.parsing_validator import ParsingValidator
from .validators.judge_validator import JudgeValidator
from .validators.vio_name_validator import VioNameValidator


class AuditorAgent:
    """
    Auditor Pattern 实现
    
    四阶段流程:
    1. 分析阶段 (LLM): 理解 spec 和 code
    2. 测试生成 (LLM): 智能生成测试用例
    3. 执行测试 (程序): 复用 executor
    4. 评审阶段 (LLM): 分析结果，生成反馈
    """
    
    def __init__(
        self,
        checker_dir: Path,
        llm_client: LLMClient,
        item_id: str = "UNKNOWN",
        on_step: Optional[Callable[[str, str, str], None]] = None
    ):
        self.checker_dir = Path(checker_dir)
        self.llm = llm_client
        self.item_id = item_id
        self._on_step = on_step
        
        # Initialize programmatic validators (reused)
        self.parsing_validator = ParsingValidator()
        self.judge_validator = JudgeValidator()
        self.vioname_validator = VioNameValidator()
        
        # Lazy-initialize executor (requires checker files)
        self._executor = None
        
        # CodeGen callback
        self._codegen_callback = None
    
    def _emit(self, step: str, status: str, message: str):
        """Emit step update via callback."""
        if self._on_step:
            self._on_step(step, status, message)
    
    @property
    def executor(self) -> TestExecutor:
        """Lazy-initialize TestExecutor"""
        if self._executor is None:
            self._executor = TestExecutor(self.checker_dir)
        return self._executor
    
    def set_codegen_callback(self, callback):
        """Set callback for CodeGen regeneration."""
        self._codegen_callback = callback
    
    # ═══════════════════════════════════════════════════════════════════════════
    # Phase 1: 分析阶段
    # ═══════════════════════════════════════════════════════════════════════════
    
    def analyze(self, format_spec: str, code: str) -> AnalysisResult:
        """
        LLM analyze FormatSpec and code.
        
        Args:
            format_spec: FormatSpec content
            code: Generated code content
            
        Returns:
            AnalysisResult
        """
        self._emit("phase1_analyze", "running", "Analyzing spec and code...")
        
        system_prompt, user_prompt = format_analysis_prompt(format_spec, code)
        response = self.llm.generate(system_prompt, user_prompt)
        
        json_str = extract_json_from_response(response)
        result = AnalysisResult.from_json(json_str)
        
        self._emit("phase1_analyze", "success", f"Analysis complete: {len(result.potential_issues)} issues, {len(result.test_recommendations)} recommendations")
        
        return result
    
    # ═══════════════════════════════════════════════════════════════════════════
    # Phase 2: 测试用例生成
    # ═══════════════════════════════════════════════════════════════════════════
    
    def generate_tests(
        self,
        analysis: AnalysisResult,
        format_spec: str,
        parsed_items: List[Dict],
        vio_names: List[str]
    ) -> TestCaseGenerationResult:
        """
        LLM intelligently generate test cases.
        
        Args:
            analysis: Analysis phase result
            format_spec: FormatSpec content
            parsed_items: Sanity parse results
            vio_names: Violation name list
            
        Returns:
            TestCaseGenerationResult
        """
        self._emit("phase2_testgen", "running", "Generating test cases...")
        
        analysis_summary = f"""Spec Summary: {analysis.spec_summary}
Code Summary: {analysis.code_summary}
Potential Issues: {', '.join(analysis.potential_issues[:3])}
Test Recommendations: {', '.join(analysis.test_recommendations[:3])}"""
        
        parsed_items_str = json.dumps(parsed_items[:5], indent=2, ensure_ascii=False)
        vio_names_str = json.dumps(vio_names[:10], ensure_ascii=False)
        
        system_prompt, user_prompt = format_testgen_prompt(
            analysis_summary, format_spec, parsed_items_str, vio_names_str
        )
        response = self.llm.generate(system_prompt, user_prompt)
        
        json_str = extract_json_from_response(response)
        result = TestCaseGenerationResult.from_json(json_str)
        
        self._emit("phase2_testgen", "success", f"Generated {len(result.test_cases)} test cases")
        
        return result
    
    def save_test_cases(
        self,
        test_gen_result: TestCaseGenerationResult,
        output_dir: Path
    ) -> List[Path]:
        """
        保存生成的测试用例为 YAML 文件
        
        Returns:
            生成的文件路径列表
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        saved_paths = []
        for tc in test_gen_result.test_cases:
            config = tc.to_yaml_dict()
            file_path = output_dir / f"{tc.name}.yaml"
            
            with open(file_path, 'w', encoding='utf-8') as f:
                yaml.dump(config, f, default_flow_style=False, allow_unicode=True)
            
            saved_paths.append(file_path)
        
        return saved_paths
    
    # ═══════════════════════════════════════════════════════════════════════════
    # Phase 3: 执行测试 (程序化)
    # ═══════════════════════════════════════════════════════════════════════════
    
    def execute_tests(self, test_configs: List[Path]) -> List[TestResult]:
        """
        Execute test cases (reusing executor).
        
        Args:
            test_configs: List of test config files
            
        Returns:
            List of TestResult
        """
        self._emit("phase3_execute", "running", "Executing tests...")
        
        results = self.executor.run_all_tests(test_configs)
        
        passed = sum(1 for r in results if r.passed)
        self._emit("phase3_execute", "success", f"Executed {len(results)} tests: {passed} passed, {len(results) - passed} failed")
        
        return results
    
    # ═══════════════════════════════════════════════════════════════════════════
    # Phase 4: 评审阶段
    # ═══════════════════════════════════════════════════════════════════════════
    
    def review(
        self,
        test_results: List[TestResult],
        format_spec: str,
        code: str
    ) -> ReviewResult:
        """
        LLM review test results and generate feedback.
        
        Args:
            test_results: Test execution results
            format_spec: FormatSpec content
            code: Code being tested
            
        Returns:
            ReviewResult (includes CodeGenFeedback)
        """
        self._emit("phase4_review", "running", "Reviewing results...")
        
        results_summary = []
        for r in test_results:
            results_summary.append({
                'test_name': r.test_name,
                'passed': r.passed,
                'status': r.status,
                'value': r.value,
                'error': r.error
            })
        test_results_str = json.dumps(results_summary, indent=2, ensure_ascii=False)
        
        system_prompt, user_prompt = format_review_prompt(
            test_results_str, format_spec, code
        )
        response = self.llm.generate(system_prompt, user_prompt)
        
        json_str = extract_json_from_response(response)
        result = ReviewResult.from_json(json_str)
        
        self._emit("phase4_review", "success", f"Decision: {result.decision.value.upper()}, Pass Rate: {result.pass_rate:.1%}")
        
        return result
    
    # ═══════════════════════════════════════════════════════════════════════════
    # Main Entry
    # ═══════════════════════════════════════════════════════════════════════════
    
    def run(
        self,
        format_spec_path: Path,
        code_path: Optional[Path] = None,
        parsed_items: Optional[List[Dict]] = None,
        vio_names: Optional[List[str]] = None
    ) -> AuditReport:
        """
        执行完整审计流程
        
        Args:
            format_spec_path: FormatSpec 文件路径
            code_path: 代码文件路径 (默认为 checker_dir/imp_logic.py)
            parsed_items: 解析结果 (可选)
            vio_names: vio_name 列表 (可选)
            
        Returns:
            AuditReport
        """
        report = AuditReport(
            item_id=self.item_id,
            timestamp=datetime.now().isoformat()
        )
        
        # 读取输入文件
        format_spec = Path(format_spec_path).read_text(encoding='utf-8')
        
        if code_path is None:
            code_path = self.checker_dir / "imp_logic.py"
        code = Path(code_path).read_text(encoding='utf-8')
        
        # 默认值
        parsed_items = parsed_items or []
        vio_names = vio_names or []
        
        try:
            # Phase 1: Analysis
            report.analysis = self.analyze(format_spec, code)
            
            # Phase 2: Generate test cases
            report.test_generation = self.generate_tests(
                report.analysis, format_spec, parsed_items, vio_names
            )
            
            # Save test cases
            test_dir = self.checker_dir / "test_cases"
            test_configs = self.save_test_cases(report.test_generation, test_dir)
            
            # Phase 3: Execute tests
            test_results = self.execute_tests(test_configs)
            report.test_results = [
                {'name': r.test_name, 'passed': r.passed, 'status': r.status}
                for r in test_results
            ]
            
            # Phase 4: Review
            report.review = self.review(test_results, format_spec, code)
            report.codegen_feedback = report.review.codegen_feedback
            
            # Handle retry
            if report.review.decision == AuditDecision.RETRY and self._codegen_callback:
                self._emit("retry", "running", "Audit failed, retrying CodeGen...")
                self._codegen_callback()
                
                self._emit("retry", "running", "Re-running after CodeGen regeneration...")
                test_results = self.execute_tests(test_configs)
                report.test_results = [
                    {'name': r.test_name, 'passed': r.passed, 'status': r.status}
                    for r in test_results
                ]
                report.review = self.review(test_results, format_spec, code)
                report.codegen_feedback = report.review.codegen_feedback
            
        except Exception as e:
            self._emit("auditor", "error", f"Auditor error: {e}")
            report.review = ReviewResult(
                decision=AuditDecision.ABORT,
                codegen_feedback=CodeGenFeedback(
                    decision=AuditDecision.ABORT,
                    natural_language_summary=f"Auditor encountered an error: {e}"
                )
            )
            report.codegen_feedback = report.review.codegen_feedback
        
        return report
    
    def generate_report_markdown(self, report: AuditReport) -> str:
        """生成 Markdown 格式报告"""
        decision_emoji = {
            AuditDecision.PASS: "✅",
            AuditDecision.RETRY: "🔄",
            AuditDecision.ABORT: "❌"
        }
        
        decision = report.review.decision if report.review else AuditDecision.ABORT
        emoji = decision_emoji.get(decision, "❓")
        
        lines = [
            f"# Audit Report: {report.item_id}",
            f"",
            f"> Generated: {report.timestamp}",
            f"",
            f"## Overall Status: {emoji} {decision.value.upper()}",
            f"",
        ]
        
        # 分析结果
        if report.analysis:
            lines.extend([
                "## Phase 1: Analysis",
                f"",
                f"**Spec Summary**: {report.analysis.spec_summary}",
                f"",
                f"**Code Summary**: {report.analysis.code_summary}",
                f"",
            ])
            
            if report.analysis.potential_issues:
                lines.append("**Potential Issues**:")
                for issue in report.analysis.potential_issues:
                    lines.append(f"- {issue}")
                lines.append("")
        
        # 测试结果
        if report.test_results:
            lines.extend([
                "## Phase 3: Test Results",
                f"",
                "| Test | Status |",
                "|------|--------|",
            ])
            for t in report.test_results:
                status = "✅" if t.get('passed') else "❌"
                lines.append(f"| {t.get('name', 'N/A')} | {status} {t.get('status', 'N/A')} |")
            lines.append("")
        
        # 评审结果
        if report.review:
            lines.extend([
                "## Phase 4: Review",
                f"",
                f"**Decision**: {report.review.decision.value.upper()}",
                f"**Pass Rate**: {report.review.pass_rate:.1%}",
                f"",
            ])
            
            if report.review.failure_analyses:
                lines.append("### Failure Analysis")
                for fa in report.review.failure_analyses:
                    lines.extend([
                        f"- **{fa.test_name}**",
                        f"  - Root Cause: {fa.root_cause}",
                        f"  - Suggested Fix: {fa.suggested_fix}",
                    ])
                lines.append("")
        
        # CodeGen 反馈
        if report.codegen_feedback:
            lines.extend([
                "## CodeGen Feedback",
                f"",
                report.codegen_feedback.natural_language_summary,
                f"",
            ])
        
        return "\n".join(lines)
    
    def save_report(self, report: AuditReport, output_path: Path):
        """保存审计报告"""
        # Markdown
        md_content = self.generate_report_markdown(report)
        Path(output_path).write_text(md_content, encoding='utf-8')
        
        # JSON
        json_path = Path(output_path).with_suffix('.json')
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(report.to_dict(), f, indent=2, ensure_ascii=False)
        
        # CodeGen Feedback (单独保存)
        if report.codegen_feedback:
            feedback_path = Path(output_path).parent / "codegen_feedback.json"
            with open(feedback_path, 'w', encoding='utf-8') as f:
                json.dump(report.codegen_feedback.to_dict(), f, indent=2, ensure_ascii=False)
