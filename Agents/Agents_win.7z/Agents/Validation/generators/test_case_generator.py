"""
Test Case Generator - 生成各 Type 测试用例

基于架构文档 §7.2 TestCaseGenerator
"""

from typing import List, Dict, Any, Optional, Iterator
from pathlib import Path
from dataclasses import dataclass
import yaml


@dataclass
class TestCase:
    """测试用例"""
    name: str
    type_name: str  # type1_na, type1_zero, type2_na, etc.
    req_value: Any
    waiver_value: Any
    pattern_items: List[str]
    waive_items: List[str]
    config_path: Optional[Path] = None


class TestCaseGenerator:
    """
    根据 parsing 结果生成测试用例 (架构 §7.2)
    
    生成 6 种 Type 变体:
    - Type 1 (N/A, N/A): 纯 Boolean 检查
    - Type 1 (N/A, 0): Boolean + 全局 waive
    - Type 2 (>0, N/A): 严格 pattern 匹配
    - Type 2 (>0, 0): Pattern + 全局 waive
    - Type 3 (>0, >0): Pattern + 选择性 waive
    - Type 4 (N/A, >0): Boolean + 选择性 waive
    """
    
    def __init__(
        self,
        item_id: str,
        item_desc: str = "",
        input_files: Optional[List[str]] = None
    ):
        self.item_id = item_id
        self.item_desc = item_desc
        self.input_files = input_files or []
    
    def generate_all_variants(
        self,
        parsed_items: List[Dict],
        vio_names: Optional[List[str]] = None
    ) -> Iterator[TestCase]:
        """
        生成所有 Type 变体
        
        Args:
            parsed_items: 解析结果 (用于生成 patterns/waivers)
            vio_names: 可选的 vio_name 列表 (用于 waiver)
        """
        yield from self._generate_type1_na()
        yield from self._generate_type1_zero()
        yield from self._generate_type2_na(vio_names or [])
        yield from self._generate_type2_zero(vio_names or [])
        yield from self._generate_type3(vio_names or [])
        yield from self._generate_type4(vio_names or [])
    
    def _generate_type1_na(self) -> Iterator[TestCase]:
        """Type 1 (N/A, N/A): 纯 Boolean 检查"""
        yield TestCase(
            name=f"{self.item_id}_type1_na",
            type_name="type1_na",
            req_value="N/A",
            waiver_value="N/A",
            pattern_items=[],
            waive_items=[]
        )
    
    def _generate_type1_zero(self) -> Iterator[TestCase]:
        """Type 1 (N/A, 0): Boolean + 全局 waive"""
        yield TestCase(
            name=f"{self.item_id}_type1_zero",
            type_name="type1_zero",
            req_value="N/A",
            waiver_value=0,
            pattern_items=[],
            waive_items=[]
        )
    
    def _generate_type2_na(self, vio_names: List[str]) -> Iterator[TestCase]:
        """Type 2 (>0, N/A): 严格 pattern 匹配"""
        # 使用全部 vio_names 作为 pattern_items
        pattern_items = vio_names[:5] if vio_names else ["*"]  # 最多 5 个
        yield TestCase(
            name=f"{self.item_id}_type2_na",
            type_name="type2_na",
            req_value=len(pattern_items),
            waiver_value="N/A",
            pattern_items=pattern_items,
            waive_items=[]
        )
    
    def _generate_type2_zero(self, vio_names: List[str]) -> Iterator[TestCase]:
        """Type 2 (>0, 0): Pattern + 全局 waive"""
        pattern_items = vio_names[:5] if vio_names else ["*"]
        yield TestCase(
            name=f"{self.item_id}_type2_zero",
            type_name="type2_zero",
            req_value=len(pattern_items),
            waiver_value=0,
            pattern_items=pattern_items,
            waive_items=[]
        )
    
    def _generate_type3(self, vio_names: List[str]) -> Iterator[TestCase]:
        """Type 3 (>0, >0): Pattern + 选择性 waive"""
        pattern_items = vio_names[:5] if vio_names else ["*"]
        # 选择一部分作为 waive_items
        waive_items = vio_names[1:3] if len(vio_names) > 2 else []
        yield TestCase(
            name=f"{self.item_id}_type3",
            type_name="type3",
            req_value=len(pattern_items),
            waiver_value=len(waive_items),
            pattern_items=pattern_items,
            waive_items=waive_items
        )
    
    def _generate_type4(self, vio_names: List[str]) -> Iterator[TestCase]:
        """Type 4 (N/A, >0): Boolean + 选择性 waive"""
        waive_items = vio_names[:2] if vio_names else []
        yield TestCase(
            name=f"{self.item_id}_type4",
            type_name="type4",
            req_value="N/A",
            waiver_value=len(waive_items),
            pattern_items=[],
            waive_items=waive_items
        )
    
    def to_yaml(self, test_case: TestCase) -> str:
        """
        将测试用例转换为 YAML 格式
        """
        config = {
            'description': self.item_desc,
            'requirements': {
                'value': test_case.req_value,
                'pattern_items': test_case.pattern_items
            },
            'input_files': self.input_files,
            'waivers': {
                'value': test_case.waiver_value,
                'waive_items': test_case.waive_items
            }
        }
        return yaml.dump(config, default_flow_style=False, allow_unicode=True)
    
    def save_test_cases(
        self,
        output_dir: Path,
        parsed_items: List[Dict],
        vio_names: Optional[List[str]] = None
    ) -> List[Path]:
        """
        保存所有测试用例到指定目录
        
        Returns:
            生成的文件路径列表
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        saved_paths = []
        
        for test_case in self.generate_all_variants(parsed_items, vio_names):
            yaml_content = self.to_yaml(test_case)
            file_path = output_dir / f"{test_case.name}.yaml"
            file_path.write_text(yaml_content, encoding='utf-8')
            test_case.config_path = file_path
            saved_paths.append(file_path)
        
        return saved_paths
    
    def recommend_requirements(self, parsed_items: List[Dict]) -> Dict:
        """
        根据 parsing 结果推荐 requirement.pattern_items
        
        分析 items 的共性，推荐合理的 patterns
        """
        # TODO: 实现智能推荐逻辑
        # 目前返回空推荐
        return {
            'recommended_patterns': [],
            'analysis': 'Not implemented yet'
        }
    
    @classmethod
    def from_format_spec(
        cls,
        format_spec_path: Path,
        sanity_item_path: Optional[Path] = None,
        item_id: str = "UNKNOWN",
        item_desc: str = ""
    ) -> 'TestCaseGenerator':
        """
        从 FormatSpec 和 sanity_item.yaml 创建生成器
        
        架构 §B.2.a 要求的输入:
        - format_spec.md: 定义 waiver 模板格式
        - sanity_item.yaml: CodeGen 发布的基础配置
        
        Args:
            format_spec_path: format_spec.md 路径
            sanity_item_path: sanity_item.yaml 路径 (可选)
            item_id: Item ID
            item_desc: Item 描述
        """
        input_files = []
        
        # 读取 sanity_item.yaml (如果存在)
        if sanity_item_path and sanity_item_path.exists():
            with open(sanity_item_path, 'r', encoding='utf-8') as f:
                sanity_config = yaml.safe_load(f)
                item_id = sanity_config.get('id', item_id)
                item_desc = sanity_config.get('description', item_desc)
                input_files = sanity_config.get('input_files', [])
        
        generator = cls(item_id, item_desc, input_files)
        
        # 解析 format_spec.md
        if format_spec_path.exists():
            generator._parse_format_spec(format_spec_path)
        
        return generator
    
    def _parse_format_spec(self, format_spec_path: Path):
        """
        解析 format_spec.md 提取模板和推荐配置
        
        解析内容:
        - Violation Name 格式模板
        - 推荐的 pattern_items
        - 推荐的 waive_items 格式
        """
        import re
        
        content = format_spec_path.read_text(encoding='utf-8')
        
        # 存储解析结果
        self.vio_name_template = ""
        self.recommended_patterns = []
        self.recommended_waivers = []

        # 1) Preferred path: parse Embedded Schema (`format_spec` root).
        block_re = re.compile(r"(?ms)^```yaml[ \t]*\n(.*?)^```[ \t]*$")
        for match in block_re.finditer(content):
            block = match.group(1).strip()
            if not block:
                continue
            try:
                doc = yaml.safe_load(block)
            except Exception:
                continue
            if not isinstance(doc, dict) or not isinstance(doc.get("format_spec"), dict):
                continue

            spec = doc.get("format_spec") or {}
            vio_name = spec.get("vio_name_format")
            if vio_name:
                self.vio_name_template = str(vio_name).strip()

            req_rows = spec.get("requirement_items", []) or []
            parsed_patterns = []
            if isinstance(req_rows, list):
                for row in req_rows:
                    if isinstance(row, dict):
                        pat = row.get("pattern")
                        if pat is not None and str(pat).strip():
                            parsed_patterns.append(str(pat).strip())
                    elif str(row).strip():
                        parsed_patterns.append(str(row).strip())
            self.recommended_patterns = parsed_patterns

            waiver_rows = spec.get("waiver_items", []) or []
            self.recommended_waivers = [str(x).strip() for x in waiver_rows if str(x).strip()]
            return
        
        # 2) Fallback: legacy / textual parsing.
        # 2.1 解析 Violation Name 模板
        template_match = re.search(
            r'### 模板\s*```\s*([^`]+)\s*```',
            content, re.MULTILINE
        )
        if template_match:
            self.vio_name_template = template_match.group(1).strip()

        if not self.vio_name_template:
            vio_match = re.search(r'vio_name_format:\s*["`\']?([^\n"`\']+)["`\']?', content)
            if vio_match:
                self.vio_name_template = vio_match.group(1).strip()
        
        # 2.2 解析推荐的 pattern_items (legacy chinese section)
        pattern_section = re.search(
            r'推荐的 requirement\.pattern_items.*?```yaml\s*pattern_items:\s*(.*?)```',
            content, re.DOTALL
        )
        if pattern_section:
            patterns_text = pattern_section.group(1)
            self.recommended_patterns = [
                line.strip().lstrip('- "').rstrip('"')
                for line in patterns_text.strip().split('\n')
                if line.strip().startswith('-')
            ]

        # 2.3 解析推荐的 pattern_items (new markdown table)
        if not self.recommended_patterns:
            req_section = re.search(
                r'##\s*Requirement Items(.*?)(?:\n##\s+|\Z)',
                content,
                re.DOTALL | re.IGNORECASE
            )
            if req_section:
                for raw in req_section.group(1).splitlines():
                    line = raw.strip()
                    if not line.startswith("|"):
                        continue
                    cols = [x.strip() for x in line.split("|")[1:-1]]
                    if len(cols) < 4:
                        continue
                    if cols[0].lower().startswith("requirement id") or cols[0].startswith("---"):
                        continue
                    pattern = cols[3].strip("` ").strip()
                    if pattern:
                        self.recommended_patterns.append(pattern)
        
        # 2.4 解析推荐的 waive_items (legacy chinese section)
        waiver_section = re.search(
            r'### 精确匹配.*?```yaml\s*waive_items:\s*(.*?)```',
            content, re.DOTALL
        )
        if waiver_section:
            waivers_text = waiver_section.group(1)
            self.recommended_waivers = [
                line.strip().lstrip('- "').rstrip('"')
                for line in waivers_text.strip().split('\n')
                if line.strip().startswith('-')
            ]

        # 2.5 解析推荐的 waive_items (new waiver bullets)
        if not self.recommended_waivers:
            waiver_items_section = re.search(
                r'##\s*Waiver Items(.*?)(?:\n##\s+|\Z)',
                content,
                re.DOTALL | re.IGNORECASE
            )
            if waiver_items_section:
                for raw in waiver_items_section.group(1).splitlines():
                    line = raw.strip()
                    if not line.startswith("-"):
                        continue
                    token = line[1:].strip().strip("`").strip('"').strip("'")
                    if token:
                        self.recommended_waivers.append(token)
    
    def generate_from_format_spec(
        self,
        parsed_items: List[Dict],
        vioname_func: Optional[callable] = None
    ) -> Iterator[TestCase]:
        """
        基于 FormatSpec 生成测试用例
        
        使用 FormatSpec 中定义的推荐配置
        """
        # 生成 vio_names
        vio_names = []
        if vioname_func and parsed_items:
            for item in parsed_items[:10]:  # 最多使用 10 个 items
                try:
                    vio_names.append(vioname_func(item))
                except Exception:
                    pass
        
        # 如果有推荐的 patterns，使用推荐值
        if hasattr(self, 'recommended_patterns') and self.recommended_patterns:
            yield TestCase(
                name=f"{self.item_id}_type2_recommended",
                type_name="type2_recommended",
                req_value=len(self.recommended_patterns),
                waiver_value="N/A",
                pattern_items=self.recommended_patterns,
                waive_items=[]
            )
        
        # 如果有推荐的 waivers，生成 Type 3/4 测试
        if hasattr(self, 'recommended_waivers') and self.recommended_waivers:
            yield TestCase(
                name=f"{self.item_id}_type3_recommended",
                type_name="type3_recommended",
                req_value=len(self.recommended_patterns) if hasattr(self, 'recommended_patterns') else 1,
                waiver_value=len(self.recommended_waivers),
                pattern_items=self.recommended_patterns if hasattr(self, 'recommended_patterns') else ["*"],
                waive_items=self.recommended_waivers
            )
        
        # 生成标准变体
        yield from self.generate_all_variants(parsed_items, vio_names)
