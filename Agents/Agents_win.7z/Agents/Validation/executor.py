"""
Test Executor - 执行 Checker 测试

基于架构文档 §B.2.b
"""

from typing import Dict, List, Optional, Any
from pathlib import Path
from dataclasses import dataclass, field
import subprocess
import json
import shutil
import traceback


@dataclass
class TestResult:
    """单个测试执行结果"""
    test_name: str
    config_path: Path
    passed: bool = False
    is_pass: Optional[bool] = None  # checker 返回的 PASS/FAIL
    value: int = 0  # item 数量
    details: List[Dict] = field(default_factory=list)
    stdout: str = ""
    stderr: str = ""
    error: Optional[str] = None
    return_code: int = -1
    
    @property
    def status(self) -> str:
        if self.error:
            return "ERROR"
        return "PASS" if self.is_pass else "FAIL"


class TestExecutor:
    """
    测试执行器
    
    执行流程 (架构 §B.2.b):
    1. 复制 test_item.yaml → inputs/items/
    2. 运行 checker.py
    3. 保存 logs/ 和 reports/ 输出
    4. 记录 PASS/FAIL 状态
    """
    
    def __init__(
        self,
        checker_dir: Path,
        runner_name: str = "universal_runner.py",
        logic_name: str = "imp_logic.py",
        config_name: str = "imp_config.py",
        timeout: int = 60
    ):
        self.checker_dir = Path(checker_dir)
        self.runner_path = self.checker_dir / runner_name
        self.logic_path = self.checker_dir / logic_name
        self.config_path = self.checker_dir / config_name
        self.timeout = timeout
        
        # 验证文件存在
        self._validate_checker_files()
    
    def _validate_checker_files(self):
        """验证 checker 文件是否存在"""
        for path in [self.runner_path, self.logic_path, self.config_path]:
            if not path.exists():
                raise FileNotFoundError(f"Checker file not found: {path}")
    
    def run_test(self, test_config: Path) -> TestResult:
        """
        执行单个测试
        
        Args:
            test_config: 测试配置文件路径 (item.yaml)
            
        Returns:
            TestResult
        """
        result = TestResult(
            test_name=test_config.stem,
            config_path=test_config
        )
        
        try:
            # 构建命令
            cmd = [
                "python3",
                str(self.runner_path),
                "--logic", str(self.logic_path),
                "--checker-config", str(self.config_path),
                "--config", str(test_config)
            ]
            
            # 执行
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.timeout,
                cwd=str(self.checker_dir)
            )
            
            result.stdout = proc.stdout
            result.stderr = proc.stderr
            result.return_code = proc.returncode
            
            # 解析输出 (假设输出是 JSON)
            if proc.returncode == 0 and proc.stdout.strip():
                self._parse_output(result, proc.stdout)
            elif proc.returncode != 0:
                result.error = f"Checker exited with code {proc.returncode}"
                if proc.stderr:
                    result.error += f"\n{proc.stderr}"
            
            result.passed = (result.return_code == 0)
            
        except subprocess.TimeoutExpired:
            result.error = f"Timeout after {self.timeout} seconds"
        except Exception as e:
            result.error = f"Execution error: {str(e)}\n{traceback.format_exc()}"
        
        return result
    
    def _parse_output(self, result: TestResult, output: str):
        """解析 checker 输出"""
        try:
            # 尝试找到 JSON 部分
            lines = output.strip().split('\n')
            json_start = -1
            for i, line in enumerate(lines):
                if line.strip().startswith('{'):
                    json_start = i
                    break
            
            if json_start >= 0:
                json_str = '\n'.join(lines[json_start:])
                data = json.loads(json_str)
                
                result.is_pass = data.get('is_pass', False)
                result.value = data.get('value', 0)
                result.details = data.get('details', [])
        except json.JSONDecodeError:
            # 如果不是 JSON，尝试解析文本输出
            if 'PASS' in output:
                result.is_pass = True
            elif 'FAIL' in output:
                result.is_pass = False
    
    def run_all_tests(self, test_configs: List[Path]) -> List[TestResult]:
        """
        执行所有测试
        
        Args:
            test_configs: 测试配置文件列表
            
        Returns:
            TestResult 列表
        """
        results = []
        for config in test_configs:
            result = self.run_test(config)
            results.append(result)
        return results
    
    def run_tests_in_dir(self, test_dir: Path) -> List[TestResult]:
        """
        执行目录下所有测试
        
        Args:
            test_dir: 包含测试配置文件的目录
            
        Returns:
            TestResult 列表
        """
        configs = list(test_dir.glob("*.yaml"))
        return self.run_all_tests(configs)
