# JEDAI Integration Plan for Agents System

**Created**: 2026-02-07  
**Updated**: 2026-02-07  
**Status**: Phase 2 - Context Agent Enhancement (Prompt & Architecture Refactoring)

---

## 0. Context Agent Enhancement Plan (Updated 2026-02-07)

### 0.1 问题发现（第一轮调试）

| 问题 | 描述 | 状态 |
|------|------|------|
| 无调试日志 | 没有保存中间环节的输入输出 | ✅ 已修复 |
| JEDAI 模式未支持 | CLI 不支持 jedai 选项 | ✅ 已修复 |
| Windows 路径正则问题 | `\Users` 被误解为 unicode 转义 | ✅ 已修复 |
| JEDAI 连接验证 | 需要测试脚本验证连接 | ✅ 已修复 (test_jedai_connection.py) |

### 0.2 问题发现（第二轮调试 - Prompt 与设计文档偏差）

对照 `Agents/Work/IMP_10_0_0_00_DryRun/context_agent_design.md` 发现严重偏差：

#### 0.2.1 ItemSpec 问题

| 问题 | 设计文档要求 | 当前 Prompt 问题 | LLM 实际输出 |
|------|-------------|----------------|--------------|
| 子项定义不完整 | 每个对象 6 个必须子项 (file_path, file_name, design_name, generator_tool, generator_version, generation_time) | Prompt 没有指定这 6 个子项 | 只生成 2 个子项 (file_path, version_timestamp) |
| 包含 Pattern | ItemSpec 不应包含 pattern | Prompt 没有禁止 | 生成了 `read_netlist\s+...` 等 regex |
| 数据源不明确 | 应指明从 "STA日志" 或 "文件头" 提取 | Prompt 没有要求 | 混杂在 semantic targets 中 |

#### 0.2.2 ParsingSpec 问题

| 问题 | 设计文档要求 | 当前 Prompt 问题 | LLM 实际输出 |
|------|-------------|----------------|--------------|
| 未读取引用文件 | **必须**读取从日志提取的文件路径 | Prompt 没有强调 | "Referenced (not directly accessed)" |
| 子项提取不完整 | 必须提取所有 6 个子项 | Prompt 没有要求 | 缺少 generator_tool/version/time |
| 缺少状态统计 | "netlist 6/6 ✓" 格式 | Prompt 没有要求 | "overall_status: partial_pass" |

#### 0.2.3 FormatSpec 问题

| 问题 | 设计文档要求 | 当前 Prompt 问题 |
|------|-------------|----------------|
| Pattern 设计规则 | `*.v.gz` 正确，`*Genus 23.15*` 错误 | Prompt 没有说明 |
| 跨项目复用 | 不能硬编码项目名 | Prompt 没有强调 |
| 4场景框架 | Req×Waiver 组合 | Prompt 只模糊提及 |

### 0.3 问题发现（第三轮调试 - LLM 输入冗余分析）

分析 `stage_format_spec_input.md` (470行) 和 `stage_parsing_spec_input.md` (286行)：

#### LLM 输入结构分析

| 段落 | 行数 | 内容 | 必要性 | 可后续组装 |
|------|------|------|--------|-----------|
| **System Prompt** | 11行 | 角色定义和阶段边界 | ✅ 必须 | ❌ |
| **User Prompt Template** | 35行 | 阶段任务和输出格式 | ✅ 必须 | ❌ |
| **Item Context (JSON)** | 25行 | 基本元数据 | ✅ 必须 | ❌ |
| **regex_clues 数组** | 10行 | 预置正则表达式 | ⚠️ 可精简 | ✅ FormatSpec 阶段才需要 |
| **上一阶段完整输出** | 200+行 | ItemSpec/ParsingSpec 全文 | 🔴 **冗余** | ✅ 只需要结构化摘要 |
| **Evidence context 表格** | 15行 | 重复的证据记录 | 🔴 **冗余** | ✅ 已在 ParsingSpec 中 |
| **Embedded YAML** | 60+行 | 上阶段的结构化数据 | ⚠️ 可精简 | ✅ 只传 YAML，不传 Markdown |

#### 优化建议

**当前问题**：FormatSpec 输入 470 行，其中：
- 必要内容：~100行（System + User prompt + Item context + 精简证据）
- 冗余内容：~370行（完整 ItemSpec + 完整 ParsingSpec + 重复证据表）

**优化方案**：

```
原始结构 (470行):
├── System Prompt (11行)
├── User Prompt Template (35行)
├── Item Context JSON (25行) + regex_clues (10行)
├── **完整 ItemSpec Markdown** (200行) ← 冗余
├── **完整 ParsingSpec Markdown** (160行) ← 冗余
└── Evidence context 表格 (15行) ← 重复

优化后结构 (~150行):
├── System Prompt (11行)
├── User Prompt Template (35行) - 加入设计文档规则
├── Item Context JSON (25行) - 移除 regex_clues
├── ItemSpec 摘要 YAML (30行) - 只传结构化数据
│   ├── objects 列表
│   ├── sub_items 定义
│   └── data_sources
├── ParsingSpec 摘要 YAML (40行) - 只传提取结果
│   ├── object_mapping (每个子项的值和状态)
│   └── extraction_gaps
└── (去掉重复的 Evidence context)
```

**Token 节省预估**：~60-70%

### 0.4 修改方案（更新版）

#### Phase 1: Prompt 与设计文档对齐 🔴 高优先级

**Step 1: 更新 stage_system.md**
```markdown
## 关键规则

### ItemSpec 阶段规则:
- 每个对象必须定义这 6 个子项: file_path, file_name, design_name, generator_tool, generator_version, generation_time
- 不要包含正则表达式 pattern - 只定义提取什么，不定义怎么提取
- 指明每个子项的数据源 (STA日志 或 文件头)

### ParsingSpec 阶段规则:
- **必须读取任何提取到的文件路径** (如 netlist 路径 → 读取文件头)
- 提取 ItemSpec 定义的所有 6 个子项
- 标记状态: ✓ (成功) 或 ERROR
- 提供对象级汇总: "netlist 6/6 ✓"

### FormatSpec 阶段规则:
- Pattern 必须跨项目可复用
- 正确: `*.v.gz`, `*/dbs/*`, `*Synthesis*`
- 错误: `*block_A*`, `*Genus 23.15*`, 具体项目路径
```

**Step 2: 更新 itemspec_user.md**
- 添加 6 子项要求
- 禁止 pattern
- 要求数据源表

**Step 3: 更新 parsing_spec_user.md**
- 添加 "必须读取引用文件" 规则
- 添加提取完整性检查
- 添加 X/Y 统计格式

**Step 4: 更新 format_spec_user.md**
- 添加 pattern 设计规则
- 添加 4 场景框架

#### Phase 2: LLM 输入精简 🟡 中优先级

**Step 5: 修改 context_pipeline.py 的 prompt 组装逻辑**
- 上阶段输出只传 Embedded YAML，不传完整 Markdown
- 移除重复的 Evidence context 表格
- Item context 只保留必要字段

**Step 6: 创建摘要提取函数**
```python
def _extract_spec_summary(spec_markdown: str) -> str:
    """从完整 Markdown 提取 YAML 摘要"""
    # 只返回 Embedded Schema 部分
```

#### Phase 3: 路径映射修复 🟡 中优先级

**Step 7: 更新 io_resolver.py**
- 添加跨环境路径映射
- 日志路径 `/Users/daiwt/.../CHECKLIST/...` → 本地 `${CHECKLIST_ROOT}/...`

#### Phase 4: 验证与测试 🟢 低优先级

**Step 8: 重新运行 JEDAI 测试**
**Step 9: 对比 DryRun 输出**

### 0.5 文件修改清单

| 文件 | 修改内容 | 优先级 |
|------|----------|--------|
| `Agents/Context/prompts/stage_system.md` | 添加阶段规则 | 🔴 高 |
| `Agents/Context/prompts/itemspec_user.md` | 6子项+禁止pattern | 🔴 高 |
| `Agents/Context/prompts/parsing_spec_user.md` | 必须读取文件+统计 | 🔴 高 |
| `Agents/Context/prompts/format_spec_user.md` | pattern规则+场景 | 🔴 高 |
| `Agents/Context/context_pipeline.py` | 输入精简逻辑 | 🟡 中 |
| `Agents/Context/io_resolver.py` | 路径映射 | 🟡 中 |
| `Agents/Context/test_jedai_connection.py` | ✅ 已创建 | ✅ 完成 |

### 0.6 对比分析结果 (Mock模式运行 2026-02-07)

**执行目录**: `Agents/Work/Context_Agent_Debug/IMP-10-0-0-00/`

#### 0.6.1 ItemSpec 对比

| 维度 | DryRun (参考) | 当前生成 | 差异评估 |
|------|--------------|----------|----------|
| **子项数量** | 6个/对象，全必须 | 9个/对象，混合必须/可选 | 🔴 不一致 |
| **子项名称** | file_path, file_name, design_name, generator_tool, generator_version, generation_time | 加了 status, source_reference, version_token | 🔴 不一致 |
| **数据源标注** | 明确表格 (STA日志/文件头) | 无 | 🔴 缺失 |
| **Pattern** | 无 | 无 | ✅ 一致 |
| **Cross-Object规则** | netlist.design_name == spef.design_name | 有 CR1 规则 | ✅ 一致 |

#### 0.6.2 ParsingSpec 对比

| 维度 | DryRun (参考) | 当前生成 | 差异评估 |
|------|--------------|----------|----------|
| **netlist提取** | 6/6 ✓ 全成功 | 5/6 PARTIAL | 🔴 缺 generator_tool/version/time |
| **netlist文件头读取** | ✅ 读取了 `Cadence Genus 23.15-s099_1` | ❌ "Referenced (not directly accessed)" | 🔴 **核心问题** |
| **spef状态** | 0/6 ✗ 整体缺失 | 2/6 PARTIAL | ⚠️ 格式不同 |
| **skip原因** | `we are writing post-synthesis SDF files` | 相同 | ✅ 一致 |
| **统计格式** | "6/6 ✓" | "mandatory_found: 5" | ⚠️ 格式不同 |

#### 0.6.3 FormatSpec 对比

| 维度 | DryRun (参考) | 当前生成 | 差异评估 |
|------|--------------|----------|----------|
| **Pattern格式** | 聚合: `"netlist: file_path=*/dbs/*; file_name=*.v.gz"` | 细粒度 R1-R12 | ⚠️ 结构不同 |
| **Pattern可复用性** | `*Synthesis*`, `*.*-*` | `phy_cmn_phase_align_digtop.v.gz` 硬编码 | 🔴 违反设计 |
| **4场景** | 完整YAML | 4场景描述 | ✅ 类似 |
| **Waiver items** | `spef:*` | `netlist:*, spef:*` | ⚠️ 略有差异 |

#### 0.6.4 核心问题根因

| 问题 | 根因 | 解决方案 |
|------|------|----------|
| **未读取netlist文件头** | `io_resolver._resolve_possible_reference()` 只接受存在的路径；日志中 `/Users/daiwt/...` 在Windows不存在 | 添加 CHECKLIST_ROOT 相对路径映射 |
| **子项定义偏差** | Prompt 没有指定标准6子项 | 更新 itemspec_user.md |
| **Pattern硬编码** | Prompt 没有可复用性规则 | 更新 format_spec_user.md |

---

## 1. Background

### 1.1 Agents System Architecture

Multi-Agent architecture for automated EDA checker code generation:

```
┌───────────────────┐
│  A. Context Agent │ → parsing_spec.md + format_spec.md + item_spec.md
└─────────┬─────────┘
          │
┌─────────▼─────────┐
│  B.1 CodeGen      │ → checker.py + sanity_item.yaml
└─────────┬─────────┘
          │
┌─────────▼─────────┐
│  B.2 Validation   │ → validation_report.md
└─────────┬─────────┘
          │ Retry if failed
┌─────────▼─────────┐
│  Complete / Fail  │
└───────────────────┘
```

### 1.2 JEDAI Gateway

- **URL**: `https://jedai-ai:2513`
- **Supported Models**: 41+ models (Claude, GPT-5, Gemini, etc.)
- **Default Model**: `claude-opus-4-5`
- **Authentication**: LDAP-based via `JedaiAuth` class

---

## 2. Integration Requirements

1. ✅ Support both `JEDAI_TOKEN` env var and username/password auth
2. ✅ Keep existing clients (MOCK, REAL, INTERACTIVE) as fallback
3. ✅ Streaming marked as TODO (non-streaming fallback)
4. ✅ Backend first, then frontend
5. ✅ Default to JEDAI mode with `claude-opus-4-5`

---

## 3. Implementation Plan

### Phase 1: Core LLM Client (Sync Interface) ✅

| Step | File | Changes |
|------|------|---------|
| 1 | `Agents/CodeGen/llm_client.py` | Add `LLMMode.JEDAI` enum |
| 2 | `Agents/CodeGen/llm_client.py` | Create `JedaiClient(LLMClient)` class |
| 3 | `Agents/CodeGen/llm_client.py` | Update `create_client()` factory |
| 4 | `Agents/CodeGen/__init__.py` | Export `JedaiClient` |

#### JedaiClient Implementation

```python
class JedaiClient(LLMClient):
    """JEDAI LLM client using enterprise gateway."""
    
    def __init__(self, model: str = "claude-opus-4-5", timeout: float = 120.0):
        self.model = MODEL_ALIASES.get(model, model)
        self.auth = JedaiAuth()
        self.base_url = JEDAI_URL
        self.timeout = timeout
    
    def generate(self, system_prompt: str, user_prompt: str) -> str:
        # Uses httpx for sync HTTP calls to /v1/chat/completions
```

### Phase 2: Configuration Updates ✅

| Step | File | Changes |
|------|------|---------|
| 5 | `Agents/Orchestrator/orchestrator.py` | Add `jedai_model` to `PipelineConfig` |
| 6 | `Agents/Orchestrator/orchestrator.py` | Change default `llm_mode` to `JEDAI` |
| 7 | `Agents/Orchestrator/orchestrator.py` | Update `_create_llm_client()` for JEDAI |
| 8 | `Agents/Dashboard/server.py` | Add `jedai_model` to `PipelineStartRequest` |
| 9 | `Agents/Dashboard/server.py` | Add `"jedai"` to mode_map, set as default |

#### PipelineConfig Changes

```python
@dataclass
class PipelineConfig:
    # LLM 配置
    llm_mode: LLMMode = LLMMode.JEDAI  # Changed from MOCK
    jedai_model: str = "claude-opus-4-5"  # New parameter
    api_key: Optional[str] = None
    mocks_dir: Optional[Path] = None
```

### Phase 3: Copilot Provider (Async Interface) ✅

| Step | File | Changes |
|------|------|---------|
| 10 | `Agents/Dashboard/copilot/jedai_llm.py` | Create `JedaiChatProvider` |
| 11 | `Agents/Dashboard/copilot/__init__.py` | Register JEDAI as default provider |

#### JedaiChatProvider Implementation

```python
class JedaiChatProvider(LLMInterface):
    """JEDAI LLM provider for production use."""
    
    async def chat(self, request: ChatRequest) -> ChatResponse:
        # Non-streaming completion via httpx AsyncClient
        
    async def chat_stream(self, request, tool_executor) -> AsyncIterator[StreamChunk]:
        # TODO: Real SSE streaming
        # Currently falls back to non-streaming with simulated chunks
```

### Phase 4: Frontend Integration (PENDING)

| Step | Task |
|------|------|
| 12 | Add model selector dropdown to frontend |
| 13 | Add `/api/models` endpoint to list available models |
| 14 | Update frontend API calls with model parameter |

### Phase 5: Testing and Validation (PENDING)

| Step | Task |
|------|------|
| 15 | Unit tests for JedaiClient |
| 16 | Integration tests for full pipeline with JEDAI |
| 17 | End-to-end test with real checker generation |

---

## 4. Files Modified

### Backend (Completed)

| File | Status | Description |
|------|--------|-------------|
| `Agents/CodeGen/llm_client.py` | ✅ Modified | Added JedaiClient, LLMMode.JEDAI |
| `Agents/CodeGen/__init__.py` | ✅ Modified | Exported JedaiClient |
| `Agents/Orchestrator/orchestrator.py` | ✅ Modified | JEDAI config in PipelineConfig |
| `Agents/Dashboard/server.py` | ✅ Modified | JEDAI mode in API |
| `Agents/Dashboard/copilot/jedai_llm.py` | ✅ Created | Async JEDAI provider |
| `Agents/Dashboard/copilot/__init__.py` | ✅ Modified | Provider registration |
| `JEDAI/model_config.py` | ✅ Updated | Added claude-opus-4-5 |

### Frontend (Pending)

| File | Status | Description |
|------|--------|-------------|
| `Agents/Dashboard/frontend/` | ⏳ Pending | Model selector UI |

---

## 5. Authentication Flow

```
┌─────────────────┐
│  Environment    │
│  JEDAI_TOKEN?   │
└────────┬────────┘
         │
    ┌────▼────┐     ┌──────────────┐
    │   No    │────►│ Check cached │
    └─────────┘     │ ~/.jedai_token│
                    └───────┬──────┘
         │                  │
    ┌────▼────┐     ┌──────▼──────┐
    │   Yes   │     │   Valid?     │
    └────┬────┘     └──────┬──────┘
         │                 │
         │          ┌──────▼──────┐
         │          │  No: Login  │
         │          │  via LDAP   │
         │          └──────┬──────┘
         │                 │
    ┌────▼─────────────────▼────┐
    │     Use Token for API     │
    └───────────────────────────┘
```

---

## 6. Model Aliases

```python
MODEL_ALIASES = {
    "claude": "claude-opus-4-5",
    "opus": "claude-opus-4-5",
    "opus-4.5": "claude-opus-4-5",
    "sonnet": "claude-sonnet-4",
    "gpt": "gpt-5",
    "gpt5": "gpt-5",
    "gemini": "gemini-2.5-pro",
    # ... more aliases
}
```

---

## 7. Usage Examples

### Pipeline with JEDAI (Default)

```python
from Agents.Orchestrator import OrchestratorAgent, PipelineConfig

config = PipelineConfig(
    item_id="IMP-10-0-0-00",
    work_dir=Path("./work"),
    # llm_mode defaults to JEDAI
    # jedai_model defaults to "claude-opus-4-5"
)
agent = OrchestratorAgent(config)
result = agent.run()
```

### Fallback to Mock

```python
config = PipelineConfig(
    item_id="IMP-10-0-0-00",
    work_dir=Path("./work"),
    llm_mode=LLMMode.MOCK,
    mocks_dir=Path("./mocks")
)
```

### Direct LLM Client Usage

```python
from Agents.CodeGen import create_client, LLMMode

client = create_client(LLMMode.JEDAI, jedai_model="claude-opus-4-5")
response = client.generate(
    system_prompt="You are an EDA expert.",
    user_prompt="Explain timing constraints."
)
```

---

## 8. Next Steps

1. **User Review**: Verify backend implementation
2. **Frontend Development**: Add model selector UI
3. **Testing**: Run end-to-end with real JEDAI calls
4. **Documentation**: Update README files
