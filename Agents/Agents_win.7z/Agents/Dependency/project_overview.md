# Checker Agent 项目详细总结

> **版本**: v2.0 | **日期**: 2026-02-06 | **状态**: 后端开发完成，可启动前端

---

## 1. 项目概述

Checker Agent 系统是一个基于 LLM 的自动化代码生成与验证框架，用于生成 EDA 工具的检查脚本。

### 1.1 核心能力

| 能力 | 描述 |
|------|------|
| **代码生成** | 根据 Spec 自动生成 Python 检查脚本 |
| **智能验证** | LLM 驱动的测试用例生成与评审 |
| **流水线编排** | 多 Agent 协作的完整 Pipeline |
| **Dashboard API** | FastAPI + WebSocket 实时状态推送 |

### 1.2 系统架构

```
┌─────────────────────────────────────────────────────────────────┐
│                    Dashboard (FastAPI + WebSocket)               │
│                   /api/pipeline/* + /ws/pipeline                 │
└────────────────────────────────┬────────────────────────────────┘
                                 │
┌────────────────────────────────▼────────────────────────────────┐
│                      OrchestratorAgent                           │
│                   (on_status callback 支持)                       │
└────────────────────────────────┬────────────────────────────────┘
                                 │
         ┌───────────────────────┼───────────────────────┐
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│  Context Agent  │───▶│  CodeGen Agent  │───▶│   AuditorAgent  │
│   (暂时占空)     │    │ (on_phase 支持)  │    │ (on_step 支持)  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

---

## 2. 目录结构

```
Agents/
├── Dashboard/              # Dashboard 后端 (NEW)
│   ├── __init__.py
│   ├── __main__.py         # python -m Dashboard 入口
│   ├── server.py           # FastAPI + WebSocket + PipelineService
│   └── test_callback_chain.py
│
├── Orchestrator/           # 系统协调器
│   └── orchestrator.py     # PipelineConfig, OrchestratorAgent
│
├── CodeGen/                # 代码生成 Agent (13 文件)
│   ├── orchestrator.py     # 8步流程控制
│   ├── llm_client.py       # LLM 抽象层 (Mock/Real/Interactive)
│   ├── prompts.py          # System/User Prompt 模板
│   ├── code_extractor.py   # LLM 响应代码提取
│   ├── assembler.py        # 三文件组装 (Runner/Logic/Config)
│   ├── sanity_runner.py    # 分阶段 Sanity 验证
│   ├── stage_validator.py  # 阶段验证器
│   ├── spec_converter.py   # FormatSpec → imp_config.py
│   ├── workflow_state.py   # 状态机
│   └── config.py           # 配置管理
│
├── Validation/             # 验证 Agent (8 文件)
│   ├── auditor.py          # AuditorAgent 主类 (4阶段 LLM 驱动)
│   ├── schemas.py          # AnalysisResult, TestCase, ReviewResult
│   ├── auditor_prompts.py  # 3阶段 Prompt 模板
│   ├── executor.py         # 测试执行器
│   ├── reviewer.py         # 评审循环
│   ├── validator.py        # 程序化验证器
│   └── validators/         # 原子单元验证器
│
├── Framework/              # Checker 框架层 (8 文件)
│   ├── unified_checker.py  # 统一 Checker (支持 Type 1-4)
│   ├── check_module.py     # CheckModule 接口
│   ├── waiver_module.py    # WaiverModule 接口
│   ├── output_builder.py   # OutputBuilder 报告生成
│   └── interfaces.py       # 核心接口定义
│
├── Context/                # 语义理解 Agent (暂空)
│   └── (placeholder)
│
├── Dependency/             # 依赖和设计文档
│   └── checker_architecture_refactoring.md
│
└── Work/                   # 工作目录 (测试数据)
    └── CodeGen_E2E_Test/   # E2E 测试用例
```

---

## 3. 核心组件详解

### 3.1 OrchestratorAgent

**位置**: `Orchestrator/orchestrator.py`

**职责**: 协调完整流水线，管理子 Agent 生命周期

**关键特性**:
- `on_status` callback 支持实时状态推送
- `cancel_token` 支持用户取消
- `stage_timestamps` 记录阶段耗时
- 自动传递 callback 到子 Agent

**接口**:
```python
OrchestratorAgent(
    config: PipelineConfig,
    on_status: Optional[Callable[[str, str, str], None]] = None,
    cancel_token: Optional[threading.Event] = None
)
```

---

### 3.2 CodeGen Agent

**位置**: `CodeGen/orchestrator.py`

**职责**: 根据 Spec 生成三个原子单元代码

**8步流程**:
1. 加载 item.yaml
2. 解析 input_files
3. LLM 生成 `_parse_input_files`
4. Parsing Sanity 验证
5. LLM 生成 `_judge_item` + `_build_vio_name`
6. Check Sanity 验证
7. 组装完整代码
8. 最终验证

**产物**:
- `imp_logic.py`: 三个原子单元函数
- `imp_config.py`: Type 配置
- `universal_runner.py`: 可执行 Checker

---

### 3.3 AuditorAgent

**位置**: `Validation/auditor.py`

**职责**: LLM 驱动的代码验证和反馈生成

**4阶段流程**:
| 阶段 | 类型 | 功能 |
|------|------|------|
| Phase 1 | LLM | 分析 Spec + Code |
| Phase 2 | LLM | 智能生成测试用例 |
| Phase 3 | 程序 | 执行测试 |
| Phase 4 | LLM | 评审 + 生成反馈 |

**产物**:
- `AuditReport`: 包含分析、测试、评审结果
- `CodeGenFeedback`: 给 CodeGen 的改进建议

---

### 3.4 Dashboard Backend

**位置**: `Dashboard/server.py`

**职责**: 提供 API 和 WebSocket 实时事件流

**API 端点**:
| 方法 | 端点 | 功能 |
|------|------|------|
| POST | `/api/pipeline/start` | 启动 Pipeline |
| POST | `/api/pipeline/stop` | 停止 Pipeline |
| GET | `/api/pipeline/status` | 获取当前状态 |
| WS | `/ws/pipeline` | 实时事件流 |
| GET | `/api/files/list` | 列出文件 |
| GET | `/api/files/content` | 读取文件 |
| PUT | `/api/files/content` | 写入文件 |

**启动命令**:
```bash
cd Agents && python -m Dashboard --port 8080
```

---

## 4. 数据结构

### 4.1 配置类

```python
@dataclass
class PipelineConfig:
    item_id: str
    work_dir: Path
    llm_mode: LLMMode = LLMMode.MOCK
    api_key: Optional[str] = None
    mocks_dir: Optional[Path] = None
    max_codegen_retries: int = 3
    max_validation_retries: int = 1
```

### 4.2 结果类

```python
@dataclass
class PipelineResult:
    success: bool = False
    stage: PipelineStage = PipelineStage.INIT
    codegen_output: Optional[GenerationResult] = None
    validation_output: Optional[AuditReport] = None
    error_message: str = ""
    stage_timestamps: Dict[str, Dict[str, str]] = field(default_factory=dict)
```

---

## 5. 开发状态

| Phase | 描述 | 状态 |
|-------|------|------|
| Phase 1 | 基础设施准备 | ✅ 完成 |
| Phase 1.5 | 架构重构设计 | ✅ 完成 |
| Phase 2 | Context Agent | ⏸️ 暂缓 |
| Phase 2A | Framework Layer | ✅ 完成 |
| Phase 3 | CodeGen Agent | ✅ 完成 |
| Phase 4 | Validation Agent | ✅ 完成 |
| Phase 5 | 系统集成 | ✅ 完成 |
| Phase 6 | Dashboard Backend | ✅ 完成 |
| Phase 7 | Dashboard Frontend | ⏳ 待开始 |

---

## 6. 依赖清单

### Python 核心依赖
```
google-generativeai>=0.3.0   # Gemini LLM API
PyYAML>=6.0                  # YAML 解析
```

### Dashboard 依赖
```
fastapi>=0.108.0             # Web 框架
uvicorn>=0.25.0              # ASGI 服务器
websockets>=12.0             # WebSocket 支持
pydantic>=2.5.0              # 数据验证
```

---

## 7. 使用示例

### 7.1 完整 Pipeline

```python
from Orchestrator.orchestrator import OrchestratorAgent, PipelineConfig
from CodeGen.llm_client import LLMMode
from pathlib import Path

def on_status(stage, status, message):
    print(f"[{stage}] {status}: {message}")

config = PipelineConfig(
    item_id="IMP-10-0-0-00",
    work_dir=Path("./output"),
    llm_mode=LLMMode.MOCK,
    mocks_dir=Path("./mocks")
)

agent = OrchestratorAgent(config, on_status=on_status)
result = agent.run()

if result.success:
    print("Pipeline passed!")
else:
    print(f"Failed at: {result.stage}")
```

### 7.2 启动 Dashboard

```bash
# 启动后端服务器
cd Agents && python -m Dashboard --port 8080

# 测试 API
curl http://localhost:8080/api/pipeline/status
```

---

## 8. 文件清单

| 文件 | 行数 | 功能 |
|------|------|------|
| `Orchestrator/orchestrator.py` | 460 | 流水线协调 |
| `CodeGen/orchestrator.py` | 630 | 8步代码生成 |
| `CodeGen/assembler.py` | 700 | 代码组装 |
| `Validation/auditor.py` | 437 | 4阶段审计 |
| `Framework/unified_checker.py` | 600 | 统一 Checker |
| `Dashboard/server.py` | 385 | FastAPI 服务器 |

---

## 9. 许可证

Internal Use Only - AAI Team
