# Checker 架构重构设计文档

> **版本**: v1.0 | **日期**: 2026-02-04 | **状态**: 设计中

---

## 一、核心设计理念

### 1.1 关注点分离 (Separation of Concerns)

将 Checker 分为三个层次，明确各层职责：

```
┌─────────────────────────────────────────────────────────────────────┐
│     Layer 1: Checker 顶层 (完全固化 - 不需要 LLM)                    │
├─────────────────────────────────────────────────────────────────────┤
│ • 输入提取: 从 item.yaml 提取 ID/description/req/waiver             │
│ • 类型分发: 根据 req.value + waiver.value 调用 Type 模块             │
│ • 输出控制: 标准化格式输出                                           │
└────────────────────────────────┬────────────────────────────────────┘
                                 │
┌────────────────────────────────▼────────────────────────────────────┐
│     Layer 2: Type 模块 (完全固化 - 不需要 LLM)                       │
├─────────────────────────────────────────────────────────────────────┤
│ Type 1: check_logic(parsed) → found/missing                         │
│ Type 2: check_logic(parsed) → found/missing/extra                   │
│ Type 3: check_logic + waiver_logic → +waived/unused                 │
│ Type 4: check_logic + waiver_logic → +waived/unused                 │
└────────────────────────────────┬────────────────────────────────────┘
                                 │
┌────────────────────────────────▼────────────────────────────────────┐
│     Layer 3: 原子单元 (LLM CodeGen 生成 - 每个 checker 不同)         │
├─────────────────────────────────────────────────────────────────────┤
│ • _parse_input_files: 从输入文件提取结构化数据 (items 列表)          │
│ • _judge_item: 判断单个 item 的 PASS/FAIL 条件                       │
│ • _build_vio_name: 构造用于 pattern/waiver 匹配的字符串              │
└─────────────────────────────────────────────────────────────────────┘
```

### 1.2 关键洞察

| 洞察 | 说明 |
|------|------|
| **waiver.value=0 可框架固化** | 逻辑简单：FAIL→INFO, 强制 PASS, 添加 `[WAIVED_AS_INFO]` |
| **waiver.value>0 需要灵活性** | 默认使用通配符/正则匹配，复杂场景 LLM 生成自定义 matcher |
| **LLM 不需要知道 Type** | LLM 只生成功能原子单元，框架负责组装 |
| **原子单元可独立测试** | 每个函数有明确的输入输出规范 |

---

## 二、Type 级别字段规范

### 2.1 Type 返回字段

| Type | 字段 | 说明 |
|------|------|------|
| **Type 1** | `status`, `found_items`, `missing_items` | Boolean check |
| **Type 2** | Type 1 + `extra_items` | Pattern search |
| **Type 3** | Type 2 + `waived`, `unused_waivers` | Pattern + Waiver |
| **Type 4** | Type 1 + `waived`, `unused_waivers` | Boolean + Waiver |

### 2.2 字段详细定义

```python
# 所有 item 字段必须包含的元数据
ItemMetadata = {
    'name': str,           # item 唯一标识/显示名称
    'line_number': int,    # 源文件行号 (用于 report)
    'file_path': str,      # 源文件路径 (用于 report)
    # 以下为可选字段
    'line_content': str,   # 原始行内容 (调试用)
    'raw_data': Dict,      # 原始解析数据 (扩展用)
}

# Type 1/2/3/4 通用字段
found_items: Dict[str, ItemMetadata]     # 通过检查的 items
missing_items: Dict[str, ItemMetadata]   # 未通过检查的 items (unwaived)

# Type 2/3 额外字段
extra_items: Dict[str, ItemMetadata]     # 不在 pattern_items 中的 items

# Type 3/4 额外字段
waived: Dict[str, ItemMetadata]          # 被 waiver 匹配的 items
unused_waivers: Dict[str, ItemMetadata]  # 未使用的 waiver entries
```

---

## 三、原子单元接口定义 (双阶段架构 v4)

### 3.1 核心理念：三个独立函数

根据双阶段架构，LLM CodeGen Agent 生成**三个独立的代码片段**：

| 函数 | 职责 | 接口 |
|------|------|------|
| `_parse_input_files` | 从输入文件提取结构化数据 | `(input_files) → List[Dict]` |
| `_judge_item` | 判断单个 item 是否满足检查条件 | `(item) → bool` |
| `_build_vio_name` | 构造用于 pattern/waiver 匹配的字符串 | `(item) → str` |

**关键设计**：
- 这三个函数由**同一个 LLM prompt** 一次性生成
- LLM 定义 item 的字段结构，自己知道如何使用
- 框架不关心 item 的具体字段，只调用这三个函数

### 3.2 `_parse_input_files` - 数据提取

```python
def _parse_input_files(self, input_files: List[Path]) -> List[Dict]:
    """
    从输入文件提取结构化数据
    
    返回:
        items 列表，每个 item 必须包含:
        - line_number: int (用于报告)
        - file_path: str (用于报告)
        - 其他字段由 LLM 自定义 (供 _judge_item 和 _build_vio_name 使用)
    """
    items = []
    for file_path in input_files:
        lines = open(file_path).readlines()
        # ... 解析逻辑 (LLM 生成) ...
        items.append({
            # 框架要求的字段
            'line_number': ...,
            'file_path': str(file_path),
            # LLM 自定义字段
            'view': ...,
            'path_group': ...,
            'wns': ...,
            'violation_count': ...,
        })
    return items
```

### 3.3 `_judge_item` - 检查判断

```python
def _judge_item(self, item: Dict) -> bool:
    """
    判断单个 item 是否满足检查条件
    
    返回:
        True = PASS, False = FAIL
    """
    # LLM 根据 ItemSpec 的要求生成判断逻辑
    return item['wns'] >= 0 or item['violation_count'] == 0
```

### 3.4 `_build_vio_name` - 匹配字符串构造

```python
def _build_vio_name(self, item: Dict) -> str:
    """
    构造用于 pattern/waiver 匹配的字符串
    
    注意: 格式由语义理解 Agent 在 format_spec.md 中定义，
          CodeGen Agent 根据 format_spec.md 生成此函数
    """
    # LLM 根据 format_spec.md 的模板生成
    return f"View '{item['view']}' path_group '{item['path_group']}' {item['timing_type']}"
```

### 3.5 完整示例 (IMP-10-0-0-11)

```python
# === 代码片段 1: _parse_input_files ===

def _parse_input_files(self, input_files):
    """从 check_signoff.results 提取 timing 数据"""
    items = []
    for file_path in input_files:
        lines = open(file_path).readlines()
        
        # 解析表头 (参考 parsing_spec.md L42)
        header_line = lines[41]
        views = re.findall(r'(\w+)\(\)', header_line)
        
        # 解析子表头 (参考 parsing_spec.md L46)
        subheader = lines[45]
        timing_types = re.findall(r'(setup|hold)', subheader)
        
        # 解析数据行 (参考 parsing_spec.md L47-L78)
        for i, line in enumerate(lines[46:78]):
            path_group = line.split(',')[0].strip()
            cells = line.split(',')[1:]
            
            for j, cell in enumerate(cells):
                match = re.match(r'(-?\d+\.\d+)\((\d+)\)', cell)
                if match:
                    items.append({
                        'view': views[j // 2],
                        'path_group': path_group,
                        'timing_type': timing_types[j % 2],
                        'wns': float(match.group(1)),
                        'violation_count': int(match.group(2)),
                        'line_number': 47 + i,
                        'file_path': str(file_path)
                    })
    return items


# === 代码片段 2: _judge_item ===

def _judge_item(self, item):
    """判断 timing path 是否 clean"""
    return item['wns'] >= 0 or item['violation_count'] == 0


# === 代码片段 3: _build_vio_name ===

def _build_vio_name(self, item):
    """构造用于 waiver 匹配的字符串 (参考 format_spec.md)"""
    return f"View '{item['view']}' path_group '{item['path_group']}' {item['timing_type']}"
```

### 3.6 接口约束

```python
class CheckerInterface(ABC):
    """LLM 必须实现的接口"""
    
    @abstractmethod
    def _parse_input_files(self, input_files: List[Path]) -> List[Dict]:
        """
        返回 items 列表。
        每个 item 必须包含 line_number 和 file_path。
        其他字段由 LLM 自定义。
        """
        pass
    
    @abstractmethod
    def _judge_item(self, item: Dict) -> bool:
        """判断单个 item 是否满足条件"""
        pass
    
    @abstractmethod
    def _build_vio_name(self, item: Dict) -> str:
        """构造用于匹配的字符串"""
        pass
```

### 3.7 FormatSpec 的角色 (重要澄清)

| 阶段 | FormatSpec 的作用 |
|------|-------------------|
| A.2 语义理解 | 生成 `format_spec.md`，定义匹配模板和推荐 items |
| B.1 CodeGen | **读取** `format_spec.md`，据此生成 `_build_vio_name` 函数 |
| 运行时 | **不存在** FormatSpec，只有 `_build_vio_name` 函数 |

**关键**：FormatSpec 是**开发时契约**，不是运行时配置。

---

## 四、Type 模块实现 (双阶段架构 v4 - 调用 LLM 函数)

### 4.1 两个正交维度

```
                        检查方式
                 Boolean    |    Pattern
              ──────────────────────────────
       无     │  Type 1    |    Type 2   │
  Waiver     ──────────────────────────────
       有     │  Type 4    |    Type 3   │
              ──────────────────────────────
```

### 4.2 框架调用 LLM 函数的方式

```python
# ═══════════════════════════════════════════════════════════════════
# 功能模块 1: CheckModule - 调用 _judge_item 和 _build_vio_name
# ═══════════════════════════════════════════════════════════════════

class CheckModule:
    """处理检查逻辑 (Boolean / Pattern)"""
    
    @staticmethod
    def boolean_check(
        parsed_items: List[Dict],
        judge_func: Callable,       # 开发时由 LLM 生成，运行时由框架调用
        vio_name_func: Callable     # 开发时由 LLM 生成，运行时由框架调用
    ) -> CheckResult:
        """
        Boolean 检查: 根据 judge_func 判断 PASS/FAIL
        用于: Type 1, Type 4
        """
        found = {}
        missing = {}
        
        for item in parsed_items:
            vio_name = vio_name_func(item)  # 使用 LLM 生成的函数
            if judge_func(item):            # 使用 LLM 生成的函数
                found[vio_name] = item
            else:
                missing[vio_name] = item
        
        return CheckResult(found=found, missing=missing)
    
    @staticmethod
    def pattern_check(
        parsed_items: List[Dict],
        pattern_items: List[str],
        judge_func: Callable,
        vio_name_func: Callable,
        match_func: Callable = default_substring_match  # 框架默认匹配
    ) -> CheckResult:
        """
        Pattern 检查: 匹配 pattern_items
        用于: Type 2, Type 3
        """
        found = {}
        missing_patterns = []
        extra = {}
        matched_names = set()
        
        for pattern in pattern_items:
            matched = False
            for item in parsed_items:
                vio_name = vio_name_func(item)
                if judge_func(item) and match_func(vio_name, pattern):
                    found[vio_name] = item
                    matched_names.add(vio_name)
                    matched = True
                    break
            if not matched:
                missing_patterns.append(pattern)
        
        for item in parsed_items:
            vio_name = vio_name_func(item)
            if vio_name not in matched_names:
                extra[vio_name] = item
        
        missing = {p: {'name': p} for p in missing_patterns}
        
        return CheckResult(found=found, missing=missing, extra=extra)


# ═══════════════════════════════════════════════════════════════════
# 功能模块 2: WaiverModule - 调用 _build_vio_name
# ═══════════════════════════════════════════════════════════════════

class WaiverModule:
    """处理 Waiver 逻辑"""
    
    @staticmethod
    def apply_waivers(
        violation_items: Dict[str, Dict],
        waiver_value: Any,
        waive_items: List[str],
        parsed_items: List[Dict],
        vio_name_func: Callable,     # 开发时由 LLM 生成，运行时由框架调用
        match_func: Callable = default_waiver_match  # 框架默认匹配
    ) -> WaiverResult:
        """
        应用 Waiver 逻辑
        用于: Type 3, Type 4
        """
        # waiver.value = 0: 全部 waive
        if waiver_value == 0 or waiver_value == '0':
            return WaiverResult(
                unwaived={},
                waived=violation_items,
                unused={}
            )
        
        # waiver.value > 0: 逐个匹配
        waive_dict = parse_waive_items(waive_items)
        waived = {}
        unwaived = {}
        used_patterns = set()
        
        for vio_name, item_meta in violation_items.items():
            matched_pattern = None
            for pattern in waive_dict:
                if match_func(vio_name, pattern):  # 使用 vio_name 匹配
                    matched_pattern = pattern
                    used_patterns.add(pattern)
                    break
            
            if matched_pattern:
                waived[vio_name] = item_meta
            else:
                unwaived[vio_name] = item_meta
        
        unused = {p: {} for p in waive_dict if p not in used_patterns}
        
        return WaiverResult(unwaived=unwaived, waived=waived, unused=unused)


# ═══════════════════════════════════════════════════════════════════
# 框架默认匹配函数 (可被 LLM 覆盖)
# ═══════════════════════════════════════════════════════════════════

def default_substring_match(vio_name: str, pattern: str) -> bool:
    """默认子串匹配"""
    return pattern in vio_name or vio_name in pattern

def default_waiver_match(vio_name: str, pattern: str) -> bool:
    """默认 waiver 匹配 (支持 * 通配符)"""
    if '*' in pattern or '?' in pattern:
        return fnmatch.fnmatch(vio_name, pattern)
    return pattern in vio_name or vio_name in pattern
```

### 4.3 UnifiedChecker - 组装 LLM 代码片段

```python
class UnifiedChecker(BaseChecker):
    """
    统一的 Checker 实现
    
    LLM 必须提供三个函数:
    - _parse_input_files(input_files) -> List[Dict]
    - _judge_item(item) -> bool
    - _build_vio_name(item) -> str
    """
    
    def execute_check(self) -> CheckResult:
        # 1. 验证输入文件
        valid_files, missing_files = self.validate_input_files()
        if missing_files:
            raise ConfigurationError(self.create_missing_files_error(missing_files))
        
        # 2. 调用 LLM 生成的 _parse_input_files
        parsed_items = self._parse_input_files(valid_files)
        
        # 3. 确定 Type 并执行检查
        requirements = self.get_requirements()
        waivers = self.get_waivers()
        
        has_pattern = requirements.get('value', 'N/A') != 'N/A'
        pattern_items = requirements.get('pattern_items', [])
        waiver_value = waivers.get('value', 'N/A')
        has_waiver = waiver_value != 'N/A'
        
        # 4. 执行检查 (使用 LLM 的 _judge_item 和 _build_vio_name)
        if has_pattern:
            check_result = CheckModule.pattern_check(
                parsed_items, pattern_items,
                self._judge_item, self._build_vio_name
            )
        else:
            check_result = CheckModule.boolean_check(
                parsed_items,
                self._judge_item, self._build_vio_name
            )
        
        # 5. 应用 Waiver (如果需要)
        if not has_waiver:
            return self.build_output(FinalResult(
                found=check_result.found,
                missing=check_result.missing,
                extra=check_result.extra if has_pattern else None,
                waived=None, unused=None
            ))
        
        waive_items = waivers.get('waive_items', [])
        target = check_result.extra if has_pattern else check_result.missing
        
        waiver_result = WaiverModule.apply_waivers(
            target, waiver_value, waive_items, parsed_items,
            self._build_vio_name
        )
        
        if has_pattern:
            return self.build_output(FinalResult(
                found=check_result.found,
                missing=check_result.missing,
                extra=waiver_result.unwaived,
                waived=waiver_result.waived,
                unused=waiver_result.unused
            ))
        else:
            return self.build_output(FinalResult(
                found=check_result.found,
                missing=waiver_result.unwaived,
                extra=None,
                waived=waiver_result.waived,
                unused=waiver_result.unused
            ))
```

### 4.4 模块复用关系图

```
┌─────────────────────────────────────────────────────────────────────┐
│                         UnifiedChecker                              │
│        提供 LLM 生成的: _parse_input_files                          │
│                        _judge_item                                  │
│                        _build_vio_name                              │
└────────────────────────────────┬────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│                     框架模块 (固化代码)                              │
├───────────────────────────┬─────────────────────────────────────────┤
│      CheckModule          │         WaiverModule                    │
│  ┌─────────────────────┐  │  ┌────────────────────────────────────┐ │
│  │ boolean_check()     │  │  │ apply_waivers()                    │ │
│  │ 调用: _judge_item   │  │  │ 使用: _build_vio_name 的输出      │ │
│  │      _build_vio_name│  │  │ 匹配: 框架默认 or LLM 自定义      │ │
│  └─────────────────────┘  │  └────────────────────────────────────┘ │
│  ┌─────────────────────┐  │                                         │
│  │ pattern_check()     │  │                                         │
│  │ 调用: _judge_item   │  │                                         │
│  │      _build_vio_name│  │                                         │
│  └─────────────────────┘  │                                         │
└───────────────────────────┴─────────────────────────────────────────┘

Type 组合:
- Type 1 = boolean_check(_judge_item, _build_vio_name)
- Type 2 = pattern_check(_judge_item, _build_vio_name)
- Type 3 = pattern_check() + apply_waivers(extra)
- Type 4 = boolean_check() + apply_waivers(missing)
```

### 4.5 SCENARIO_CONFIG - 场景配置 (v4.1 新增)

**背景**: Format Spec 在 CodeGen 之前生成，包含四种场景的 descriptions/reasons 配置。

```python
class UnifiedChecker(BaseChecker):
    # 场景配置 (由 CodeGen 从 Format Spec 提取)
    SCENARIO_CONFIG = {
        'scenario_1': {  # req=N/A, waiver=N/A
            'found_desc': "...",
            'missing_desc': "...",
            'found_reason': "...",
            'missing_reason': "...",
        },
        'scenario_2': {  # req=N/A, waiver>0
            'found_desc': "...",
            'missing_desc': "...",
            'waived_desc': "...",
            'unused_desc': "...",
            'found_reason': "...",
            'missing_reason': "...",
            'waived_reason': "...",
            'unused_reason': "...",
        },
        'scenario_3': {  # req>0, waiver=N/A
            # Pattern check semantics
            'found_desc': "...",
            'found_reason': "...",
        },
        'scenario_4': {  # req>0, waiver>0
            # Pattern + waiver semantics
            ...
        },
    }
    
    def _detect_scenario(self, has_pattern: bool, has_waiver: bool) -> int:
        """根据 req/waiver 配置返回场景号 1-4"""
        if not has_pattern and not has_waiver:
            return 1
        elif not has_pattern and has_waiver:
            return 2
        elif has_pattern and not has_waiver:
            return 3
        else:
            return 4
    
    def _get_scenario_descriptions(self, scenario: int) -> dict:
        """根据场景号获取 descriptions/reasons 配置"""
        return self.SCENARIO_CONFIG.get(f'scenario_{scenario}', {})
```

**关键设计**:
- SCENARIO_CONFIG 由 CodeGen Agent 从 Format Spec 提取
- 框架根据运行时 req/waiver 配置自动选择场景
- LLM 不需要关心场景选择逻辑

### 4.6 缓存机制 (v4.1 新增)

```python
class UnifiedChecker(BaseChecker):
    def execute_check(self):
        # ... 执行检查逻辑 ...
        
        # 缓存结果 (与 BaseChecker._result_cache 兼容)
        BaseChecker._result_cache[self.item_id] = check_result_output
        
        return check_result_output
```

**设计要点**:
- 使用 `BaseChecker._result_cache` 类变量存储结果
- 与现有 YAML 生成器兼容
- 支持后续 ResultCacheManager 扩展

### 4.7 统一匹配逻辑 (v4.1 新增)

**核心洞察**: Requirement pattern 和 Waiver pattern 使用相同格式，因此匹配逻辑可统一。

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        统一匹配函数                                       │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  def unified_match(vio_name: str, pattern: str) -> bool:                │
│      """通用匹配：支持通配符和子串匹配"""                                  │
│      if '*' in pattern or '?' in pattern:                               │
│          return fnmatch.fnmatch(vio_name, pattern)                      │
│      return pattern in vio_name or vio_name in pattern                  │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│  应用场景:                                                               │
│  - CheckModule.pattern_check() 中匹配 requirement.pattern_items         │
│  - WaiverModule.apply_waivers() 中匹配 waiver.waive_items               │
└─────────────────────────────────────────────────────────────────────────┘
```

**设计结论**:
- `default_pattern_match` 和 `default_waiver_match` 应合并为一个函数
- LLM 生成的 `_build_vio_name` 返回值同时用于 pattern 和 waiver 匹配
- Waiver pattern 格式必须与 Requirement pattern 格式兼容

```python
# 推荐: 合并为统一匹配函数
def unified_pattern_match(vio_name: str, pattern: str) -> bool:
    """Unified pattern matching for both requirement and waiver"""
    if '*' in pattern or '?' in pattern:
        return fnmatch.fnmatch(vio_name, pattern)
    return pattern in vio_name or vio_name in pattern

# 使用
CheckModule.pattern_check(..., match_func=unified_pattern_match)
WaiverModule.apply_waivers(..., match_func=unified_pattern_match)
```

---


## 五、双阶段架构设计 (v4)

### 5.1 核心理念：语义理解与代码开发分离

```
┌─────────────────────────────────────────────────────────────────────────┐
│                     A. 语义理解 Agent                                    │
│                 (langchain/CoT, 无代码生成)                              │
├─────────────────────────────────────────────────────────────────────────┤
│ A.1 Parsing Spec → 提取关键字段，保留源文件文本信息 (行号)               │
│ A.2 FormatSpec → 推理 requirement/waiver 格式契约                       │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │ md 产物
                                 ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                     B. 代码开发 Agent                                    │
│                 (CodeGen + Validation)                                  │
├─────────────────────────────────────────────────────────────────────────┤
│ B.1 CodeGen → 根据 md 写代码片段，sanity 验证，发布                      │
│ B.2 Validation → 开发测试 item.yaml，执行测试，评审报告                  │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 5.2 阶段 A：语义理解 Agent

### A.1 Parsing Spec 生成

**输入**: ItemSpec + input_file (example log)

**输出**: `parsing_spec.md`

```markdown
# Parsing Spec for IMP-10-0-0-11

## 1. 数据源
- 文件类型: check_signoff.results
- 解析区域: 表格区域

## 2. 源文本引用
> **L42-L45**: 表头行，包含 view 名称
> ```
> ,func_slow_max(),func_fast_min(),...
> ```
>
> **L46**: 子表头，包含 timing type
> ```
> ,setup,hold,setup,hold,...
> ```
>
> **L47-L78**: 数据行，包含 WNS 和 violation count
> ```
> reg2reg,-0.0234(15),0.0000(0),...
> ```

## 3. 提取字段

| 字段名 | 类型 | 来源位置 | 提取方法 |
|--------|------|----------|----------|
| view | str | L42 表头 | 正则 `(\w+)\(\)` |
| path_group | str | 数据行首列 | 直接读取 |
| timing_type | str | L46 子表头 | 匹配 `setup/hold` |
| wns | float | 单元格 | 正则 `(-?\d+\.\d+)\(` |
| violation_count | int | 单元格 | 正则 `\((\d+)\)` |

## 4. 判断条件
- **is_valid**: `wns >= 0 or violation_count == 0`
- **推理依据**: timing clean 意味着没有负 slack 或没有 violation
```

**关键设计**:
- 保留行号标注 (`L42-L45`)，方便脚本拼装
- 保留源文件文本片段，节省后续 token
- 结构化表格，便于 CodeGen 直接使用

---

### A.2 FormatSpec 生成

**输入**: `parsing_spec.md`

**输出**: `format_spec.md` (作为契约)

```markdown
# FormatSpec for IMP-10-0-0-11

## 1. Violation Name 格式

### 模板
```
View '{view}' path_group '{path_group}' {timing_type}
```

### 字段说明
| 字段 | 来源 | 示例值 |
|------|------|--------|
| view | parsing_spec.view | func_slow_max |
| path_group | parsing_spec.path_group | reg2reg |
| timing_type | parsing_spec.timing_type | setup |

### 示例输出
```
View 'func_slow_max' path_group 'reg2reg' setup
```

### 信心度
- **评分**: 0.85
- **依据**: 这三个字段组合唯一标识一条 timing path

## 2. 推荐的 requirement.pattern_items

```yaml
pattern_items:
  - "func_slow_max: reg2reg (setup)"
  - "func_fast_min: * (hold)"
```

## 3. 推荐的 waiver.waive_items 格式

### 精确匹配
```yaml
waive_items:
  - "View 'func_slow_max' path_group 'io2reg' setup"
```

### 通配匹配
```yaml
waive_items:
  - "View '*' path_group 'io2reg' *"
```
```

---

## 5.3 阶段 B：代码开发 Agent

### B.1 CodeGen Agent

#### B.1.a 代码片段生成

**输入**: `parsing_spec.md` + `format_spec.md`

**输出**: 代码片段 (非完整文件) + `sanity_item.yaml`

```python
# === 代码片段 1: _parse_input_files ===
# File: parsing_logic.py

def _parse_input_files(self, input_files):
    """
    从 check_signoff.results 提取 timing 数据
    参考: parsing_spec.md L42-L78
    """
    items = []
    for file_path in input_files:
        lines = open(file_path).readlines()
        
        # 解析表头 (L42)
        header_line = lines[41]  # 0-indexed
        views = re.findall(r'(\w+)\(\)', header_line)
        
        # 解析子表头 (L46)
        subheader = lines[45]
        timing_types = re.findall(r'(setup|hold)', subheader)
        
        # 解析数据行 (L47-L78)
        for i, line in enumerate(lines[46:78]):
            path_group = line.split(',')[0].strip()
            cells = line.split(',')[1:]
            
            for j, cell in enumerate(cells):
                match = re.match(r'(-?\d+\.\d+)\((\d+)\)', cell)
                if match:
                    wns = float(match.group(1))
                    count = int(match.group(2))
                    
                    items.append({
                        'view': views[j // 2],
                        'path_group': path_group,
                        'timing_type': timing_types[j % 2],
                        'wns': wns,
                        'violation_count': count,
                        'line_number': 47 + i,
                        'file_path': str(file_path)
                    })
    return items
```

```python
# === 代码片段 2: _judge_item ===
# File: check_logic.py

def _judge_item(self, item):
    """判断 timing path 是否 clean"""
    return item['wns'] >= 0 or item['violation_count'] == 0
```

```python
# === 代码片段 3: _build_vio_name ===
# File: waiver_logic.py

def _build_vio_name(self, item):
    """构造用于 waiver 匹配的字符串"""
    return f"View '{item['view']}' path_group '{item['path_group']}' {item['timing_type']}"
```

```yaml
# === sanity_item.yaml ===
id: IMP-10-0-0-11
description: "Confirm the timing of all path groups is clean"
requirement:
  value: "N/A"
waiver:
  value: "N/A"
```

#### B.1.b Sanity 验证 (分步执行)

```
┌─────────────────────────────────────────────────────────────────────────┐
│ Step 1: 解析 sanity_item.yaml                                           │
│         框架模板: parse_item_yaml.py                                    │
│         输出: item_config.json                                          │
├─────────────────────────────────────────────────────────────────────────┤
│ Step 2: 执行 parsing_logic.py                                           │
│         框架模板: run_parsing_only.py                                   │
│         输入: input_file + parsing_logic.py                             │
│         输出: parsing_result.json                                       │
├─────────────────────────────────────────────────────────────────────────┤
│ Step 3: 执行 check_logic.py                                             │
│         框架模板: run_check_only.py                                     │
│         输入: parsing_result.json + check_logic.py + requirement        │
│         输出: check_result.json                                         │
├─────────────────────────────────────────────────────────────────────────┤
│ Step 4: 框架预编译                                                       │
│         合并代码片段 → 完整 checker.py                                  │
│         语法检查 → 避免代码格式问题                                      │
└─────────────────────────────────────────────────────────────────────────┘
```

#### B.1.c 评估循环

```
┌─────────────────────────────────────────────────────────────────────────┐
│ CodeGen 审查 sanity 结果                                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│ ┌─────────────┐                                                         │
│ │ 审查通过？   │──YES──→ 发布: 完整代码 + sanity_item.yaml              │
│ └──────┬──────┘                                                         │
│        │ NO                                                             │
│        ▼                                                                │
│ ┌─────────────┐                                                         │
│ │ 重试次数<3？ │──YES──→ 重新执行 B.1.a + B.1.b                          │
│ └──────┬──────┘                                                         │
│        │ NO                                                             │
│        ▼                                                                │
│    报错终止，请求人工介入                                                │
└─────────────────────────────────────────────────────────────────────────┘
```

---

### B.2 Validation Agent

#### B.2.a 测试用例生成

**输入**: `format_spec.md` + `sanity_item.yaml` + CodeGen 发布的代码

**输出**: 各场景 `item.yaml`

```yaml
# test_type1_na.yaml
id: IMP-10-0-0-11
requirement:
  value: "N/A"
waiver:
  value: "N/A"

---
# test_type4_waiver.yaml
id: IMP-10-0-0-11
requirement:
  value: "N/A"
waiver:
  value: 2
  waive_items:
    - "View 'func_slow_max' path_group 'io2reg' setup"
    - "View '*' path_group 'async' *"
```

#### B.2.b 执行测试

```
for each test_item.yaml:
    1. 复制 test_item.yaml → inputs/items/
    2. 运行 checker.py
    3. 保存 logs/ 和 reports/ 输出
    4. 记录 PASS/FAIL 状态
```

#### B.2.c 评审循环

```
┌─────────────────────────────────────────────────────────────────────────┐
│ Validation Agent 对比 itemspec + formatspec + 测试结果                  │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│ ┌─────────────┐                                                         │
│ │ 审核通过？   │──YES──→ 生成 validation_report.md                       │
│ └──────┬──────┘                                                         │
│        │ NO                                                             │
│        ▼                                                                │
│ ┌─────────────────────────────────────────────────────────────────────┐ │
│ │ 给出原因，回退到 B.1 重新开发                                        │ │
│ │ 然后再次执行 B.2                                                     │ │
│ └──────────────────────────────┬──────────────────────────────────────┘ │
│                                │                                        │
│                                ▼                                        │
│ ┌─────────────┐                                                         │
│ │ 再次通过？   │──YES──→ 生成 validation_report.md                       │
│ └──────┬──────┘                                                         │
│        │ NO                                                             │
│        ▼                                                                │
│    报错终止，请求人工介入                                                │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 六、完整开发流程图

```
                    ┌─────────────────────┐
                    │      ItemSpec       │
                    │   (description +    │
                    │    input_file)      │
                    └──────────┬──────────┘
                               │
        ═══════════════════════╪═══════════════════════════
                    A. 语义理解 Agent
        ═══════════════════════╪═══════════════════════════
                               │
                    ┌──────────▼──────────┐
                    │    A.1 Parsing Spec │
                    │    生成 (CoT)       │
                    └──────────┬──────────┘
                               │
                    ┌──────────▼──────────┐
                    │    parsing_spec.md  │
                    │  (字段 + 行号引用)   │
                    └──────────┬──────────┘
                               │
                    ┌──────────▼──────────┐
                    │    A.2 FormatSpec   │
                    │    生成 (CoT)       │
                    └──────────┬──────────┘
                               │
                    ┌──────────▼──────────┐
                    │    format_spec.md   │
                    │   (契约 + 推荐)     │
                    └──────────┬──────────┘
                               │
        ═══════════════════════╪═══════════════════════════
                    B. 代码开发 Agent
        ═══════════════════════╪═══════════════════════════
                               │
          ┌────────────────────┼───────────────────────┐
          │                    │                       │
          ▼                    ▼                       │
┌───────────────────┐ ┌───────────────────┐           │
│ B.1.a 代码片段生成 │ │ sanity_item.yaml │           │
│ - parsing_logic   │ └─────────┬─────────┘           │
│ - check_logic     │           │                     │
│ - waiver_logic    │           │                     │
└─────────┬─────────┘           │                     │
          │                     │                     │
          └──────────┬──────────┘                     │
                     │                                │
          ┌──────────▼──────────┐                     │
          │  B.1.b Sanity 验证  │                     │
          │  (分步执行 + 预编译) │                     │
          └──────────┬──────────┘                     │
                     │                                │
          ┌──────────▼──────────┐                     │
          │  B.1.c 评估循环     │◄────────────────────┤
          │  (最多3轮)          │                     │
          └──────────┬──────────┘                     │
                     │ 通过                           │
          ┌──────────▼──────────┐                     │
          │  发布: checker.py   │                     │
          │  + sanity_item.yaml │                     │
          └──────────┬──────────┘                     │
                     │                                │
          ┌──────────▼──────────┐                     │
          │ B.2.a 测试用例生成  │                     │
          │ (Type 1/2/3/4)      │                     │
          └──────────┬──────────┘                     │
                     │                                │
          ┌──────────▼──────────┐                     │
          │ B.2.b 执行测试      │                     │
          └──────────┬──────────┘                     │
                     │                                │
          ┌──────────▼──────────┐                     │
          │ B.2.c 评审循环      │─────失败────────────┘
          │ (最多1轮回退B.1)    │
          └──────────┬──────────┘
                     │ 通过
          ┌──────────▼──────────┐
          │ validation_report   │
          │        .md          │
          └─────────────────────┘
```

---

## 6.1 框架模板支持

### run_parsing_only.py

```python
"""框架模板: 单独执行 parsing_logic"""

import sys
import json
from pathlib import Path

def run_parsing_only(parsing_logic_module, input_files, output_file):
    """
    Args:
        parsing_logic_module: 包含 _parse_input_files 函数的模块
        input_files: 输入文件列表
        output_file: 输出 JSON 路径
    """
    # 动态加载 LLM 生成的代码片段
    from importlib import import_module
    mod = import_module(parsing_logic_module)
    
    # 创建临时 checker 实例
    class TempChecker:
        pass
    checker = TempChecker()
    checker._parse_input_files = mod._parse_input_files.__get__(checker)
    
    # 执行 parsing
    items = checker._parse_input_files(input_files)
    
    # 保存结果
    with open(output_file, 'w') as f:
        json.dump({'items': items, 'count': len(items)}, f, indent=2)
    
    return items

if __name__ == '__main__':
    run_parsing_only(
        parsing_logic_module=sys.argv[1],
        input_files=sys.argv[2].split(','),
        output_file=sys.argv[3]
    )
```

### run_check_only.py

```python
"""框架模板: 单独执行 check_logic"""

import json
from pathlib import Path

def run_check_only(parsing_result_file, check_logic_module, requirement_items, output_file):
    """
    Args:
        parsing_result_file: parsing 结果 JSON
        check_logic_module: 包含 _judge_item 和 _build_vio_name 的模块
        requirement_items: requirement.pattern_items (可选)
        output_file: 输出 JSON 路径
    """
    # 加载 parsing 结果
    with open(parsing_result_file) as f:
        parsing_result = json.load(f)
    items = parsing_result['items']
    
    # 加载 LLM 生成的代码
    from importlib import import_module
    mod = import_module(check_logic_module)
    
    # 执行 check
    found = {}
    missing = {}
    
    for item in items:
        if mod._judge_item(None, item):  # self=None for standalone
            vio_name = mod._build_vio_name(None, item)
            found[vio_name] = item
        else:
            vio_name = mod._build_vio_name(None, item)
            missing[vio_name] = item
    
    # 保存结果
    result = {
        'found_count': len(found),
        'missing_count': len(missing),
        'found': found,
        'missing': missing
    }
    with open(output_file, 'w') as f:
        json.dump(result, f, indent=2)
    
    return result
```

---

## 6.2 产物清单

| 阶段 | 产物 | 格式 | 用途 |
|------|------|------|------|
| A.1 | `parsing_spec.md` | Markdown | CodeGen 参考 |
| A.2 | `format_spec.md` | Markdown | CodeGen + Validation 契约 |
| B.1.a | `parsing_logic.py` | Python 片段 | sanity 验证 |
| B.1.a | `check_logic.py` | Python 片段 | sanity 验证 |
| B.1.a | `waiver_logic.py` | Python 片段 | sanity 验证 |
| B.1.a | `sanity_item.yaml` | YAML | sanity 验证 |
| B.1.b | `parsing_result.json` | JSON | 中间结果 |
| B.1.b | `check_result.json` | JSON | 中间结果 |
| B.1.c | `checker.py` | Python 完整 | 最终发布 |
| B.2.a | `test_type*.yaml` | YAML | 测试用例 |
| B.2.c | `validation_report.md` | Markdown | 验证报告 |

---

## 七、验证策略

### 7.1 原子单元验证流程

```python
class AtomicUnitValidator:
    """验证 LLM 生成的原子单元"""
    
    def validate_parse_input_files(self, func, test_file: Path):
        """验证 _parse_input_files 函数"""
        items = func([test_file])
        
        # 必须返回 list
        assert isinstance(items, list), "items must be list"
        
        # 每个 item 必须有必需字段
        for item in items:
            assert 'line_number' in item, "Missing line_number"
            assert 'file_path' in item, "Missing file_path"
        
        return ValidationResult(passed=True, items=items)
    
    def validate_judge_item(self, func, items: List[Dict], expected: List[bool]):
        """验证 _judge_item 函数"""
        results = []
        for item, exp in zip(items, expected):
            actual = func(item)
            results.append({
                'item': item,
                'expected': exp,
                'actual': actual,
                'passed': exp == actual
            })
        return ValidationResult(results=results)
    
    def validate_build_vio_name(self, func, items: List[Dict]):
        """验证 _build_vio_name 函数"""
        results = []
        for item in items:
            vio_name = func(item)
            assert isinstance(vio_name, str), "vio_name must be string"
            assert len(vio_name) > 0, "vio_name cannot be empty"
            results.append({
                'item': item,
                'vio_name': vio_name
            })
        return ValidationResult(results=results)
```

### 7.2 测试用例生成

```python
class TestCaseGenerator:
    """根据 parsing 结果生成测试用例"""
    
    def generate_item_yaml_variants(self, parsed_items: List[Dict]):
        """生成各种 Type 的测试配置"""
        
        # Type 1 (N/A): 纯 Boolean 检查
        yield self._generate_type1_na(parsed_items)
        
        # Type 1 (0): Boolean + 全局 waive
        yield self._generate_type1_zero(parsed_items)
        
        # Type 2 (N/A): 严格 pattern 匹配
        yield self._generate_type2_na(parsed_items)
        
        # Type 3: Pattern + 选择性 waive
        yield self._generate_type3(parsed_items)
        
        # Type 4: Boolean + 选择性 waive
        yield self._generate_type4(parsed_items)
    
    def recommend_requirements(self, parsed_items: List[Dict]):
        """根据 parsing 结果推荐 requirement.pattern_items"""
        # 分析 items 的共性，推荐合理的 patterns
        pass
```

---

## 八、目录结构设计

```
CHECKLIST/
├── Check_modules/
│   └── common/
│       ├── checker_framework/           ← 完全固化 (不需要 LLM)
│       │   ├── __init__.py
│       │   ├── base_checker.py          # 基类 (简化)
│       │   ├── type_dispatcher.py       # Type 分发
│       │   ├── type1_executor.py        # Type 1 执行
│       │   ├── type2_executor.py        # Type 2 执行
│       │   ├── type3_executor.py        # Type 3 执行
│       │   ├── type4_executor.py        # Type 4 执行
│       │   ├── waiver_handler.py        # Waiver 处理
│       │   ├── output_builder.py        # 输出构建
│       │   └── interfaces.py            # 接口定义
│       │
│       └── atomic_units/                ← LLM CodeGen 生成
│           ├── __init__.py
│           └── IMP_10_0_0_11/
│               ├── __init__.py
│               ├── parsing_logic.py     # _parse_input_files 函数
│               ├── check_logic.py       # _judge_item 函数
│               └── waiver_logic.py      # _build_vio_name 函数
│
├── Agents/
│   ├── Context/                         ← 生成 ItemSpec
│   ├── CodeGen/                         ← 生成原子单元
│   │   ├── prompts/
│   │   │   ├── parsing_spec.md          # A.1 语义理解 Prompt
│   │   │   ├── format_spec.md           # A.2 语义理解 Prompt
│   │   │   └── codegen.md               # B.1 代码生成 Prompt
│   │   └── templates/
│   │       ├── run_parsing_only.py      # 框架模板
│   │       └── run_check_only.py        # 框架模板
│   └── Validation/                      ← 验证原子单元
│       ├── validators/
│       │   ├── parsing_validator.py
│       │   ├── judge_validator.py
│       │   └── vio_name_validator.py
│       └── generators/
│           └── test_case_generator.py
```

---

## 九、下一步行动

### 9.1 Phase 2A: 框架层实现
- [ ] 实现 `checker_framework/interfaces.py` (接口定义)
- [ ] 实现 `type_dispatcher.py`
- [ ] 实现 Type 1-4 执行器
- [ ] 实现 `waiver_handler.py`

### 9.2 Phase 2B: CodeGen Agent
- [ ] 设计各原子单元的 Prompt
- [ ] 实现原子单元模块加载器
- [ ] 测试端到端生成流程

### 9.3 Phase 2C: Validation Agent
- [ ] 实现原子单元验证器
- [ ] 实现测试用例生成器
- [ ] 实现 requirement 推荐逻辑
