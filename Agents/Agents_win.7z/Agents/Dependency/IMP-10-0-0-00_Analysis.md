# IMP-10-0-0-00 Checker 深度代码分析报告

## 一、文件概述

| 项目 | 值 |
|------|-----|
| **文件路径** | `Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-00.py` |
| **总行数** | 692 行 |
| **作者** | yyin |
| **创建日期** | 2026-01-06 |
| **使用模板版本** | checker_templates v1.1.0 |

---

## 二、代码结构总览

```
IMP-10-0-0-00.py
├── 文件头注释 (Lines 1-44)
│   ├── 脚本名称和目的
│   ├── 检查逻辑说明
│   ├── 类型检测规则
│   ├── 输出行为说明
│   └── Waiver 标签规则
│
├── 导入语句 (Lines 46-66)
│   ├── 标准库导入
│   ├── 路径设置
│   └── 模板 Mixin 导入
│
├── Check_10_0_0_00 类 (Lines 70-674)
│   ├── 类常量定义 (Lines 86-116)
│   ├── __init__ 构造函数 (Lines 118-127)
│   ├── execute_check 主入口 (Lines 133-157)
│   ├── _parse_input_files 解析方法 (Lines 163-324)
│   ├── _extract_file_version 版本提取 (Lines 326-397)
│   ├── _execute_type1 (Lines 403-455)
│   ├── _execute_type2 (Lines 461-508)
│   ├── _execute_type3 (Lines 514-589)
│   └── _execute_type4 (Lines 595-674)
│
└── 入口点 (Lines 677-692)
    └── main() 函数
```

---

## 三、详细代码分析

### 3.1 文件头注释 (Lines 1-44)

```python
################################################################################
# Script Name: IMP-10-0-0-00.py
#
# Purpose:
#   Confirm the netlist/spef version is correct.
```

**关键信息文档**:
- **Purpose** (Line 4-5): 确认 netlist/spef 版本正确
- **Logic** (Lines 7-16): 解析 sta_post_syn.log，提取文件路径和版本信息
- **Auto Type Detection** (Lines 18-22): 四种类型的自动检测规则
- **Output Behavior** (Lines 24-30): existence_check vs status_check 模式
- **Waiver Tag Rules** (Lines 32-38): 三种 waiver 标签的使用规则

---

### 3.2 导入语句 (Lines 46-66)

```python
from pathlib import Path
import re
import sys
import gzip
from typing import List, Dict, Tuple, Optional, Any
```

**标准库导入**:
| 模块 | 用途 |
|------|------|
| `Path` | 跨平台路径处理 |
| `re` | 正则表达式匹配 |
| `sys` | 添加模块搜索路径 |
| `gzip` | 处理 .gz 压缩文件 |
| `typing` | 类型注解 |

**路径设置 (Lines 53-58)**:
```python
_SCRIPT_DIR = Path(__file__).resolve().parent
_CHECK_MODULES_DIR = _SCRIPT_DIR.parents[2]  # Go up to Check_modules/
_COMMON_DIR = _CHECK_MODULES_DIR / 'common'
if str(_COMMON_DIR) not in sys.path:
    sys.path.insert(0, str(_COMMON_DIR))
```

目录结构推导:
```
scripts/checker/IMP-10-0-0-00.py  ← _SCRIPT_DIR
scripts/                          ← parents[0]
10.0_STA_DCD_CHECK/               ← parents[1]
Check_modules/                    ← parents[2] = _CHECK_MODULES_DIR
Check_modules/common/             ← _COMMON_DIR
```

**框架导入 (Lines 60-66)**:
```python
from base_checker import BaseChecker, CheckResult, ConfigurationError
from output_formatter import DetailItem, Severity, create_check_result

# MANDATORY: Import template mixins (checker_templates v1.1.0)
from checker_templates.waiver_handler_template import WaiverHandlerMixin
from checker_templates.output_builder_template import OutputBuilderMixin
from checker_templates.input_file_parser_template import InputFileParserMixin
```

| 导入 | 来源文件 | 用途 |
|------|----------|------|
| `BaseChecker` | base_checker.py | 所有 checker 的基类 |
| `CheckResult` | output_formatter.py | 检查结果数据结构 |
| `ConfigurationError` | base_checker.py | 配置错误异常 |
| `DetailItem` | output_formatter.py | 详细项数据结构 |
| `Severity` | output_formatter.py | 严重级别枚举 (INFO/WARN/FAIL) |
| `WaiverHandlerMixin` | waiver_handler_template.py | Waiver 处理模板 |
| `OutputBuilderMixin` | output_builder_template.py | 输出构建模板 |
| `InputFileParserMixin` | input_file_parser_template.py | 输入文件解析模板 |

---

### 3.3 类定义与继承 (Line 70)

```python
class Check_10_0_0_00(InputFileParserMixin, OutputBuilderMixin, WaiverHandlerMixin, BaseChecker):
```

**继承顺序 (MRO - Method Resolution Order)**: 
```
Check_10_0_0_00
    → InputFileParserMixin    # 输入文件解析能力
    → OutputBuilderMixin      # 输出构建能力
    → WaiverHandlerMixin      # Waiver 处理能力
    → BaseChecker             # 基础功能 (路径、配置、输出)
```

**Mixin 继承顺序的重要性**:
- Python 使用 C3 线性化算法解析 MRO
- 左侧的 Mixin 方法优先级更高
- `InputFileParserMixin` 放在最左边，其解析方法优先

---

### 3.4 类常量定义 (Lines 86-116)

**描述常量 (DESC) - 用于日志分组描述**:
```python
# Type 1/4: Boolean checks - emphasize "found/not found" (existence)
FOUND_DESC_TYPE1_4 = "Netlist and SPEF version information extracted and verified"
MISSING_DESC_TYPE1_4 = "Netlist or SPEF version information missing or incomplete"

# Type 2/3: Pattern checks - emphasize "matched/satisfied" (pattern validation)
FOUND_DESC_TYPE2_3 = "Required version patterns matched and validated"
MISSING_DESC_TYPE2_3 = "Expected version patterns not satisfied or missing"

# All Types (waiver description unified)
WAIVED_DESC = "Version mismatches waived per configuration"
```

**原因常量 (REASON) - 用于单项详情说明**:
```python
# Type 1/4: Boolean checks
FOUND_REASON_TYPE1_4 = "Netlist and SPEF version information found in log and file headers"
MISSING_REASON_TYPE1_4 = "Version information not found in expected locations"

# Type 2/3: Pattern checks
FOUND_REASON_TYPE2_3 = "Version pattern matched and timestamp validated"
MISSING_REASON_TYPE2_3 = "Version pattern not satisfied or timestamp mismatch"

# Waiver-related (Type 3/4 only)
WAIVED_BASE_REASON = "Version mismatch waived per project configuration"
UNUSED_WAIVER_REASON = "Waiver defined but no version mismatch matched"
```

**设计理念**:
- Type 1/4 (Boolean) 使用 "found/not found" 语义
- Type 2/3 (Pattern) 使用 "matched/satisfied" 语义
- 常量命名遵循 `<用途>_<适用类型>` 模式

---

### 3.5 构造函数 (Lines 118-127)

```python
def __init__(self):
    """Initialize the checker."""
    super().__init__(
        check_module="10.0_STA_DCD_CHECK",
        item_id="IMP-10-0-0-00",
        item_desc="Confirm the netlist/spef version is correct."
    )
    # Custom member variables for parsed data
    self._parsed_items: List[Dict[str, Any]] = []
    self._metadata: Dict[str, str] = {}
```

**参数说明**:
| 参数 | 值 | 用途 |
|------|-----|------|
| `check_module` | "10.0_STA_DCD_CHECK" | 模块名称，用于路径定位 |
| `item_id` | "IMP-10-0-0-00" | 唯一标识符，用于配置加载 |
| `item_desc` | "Confirm..." | 检查项描述 |

**实例变量**:
| 变量 | 类型 | 用途 |
|------|------|------|
| `_parsed_items` | `List[Dict]` | 缓存解析出的版本信息 |
| `_metadata` | `Dict[str, str]` | 缓存文件元数据 |

---

### 3.6 主执行方法 execute_check (Lines 133-157)

```python
def execute_check(self) -> CheckResult:
    try:
        if self.root is None:
            raise RuntimeError("Checker not initialized. Call init_checker() first.")
        
        # Detect checker type (use BaseChecker method)
        checker_type = self.detect_checker_type()
        
        # Execute based on type
        if checker_type == 1:
            return self._execute_type1()
        elif checker_type == 2:
            return self._execute_type2()
        elif checker_type == 3:
            return self._execute_type3()
        else:  # checker_type == 4
            return self._execute_type4()
    except ConfigurationError as e:
        return e.check_result
```

**执行流程**:
```
execute_check()
    ├── 检查初始化状态
    ├── 自动检测 Checker 类型 (由 BaseChecker.detect_checker_type() 实现)
    ├── 根据类型分发到对应的执行方法
    │   ├── Type 1 → _execute_type1()
    │   ├── Type 2 → _execute_type2()
    │   ├── Type 3 → _execute_type3()
    │   └── Type 4 → _execute_type4()
    └── 捕获 ConfigurationError 并返回其 check_result
```

---

### 3.7 输入解析方法 _parse_input_files (Lines 163-324)

这是核心解析逻辑，负责从 STA 日志中提取版本信息。

#### 3.7.1 方法签名和返回值

```python
def _parse_input_files(self) -> Dict[str, Any]:
    """
    Returns:
        Dict with parsed data:
        - 'items': List[Dict] - Version information items with metadata
        - 'metadata': Dict - File metadata (tool version, design name, etc.)
        - 'errors': List - Any parsing errors encountered
    """
```

#### 3.7.2 第一步：验证输入文件 (Lines 177-182)

```python
valid_files, missing_files = self.validate_input_files()
if missing_files:
    raise ConfigurationError(
        self.create_missing_files_error(missing_files)
    )
```

调用 `BaseChecker.validate_input_files()` 验证配置的输入文件是否存在。

#### 3.7.3 第二步：解析 STA 日志 (Lines 188-273)

使用 6 个正则表达式模式提取信息:

| Pattern | 正则表达式 | 提取内容 | 示例匹配 |
|---------|-----------|---------|----------|
| 1 | `read_netlist\s+([^\s]+\.v(?:\.gz)?)` | Netlist 路径 | `read_netlist /path/to/design.v.gz` |
| 2 | `\[INFO\]\s+Skipping SPEF reading as (.+)` | SPEF 跳过原因 | `[INFO] Skipping SPEF reading as ...` |
| 3 | `read_spef\s+([^\s]+\.spef(?:\.gz)?)` | SPEF 路径 | `read_spef /path/to/design.spef` |
| 4 | `#\s*Parasitics Mode:\s*(.+)` | Parasitics 模式 | `# Parasitics Mode: No SPEF/RCDB` |
| 5 | `Top level cell is\s+(\S+)` | 顶层设计名 | `Top level cell is phy_cmn_...` |
| 6 | `Program version\s*=\s*([\d\.\-\w]+)` | 工具版本 | `Program version = 23.15-s108_1` |

**提取的 item 数据结构**:
```python
{
    'name': "Netlist: phy_cmn_phase_align_digtop.v.gz",
    'type': 'netlist_path',      # 类型标识
    'path': '/full/path/to/file.v.gz',
    'line_number': 6,            # 在日志中的行号
    'file_path': '/path/to/sta_post_syn.log'  # 来源文件
}
```

#### 3.7.4 第三步：二次验证 - 提取 Netlist 版本 (Lines 275-287)

```python
if netlist_path:
    netlist_version = self._extract_file_version(netlist_path, 'netlist')
    if netlist_version:
        items.append({
            'name': f"Netlist Version: {netlist_version}",
            'type': 'netlist_version',
            'version': netlist_version,
            'line_number': 3,  # Netlist version is on line 3
            'file_path': netlist_path
        })
```

**关键点**: Netlist 版本固定从**第 3 行**提取。

#### 3.7.5 第四步：二次验证 - 提取 SPEF 版本 (Lines 289-301)

```python
if spef_path and spef_status == "Read":
    spef_version = self._extract_file_version(spef_path, 'spef')
```

只有当 SPEF 被实际读取时才尝试提取版本。

#### 3.7.6 第五步：存储和返回 (Lines 316-324)

```python
self._parsed_items = items
self._metadata = metadata

return {
    'items': items,
    'metadata': metadata,
    'errors': errors
}
```

---

### 3.8 版本提取方法 _extract_file_version (Lines 326-397)

```python
def _extract_file_version(self, file_path: str, file_type: str) -> Optional[str]:
```

#### 3.8.1 智能文件打开 (Lines 338-351)

```python
try:
    # Always try to open as plain text first
    f = open(file_path, 'r', encoding='utf-8', errors='ignore')
except Exception:
    # If plain text fails and file has .gz extension, try gzip
    if file_path.endswith('.gz'):
        f = gzip.open(file_path, 'rt', encoding='utf-8', errors='ignore')
```

**设计亮点**: 先尝试纯文本打开，失败后再尝试 gzip，因为 `.gz` 扩展名的文件不一定真的是压缩文件。

#### 3.8.2 Netlist 版本提取 (Lines 354-376)

```python
if file_type == 'netlist':
    for i, line in enumerate(f, 1):
        if i == 3:
            # Pattern 1: "Generated on: Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC)"
            match_generated = re.search(r'Generated on:\s*(.+?)\s+\w+\s+\((.+?)\)', line)
            if match_generated:
                return match_generated.group(1).strip()
            
            # Pattern 2: Alternative - just "Generated on: <timestamp>"
            match_simple = re.search(r'Generated on:\s*(.+?)$', line)
            ...
```

**只读取第 3 行**，因为 Cadence Genus 生成的 netlist 版本信息固定在第 3 行。

#### 3.8.3 SPEF 版本提取 (Lines 377-391)

```python
else:  # file_type == 'spef'
    for i, line in enumerate(f, 1):
        if i > 100:
            break
        
        # Pattern 3: SPEF DATE field
        match_date = re.search(r'DATE\s+"(.+?)"', line)
        if match_date:
            return match_date.group(1).strip()
```

读取前 100 行查找 `DATE` 字段。

---

### 3.9 Type 1 执行方法 (Lines 403-455)

```python
def _execute_type1(self) -> CheckResult:
    """Type 1: Boolean Check."""
    data = self._parse_input_files()
    items = data.get('items', [])
    errors = data.get('errors', [])
    
    # Check if we have the required version information
    has_netlist_path = any(item['type'] == 'netlist_path' for item in items)
    has_spef_status = any(item['type'] in ['spef_status', 'spef_path'] for item in items)
```

**检查条件**:
- 找到 netlist 路径 → `has_netlist_path = True`
- 找到 SPEF 状态 (跳过或读取) → `has_spef_status = True`
- 两者都满足 → PASS

**输出构建**:
```python
return self.build_complete_output(
    found_items=found_items,
    missing_items=missing_items,
    found_desc=self.FOUND_DESC_TYPE1_4,
    missing_desc=self.MISSING_DESC_TYPE1_4,
    found_reason=self.FOUND_REASON_TYPE1_4,
    missing_reason=self.MISSING_REASON_TYPE1_4
)
```

使用 `OutputBuilderMixin.build_complete_output()` 一步生成完整结果。

---

### 3.10 Type 2 执行方法 (Lines 461-508)

```python
def _execute_type2(self) -> CheckResult:
    """Type 2: Value Check."""
    data = self._parse_input_files()
    items = data.get('items', [])
    
    # Get requirements
    pattern_items = self.item_data.get('requirements', {}).get('pattern_items', [])
    
    # existence_check mode: Check if pattern_items exist in parsed items
    for pattern in pattern_items:
        matched = False
        for item in items:
            if (pattern.lower() in item['name'].lower() or 
                pattern.lower() in item.get('type', '').lower()):
                found_items[item['name']] = {...}
                matched = True
                break
        
        if not matched:
            missing_items.append(pattern)
```

**检查逻辑**:
- 遍历 `pattern_items` 配置
- 在解析结果中搜索匹配项 (不区分大小写的子字符串匹配)
- 匹配成功 → `found_items`
- 匹配失败 → `missing_items`

---

### 3.11 Type 3 执行方法 (Lines 514-589)

```python
def _execute_type3(self) -> CheckResult:
    """Type 3: Value check with waiver support."""
    # ... (similar to Type 2)
    
    # Get waivers
    waivers = self.get_waivers()
    waive_items_raw = waivers.get('waive_items', [])
    waive_dict = self.parse_waive_items(waive_items_raw)  # From WaiverHandlerMixin
    
    # Separate waived/unwaived using template helper
    for violation in violations:
        if self.match_waiver_entry(violation, waive_dict):  # From WaiverHandlerMixin
            waived_items[violation] = {...}
        else:
            unwaived_items.append(violation)
    
    # Find unused waivers
    unused_waivers = [name for name in waive_dict.keys() if name not in used_names]
```

**与 Type 2 的区别**:
1. 调用 `parse_waive_items()` 解析 waiver 配置
2. 调用 `match_waiver_entry()` 匹配 waiver
3. 分离 waived/unwaived 项目
4. 检测未使用的 waiver

**输出构建扩展**:
```python
return self.build_complete_output(
    found_items=found_items,
    waived_items=waived_items,      # Type 3 新增
    missing_items=unwaived_items,
    waive_dict=waive_dict,          # Type 3 新增
    unused_waivers=unused_waivers,  # Type 3 新增
    waived_desc=self.WAIVED_DESC,
    waived_base_reason=self.WAIVED_BASE_REASON,
    unused_waiver_reason=self.UNUSED_WAIVER_REASON
)
```

---

### 3.12 Type 4 执行方法 (Lines 595-674)

```python
def _execute_type4(self) -> CheckResult:
    """Type 4: Boolean check with waiver support (Type 1 + waiver)."""
```

**本质**: Type 1 (Boolean) + Type 3 的 waiver 处理逻辑

检查条件与 Type 1 相同，但违规项可被 waiver 豁免。

---

### 3.13 入口点 (Lines 677-692)

```python
def main():
    """Main entry point."""
    checker = Check_10_0_0_00()
    checker.init_checker(Path(__file__))
    result = checker.execute_check()
    checker.write_output(result)
    return 0 if result.is_pass else 1


if __name__ == '__main__':
    import sys
    sys.exit(main())
```

**执行流程**:
```
main()
├── 1. 创建 checker 实例
├── 2. 初始化 (加载配置、设置路径)
├── 3. 执行检查
├── 4. 写入输出 (log + report + cache)
└── 5. 返回退出码 (0=PASS, 1=FAIL)
```

---

## 四、类继承关系图

```
                          ┌──────────────────────┐
                          │    Check_10_0_0_00   │
                          │  (具体 Checker 实现)  │
                          └──────────┬───────────┘
                                     │
            ┌────────────────────────┼────────────────────────┐
            │                        │                        │
            ▼                        ▼                        ▼
┌─────────────────────┐  ┌─────────────────────┐  ┌─────────────────────┐
│ InputFileParserMixin│  │ OutputBuilderMixin  │  │ WaiverHandlerMixin  │
│                     │  │                     │  │                     │
│ - parse_log_with_   │  │ - build_complete_   │  │ - parse_waive_items│
│   patterns()        │  │   output()          │  │ - match_waiver_    │
│ - normalize_command │  │ - build_details_    │  │   entry()          │
│                     │  │   from_items()      │  │ - classify_items_  │
│                     │  │                     │  │   by_waiver()      │
└─────────────────────┘  └─────────────────────┘  └─────────────────────┘
                                     │
                                     ▼
                          ┌──────────────────────┐
                          │     BaseChecker      │
                          │                      │
                          │ - init_checker()     │
                          │ - validate_input_    │
                          │   files()            │
                          │ - detect_checker_    │
                          │   type()             │
                          │ - write_output()     │
                          │ - get_requirements() │
                          │ - get_waivers()      │
                          └──────────────────────┘
```

---

## 五、数据流图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                              配置加载                                    │
│  inputs/items/IMP-10-0-0-00.yaml                                        │
│  ├── input_files: [sta_post_syn.log]                                   │
│  ├── requirements: {value, pattern_items}                              │
│  └── waivers: {value, waive_items}                                     │
└─────────────────────────────┬───────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         _parse_input_files()                            │
│                                                                         │
│  sta_post_syn.log ──────┐                                              │
│                         ▼                                               │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ 正则匹配:                                                         │   │
│  │  ├── read_netlist → netlist_path                                │   │
│  │  ├── Skipping SPEF → spef_status                                │   │
│  │  ├── read_spef → spef_path                                      │   │
│  │  ├── Parasitics Mode → parasitics_mode                          │   │
│  │  ├── Top level cell → top_design                                │   │
│  │  └── Program version → tool_version                             │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                         │                                               │
│                         ▼                                               │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ 二次验证:                                                         │   │
│  │  ├── 打开 netlist 文件 → 第 3 行提取版本                          │   │
│  │  └── 打开 SPEF 文件 → DATE 字段提取版本 (如果读取)                 │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                         │                                               │
│                         ▼                                               │
│                   {items, metadata, errors}                             │
└─────────────────────────────┬───────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                      类型特定处理逻辑                                    │
│                                                                         │
│  Type 1/4: Boolean Check                                               │
│  ├── 检查 has_netlist_path AND has_spef_status                        │
│  └── 所有 items → found_items                                          │
│                                                                         │
│  Type 2/3: Pattern Check                                               │
│  ├── 遍历 pattern_items                                                │
│  ├── 在 items 中搜索匹配                                               │
│  └── 匹配 → found, 未匹配 → missing                                    │
│                                                                         │
│  Type 3/4: Waiver 处理                                                 │
│  ├── 解析 waive_items → waive_dict                                    │
│  ├── violations 与 waive_dict 匹配                                     │
│  └── 分离 waived/unwaived/unused                                       │
└─────────────────────────────┬───────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    build_complete_output()                              │
│                                                                         │
│  输入:                                                                  │
│  ├── found_items: Dict[name, metadata]                                 │
│  ├── missing_items: List[name]                                         │
│  ├── waived_items: Dict[name, metadata] (Type 3/4)                     │
│  ├── unused_waivers: List[name] (Type 3/4)                             │
│  └── *_desc, *_reason 常量                                             │
│                         │                                               │
│                         ▼                                               │
│  输出: CheckResult                                                      │
│  ├── is_pass: bool                                                     │
│  ├── value: "N/A" / int                                                │
│  ├── details: List[DetailItem]                                         │
│  ├── info_groups: Dict                                                 │
│  ├── error_groups: Dict                                                │
│  └── warn_groups: Dict                                                 │
└─────────────────────────────┬───────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         write_output()                                  │
│                                                                         │
│  ├── logs/IMP-10-0-0-00.log   (简洁格式)                               │
│  ├── reports/IMP-10-0-0-00.rpt (详细格式)                              │
│  └── outputs/.cache/IMP-10-0-0-00.pickle (缓存)                        │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 六、关键设计模式

### 6.1 Mixin 模式
通过多继承组合功能，避免代码重复。每个 Mixin 提供独立的功能集。

### 6.2 策略模式 (Type 1/2/3/4)
根据配置自动选择执行策略，`execute_check()` 作为统一入口。

### 6.3 模板方法模式
`BaseChecker` 定义骨架 (`init_checker` → `execute_check` → `write_output`)，子类实现 `execute_check()`。

### 6.4 配置驱动
相同的 Python 代码，通过修改 YAML 配置可以产生不同的检查行为。

---

## 七、扩展此 Checker 的指南

### 7.1 添加新的提取模式

在 `_parse_input_files()` 中添加新的正则表达式:

```python
# Pattern N: Extract XXX
match_xxx = re.search(r'YOUR_PATTERN_HERE', line)
if match_xxx:
    items.append({
        'name': f"XXX: {match_xxx.group(1)}",
        'type': 'xxx_type',
        'value': match_xxx.group(1),
        'line_number': line_num,
        'file_path': str(file_path)
    })
```

### 7.2 修改检查逻辑

在对应的 `_execute_typeN()` 方法中修改条件判断。

### 7.3 添加新的描述/原因常量

在类顶部添加常量，并在 `build_complete_output()` 调用时使用。

---

*文档生成时间: 2026-02-04*
*分析对象: IMP-10-0-0-00.py (692 行)*
