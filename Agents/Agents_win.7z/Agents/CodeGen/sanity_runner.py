#!/usr/bin/env python3
"""
CodeGen Agent - Sanity Runner

Executes sanity checks on generated checker code.
Supports incremental testing and diff analysis.

Author: CodeGen Agent Team  
Date: 2026-02-04
"""

import subprocess
import sys
from typing import Dict, Any, Optional, List, Tuple
from pathlib import Path
from dataclasses import dataclass, field
import tempfile
import difflib


@dataclass
class SanityResult:
    """Result of a sanity check"""
    passed: bool
    iteration: int = 1
    
    # Execution results
    import_success: bool = False
    syntax_valid: bool = False
    parse_success: bool = False
    check_success: bool = False
    
    # Error details
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    # Output comparison
    expected_output: Optional[str] = None
    actual_output: Optional[str] = None
    diff_summary: Optional[str] = None
    
    def add_error(self, error: str):
        """Add error message"""
        self.errors.append(error)
        self.passed = False
    
    def add_warning(self, warning: str):
        """Add warning message"""
        self.warnings.append(warning)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            'passed': self.passed,
            'iteration': self.iteration,
            'import_success': self.import_success,
            'syntax_valid': self.syntax_valid,
            'parse_success': self.parse_success,
            'check_success': self.check_success,
            'errors': self.errors,
            'warnings': self.warnings,
            'diff_summary': self.diff_summary
        }


class SanityRunner:
    """
    Executes sanity checks on generated checker code
    
    Verifies:
    1. Syntax validity (AST parsing)
    2. Import success (module loads)
    3. Parse execution (no errors on sample input)
    4. Check execution (produces expected output type)
    """
    
    def __init__(
        self,
        checker_path: Path,
        sample_input: Optional[Path] = None,
        expected_output: Optional[Path] = None
    ):
        """
        Initialize sanity runner
        
        Args:
            checker_path: Path to generated checker file
            sample_input: Optional sample input file for testing
            expected_output: Optional expected output for comparison
        """
        self.checker_path = Path(checker_path)
        self.sample_input = Path(sample_input) if sample_input else None
        self.expected_output = Path(expected_output) if expected_output else None
    
    def run(self, iteration: int = 1) -> SanityResult:
        """
        Execute full sanity check
        
        Args:
            iteration: Current iteration number
            
        Returns:
            SanityResult with pass/fail and details
        """
        result = SanityResult(passed=True, iteration=iteration)
        
        # 1. Check file exists
        if not self.checker_path.exists():
            result.add_error(f"Checker file not found: {self.checker_path}")
            return result
        
        # 2. Validate syntax
        syntax_ok, syntax_errors = self._check_syntax()
        result.syntax_valid = syntax_ok
        if not syntax_ok:
            for err in syntax_errors:
                result.add_error(f"Syntax: {err}")
            return result
        
        # 3. Test import
        import_ok, import_error = self._check_import()
        result.import_success = import_ok
        if not import_ok:
            result.add_error(f"Import: {import_error}")
            return result
        
        # 4. Test parsing (if sample input available)
        if self.sample_input and self.sample_input.exists():
            parse_ok, parse_error = self._check_parse()
            result.parse_success = parse_ok
            if not parse_ok:
                result.add_error(f"Parse: {parse_error}")
                return result
        else:
            result.parse_success = True  # Skip if no sample
            result.add_warning("No sample input provided, skipping parse test")
        
        # 5. Test check execution
        check_ok, check_error = self._check_execution()
        result.check_success = check_ok
        if not check_ok:
            result.add_error(f"Execution: {check_error}")
            return result
        
        # 6. Compare output (if expected available)
        if self.expected_output and self.expected_output.exists():
            diff = self._compare_output()
            if diff:
                result.diff_summary = diff
                result.add_warning(f"Output differs from expected: {diff[:200]}")
        
        return result
    
    def _check_syntax(self) -> Tuple[bool, List[str]]:
        """Validate Python syntax"""
        import ast
        
        try:
            code = self.checker_path.read_text(encoding='utf-8')
            ast.parse(code)
            return True, []
        except SyntaxError as e:
            return False, [f"Line {e.lineno}: {e.msg}"]
    
    def _check_import(self) -> Tuple[bool, Optional[str]]:
        """Test if module can be imported"""
        # Run import check in subprocess to avoid polluting current process
        script = f"""
import sys
sys.path.insert(0, '{self.checker_path.parent}')
try:
    import importlib.util
    spec = importlib.util.spec_from_file_location("checker", "{self.checker_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    print("OK")
except Exception as e:
    print(f"ERROR: {{e}}")
"""
        try:
            result = subprocess.run(
                [sys.executable, "-c", script],
                capture_output=True,
                text=True,
                timeout=30
            )
            output = result.stdout.strip()
            if output == "OK":
                return True, None
            else:
                return False, output.replace("ERROR: ", "")
        except subprocess.TimeoutExpired:
            return False, "Import timed out"
        except Exception as e:
            return False, str(e)
    
    def _check_parse(self) -> Tuple[bool, Optional[str]]:
        """Test parsing with sample input"""
        if not self.sample_input:
            return True, None
        
        script = f"""
import sys
sys.path.insert(0, '{self.checker_path.parent.parent.parent}')
import importlib.util
spec = importlib.util.spec_from_file_location("checker", "{self.checker_path}")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

# Find checker class
for name in dir(module):
    obj = getattr(module, name)
    if isinstance(obj, type) and name.startswith('Check_'):
        checker = obj()
        from pathlib import Path
        try:
            items = checker._parse_input_files([Path("{self.sample_input}")])
            print(f"OK: {{len(items)}} items parsed")
        except Exception as e:
            print(f"ERROR: {{e}}")
        break
else:
    print("ERROR: No checker class found")
"""
        try:
            result = subprocess.run(
                [sys.executable, "-c", script],
                capture_output=True,
                text=True,
                timeout=60
            )
            output = result.stdout.strip()
            if output.startswith("OK"):
                return True, None
            else:
                return False, output.replace("ERROR: ", "")
        except subprocess.TimeoutExpired:
            return False, "Parse timed out"
        except Exception as e:
            return False, str(e)
    
    def _check_execution(self) -> Tuple[bool, Optional[str]]:
        """Test full check execution"""
        # Basic execution test - just verify the checker can be instantiated
        script = f"""
import sys
sys.path.insert(0, '{self.checker_path.parent.parent.parent}')
import importlib.util
spec = importlib.util.spec_from_file_location("checker", "{self.checker_path}")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

for name in dir(module):
    obj = getattr(module, name)
    if isinstance(obj, type) and name.startswith('Check_'):
        checker = obj()
        # Verify required methods exist
        assert hasattr(checker, '_parse_input_files'), "_parse_input_files missing"
        assert hasattr(checker, '_judge_item'), "_judge_item missing"
        assert hasattr(checker, '_build_vio_name'), "_build_vio_name missing"
        print("OK")
        break
else:
    print("ERROR: No checker class found")
"""
        try:
            result = subprocess.run(
                [sys.executable, "-c", script],
                capture_output=True,
                text=True,
                timeout=30
            )
            output = result.stdout.strip()
            stderr = result.stderr.strip()
            
            if output == "OK":
                return True, None
            elif stderr:
                return False, stderr.split('\n')[-1]
            else:
                return False, output.replace("ERROR: ", "")
        except subprocess.TimeoutExpired:
            return False, "Execution timed out"
        except Exception as e:
            return False, str(e)
    
    def _compare_output(self) -> Optional[str]:
        """Compare actual output with expected"""
        if not self.expected_output:
            return None
        
        # This would need actual run output - simplified for now
        return None


def generate_diff(expected: str, actual: str) -> str:
    """
    Generate unified diff between expected and actual output
    
    Returns:
        Diff string or empty if identical
    """
    expected_lines = expected.splitlines(keepends=True)
    actual_lines = actual.splitlines(keepends=True)
    
    diff = list(difflib.unified_diff(
        expected_lines,
        actual_lines,
        fromfile='expected',
        tofile='actual',
        lineterm=''
    ))
    
    return ''.join(diff)
