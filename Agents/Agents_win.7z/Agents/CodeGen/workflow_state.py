#!/usr/bin/env python3
"""
CodeGen Agent - Workflow State Machine

Manages workflow state for checkpoint recovery and breakpoint resumption.

Design Principles:
- State persistence to YAML for recovery
- Support for blocking intervention with state protection
- Stage-based workflow tracking

Author: CodeGen Agent Team
Date: 2026-02-04
"""

from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import Dict, Any, Optional, List
from pathlib import Path
from datetime import datetime
import yaml


class WorkflowStage(Enum):
    """Workflow stages aligned with architecture document"""
    
    # Phase A: Context Agent (Semantic Understanding)
    INIT = "init"
    CONTEXT_PARSING_SPEC = "a.1_parsing_spec"
    CONTEXT_FORMAT_SPEC = "a.2_format_spec"
    CONTEXT_DONE = "a_done"
    
    # Phase B.1: CodeGen Agent
    CODEGEN_PARSING = "b.1.1_parsing_logic"
    CODEGEN_CHECK = "b.1.2_check_logic"
    CODEGEN_WAIVER = "b.1.3_waiver_logic"
    CODEGEN_ASSEMBLE = "b.1.4_assemble"
    CODEGEN_SANITY = "b.1.5_sanity"
    CODEGEN_DONE = "b.1_done"
    
    # Phase B.2: Validation Agent
    VALIDATION_TESTGEN = "b.2.1_test_generation"
    VALIDATION_EXECUTE = "b.2.2_test_execution"
    VALIDATION_REVIEW = "b.2.3_review"
    VALIDATION_DONE = "b.2_done"
    
    # Final states
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED_FOR_INTERVENTION = "blocked"


class WorkflowStatus(Enum):
    """Current workflow status"""
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"  # Blocked for human intervention


@dataclass
class SanityResult:
    """Result of a sanity check iteration"""
    iteration: int
    passed: bool
    errors: List[str] = field(default_factory=list)
    diff_summary: Optional[str] = None


@dataclass
class WorkflowState:
    """
    Workflow state with checkpoint support
    
    Persisted to state.yaml for recovery after interruption.
    """
    
    item_id: str
    current_stage: WorkflowStage = WorkflowStage.INIT
    status: WorkflowStatus = WorkflowStatus.RUNNING
    
    # Timestamps
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    
    # Stage-specific data
    context_data: Dict[str, Any] = field(default_factory=dict)
    codegen_data: Dict[str, Any] = field(default_factory=dict)
    validation_data: Dict[str, Any] = field(default_factory=dict)
    
    # Retry tracking
    sanity_iterations: int = 0
    sanity_max_iterations: int = 3
    sanity_results: List[Dict] = field(default_factory=list)
    
    validation_rollbacks: int = 0
    validation_max_rollbacks: int = 1
    
    # Error tracking
    last_error: Optional[str] = None
    error_history: List[str] = field(default_factory=list)
    
    def update_stage(self, stage: WorkflowStage):
        """Update current stage and timestamp"""
        self.current_stage = stage
        self.updated_at = datetime.now().isoformat()
    
    def record_sanity_result(self, result: SanityResult):
        """Record sanity check result"""
        self.sanity_iterations = result.iteration
        self.sanity_results.append(asdict(result))
        self.updated_at = datetime.now().isoformat()
    
    def can_retry_sanity(self) -> bool:
        """Check if more sanity iterations are allowed"""
        return self.sanity_iterations < self.sanity_max_iterations
    
    def can_rollback_validation(self) -> bool:
        """Check if validation rollback is allowed"""
        return self.validation_rollbacks < self.validation_max_rollbacks
    
    def record_error(self, error: str):
        """Record error and update status"""
        self.last_error = error
        self.error_history.append(f"{datetime.now().isoformat()}: {error}")
        self.updated_at = datetime.now().isoformat()
    
    def block_for_intervention(self, reason: str):
        """Block workflow for human intervention"""
        self.status = WorkflowStatus.BLOCKED
        self.current_stage = WorkflowStage.BLOCKED_FOR_INTERVENTION
        self.record_error(f"BLOCKED: {reason}")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for YAML serialization"""
        return {
            'item_id': self.item_id,
            'current_stage': self.current_stage.value,
            'status': self.status.value,
            'created_at': self.created_at,
            'updated_at': self.updated_at,
            'context_data': self.context_data,
            'codegen_data': self.codegen_data,
            'validation_data': self.validation_data,
            'sanity_iterations': self.sanity_iterations,
            'sanity_max_iterations': self.sanity_max_iterations,
            'sanity_results': self.sanity_results,
            'validation_rollbacks': self.validation_rollbacks,
            'validation_max_rollbacks': self.validation_max_rollbacks,
            'last_error': self.last_error,
            'error_history': self.error_history
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'WorkflowState':
        """Create from dictionary (loaded from YAML)"""
        state = cls(item_id=data['item_id'])
        state.current_stage = WorkflowStage(data['current_stage'])
        state.status = WorkflowStatus(data['status'])
        state.created_at = data.get('created_at', state.created_at)
        state.updated_at = data.get('updated_at', state.updated_at)
        state.context_data = data.get('context_data', {})
        state.codegen_data = data.get('codegen_data', {})
        state.validation_data = data.get('validation_data', {})
        state.sanity_iterations = data.get('sanity_iterations', 0)
        state.sanity_max_iterations = data.get('sanity_max_iterations', 3)
        state.sanity_results = data.get('sanity_results', [])
        state.validation_rollbacks = data.get('validation_rollbacks', 0)
        state.validation_max_rollbacks = data.get('validation_max_rollbacks', 1)
        state.last_error = data.get('last_error')
        state.error_history = data.get('error_history', [])
        return state


class StateManager:
    """
    State persistence manager
    
    Handles saving and loading workflow state for checkpoint recovery.
    """
    
    def __init__(self, work_dir: Path):
        """
        Initialize state manager
        
        Args:
            work_dir: Working directory for this item (e.g., Agents/Work/IMP-10-0-0-00/)
        """
        self.work_dir = Path(work_dir)
        self.state_file = self.work_dir / "state.yaml"
    
    def save(self, state: WorkflowState):
        """
        Save state to YAML file
        
        Protected operation for checkpoint recovery.
        """
        self.work_dir.mkdir(parents=True, exist_ok=True)
        
        with open(self.state_file, 'w', encoding='utf-8') as f:
            yaml.dump(state.to_dict(), f, default_flow_style=False, allow_unicode=True)
    
    def load(self) -> Optional[WorkflowState]:
        """
        Load state from YAML file
        
        Returns None if no state file exists.
        """
        if not self.state_file.exists():
            return None
        
        with open(self.state_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        return WorkflowState.from_dict(data)
    
    def exists(self) -> bool:
        """Check if state file exists"""
        return self.state_file.exists()
    
    def get_stage(self) -> Optional[WorkflowStage]:
        """Get current stage without loading full state"""
        state = self.load()
        return state.current_stage if state else None
    
    def is_blocked(self) -> bool:
        """Check if workflow is blocked for intervention"""
        state = self.load()
        return state.status == WorkflowStatus.BLOCKED if state else False
    
    def resume(self) -> WorkflowState:
        """
        Resume from checkpoint
        
        Returns existing state or creates new one.
        """
        state = self.load()
        if state:
            if state.status == WorkflowStatus.BLOCKED:
                # Reset blocked status on resume
                state.status = WorkflowStatus.RUNNING
                state.updated_at = datetime.now().isoformat()
            return state
        
        raise FileNotFoundError(
            f"No state file found at {self.state_file}. "
            "Cannot resume without existing checkpoint."
        )
    
    def create_new(self, item_id: str) -> WorkflowState:
        """Create new workflow state"""
        state = WorkflowState(item_id=item_id)
        self.save(state)
        return state
