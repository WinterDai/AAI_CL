#!/usr/bin/env python3
"""
CodeGen Agent - Code Extractor

Extracts Python code from LLM responses.
Handles various response formats including markdown code blocks.

Author: CodeGen Agent Team
Date: 2026-02-06
"""

import re
import ast
from typing import Optional, List, Tuple


class CodeExtractor:
    """
    Extract and validate Python code from LLM responses.
    
    Handles:
    - Markdown code blocks (```python ... ```)
    - Plain code blocks (``` ... ```)
    - Raw Python code
    """
    
    def __init__(self):
        self._last_error = None
    
    @property
    def last_error(self) -> Optional[str]:
        """Get the last extraction/validation error"""
        return self._last_error
    
    def extract_code(self, response: str) -> Optional[str]:
        """
        Extract Python code from LLM response.
        
        Args:
            response: Raw LLM response text
            
        Returns:
            Extracted Python code or None if no code found
        """
        self._last_error = None
        
        # Try to extract from markdown code blocks
        patterns = [
            # Python code block
            r'```python\s*\n(.*?)```',
            # Generic code block
            r'```\s*\n(.*?)```',
            # Code block with py marker
            r'```py\s*\n(.*?)```',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, response, re.DOTALL)
            if matches:
                # Return the first valid Python code block
                for code in matches:
                    code = code.strip()
                    if self._is_valid_python(code):
                        return code
                # If no valid code found, return first match anyway
                return matches[0].strip()
        
        # Try extracting raw code (no markdown)
        # Look for function definitions
        func_pattern = r'(def\s+\w+\s*\([^)]*\)\s*(?:->.*?)?:\s*\n(?:[ \t]+.+\n?)+)'
        func_matches = re.findall(func_pattern, response)
        if func_matches:
            return '\n\n'.join(func_matches)
        
        # Return None if no code found
        self._last_error = "No Python code found in response"
        return None
    
    def extract_function(self, response: str, function_name: str) -> Optional[str]:
        """
        Extract a specific function from LLM response.
        
        Args:
            response: Raw LLM response text
            function_name: Name of the function to extract
            
        Returns:
            Function code or None if not found
        """
        code = self.extract_code(response)
        if not code:
            return None
        
        # Parse and find the function
        try:
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef) and node.name == function_name:
                    # Extract the function source
                    lines = code.split('\n')
                    start = node.lineno - 1
                    end = node.end_lineno or len(lines)
                    return '\n'.join(lines[start:end])
        except SyntaxError:
            pass
        
        # Fallback: regex extraction
        pattern = rf'(def\s+{function_name}\s*\([^)]*\)\s*(?:->.*?)?:\s*\n(?:[ \t]+.+\n?)+)'
        match = re.search(pattern, code)
        if match:
            return match.group(1)
        
        self._last_error = f"Function '{function_name}' not found in code"
        return None
    
    def validate_syntax(self, code: str) -> Tuple[bool, Optional[str]]:
        """
        Validate Python syntax.
        
        Args:
            code: Python code to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        try:
            ast.parse(code)
            return True, None
        except SyntaxError as e:
            error_msg = f"Line {e.lineno}: {e.msg}"
            return False, error_msg
    
    def _is_valid_python(self, code: str) -> bool:
        """Check if code is valid Python"""
        try:
            ast.parse(code)
            return True
        except SyntaxError:
            return False
    
    def extract_class_methods(self, response: str, class_name: str = None) -> List[Tuple[str, str]]:
        """
        Extract all methods from a class in the response.
        
        Args:
            response: Raw LLM response text
            class_name: Optional class name to filter
            
        Returns:
            List of (method_name, method_code) tuples
        """
        code = self.extract_code(response)
        if not code:
            return []
        
        methods = []
        try:
            tree = ast.parse(code)
            
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    if class_name and node.name != class_name:
                        continue
                    
                    for item in node.body:
                        if isinstance(item, ast.FunctionDef):
                            lines = code.split('\n')
                            start = item.lineno - 1
                            end = item.end_lineno or len(lines)
                            method_code = '\n'.join(lines[start:end])
                            methods.append((item.name, method_code))
        except SyntaxError:
            pass
        
        return methods
    
    def fix_indentation(self, code: str, target_indent: int = 4) -> str:
        """
        Normalize indentation of code.
        
        Args:
            code: Code to fix
            target_indent: Spaces per indentation level
            
        Returns:
            Code with normalized indentation
        """
        lines = code.split('\n')
        if not lines:
            return code
        
        # Find minimum indentation (excluding empty lines)
        min_indent = float('inf')
        for line in lines:
            stripped = line.lstrip()
            if stripped:  # Non-empty line
                indent = len(line) - len(stripped)
                min_indent = min(min_indent, indent)
        
        if min_indent == float('inf'):
            min_indent = 0
        
        # Remove minimum indent from all lines
        result = []
        for line in lines:
            if line.strip():
                result.append(line[min_indent:])
            else:
                result.append('')
        
        return '\n'.join(result)
