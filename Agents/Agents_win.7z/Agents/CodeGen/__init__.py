#!/usr/bin/env python3
"""
CodeGen Agent Package

This package provides the CodeGen Agent infrastructure for generating
checker code from specifications.

Modules:
- llm_client: LLM abstraction layer (Gemini, Interactive, Mock)
- workflow_state: State machine with checkpoint recovery
- config: Configuration management
- prompts: System and user prompt templates
- assembler: Code assembly with AST validation
- sanity_runner: Execution testing
"""

from .llm_client import (
    LLMClient,
    LLMMode,
    GeminiClient,
    InteractiveClient,
    MockClient,
    JedaiClient,
    ParallelExecutor,
    create_client
)

from .workflow_state import (
    WorkflowStage,
    WorkflowStatus,
    WorkflowState,
    StateManager,
    SanityResult
)

from .config import (
    Config,
    LLMConfig,
    WorkflowConfig,
    PathConfig,
    Environment,
    load_config
)

from .prompts import (
    PromptBuilder,
    PromptContext,
    SYSTEM_PROMPT_PARSING,
    SYSTEM_PROMPT_CHECK,
    SYSTEM_PROMPT_VIONAME,
    SYSTEM_PROMPT_CONTEXT
)

from .assembler import (
    CodeAssembler,
    extract_code_from_response
)

from .sanity_runner import (
    SanityRunner,
    SanityResult as SanityCheckResult,
    generate_diff
)

__all__ = [
    # LLM Client
    'LLMClient',
    'LLMMode',
    'GeminiClient',
    'InteractiveClient',
    'MockClient',
    'JedaiClient',
    'ParallelExecutor',
    'create_client',
    
    # Workflow State
    'WorkflowStage',
    'WorkflowStatus',
    'WorkflowState',
    'StateManager',
    'SanityResult',
    
    # Config
    'Config',
    'LLMConfig',
    'WorkflowConfig',
    'PathConfig',
    'Environment',
    'load_config',
    
    # Prompts
    'PromptBuilder',
    'PromptContext',
    'SYSTEM_PROMPT_PARSING',
    'SYSTEM_PROMPT_CHECK',
    'SYSTEM_PROMPT_VIONAME',
    'SYSTEM_PROMPT_CONTEXT',
    
    # Assembler
    'CodeAssembler',
    'extract_code_from_response',
    
    # Sanity Runner
    'SanityRunner',
    'SanityCheckResult',
    'generate_diff',
]
