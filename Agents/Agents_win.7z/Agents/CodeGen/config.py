#!/usr/bin/env python3
"""
CodeGen Agent - Configuration Management

Handles configuration loading and environment setup.

Author: CodeGen Agent Team
Date: 2026-02-04
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional
from pathlib import Path
from enum import Enum
import yaml
import os


class Environment(Enum):
    """Deployment environment"""
    DEVELOPMENT = "development"
    PRODUCTION = "production"
    TEST = "test"


@dataclass
class LLMConfig:
    """LLM-specific configuration"""
    mode: str = "interactive"  # real | interactive | mock
    provider: str = "gemini"
    model: str = "gemini-2.0-flash"
    api_key_env: str = "GEMINI_API_KEY"
    max_tokens: int = 8000
    
    def get_api_key(self) -> Optional[str]:
        """Get API key from environment"""
        return os.environ.get(self.api_key_env)


@dataclass
class WorkflowConfig:
    """Workflow execution configuration"""
    sanity_max_iterations: int = 3
    validation_max_rollbacks: int = 1
    auto_save_checkpoints: bool = True
    verbose_logging: bool = False


@dataclass
class PathConfig:
    """Directory paths configuration"""
    agents_dir: Path = field(default_factory=lambda: Path("Agents"))
    work_dir: Path = field(default_factory=lambda: Path("Agents/Work"))
    mocks_dir: Path = field(default_factory=lambda: Path("Agents/Work/mocks"))
    templates_dir: Path = field(default_factory=lambda: Path("Agents/CodeGen/templates"))
    outputs_dir: Path = field(default_factory=lambda: Path("Agents/CodeGen/outputs"))


@dataclass
class Config:
    """
    Main configuration container
    
    Loads from config.yaml or uses defaults.
    """
    environment: Environment = Environment.DEVELOPMENT
    llm: LLMConfig = field(default_factory=LLMConfig)
    workflow: WorkflowConfig = field(default_factory=WorkflowConfig)
    paths: PathConfig = field(default_factory=PathConfig)
    
    @classmethod
    def from_yaml(cls, config_path: Path) -> 'Config':
        """Load configuration from YAML file"""
        if not config_path.exists():
            return cls()
        
        with open(config_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f) or {}
        
        return cls.from_dict(data)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Config':
        """Create configuration from dictionary"""
        config = cls()
        
        # Environment
        if 'environment' in data:
            config.environment = Environment(data['environment'])
        
        # LLM config
        if 'llm' in data:
            llm_data = data['llm']
            config.llm = LLMConfig(
                mode=llm_data.get('mode', config.llm.mode),
                provider=llm_data.get('provider', config.llm.provider),
                model=llm_data.get('model', config.llm.model),
                api_key_env=llm_data.get('api_key_env', config.llm.api_key_env),
                max_tokens=llm_data.get('max_tokens', config.llm.max_tokens)
            )
        
        # Workflow config
        if 'workflow' in data:
            wf_data = data['workflow']
            config.workflow = WorkflowConfig(
                sanity_max_iterations=wf_data.get('sanity_max_iterations', 3),
                validation_max_rollbacks=wf_data.get('validation_max_rollbacks', 1),
                auto_save_checkpoints=wf_data.get('auto_save_checkpoints', True),
                verbose_logging=wf_data.get('verbose_logging', False)
            )
        
        # Path config
        if 'paths' in data:
            path_data = data['paths']
            config.paths = PathConfig(
                agents_dir=Path(path_data.get('agents_dir', 'Agents')),
                work_dir=Path(path_data.get('work_dir', 'Agents/Work')),
                mocks_dir=Path(path_data.get('mocks_dir', 'Agents/Work/mocks')),
                templates_dir=Path(path_data.get('templates_dir', 'Agents/CodeGen/templates')),
                outputs_dir=Path(path_data.get('outputs_dir', 'Agents/CodeGen/outputs'))
            )
        
        return config
    
    def validate(self) -> list:
        """
        Validate configuration
        
        Returns list of validation errors (empty if valid)
        """
        errors = []
        
        # Check production restrictions
        if self.environment == Environment.PRODUCTION:
            if self.llm.mode == "mock":
                errors.append("Mock mode is not allowed in production")
        
        # Check API key for real mode
        if self.llm.mode == "real":
            if not self.llm.get_api_key():
                errors.append(
                    f"API key not found. Set {self.llm.api_key_env} environment variable"
                )
        
        return errors
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            'environment': self.environment.value,
            'llm': {
                'mode': self.llm.mode,
                'provider': self.llm.provider,
                'model': self.llm.model,
                'api_key_env': self.llm.api_key_env,
                'max_tokens': self.llm.max_tokens
            },
            'workflow': {
                'sanity_max_iterations': self.workflow.sanity_max_iterations,
                'validation_max_rollbacks': self.workflow.validation_max_rollbacks,
                'auto_save_checkpoints': self.workflow.auto_save_checkpoints,
                'verbose_logging': self.workflow.verbose_logging
            },
            'paths': {
                'agents_dir': str(self.paths.agents_dir),
                'work_dir': str(self.paths.work_dir),
                'mocks_dir': str(self.paths.mocks_dir),
                'templates_dir': str(self.paths.templates_dir),
                'outputs_dir': str(self.paths.outputs_dir)
            }
        }


def load_config(config_path: Optional[Path] = None) -> Config:
    """
    Load configuration with sensible defaults
    
    Searches for config.yaml in standard locations if path not provided.
    """
    if config_path and config_path.exists():
        return Config.from_yaml(config_path)
    
    # Default search paths
    search_paths = [
        Path("Agents/CodeGen/config.yaml"),
        Path("config.yaml"),
        Path.home() / ".codegen_agent" / "config.yaml"
    ]
    
    for path in search_paths:
        if path.exists():
            return Config.from_yaml(path)
    
    # Return defaults
    return Config()
