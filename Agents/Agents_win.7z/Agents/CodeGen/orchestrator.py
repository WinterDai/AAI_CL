#!/usr/bin/env python3
"""
CodeGen Agent - Orchestrator

Main pipeline that coordinates the end-to-end code generation process:
1. Load Specs (ItemSpec, ParsingSpec, FormatSpec)
2. Build Prompts
3. Call LLM
4. Extract Code
5. Assemble Output Files
6. Run Sanity Checks
7. Retry if needed

Author: CodeGen Agent Team
Date: 2026-02-06
"""

import sys
import os
from pathlib import Path
from typing import Dict, Optional, Tuple, List, Any
from dataclasses import dataclass, field
from enum import Enum, auto
import json
import traceback

# Add parent directories to path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from Agents.CodeGen.llm_client import LLMClient, GeminiClient, InteractiveClient, MockClient, JedaiClient, LLMMode
from Agents.CodeGen.prompts import PromptBuilder, PromptContext
from Agents.CodeGen.code_extractor import CodeExtractor
from Agents.CodeGen.spec_converter import FormatSpecConverter
from Agents.CodeGen.assembler import CodeAssembler
from Agents.CodeGen.stage_validator import StageValidator, ValidationResult


class GenerationPhase(Enum):
    """Code generation phases"""
    PARSING = auto()
    CHECK = auto()
    VIONAME = auto()
    CONFIG = auto()
    ASSEMBLY = auto()
    SANITY = auto()


@dataclass
class SpecContext:
    """Container for all specification documents"""
    item_spec: str = ""
    parsing_spec: str = ""
    format_spec: str = ""
    input_samples: str = ""
    
    # Metadata extracted from specs
    item_id: str = ""
    item_desc: str = ""
    check_module: str = ""


@dataclass
class GenerationResult:
    """Result of code generation"""
    success: bool = False
    phase: GenerationPhase = GenerationPhase.PARSING
    
    # Generated code
    parse_code: str = ""
    judge_code: str = ""
    vio_name_code: str = ""
    helper_methods: List[str] = field(default_factory=list)
    
    # Output files
    runner_path: Optional[Path] = None
    logic_path: Optional[Path] = None
    config_path: Optional[Path] = None
    
    # Errors
    error_message: str = ""
    retry_count: int = 0


class Orchestrator:
    """
    Main orchestrator for end-to-end code generation.
    
    Usage:
        orchestrator = Orchestrator(
            work_dir=Path("Agents/Work/IMP_10_0_0_00"),
            llm_mode="interactive"
        )
        result = orchestrator.run()
    """
    
    MAX_RETRIES = 3
    
    def __init__(
        self,
        work_dir: Path,
        llm_mode: str = "interactive",
        api_key: Optional[str] = None,
        mocks_dir: Optional[Path] = None,
        on_phase: Optional[Callable[[str, str, str], None]] = None
    ):
        """
        Initialize orchestrator.
        
        Args:
            work_dir: Working directory containing specs and for output
            llm_mode: LLM mode - "real", "interactive", or "mock"
            api_key: API key for real mode
            mocks_dir: Directory for mock responses
            on_phase: Callback for phase updates (phase, status, message)
        """
        self.work_dir = Path(work_dir)
        self.llm_mode = llm_mode
        self._on_phase = on_phase
        
        # Initialize components
        self.llm_client = self._create_llm_client(llm_mode, api_key, mocks_dir)
        self.prompt_builder = PromptBuilder()
        self.code_extractor = CodeExtractor()
        
        # State
        self.spec_context = SpecContext()
        self.result = GenerationResult()
        
        # Intermediate files directory
        self.debug_dir = self.work_dir / "debug"
        self.debug_dir.mkdir(parents=True, exist_ok=True)
        
        # Stage validator for sanity checks
        self.stage_validator = StageValidator(work_dir=self.work_dir, debug_dir=self.debug_dir)
    
    def _emit(self, phase: str, status: str, message: str):
        """Emit phase update via callback."""
        if self._on_phase:
            self._on_phase(phase, status, message)
    
    def _create_llm_client(
        self,
        mode: str,
        api_key: Optional[str],
        mocks_dir: Optional[Path]
    ) -> LLMClient:
        """Create LLM client based on mode"""
        if mode == "real":
            return GeminiClient(api_key=api_key)
        elif mode == "jedai":
            # Use JEDAI enterprise LLM gateway (like Context Agent)
            return JedaiClient(model="claude-opus-4-5")
        elif mode == "mock":
            if not mocks_dir:
                mocks_dir = self.work_dir / "mocks"
            return MockClient(mocks_dir=mocks_dir)
        else:
            return InteractiveClient()
    
    def load_specs(self) -> bool:
        """
        Load specification files from work directory.
        
        Returns:
            True if all required specs loaded successfully
        """
        spec_files = {
            'item_spec': ['itemspec.md', 'item_spec.md'],
            'parsing_spec': ['parsing_spec.md', 'parsingspec.md'],
            'format_spec': ['format_spec.md', 'formatspec.md'],
        }
        
        for spec_name, filenames in spec_files.items():
            for filename in filenames:
                spec_path = self.work_dir / filename
                if spec_path.exists():
                    content = spec_path.read_text(encoding='utf-8')
                    setattr(self.spec_context, spec_name, content)
                    break
        
        # Load input samples if available
        samples_path = self.work_dir / "input_samples.txt"
        if samples_path.exists():
            self.spec_context.input_samples = samples_path.read_text(encoding='utf-8')
        
        # Extract metadata
        self._extract_metadata()
        
        # Validate required specs
        if not self.spec_context.item_spec:
            self.result.error_message = "ItemSpec not found"
            return False
        
        return True
    
    def _extract_metadata(self):
        """Extract metadata from specs"""
        import re
        
        # Extract Item ID from ItemSpec
        patterns = [
            r'#\s*([\w-]+-\d+-\d+-\d+-\d+)',
            r'Item[:\s]*([\w-]+-\d+-\d+-\d+-\d+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, self.spec_context.item_spec)
            if match:
                self.spec_context.item_id = match.group(1)
                break
        
        # Extract description
        desc_pattern = r'#[^:]+:\s*(.+?)(?:\n|$)'
        match = re.search(desc_pattern, self.spec_context.item_spec)
        if match:
            self.spec_context.item_desc = match.group(1).strip()
        
        # Extract check module
        module_pattern = r'(\d+\.\d+_\w+_CHECK)'
        match = re.search(module_pattern, self.spec_context.item_spec)
        if match:
            self.spec_context.check_module = match.group(1)
    
    def generate_parsing_code(self) -> bool:
        """
        Generate _parse_input_files code using LLM.
        
        Returns:
            True if generation successful
        """
        self.result.phase = GenerationPhase.PARSING
        
        # Set context for prompt builder
        self.prompt_builder.set_context(
            item_spec=self.spec_context.item_spec,
            input_samples=self.spec_context.input_samples,
            parsing_spec=self.spec_context.parsing_spec,
        )
        
        # Build prompts
        system_prompt, user_prompt = self.prompt_builder.build_parsing_prompt()
        
        # Save prompts for debugging
        self._save_debug_file("parsing_system_prompt.txt", system_prompt)
        self._save_debug_file("parsing_user_prompt.txt", user_prompt)
        
        # Call LLM
        try:
            response = self.llm_client.generate(system_prompt, user_prompt)
            self._save_debug_file("parsing_response.txt", response)
            
            # Extract code
            code = self.code_extractor.extract_code(response)
            if not code:
                self.result.error_message = f"Failed to extract parsing code: {self.code_extractor.last_error}"
                return False
            
            # Validate syntax
            is_valid, error = self.code_extractor.validate_syntax(code)
            if not is_valid:
                self.result.error_message = f"Parsing code syntax error: {error}"
                self._save_debug_file("parsing_code_invalid.py", code)
                return False
            
            self.result.parse_code = code
            self._save_debug_file("parsing_code.py", code)
            return True
            
        except Exception as e:
            self.result.error_message = f"LLM error in parsing phase: {str(e)}"
            return False
    
    def generate_check_code(self) -> bool:
        """
        Generate _judge_item code using LLM.
        
        Returns:
            True if generation successful
        """
        self.result.phase = GenerationPhase.CHECK
        
        # Set context for prompt builder (add parsing code as context)
        self.prompt_builder.set_context(
            item_spec=self.spec_context.item_spec,
            parsing_spec=self.spec_context.parsing_spec,
            check_criteria="Item found = PASS, Item not found = FAIL",
        )
        self.prompt_builder.context.accumulate("parsing_code", self.result.parse_code)
        
        # Build prompts
        system_prompt, user_prompt = self.prompt_builder.build_check_prompt()
        
        # Save prompts
        self._save_debug_file("check_system_prompt.txt", system_prompt)
        self._save_debug_file("check_user_prompt.txt", user_prompt)
        
        # Call LLM
        try:
            response = self.llm_client.generate(system_prompt, user_prompt)
            self._save_debug_file("check_response.txt", response)
            
            # Extract code
            code = self.code_extractor.extract_code(response)
            if not code:
                self.result.error_message = f"Failed to extract check code: {self.code_extractor.last_error}"
                return False
            
            # Validate syntax
            is_valid, error = self.code_extractor.validate_syntax(code)
            if not is_valid:
                self.result.error_message = f"Check code syntax error: {error}"
                self._save_debug_file("check_code_invalid.py", code)
                return False
            
            self.result.judge_code = code
            self._save_debug_file("check_code.py", code)
            return True
            
        except Exception as e:
            self.result.error_message = f"LLM error in check phase: {str(e)}"
            return False
    
    def run_parsing_sanity(self) -> bool:
        """
        Run sanity check on parsing code.
        
        Returns:
            True if sanity check passes
        """
        self.result.phase = GenerationPhase.SANITY
        
        # Get test files if available
        test_files = []
        test_input_dir = self.work_dir / "test_input"
        if test_input_dir.exists():
            test_files = list(test_input_dir.glob("*"))
        
        # Validate parsing code
        validation = self.stage_validator.validate_parsing_stage(
            parse_code=self.result.parse_code,
            test_files=test_files if test_files else None
        )
        
        self._save_debug_file("parsing_sanity_result.json", json.dumps({
            "passed": validation.passed,
            "error": validation.error_message,
            "items_count": len(validation.items)
        }, indent=2))
        
        if not validation.passed:
            self.result.error_message = f"Parsing sanity failed: {validation.error_message}"
            return False
        
        return True
    
    def run_check_sanity(self) -> bool:
        """
        Run sanity check on check code.
        
        Returns:
            True if sanity check passes
        """
        self.result.phase = GenerationPhase.SANITY
        
        # Create test items for validation
        test_items = [
            {"name": "test_item_pass", "found": True, "line_number": 1, "file_path": "test.txt"},
            {"name": "test_item_fail", "found": False, "line_number": 2, "file_path": "test.txt"},
        ]
        
        # Validate check code
        validation = self.stage_validator.validate_check_stage(
            check_code=self.result.judge_code,
            test_items=test_items
        )
        
        self._save_debug_file("check_sanity_result.json", json.dumps({
            "passed": validation.passed,
            "error": validation.error_message,
            "results": validation.results
        }, indent=2, default=str))
        
        if not validation.passed:
            self.result.error_message = f"Check sanity failed: {validation.error_message}"
            return False
        
        return True
    
    # =========================================================================
    # Self-Critique Methods (from Context Agent pattern)
    # =========================================================================
    
    def _get_test_files(self) -> List[Path]:
        """Get test files for validation."""
        test_files = []
        test_input_dir = self.work_dir / "test_input"
        if test_input_dir.exists():
            test_files = list(test_input_dir.glob("*"))
        return test_files
    
    def generate_parsing_code_with_feedback(self, max_retries: int = 2) -> bool:
        """
        Generate _parse_input_files code using LLM with self-critique loop.
        
        Implements the Context Agent pattern: validation failures are formatted
        and appended to the prompt for retry, giving LLM explicit feedback.
        
        Args:
            max_retries: Maximum retry attempts (default 2)
            
        Returns:
            True if generation successful
        """
        self.result.phase = GenerationPhase.PARSING
        
        # Set context for prompt builder
        self.prompt_builder.set_context(
            item_spec=self.spec_context.item_spec,
            input_samples=self.spec_context.input_samples,
            parsing_spec=self.spec_context.parsing_spec,
        )
        
        # Build base prompts
        system_prompt, base_user_prompt = self.prompt_builder.build_parsing_prompt()
        current_user_prompt = base_user_prompt
        
        # Get test files for validation
        test_files = self._get_test_files()
        
        for attempt in range(max_retries + 1):
            attempt_num = attempt + 1
            self._save_debug_file(f"parsing_attempt{attempt_num}_user_prompt.txt", current_user_prompt)
            
            try:
                response = self.llm_client.generate(system_prompt, current_user_prompt)
                self._save_debug_file(f"parsing_attempt{attempt_num}_response.txt", response)
                
                # Extract code
                code = self.code_extractor.extract_code(response)
                if not code:
                    error_msg = f"Failed to extract code: {self.code_extractor.last_error}"
                    if attempt < max_retries:
                        feedback = f"## RETRY - Code Extraction Failed\n\n{error_msg}\n\nPlease output ONLY valid Python code in a ```python block."
                        current_user_prompt = base_user_prompt + "\n\n" + feedback
                        self._save_debug_file(f"parsing_attempt{attempt_num}_feedback.md", feedback)
                        continue
                    self.result.error_message = error_msg
                    return False
                
                # Validate with structured feedback
                validation = self.stage_validator.validate_parsing_stage(
                    parse_code=code,
                    test_files=test_files if test_files else None
                )
                
                self._save_debug_file(f"parsing_attempt{attempt_num}_validation.json", json.dumps({
                    "passed": validation.passed,
                    "error": validation.error_message,
                    "checked_items": [(n, p, d) for n, p, d in validation.checked_items],
                }, indent=2, default=str))
                
                if validation.passed:
                    self.result.parse_code = code
                    self._save_debug_file("parsing_code_final.py", code)
                    return True
                
                # Validation failed - prepare feedback for retry
                if attempt < max_retries:
                    feedback = validation.format_for_llm_feedback()
                    current_user_prompt = base_user_prompt + "\n\n" + feedback
                    self._save_debug_file(f"parsing_attempt{attempt_num}_feedback.md", feedback)
                else:
                    self.result.error_message = validation.error_message
                    
            except Exception as e:
                self.result.error_message = f"LLM error in parsing phase: {str(e)}"
                if attempt >= max_retries:
                    return False
        
        return False
    
    def generate_check_code_with_feedback(self, max_retries: int = 2) -> bool:
        """
        Generate _judge_item code using LLM with self-critique loop.
        
        Args:
            max_retries: Maximum retry attempts (default 2)
            
        Returns:
            True if generation successful
        """
        self.result.phase = GenerationPhase.CHECK
        
        # Set context for prompt builder (add parsing code as context)
        self.prompt_builder.set_context(
            item_spec=self.spec_context.item_spec,
            parsing_spec=self.spec_context.parsing_spec,
            check_criteria="Item found = PASS, Item not found = FAIL",
        )
        self.prompt_builder.context.accumulate("parsing_code", self.result.parse_code)
        
        # Build base prompts
        system_prompt, base_user_prompt = self.prompt_builder.build_check_prompt()
        current_user_prompt = base_user_prompt
        
        # Create test items for validation
        test_items = [
            {"name": "test_item_pass", "found": True, "line_number": 1, "file_path": "test.txt"},
            {"name": "test_item_fail", "found": False, "line_number": 2, "file_path": "test.txt"},
        ]
        
        for attempt in range(max_retries + 1):
            attempt_num = attempt + 1
            self._save_debug_file(f"check_attempt{attempt_num}_user_prompt.txt", current_user_prompt)
            
            try:
                response = self.llm_client.generate(system_prompt, current_user_prompt)
                self._save_debug_file(f"check_attempt{attempt_num}_response.txt", response)
                
                # Extract code
                code = self.code_extractor.extract_code(response)
                if not code:
                    error_msg = f"Failed to extract code: {self.code_extractor.last_error}"
                    if attempt < max_retries:
                        feedback = f"## RETRY - Code Extraction Failed\n\n{error_msg}\n\nPlease output ONLY valid Python code in a ```python block."
                        current_user_prompt = base_user_prompt + "\n\n" + feedback
                        continue
                    self.result.error_message = error_msg
                    return False
                
                # Validate with structured feedback
                validation = self.stage_validator.validate_check_stage(
                    check_code=code,
                    test_items=test_items
                )
                
                self._save_debug_file(f"check_attempt{attempt_num}_validation.json", json.dumps({
                    "passed": validation.passed,
                    "error": validation.error_message,
                    "checked_items": [(n, p, d) for n, p, d in validation.checked_items],
                }, indent=2, default=str))
                
                if validation.passed:
                    self.result.judge_code = code
                    self._save_debug_file("check_code_final.py", code)
                    return True
                
                # Validation failed - prepare feedback for retry
                if attempt < max_retries:
                    feedback = validation.format_for_llm_feedback()
                    current_user_prompt = base_user_prompt + "\n\n" + feedback
                    self._save_debug_file(f"check_attempt{attempt_num}_feedback.md", feedback)
                else:
                    self.result.error_message = validation.error_message
                    
            except Exception as e:
                self.result.error_message = f"LLM error in check phase: {str(e)}"
                if attempt >= max_retries:
                    return False
        
        return False

    def generate_config(self) -> bool:
        """
        Generate imp_config.py from FormatSpec.
        
        Returns:
            True if generation successful
        """
        self.result.phase = GenerationPhase.CONFIG
        
        format_spec_path = self.work_dir / "format_spec.md"
        if not format_spec_path.exists():
            # Use defaults
            format_spec_path = self.work_dir / "formatspec.md"
        
        try:
            converter = FormatSpecConverter(format_spec_path)
            config_code = converter.generate_config_file()
            
            self._save_debug_file("config_generated.py", config_code)
            return True
            
        except Exception as e:
            self.result.error_message = f"Config generation error: {str(e)}"
            return False
    
    def assemble_output(self) -> bool:
        """
        Assemble final output files.
        
        Returns:
            True if assembly successful
        """
        self.result.phase = GenerationPhase.ASSEMBLY
        
        try:
            # Create assembler
            assembler = CodeAssembler(
                item_id=self.spec_context.item_id,
                item_desc=self.spec_context.item_desc,
                check_module=self.spec_context.check_module
            )
            
            # Set generated code
            assembler.set_parse_code(self.result.parse_code)
            assembler.set_judge_code(self.result.judge_code)
            # Set default vioname code (will be overridden by imp_config.py in three-file mode)
            assembler.set_vioname_code('''def _build_vio_name(self, item: Dict) -> str:
        """Build violation name from item for pattern matching."""
        return item.get('name', str(item))''')
            
            # Generate runner
            runner_code = assembler.assemble(mode='runner')
            runner_path = self.work_dir / "universal_runner.py"
            runner_path.write_text(runner_code, encoding='utf-8')
            self.result.runner_path = runner_path
            
            # Generate logic file
            logic_code = assembler.assemble(mode='logic')
            logic_path = self.work_dir / "imp_logic.py"
            logic_path.write_text(logic_code, encoding='utf-8')
            self.result.logic_path = logic_path
            
            # Generate config file
            format_spec_path = self.work_dir / "format_spec.md"
            converter = FormatSpecConverter(format_spec_path)
            config_path = self.work_dir / "imp_config.py"
            converter.save_config_file(config_path)
            self.result.config_path = config_path
            
            return True
            
        except Exception as e:
            self.result.error_message = f"Assembly error: {str(e)}\n{traceback.format_exc()}"
            return False
    
    def run_sanity_check(self) -> bool:
        """
        Run sanity check on generated code.
        
        Returns:
            True if sanity check passes
        """
        self.result.phase = GenerationPhase.SANITY
        
        # Basic syntax check
        for path in [self.result.logic_path, self.result.config_path]:
            if path and path.exists():
                code = path.read_text(encoding='utf-8')
                is_valid, error = self.code_extractor.validate_syntax(code)
                if not is_valid:
                    self.result.error_message = f"Sanity check failed for {path.name}: {error}"
                    return False
        
        # TODO: Run actual tests against test configs
        return True
    
    def run(self) -> GenerationResult:
        """
        Run the full code generation pipeline with self-critique.
        
        Uses the Context Agent pattern: validation failures are formatted
        as structured feedback and appended to retry prompts.
        
        Returns:
            GenerationResult with success status and outputs
        """
        self._emit("codegen", "starting", f"Starting generation for {self.work_dir.name}")
        
        # Step 1: Load specs
        self._emit("step1_load", "running", "Loading specifications...")
        if not self.load_specs():
            self._emit("step1_load", "failed", f"Failed: {self.result.error_message}")
            return self.result
        self._emit("step1_load", "success", f"Loaded specs for {self.spec_context.item_id}")
        
        # Step 2: Generate parsing code (with internal self-critique loop)
        self._emit("step2_parsing", "running", "Generating parsing code with self-critique...")
        if not self.generate_parsing_code_with_feedback(max_retries=self.MAX_RETRIES - 1):
            self._emit("step2_parsing", "failed", f"Failed: {self.result.error_message}")
            return self.result
        self._emit("step2_parsing", "success", "Parsing code generated")
        
        # Step 3: Generate check code (with internal self-critique loop)
        self._emit("step3_check", "running", "Generating check code with self-critique...")
        if not self.generate_check_code_with_feedback(max_retries=self.MAX_RETRIES - 1):
            self._emit("step3_check", "failed", f"Failed: {self.result.error_message}")
            return self.result
        self._emit("step3_check", "success", "Check code generated")
        
        # Step 4: Generate config
        self._emit("step4_config", "running", "Generating config from FormatSpec...")
        if not self.generate_config():
            self._emit("step4_config", "warning", f"Warning: {self.result.error_message}")
            # Continue anyway with defaults
        else:
            self._emit("step4_config", "success", "Config generated")
        
        # Step 5: Assemble output
        self._emit("step5_assemble", "running", "Assembling output files...")
        if not self.assemble_output():
            self._emit("step5_assemble", "failed", f"Failed: {self.result.error_message}")
            return self.result
        self._emit("step5_assemble", "success", f"Assembled: {self.result.runner_path.name}, {self.result.logic_path.name}, {self.result.config_path.name}")
        
        # Step 6: Final Sanity check
        self._emit("step6_final", "running", "Running final sanity check...")
        if not self.run_sanity_check():
            self._emit("step6_final", "failed", f"Failed: {self.result.error_message}")
            return self.result
        self._emit("step6_final", "success", "Final sanity check passed")
        
        # Success!
        self.result.success = True
        self._emit("codegen", "complete", f"Generation completed successfully. Output: {self.result.runner_path.name}")
        
        return self.result
    
    def run_legacy(self) -> GenerationResult:
        """
        Legacy run method with blind retries (preserved for comparison).
        """
        self._emit("codegen", "starting", f"Starting generation for {self.work_dir.name}")
        
        # Step 1: Load specs
        self._emit("step1_load", "running", "Loading specifications...")
        if not self.load_specs():
            self._emit("step1_load", "failed", f"Failed: {self.result.error_message}")
            return self.result
        self._emit("step1_load", "success", f"Loaded specs for {self.spec_context.item_id}")
        
        # Retry loop for Parsing phase
        parsing_success = False
        for parsing_retry in range(self.MAX_RETRIES):
            # Step 2: Generate parsing code
            self._emit("step2_parsing", "running", f"Generating parsing code (attempt {parsing_retry + 1})")
            if not self.generate_parsing_code():
                self._emit("step2_parsing", "failed", f"Failed: {self.result.error_message}")
                if parsing_retry < self.MAX_RETRIES - 1:
                    self._emit("step2_parsing", "retrying", "Retrying parsing...")
                    continue
                return self.result
            self._emit("step2_parsing", "success", "Parsing code generated")
            
            # Step 3: Parsing Sanity Check
            self._emit("step3_sanity", "running", "Running parsing sanity check...")
            if not self.run_parsing_sanity():
                self._emit("step3_sanity", "failed", f"Failed: {self.result.error_message}")
                if parsing_retry < self.MAX_RETRIES - 1:
                    self._emit("step3_sanity", "retrying", "Retrying parsing...")
                    continue
                return self.result
            self._emit("step3_sanity", "success", "Parsing sanity passed")
            parsing_success = True
            break
        
        if not parsing_success:
            return self.result
        
        # Retry loop for Check phase
        check_success = False
        for check_retry in range(self.MAX_RETRIES):
            # Step 4: Generate check code
            self._emit("step4_check", "running", f"Generating check code (attempt {check_retry + 1})")
            if not self.generate_check_code():
                self._emit("step4_check", "failed", f"Failed: {self.result.error_message}")
                if check_retry < self.MAX_RETRIES - 1:
                    self._emit("step4_check", "retrying", "Retrying check...")
                    continue
                return self.result
            self._emit("step4_check", "success", "Check code generated")
            
            # Step 5: Check Sanity
            self._emit("step5_sanity", "running", "Running check sanity check...")
            if not self.run_check_sanity():
                self._emit("step5_sanity", "failed", f"Failed: {self.result.error_message}")
                if check_retry < self.MAX_RETRIES - 1:
                    self._emit("step5_sanity", "retrying", "Retrying check...")
                    continue
                return self.result
            self._emit("step5_sanity", "success", "Check sanity passed")
            check_success = True
            break
        
        if not check_success:
            return self.result
        
        # Step 6: Generate config
        self._emit("step6_config", "running", "Generating config from FormatSpec...")
        if not self.generate_config():
            self._emit("step6_config", "warning", f"Warning: {self.result.error_message}")
            # Continue anyway with defaults
        else:
            self._emit("step6_config", "success", "Config generated")
        
        # Step 7: Assemble output
        self._emit("step7_assemble", "running", "Assembling output files...")
        if not self.assemble_output():
            self._emit("step7_assemble", "failed", f"Failed: {self.result.error_message}")
            return self.result
        self._emit("step7_assemble", "success", f"Assembled: {self.result.runner_path.name}, {self.result.logic_path.name}, {self.result.config_path.name}")
        
        # Step 8: Final Sanity check
        self._emit("step8_final", "running", "Running final sanity check...")
        if not self.run_sanity_check():
            self._emit("step8_final", "failed", f"Failed: {self.result.error_message}")
            return self.result
        self._emit("step8_final", "success", "Final sanity check passed")
        
        # Success!
        self.result.success = True
        
        self._emit("codegen", "complete", f"Generation completed successfully. Output: {self.result.runner_path.name}")
        
        return self.result
    
    def _save_debug_file(self, filename: str, content: str):
        """Save intermediate file for debugging"""
        filepath = self.debug_dir / filename
        filepath.write_text(content, encoding='utf-8')


def main():
    """CLI entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description='CodeGen Agent Orchestrator')
    parser.add_argument('work_dir', help='Working directory with specs')
    parser.add_argument('--mode', choices=['real', 'interactive', 'mock', 'jedai'],
                       default='interactive', help='LLM mode (jedai recommended for enterprise)')
    parser.add_argument('--api-key', help='API key for real mode')
    args = parser.parse_args()
    
    print(f"[CodeGen Agent] LLM Mode: {args.mode}")
    
    orchestrator = Orchestrator(
        work_dir=Path(args.work_dir),
        llm_mode=args.mode,
        api_key=args.api_key
    )
    
    result = orchestrator.run()
    
    # Save result summary
    result_summary = {
        'success': result.success,
        'phase': result.phase.name,
        'retry_count': result.retry_count,
        'error_message': result.error_message,
        'outputs': {
            'runner': str(result.runner_path) if result.runner_path else None,
            'logic': str(result.logic_path) if result.logic_path else None,
            'config': str(result.config_path) if result.config_path else None,
        }
    }
    
    summary_path = Path(args.work_dir) / "generation_result.json"
    summary_path.write_text(json.dumps(result_summary, indent=2), encoding='utf-8')
    
    print(json.dumps(result_summary, indent=2))
    
    return 0 if result.success else 1


if __name__ == "__main__":
    sys.exit(main())
