#!/usr/bin/env python3
"""
CodeGen Agent - Prompt Templates

System and user prompt templates for code generation stages.
Uses Progressive Context strategy as per design document.

Author: CodeGen Agent Team
Date: 2026-02-04
"""

from dataclasses import dataclass
from typing import Dict, Any, Optional
from pathlib import Path


# ═══════════════════════════════════════════════════════════════════════════════
# System Prompt Templates
# ═══════════════════════════════════════════════════════════════════════════════

SYSTEM_PROMPT_PARSING = """You are a code generation expert specializing in file parsing.

Your task is to generate Python code that parses input files and extracts structured data.

CONSTRAINTS:
1. Output ONLY valid Python code, no explanations
2. The function must be named `_parse_input_files`
3. Return type: List[Dict] where each dict contains:
   - line_number: int (source line for error reporting)
   - file_path: str (source file path)
   - Additional fields as needed for check logic
4. Handle file encoding (utf-8 with errors='ignore')
5. Handle both regular and gzip-compressed files if applicable
6. Use regex for pattern matching when appropriate

CODE TEMPLATE:
```python
def _parse_input_files(self, input_files: List[Path]) -> List[Dict]:
    items = []
    for file_path in input_files:
        # Your parsing logic here
        pass
    return items
```
"""

SYSTEM_PROMPT_CHECK = """You are a code generation expert specializing in validation logic.

Your task is to generate Python code that determines if an item passes or fails a check.

CONSTRAINTS:
1. Output ONLY valid Python code, no explanations
2. The function must be named `_judge_item`
3. Accept a single Dict parameter (item)
4. Return bool: True = PASS, False = FAIL
5. Use only fields populated by _parse_input_files

CODE TEMPLATE:
```python
def _judge_item(self, item: Dict) -> bool:
    # Your check logic here
    return item.get('is_valid', False)
```
"""

SYSTEM_PROMPT_VIONAME = """You are a code generation expert specializing in string formatting.

Your task is to generate Python code that creates a matching string for pattern/waiver matching.

CONSTRAINTS:
1. Output ONLY valid Python code, no explanations
2. The function must be named `_build_vio_name`
3. Accept a single Dict parameter (item)
4. Return str: formatted matching string
5. Include relevant fields that identify the item uniquely
6. Match the format expected by pattern_items and waive_items

CODE TEMPLATE:
```python
def _build_vio_name(self, item: Dict) -> str:
    return f"<format string using item fields>"
```
"""

SYSTEM_PROMPT_CONTEXT = """You are a semantic analysis expert for design verification checkers.

Your task is to analyze item specifications and generate structured context.

OUTPUT FORMAT (Markdown):
1. Item Overview section
2. Input File Analysis section  
3. Parsing Strategy section
4. Check Logic section
5. Output Format section

Be precise and technical. Include regex patterns and data structures.
"""


# ═══════════════════════════════════════════════════════════════════════════════
# User Prompt Templates
# ═══════════════════════════════════════════════════════════════════════════════

USER_PROMPT_PARSING = """Generate parsing code for the following checker:

## Item Specification
{item_spec}

## Input File Samples
{input_samples}

## Context Analysis
{parsing_spec}

Generate the `_parse_input_files` method implementation.
Output ONLY the function body code (no class wrapper).
"""

USER_PROMPT_CHECK = """Generate check logic for the following checker:

## Item Specification
{item_spec}

## Parsing Spec (fields available in each item)
{parsing_spec}

## Check Criteria
{check_criteria}

Generate the `_judge_item` method implementation.
Output ONLY the function body code.
"""

USER_PROMPT_VIONAME = """Generate violation name builder for the following checker:

## Item Specification
{item_spec}

## Parsed Item Fields
{item_fields}

## Pattern/Waiver Format Examples
{pattern_examples}

Generate the `_build_vio_name` method implementation.
Output ONLY the function body code.
"""

USER_PROMPT_CONTEXT_PARSING = """Analyze the input file format for this checker:

## Item Specification
{item_spec}

## Sample Input Files
{input_samples}

Generate a parsing_spec.md that describes:
1. File format and structure
2. Key patterns to extract (with regex)
3. Fields to capture and their types
4. Edge cases to handle
"""

USER_PROMPT_CONTEXT_FORMAT = """Analyze the output format for this checker:

## Item Specification  
{item_spec}

## Parsing Spec
{parsing_spec}

## Example Patterns/Waivers
{pattern_examples}

Generate a format_spec.md that describes:
1. Violation name format
2. How items map to patterns
3. Waiver matching strategy
"""


# ═══════════════════════════════════════════════════════════════════════════════
# Prompt Builder Class
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class PromptContext:
    """Context data for prompt generation"""
    item_spec: str = ""
    input_samples: str = ""
    parsing_spec: str = ""
    format_spec: str = ""
    check_criteria: str = ""
    item_fields: str = ""
    pattern_examples: str = ""
    
    # Progressive context accumulator
    accumulated_context: str = ""
    
    def accumulate(self, key: str, value: str):
        """Add to accumulated context (Progressive Context strategy)"""
        self.accumulated_context += f"\n\n## {key}\n{value}"


class PromptBuilder:
    """
    Builds prompts using Progressive Context strategy
    
    Each stage receives context from previous stages.
    """
    
    def __init__(self, context: Optional[PromptContext] = None):
        self.context = context or PromptContext()
    
    def build_parsing_prompt(self) -> tuple:
        """Build prompts for parsing code generation"""
        user_prompt = USER_PROMPT_PARSING.format(
            item_spec=self.context.item_spec,
            input_samples=self.context.input_samples,
            parsing_spec=self.context.parsing_spec
        )
        return SYSTEM_PROMPT_PARSING, user_prompt
    
    def build_check_prompt(self) -> tuple:
        """Build prompts for check logic generation"""
        user_prompt = USER_PROMPT_CHECK.format(
            item_spec=self.context.item_spec,
            parsing_spec=self.context.parsing_spec,
            check_criteria=self.context.check_criteria
        )
        return SYSTEM_PROMPT_CHECK, user_prompt
    
    def build_vioname_prompt(self) -> tuple:
        """Build prompts for violation name generation"""
        user_prompt = USER_PROMPT_VIONAME.format(
            item_spec=self.context.item_spec,
            item_fields=self.context.item_fields,
            pattern_examples=self.context.pattern_examples
        )
        return SYSTEM_PROMPT_VIONAME, user_prompt
    
    def build_context_parsing_prompt(self) -> tuple:
        """Build prompts for context agent parsing spec"""
        user_prompt = USER_PROMPT_CONTEXT_PARSING.format(
            item_spec=self.context.item_spec,
            input_samples=self.context.input_samples
        )
        return SYSTEM_PROMPT_CONTEXT, user_prompt
    
    def build_context_format_prompt(self) -> tuple:
        """Build prompts for context agent format spec"""
        user_prompt = USER_PROMPT_CONTEXT_FORMAT.format(
            item_spec=self.context.item_spec,
            parsing_spec=self.context.parsing_spec,
            pattern_examples=self.context.pattern_examples
        )
        return SYSTEM_PROMPT_CONTEXT, user_prompt
    
    def set_context(self, **kwargs):
        """Update context fields"""
        for key, value in kwargs.items():
            if hasattr(self.context, key):
                setattr(self.context, key, value)
                self.context.accumulate(key, value)
