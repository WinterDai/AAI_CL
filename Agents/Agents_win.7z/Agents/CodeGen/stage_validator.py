#!/usr/bin/env python3
"""
CodeGen Agent - Stage Validator

Validates LLM-generated code at each stage before proceeding.
Implements atomic unit validation as per architecture design.

Author: CodeGen Agent Team
Date: 2026-02-06
"""

import sys
import os
import re
import ast
import json
import tempfile
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field


@dataclass
class ValidationResult:
    """Result of a validation step with LLM feedback capability"""
    passed: bool = False
    error_message: str = ""
    items: List[Dict] = field(default_factory=list)
    results: List[Dict] = field(default_factory=list)
    output: str = ""
    
    # Structured checks for detailed feedback (like Context Agent)
    checked_items: List[Tuple[str, bool, str]] = field(default_factory=list)
    # Each tuple: (check_name, passed, detail)
    
    def format_for_llm_feedback(self) -> str:
        """
        Format validation results for LLM retry feedback.
        
        This implements the self-critique pattern from Context Agent,
        allowing the LLM to see what checks passed/failed and fix issues.
        """
        lines = ["## VALIDATION FAILED - Please Fix\n"]
        
        # Show all checked items with pass/fail status
        if self.checked_items:
            lines.append(f"### Checked Items ({len(self.checked_items)} total)\n")
            for check_name, passed, detail in self.checked_items:
                status = "✓" if passed else "✗"
                lines.append(f"- {status} **{check_name}**: {detail}")
        
        # Highlight specific error
        if self.error_message:
            lines.append("\n### Error Details\n")
            lines.append(f"- ✗ {self.error_message}")
        
        lines.append("\n### Your Task")
        lines.append("Fix the issues marked with ✗ and regenerate the complete code.")
        lines.append("Ensure the code follows the exact function signature specified in the system prompt.")
        lines.append("Output ONLY the corrected Python code in a ```python block.")
        
        return "\n".join(lines)


class StageValidator:
    """
    Validates LLM-generated code at each generation stage.
    
    Implements:
    - Parsing stage validation (run with test data)
    - Check stage validation (run with parsed items)
    - Full integration validation
    """
    
    def __init__(self, work_dir: Path, debug_dir: Optional[Path] = None):
        """
        Initialize stage validator.
        
        Args:
            work_dir: Working directory with test data
            debug_dir: Directory for debug output
        """
        self.work_dir = Path(work_dir)
        self.debug_dir = debug_dir or self.work_dir / "debug"
        self.debug_dir.mkdir(parents=True, exist_ok=True)
    
    def validate_parsing_stage(
        self,
        parse_code: str,
        test_files: Optional[List[Path]] = None
    ) -> ValidationResult:
        """
        Validate parsing stage code with structured checks for LLM feedback.
        
        Args:
            parse_code: The _parse_input_files function code
            test_files: Optional test input files
            
        Returns:
            ValidationResult with parsing results and checked_items for feedback
        """
        result = ValidationResult()
        
        # Check 1: Syntax validation
        is_valid, error = self._validate_syntax(parse_code)
        if is_valid:
            result.checked_items.append(("Python Syntax", True, "Valid Python code"))
        else:
            result.checked_items.append(("Python Syntax", False, f"Syntax error: {error}"))
            result.error_message = f"Syntax error: {error}"
            return result
        
        # Check 2: Function name
        if '_parse_input_files' in parse_code:
            result.checked_items.append(("Function Name", True, "Found _parse_input_files"))
        else:
            result.checked_items.append(("Function Name", False, "Expected function named _parse_input_files"))
            result.error_message = "Missing required function: _parse_input_files"
            return result
        
        # Check 3: Return statement
        if 'return' in parse_code:
            result.checked_items.append(("Return Statement", True, "Has return statement"))
        else:
            result.checked_items.append(("Return Statement", False, "No return statement found"))
            result.error_message = "Missing return statement"
            return result
        
        # Check 4: Try to execute with test data if available
        if test_files:
            exec_result = self._execute_parsing(parse_code, test_files)
            if exec_result.passed:
                result.checked_items.append(("Test Execution", True, f"Parsed {len(exec_result.items)} items successfully"))
                result.items = exec_result.items
            else:
                result.checked_items.append(("Test Execution", False, exec_result.error_message))
                result.error_message = exec_result.error_message
                return result
        else:
            result.checked_items.append(("Test Execution", True, "Skipped (no test files available)"))
        
        # Check 5: Validate output structure
        if result.items:
            validation_errors = self._validate_item_structure(result.items)
            if validation_errors:
                result.error_message = f"Item structure errors: {validation_errors}"
                return result
        
        result.passed = True
        return result
    
    def validate_check_stage(
        self,
        check_code: str,
        test_items: Optional[List[Dict]] = None
    ) -> ValidationResult:
        """
        Validate check stage code with structured checks for LLM feedback.
        
        Args:
            check_code: The _judge_item function code
            test_items: Optional test items to validate against
            
        Returns:
            ValidationResult with check results and checked_items for feedback
        """
        result = ValidationResult()
        
        # Check 1: Syntax validation
        is_valid, error = self._validate_syntax(check_code)
        if is_valid:
            result.checked_items.append(("Python Syntax", True, "Valid Python code"))
        else:
            result.checked_items.append(("Python Syntax", False, f"Syntax error: {error}"))
            result.error_message = f"Syntax error: {error}"
            return result
        
        # Check 2: Function name
        if '_judge_item' in check_code:
            result.checked_items.append(("Function Name", True, "Found _judge_item"))
        else:
            result.checked_items.append(("Function Name", False, "Expected function named _judge_item"))
            result.error_message = "Missing required function: _judge_item"
            return result
        
        # Check 3: Return type (should be bool)
        if 'return True' in check_code or 'return False' in check_code or 'return ' in check_code:
            result.checked_items.append(("Return Statement", True, "Has boolean return"))
        else:
            result.checked_items.append(("Return Statement", False, "Missing return statement"))
            result.error_message = "Missing return statement"
            return result
        
        # Check 4: Execute with test items if available
        if test_items:
            exec_result = self._execute_check(check_code, test_items)
            if exec_result.passed:
                result.checked_items.append(("Test Execution", True, f"Tested {len(test_items)} items"))
                result.results = exec_result.results
            else:
                result.checked_items.append(("Test Execution", False, exec_result.error_message))
                result.error_message = exec_result.error_message
                return result
        else:
            result.checked_items.append(("Test Execution", True, "Skipped (no test items available)"))
        
        result.passed = True
        return result
    
    def validate_full_integration(
        self,
        runner_path: Path,
        logic_path: Path,
        config_path: Path,
        item_config_path: Path
    ) -> ValidationResult:
        """
        Validate full integration by running the checker.
        
        Args:
            runner_path: Path to universal_runner.py
            logic_path: Path to imp_logic.py
            config_path: Path to imp_config.py
            item_config_path: Path to item.yaml test config
            
        Returns:
            ValidationResult with execution results
        """
        result = ValidationResult()
        
        # Check all files exist
        for path in [runner_path, logic_path, config_path, item_config_path]:
            if not path.exists():
                result.error_message = f"File not found: {path}"
                return result
        
        # Run the checker
        try:
            cmd = [
                sys.executable,
                str(runner_path),
                '--logic', str(logic_path),
                '--checker-config', str(config_path),
                '--config', str(item_config_path)
            ]
            
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            result.output = proc.stdout
            
            if proc.returncode != 0:
                result.error_message = f"Execution failed: {proc.stderr}"
                self._save_debug("integration_stderr.txt", proc.stderr)
                return result
            
            # Try to parse JSON output
            try:
                output_data = json.loads(proc.stdout)
                result.results = [output_data]
            except json.JSONDecodeError:
                # Non-JSON output is acceptable
                pass
            
            result.passed = True
            self._save_debug("integration_stdout.txt", proc.stdout)
            
        except subprocess.TimeoutExpired:
            result.error_message = "Execution timed out (30s)"
        except Exception as e:
            result.error_message = f"Execution error: {str(e)}"
        
        return result
    
    def _validate_syntax(self, code: str) -> Tuple[bool, Optional[str]]:
        """Validate Python syntax"""
        try:
            ast.parse(code)
            return True, None
        except SyntaxError as e:
            return False, f"Line {e.lineno}: {e.msg}"
    
    def _validate_item_structure(self, items: List[Dict]) -> List[str]:
        """Validate that items have required fields"""
        errors = []
        required_fields = ['line_number', 'file_path']
        
        for i, item in enumerate(items):
            for field in required_fields:
                if field not in item:
                    errors.append(f"Item {i}: missing '{field}'")
        
        return errors
    
    def _execute_parsing(
        self,
        parse_code: str,
        test_files: List[Path]
    ) -> ValidationResult:
        """Execute parsing code with test files"""
        result = ValidationResult()
        
        # Create a test script
        test_script = f'''
import sys
import re
import json
from pathlib import Path

{parse_code}

# Create a mock self object
class MockSelf:
    pass

self_obj = MockSelf()

# Get the function
import types
for name, obj in list(globals().items()):
    if callable(obj) and 'parse' in name.lower():
        if isinstance(obj, types.FunctionType):
            # Bind to mock self
            bound_func = lambda files, fn=obj: fn(None, files)
            break
else:
    # Try direct call
    bound_func = lambda files: _parse_input_files(None, files)

# Run with test files
test_files = {[str(f) for f in test_files]}
try:
    items = bound_func([Path(f) for f in test_files])
    print(json.dumps({{"success": True, "items": items}}, default=str))
except Exception as e:
    print(json.dumps({{"success": False, "error": str(e)}}))
'''
        
        try:
            proc = subprocess.run(
                [sys.executable, '-c', test_script],
                capture_output=True,
                text=True,
                timeout=10,
                cwd=str(self.work_dir)
            )
            
            if proc.returncode != 0:
                result.error_message = f"Parse execution failed: {proc.stderr}"
                return result
            
            output = json.loads(proc.stdout)
            if output.get('success'):
                result.passed = True
                result.items = output.get('items', [])
            else:
                result.error_message = output.get('error', 'Unknown error')
                
        except Exception as e:
            result.error_message = f"Parse test error: {str(e)}"
        
        return result
    
    def _execute_check(
        self,
        check_code: str,
        test_items: List[Dict]
    ) -> ValidationResult:
        """Execute check code with test items"""
        result = ValidationResult()
        
        test_script = f'''
import sys
import re
import json

{check_code}

# Get the function
import types
for name, obj in list(globals().items()):
    if callable(obj) and 'judge' in name.lower():
        if isinstance(obj, types.FunctionType):
            judge_func = lambda item, fn=obj: fn(None, item)
            break
else:
    judge_func = lambda item: _judge_item(None, item)

# Run with test items (parse from JSON to handle boolean values correctly)
test_items_json = """{json.dumps(test_items)}"""
test_items = json.loads(test_items_json)
results = []
for item in test_items:
    try:
        passed = judge_func(item)
        results.append({{"item": item, "passed": passed}})
    except Exception as e:
        results.append({{"item": item, "error": str(e)}})

print(json.dumps({{"success": True, "results": results}}, default=str))
'''
        
        try:
            proc = subprocess.run(
                [sys.executable, '-c', test_script],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if proc.returncode != 0:
                result.error_message = f"Check execution failed: {proc.stderr}"
                return result
            
            output = json.loads(proc.stdout)
            if output.get('success'):
                result.passed = True
                result.results = output.get('results', [])
            else:
                result.error_message = output.get('error', 'Unknown error')
                
        except Exception as e:
            result.error_message = f"Check test error: {str(e)}"
        
        return result
    
    def _save_debug(self, filename: str, content: str):
        """Save debug file"""
        filepath = self.debug_dir / filename
        filepath.write_text(content, encoding='utf-8')
