#!/usr/bin/env python3
"""
CodeGen Agent - FormatSpec to Config Converter

Converts FormatSpec markdown files to Python config files (imp_config.py).

Author: CodeGen Agent Team
Date: 2026-02-06
"""

import re
from pathlib import Path
from typing import Dict, Optional, Any
from dataclasses import dataclass
import yaml


@dataclass
class ScenarioConfig:
    """Configuration for a single scenario"""
    found_desc: str = ""
    missing_spec: str = ""
    waived_desc: str = ""
    unused_desc: str = ""
    found_reason: str = ""
    missing_reason: str = ""
    waived_reason: str = ""
    unused_reason: str = ""


class FormatSpecConverter:
    """
    Convert FormatSpec markdown to imp_config.py Python file.
    
    FormatSpec contains:
    - SCENARIO_CONFIG definitions
    - Violation name format
    - Item metadata
    """
    
    def __init__(self, format_spec_path: Path):
        self.format_spec_path = Path(format_spec_path)
        self.content = ""
        self._format_schema: Dict[str, Any] = {}
        self._load_spec()
        self._format_schema = self._extract_embedded_format_schema()
    
    def _load_spec(self):
        """Load FormatSpec content"""
        if self.format_spec_path.exists():
            self.content = self.format_spec_path.read_text(encoding='utf-8')

    def _extract_embedded_format_schema(self) -> Dict[str, Any]:
        """Extract `format_spec` root from embedded YAML if available."""
        block_re = re.compile(r"(?ms)^```yaml[ \t]*\n(.*?)^```[ \t]*$")
        for match in block_re.finditer(self.content or ""):
            block = match.group(1).strip()
            if not block:
                continue
            try:
                doc = yaml.safe_load(block)
            except Exception:
                continue
            if isinstance(doc, dict) and isinstance(doc.get("format_spec"), dict):
                return doc.get("format_spec") or {}
        return {}
    
    def extract_item_id(self) -> str:
        """Extract item ID from FormatSpec"""
        if self._format_schema.get("item_id"):
            return str(self._format_schema.get("item_id"))

        # Try formats like: # IMP-10-0-0-00 or ## Item: IMP-10-0-0-00
        patterns = [
            r'#\s+([\w-]+-\d+-\d+-\d+-\d+)',
            r'Item\s*[ID:]*\s*([\w-]+-\d+-\d+-\d+-\d+)',
        ]
        for pattern in patterns:
            match = re.search(pattern, self.content)
            if match:
                return match.group(1)
        return "UNKNOWN"
    
    def extract_item_desc(self) -> str:
        """Extract item description"""
        if self._format_schema.get("description"):
            return str(self._format_schema.get("description")).strip()

        # Look for description after item ID
        patterns = [
            r'#.*?[:]\s*(.+?)(?:\n|$)',
            r'Description:\s*(.+?)(?:\n|$)',
        ]
        for pattern in patterns:
            match = re.search(pattern, self.content)
            if match:
                return match.group(1).strip()
        return ""
    
    def extract_check_module(self) -> str:
        """Extract check module name"""
        if self._format_schema.get("check_module"):
            return str(self._format_schema.get("check_module")).strip()

        patterns = [
            r'Check Module:\s*(\S+)',
            r'Module:\s*(\S+)',
            r'(\d+\.\d+_\w+_CHECK)',
        ]
        for pattern in patterns:
            match = re.search(pattern, self.content)
            if match:
                return match.group(1)
        return ""
    
    def extract_scenarios(self) -> Dict[str, Dict[str, str]]:
        """
        Extract scenario configurations from FormatSpec.
        
        Looks for sections like:
        ### Scenario 1 (req=N/A, waiver=N/A)
        - found_desc: ...
        - missing_desc: ...
        """
        scenarios = {}

        if isinstance(self._format_schema.get("scenario_config"), dict):
            schema_cfg = self._format_schema.get("scenario_config") or {}
            for key in ["scenario_1", "scenario_2", "scenario_3", "scenario_4"]:
                row = schema_cfg.get(key)
                if isinstance(row, dict):
                    scenarios[key] = {
                        str(k): str(v)
                        for k, v in row.items()
                        if v is not None and str(v).strip() != ""
                    }
            if scenarios:
                # Fill missing scenarios with defaults
                for key in ["scenario_1", "scenario_2", "scenario_3", "scenario_4"]:
                    if key not in scenarios:
                        scenarios[key] = self._get_default_scenario(key)
                return scenarios
        
        # Default scenarios structure
        scenario_patterns = [
            (r'scenario[_\s]*1|req\s*=\s*N/?A.*waiver\s*=\s*N/?A', 'scenario_1'),
            (r'scenario[_\s]*2|req\s*=\s*N/?A.*waiver\s*[>=]\s*0', 'scenario_2'),
            (r'scenario[_\s]*3|req\s*[>=]\s*0.*waiver\s*=\s*N/?A', 'scenario_3'),
            (r'scenario[_\s]*4|req\s*[>=]\s*0.*waiver\s*[>=]\s*0', 'scenario_4'),
        ]
        
        # Extract each scenario
        for pattern, scenario_key in scenario_patterns:
            # Find section for this scenario
            section_match = re.search(
                rf'(#+\s*.*?{pattern}.*?)\n(.*?)(?=\n#+\s|\Z)',
                self.content,
                re.IGNORECASE | re.DOTALL
            )
            
            if section_match:
                section_content = section_match.group(2)
                scenarios[scenario_key] = self._parse_scenario_content(section_content)
            else:
                # Use defaults
                scenarios[scenario_key] = self._get_default_scenario(scenario_key)
        
        return scenarios
    
    def _parse_scenario_content(self, content: str) -> Dict[str, str]:
        """Parse scenario section content"""
        config = {}
        
        field_patterns = {
            'found_desc': r'found[_\s]desc(?:ription)?:\s*["\']?(.+?)["\']?\s*(?:\n|$)',
            'missing_desc': r'missing[_\s]desc(?:ription)?:\s*["\']?(.+?)["\']?\s*(?:\n|$)',
            'waived_desc': r'waived[_\s]desc(?:ription)?:\s*["\']?(.+?)["\']?\s*(?:\n|$)',
            'unused_desc': r'unused[_\s]desc(?:ription)?:\s*["\']?(.+?)["\']?\s*(?:\n|$)',
            'found_reason': r'found[_\s]reason:\s*["\']?(.+?)["\']?\s*(?:\n|$)',
            'missing_reason': r'missing[_\s]reason:\s*["\']?(.+?)["\']?\s*(?:\n|$)',
            'waived_reason': r'waived[_\s]reason:\s*["\']?(.+?)["\']?\s*(?:\n|$)',
            'unused_reason': r'unused[_\s]reason:\s*["\']?(.+?)["\']?\s*(?:\n|$)',
        }
        
        for field, pattern in field_patterns.items():
            match = re.search(pattern, content, re.IGNORECASE)
            if match:
                config[field] = match.group(1).strip()
        
        return config
    
    def _get_default_scenario(self, scenario_key: str) -> Dict[str, str]:
        """Get default configuration for a scenario"""
        defaults = {
            'scenario_1': {
                'found_desc': "Items extracted and verified",
                'missing_desc': "Items missing or incomplete",
                'found_reason': "Information found in input files",
                'missing_reason': "Information not found in expected locations",
            },
            'scenario_2': {
                'found_desc': "Items extracted and verified",
                'missing_desc': "Items missing or incomplete",
                'waived_desc': "Items waived per configuration",
                'unused_desc': "Unused waivers",
                'found_reason': "Information found in input files",
                'missing_reason': "Information not found in expected locations",
                'waived_reason': "Waived per project configuration",
                'unused_reason': "Waiver entry not matched",
            },
            'scenario_3': {
                'found_desc': "Required patterns matched and validated",
                'missing_desc': "Expected patterns not satisfied or missing",
                'found_reason': "Pattern matched and validated",
                'missing_reason': "Pattern not satisfied or missing",
            },
            'scenario_4': {
                'found_desc': "Required patterns matched and validated",
                'missing_desc': "Expected patterns not satisfied or missing",
                'waived_desc': "Items waived per configuration",
                'unused_desc': "Unused waivers",
                'found_reason': "Pattern matched and validated",
                'missing_reason': "Pattern not satisfied or missing",
                'waived_reason': "Waived per project configuration",
                'unused_reason': "Waiver entry not matched",
            },
        }
        return defaults.get(scenario_key, defaults['scenario_1'])
    
    def extract_vio_name_format(self) -> str:
        """Extract violation name format from FormatSpec"""
        if self._format_schema.get("vio_name_format"):
            return str(self._format_schema.get("vio_name_format"))

        patterns = [
            r'vio[_\s]?name[_\s]?format:\s*["`\'](.+?)["`\']',
            r'violation[_\s]?name:\s*["`\'](.+?)["`\']',
            r'format:\s*["`\']item\[.name.\]["`\']',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, self.content, re.IGNORECASE)
            if match:
                return match.group(1)
        
        # Default format
        return "item.get('name', str(item))"
    
    def generate_config_file(self) -> str:
        """
        Generate imp_config.py content.
        
        Returns:
            Python code for imp_config.py
        """
        item_id = self.extract_item_id()
        item_desc = self.extract_item_desc()
        check_module = self.extract_check_module()
        scenarios = self.extract_scenarios()
        vio_format = self.extract_vio_name_format()
        
        # Generate Python code
        code = f'''"""
{item_id}: {item_desc}

Configuration File
Contains SCENARIO_CONFIG and _build_vio_name.
Generated from FormatSpec.
"""

from typing import Dict, Any

# =============================================================================
# Item Metadata
# =============================================================================

ITEM_ID = "{item_id}"
ITEM_DESC = "{item_desc}"
CHECK_MODULE = "{check_module}"

# =============================================================================
# Scenario-based Configuration (from FormatSpec)
# =============================================================================

SCENARIO_CONFIG = {{
'''
        
        # Add each scenario
        for scenario_key, config in scenarios.items():
            code += f"    '{scenario_key}': {{\n"
            for field, value in config.items():
                code += f'        \'{field}\': "{value}",\n'
            code += "    },\n"
        
        code += '''}

# =============================================================================
# Violation Name Builder (from FormatSpec)
# =============================================================================

def build_vio_name(item: Dict) -> str:
    """
    Build violation name for pattern/waiver matching.
    """
    return item.get('name', str(item))


# =============================================================================
# Scenario Selection Logic
# =============================================================================

def get_scenario(req_value: Any, waiver_value: Any) -> str:
    """
    Determine scenario based on requirement and waiver values.
    """
    has_req = req_value not in [None, 'N/A', 0, '0']
    has_waiver = waiver_value not in [None, 'N/A']
    
    if not has_req and not has_waiver:
        return 'scenario_1'
    elif not has_req and has_waiver:
        return 'scenario_2'
    elif has_req and not has_waiver:
        return 'scenario_3'
    else:
        return 'scenario_4'


def get_config_for_scenario(scenario: str) -> Dict:
    """Get configuration dict for a specific scenario."""
    return SCENARIO_CONFIG.get(scenario, SCENARIO_CONFIG['scenario_1'])
'''
        
        return code
    
    def save_config_file(self, output_path: Path) -> Path:
        """
        Generate and save config file.
        
        Args:
            output_path: Path to save the config file
            
        Returns:
            Path to the saved file
        """
        code = self.generate_config_file()
        output_path = Path(output_path)
        output_path.write_text(code, encoding='utf-8')
        return output_path
