# CodeGen Agent

CodeGen Agent 负责根据 ItemSpec 生成完整的 checker Python 脚本。

## 目录结构

```
CodeGen/
├── README.md           # 本文件
├── templates/          # 代码模板
│   ├── checker_skeleton.py.j2    # Checker 骨架模板
│   ├── parsing_module.py.j2      # Parsing 逻辑模板
│   ├── check_logic.py.j2         # Check Logic 模板
│   └── waiver_logic.py.j2        # Waiver Logic 模板
├── outputs/            # 生成的代码
│   └── .gitkeep
└── agent.py            # Agent 实现 (待开发)
```

## 核心功能

1. **模块化生成**
   - Parsing Module: 根据 ItemSpec Section 1+4 生成解析逻辑
   - Check Logic: 根据 ItemSpec Section 2 生成检查条件
   - Waiver Logic: 根据 ItemSpec Section 3 生成豁免逻辑
   - Assembly: 组装成完整 checker

2. **模板继承**
   - 继承 `InputFileParserMixin`
   - 继承 `OutputBuilderMixin`
   - 继承 `WaiverHandlerMixin`
   - 继承 `BaseChecker`

## 输入

- `Context/outputs/IMP-X-X-X-XX_ItemSpec.md`

## 输出

- `Check_modules/X.X_XXX_CHECK/scripts/checker/IMP-X-X-X-XX.py`
