#!/usr/bin/env python3
"""
CodeGen Agent - LLM Client Abstraction Layer

Provides a unified interface for LLM interactions with three modes:
- real: Production mode using Gemini API
- interactive: Development mode with manual input
- mock: Test-only mode reading from preset files

Design Principles:
- Abstract base class for consistent interface
- Token limit enforcement (8K per user configuration)
- Support for checkpoint recovery

Author: CodeGen Agent Team
Date: 2026-02-04
"""

from abc import ABC, abstractmethod
from enum import Enum
from typing import Optional, Dict, Any
from pathlib import Path
import os


class LLMMode(Enum):
    """LLM operation modes"""
    REAL = "real"           # Production: Call Gemini API
    INTERACTIVE = "interactive"  # Development: Print prompt, read from stdin
    MOCK = "mock"           # Test only: Read from preset files
    JEDAI = "jedai"         # Enterprise: JEDAI LLM Gateway


class LLMClient(ABC):
    """
    Abstract base class for LLM clients
    
    All implementations must respect the token limit and provide
    a consistent generate() interface.
    """
    
    MAX_TOKENS = 8000  # User-confirmed limit
    
    @abstractmethod
    def generate(self, system_prompt: str, user_prompt: str) -> str:
        """
        Generate LLM response
        
        Args:
            system_prompt: System context and instructions
            user_prompt: User-provided context and query
            
        Returns:
            LLM response text
        """
        pass
    
    def validate_token_limit(self, text: str) -> bool:
        """
        Check if text is within token limit (approximate)
        
        Uses character/4 as rough token estimate
        """
        estimated_tokens = len(text) // 4
        return estimated_tokens <= self.MAX_TOKENS
    
    def truncate_to_limit(self, text: str) -> str:
        """Truncate text to fit within token limit"""
        max_chars = self.MAX_TOKENS * 4
        if len(text) > max_chars:
            return text[:max_chars] + "\n\n[TRUNCATED DUE TO TOKEN LIMIT]"
        return text


class GeminiClient(LLMClient):
    """
    Gemini API client for production use
    
    Requires GEMINI_API_KEY environment variable
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gemini-2.0-flash"
    ):
        """
        Initialize Gemini client
        
        Args:
            api_key: Gemini API key (defaults to GEMINI_API_KEY env var)
            model: Model name (default: gemini-2.0-flash)
        """
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY")
        self.model = model
        
        if not self.api_key:
            raise ValueError(
                "Gemini API key required. Set GEMINI_API_KEY environment variable "
                "or pass api_key parameter. See: https://aistudio.google.com"
            )
    
    def generate(self, system_prompt: str, user_prompt: str) -> str:
        """Generate response using Gemini API"""
        try:
            import google.generativeai as genai
        except ImportError:
            raise ImportError(
                "google-generativeai package required. "
                "Install with: pip install google-generativeai"
            )
        
        genai.configure(api_key=self.api_key)
        model = genai.GenerativeModel(self.model)
        
        # Combine prompts (Gemini doesn't have separate system/user)
        full_prompt = f"{system_prompt}\n\n{user_prompt}"
        full_prompt = self.truncate_to_limit(full_prompt)
        
        response = model.generate_content(full_prompt)
        return response.text


class InteractiveClient(LLMClient):
    """
    Interactive client for development and debugging
    
    Prints prompts to console and reads response from stdin.
    Useful for manual testing and prompt iteration.
    """
    
    def __init__(self, preview_length: int = 500):
        """
        Initialize interactive client
        
        Args:
            preview_length: Max chars to show in prompt preview
        """
        self.preview_length = preview_length
    
    def generate(self, system_prompt: str, user_prompt: str) -> str:
        """Print prompts and read response from stdin"""
        print("\n" + "=" * 60)
        print("[SYSTEM PROMPT]")
        if len(system_prompt) > self.preview_length:
            print(system_prompt[:self.preview_length] + "...")
            print(f"  (truncated, full length: {len(system_prompt)} chars)")
        else:
            print(system_prompt)
        
        print("\n[USER PROMPT]")
        if len(user_prompt) > self.preview_length:
            print(user_prompt[:self.preview_length] + "...")
            print(f"  (truncated, full length: {len(user_prompt)} chars)")
        else:
            print(user_prompt)
        
        print("=" * 60)
        print("\nPaste your response (Ctrl+D on Unix or Ctrl+Z on Windows to end):")
        
        import sys
        try:
            response = sys.stdin.read()
        except EOFError:
            response = ""
        
        return response.strip()


class MockClient(LLMClient):
    """
    Mock client for testing (TEST ENVIRONMENT ONLY)
    
    Reads preset responses from files in the mocks directory.
    WARNING: Do not use in production!
    """
    
    def __init__(self, mocks_dir: Path):
        """
        Initialize mock client
        
        Args:
            mocks_dir: Directory containing mock response files
        """
        self.mocks_dir = Path(mocks_dir)
        self._call_count = 0
        
        if not self.mocks_dir.exists():
            raise ValueError(f"Mocks directory not found: {mocks_dir}")
    
    def generate(self, system_prompt: str, user_prompt: str) -> str:
        """Read response from mock file"""
        self._call_count += 1
        
        # Try numbered mock files first
        mock_file = self.mocks_dir / f"response_{self._call_count}.txt"
        if mock_file.exists():
            return mock_file.read_text(encoding='utf-8')
        
        # Fall back to default
        default_file = self.mocks_dir / "default_response.txt"
        if default_file.exists():
            return default_file.read_text(encoding='utf-8')
        
        raise FileNotFoundError(
            f"No mock response found for call #{self._call_count}. "
            f"Expected: {mock_file} or {default_file}"
        )


# ═══════════════════════════════════════════════════════════════════════════════
# JEDAI Client
# ═══════════════════════════════════════════════════════════════════════════════

class JedaiClient(LLMClient):
    """
    JEDAI Enterprise LLM Gateway Client
    
    Supports 40+ models including Claude Opus 4.5, GPT-5, Gemini 3, etc.
    Uses JEDAI API at https://jedai-ai:2513
    
    Authentication:
    - JEDAI_TOKEN env var (preferred)
    - JEDAI_USERNAME + JEDAI_PASSWORD for auto-login
    """
    
    DEFAULT_MODEL = "claude-opus-4-5"
    DEFAULT_TIMEOUT = 300.0  # 5 minutes for long responses
    CONNECT_TIMEOUT = 60.0
    
    def __init__(
        self,
        model: str = DEFAULT_MODEL,
        temperature: float = 0.7,
        max_tokens: int = 8192
    ):
        """
        Initialize JEDAI client
        
        Args:
            model: Model name or alias (default: claude-opus-4-5)
            temperature: Generation temperature (0.0-1.0)
            max_tokens: Maximum response tokens
        """
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        
        # Lazy-load auth and config to avoid import errors
        self._auth = None
        self._model_config = None
    
    def _get_auth(self):
        """Lazy-load JedaiAuth"""
        if self._auth is None:
            try:
                import sys
                jedai_dir = Path(__file__).resolve().parents[2] / "JEDAI"
                if str(jedai_dir) not in sys.path:
                    sys.path.insert(0, str(jedai_dir))
                from jedai_auth import JedaiAuth
                self._auth = JedaiAuth()
            except ImportError as e:
                raise ImportError(
                    f"JEDAI auth module not found. Ensure JEDAI directory exists. Error: {e}"
                )
        return self._auth
    
    def _get_model_config(self):
        """Lazy-load model configuration"""
        if self._model_config is None:
            try:
                import sys
                jedai_dir = Path(__file__).resolve().parents[2] / "JEDAI"
                if str(jedai_dir) not in sys.path:
                    sys.path.insert(0, str(jedai_dir))
                from model_config import get_model_config, JEDAI_MODELS
                config, real_name = get_model_config(self.model)
                if config is None:
                    raise ValueError(
                        f"Unknown model: {self.model}. "
                        f"Available: {list(JEDAI_MODELS.keys())[:10]}..."
                    )
                self._model_config = (config, real_name)
            except ImportError as e:
                raise ImportError(
                    f"JEDAI model_config not found. Error: {e}"
                )
        return self._model_config
    
    def generate(self, system_prompt: str, user_prompt: str) -> str:
        """
        Generate response using JEDAI API
        
        Args:
            system_prompt: System context and instructions
            user_prompt: User-provided context and query
            
        Returns:
            LLM response text
        """
        try:
            import httpx
        except ImportError:
            raise ImportError(
                "httpx package required for JEDAI client. "
                "Install with: pip install httpx"
            )
        
        auth = self._get_auth()
        model_config, real_name = self._get_model_config()
        
        # Ensure we have a valid token
        token = auth.get_token()
        if not token:
            raise RuntimeError("Failed to obtain JEDAI authentication token")
        
        # Build request body
        messages = [
            {"role": "system", "content": self.truncate_to_limit(system_prompt)},
            {"role": "user", "content": self.truncate_to_limit(user_prompt)}
        ]
        
        body = {
            "messages": messages,
            "model": model_config.get("family", "Claude"),
            "deployment": model_config.get("deployment", real_name),
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "stream": False
        }
        
        # Add location/endpoint based on model family
        if "location" in model_config:
            body["location"] = model_config["location"]
            body["project"] = "gcp-cdns-llm-test"  # Default GCP project
        if "endpoint" in model_config:
            body["endpoint"] = model_config["endpoint"]
        
        url = f"{auth.connected_url}/api/copilot/v1/llm/chat/completions"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        
        # Make request with retry on auth failure
        timeout = httpx.Timeout(self.DEFAULT_TIMEOUT, connect=self.CONNECT_TIMEOUT)
        
        for retry in range(2):  # One retry for token refresh
            try:
                with httpx.Client(timeout=timeout, verify=False) as client:
                    response = client.post(url, json=body, headers=headers)
                    
                    if response.status_code in [401, 403] and retry == 0:
                        # Token expired, refresh and retry
                        auth.clear_token()
                        auth.connect(force=True)
                        token = auth.get_token()
                        headers["Authorization"] = f"Bearer {token}"
                        continue
                    
                    response.raise_for_status()
                    data = response.json()
                    
                    # Extract content from response
                    choices = data.get("choices", [])
                    if not choices:
                        raise RuntimeError(f"Empty response from JEDAI: {data}")
                    
                    content = choices[0].get("message", {}).get("content", "")
                    return content
                    
            except httpx.HTTPStatusError as e:
                raise RuntimeError(
                    f"JEDAI API error: {e.response.status_code} - {e.response.text}"
                )
            except httpx.RequestError as e:
                raise RuntimeError(f"JEDAI connection error: {e}")
        
        raise RuntimeError("Failed to get response from JEDAI after retry")


# ═══════════════════════════════════════════════════════════════════════════════
# Parallel Executor Interface (Reserved, not implemented)
# ═══════════════════════════════════════════════════════════════════════════════

class ParallelExecutor(ABC):
    """
    Parallel processing interface (RESERVED - NOT IMPLEMENTED)
    
    This interface is reserved for future parallel batch processing.
    """
    
    @abstractmethod
    def submit_batch(self, items: list) -> list:
        """
        Submit batch of items for parallel processing
        
        Args:
            items: List of items to process
            
        Returns:
            List of results
        """
        pass


# ═══════════════════════════════════════════════════════════════════════════════
# Factory Function
# ═══════════════════════════════════════════════════════════════════════════════

def create_client(
    mode: LLMMode,
    api_key: Optional[str] = None,
    model: str = "gemini-2.0-flash",
    mocks_dir: Optional[Path] = None,
    jedai_model: str = "claude-opus-4-5",
    temperature: float = 0.7
) -> LLMClient:
    """
    Factory function to create LLM client
    
    Args:
        mode: LLMMode enum value
        api_key: API key for real mode
        model: Model name for real mode (Gemini)
        mocks_dir: Directory for mock mode
        jedai_model: Model name for JEDAI mode (default: claude-opus-4-5)
        temperature: Temperature for JEDAI mode
        
    Returns:
        Configured LLMClient instance
    """
    if mode == LLMMode.REAL:
        return GeminiClient(api_key=api_key, model=model)
    elif mode == LLMMode.INTERACTIVE:
        return InteractiveClient()
    elif mode == LLMMode.MOCK:
        if mocks_dir is None:
            raise ValueError("mocks_dir required for mock mode")
        return MockClient(mocks_dir=mocks_dir)
    elif mode == LLMMode.JEDAI:
        return JedaiClient(model=jedai_model, temperature=temperature)
    else:
        raise ValueError(f"Unknown LLM mode: {mode}")
