```markdown
Create the FormatSpec for one checker item.

Requirements:
- Output must be Markdown in English.
- Title must include item ID.
- Include exactly these sections:
  - ## Pattern Strategy
  - ## Requirement Items
  - ## Pattern Index Mapping
  - ## Waiver Items
  - ## Waiver Keyword Taxonomy
  - ## Scenario Matrix
  - ## Expected Outcomes
  - ## Embedded Schema
- Include line `vio_name_format: "item_name"`.

## CRITICAL: Pattern Design Rules

Patterns MUST be cross-project REUSABLE. Do NOT hardcode project-specific values.

| Pattern Type | CORRECT | WRONG |
|--------------|---------|-------|
| File extension | `*.v.gz`, `*.spef*` | `design_block_A.v.gz` |
| Path pattern | `*/dbs/*`, `*/logs/*` | `/Users/john/project_X/*` |
| Tool pattern | `*Synthesis*`, `*Genus*` | `Genus 23.15-s099_1` |
| Version pattern | `*.*-*` | `23.15-s099_1` |

## Requirement Items (Based on ItemSpec Sub-Items)

Create requirement_items for each mandatory sub-item defined in ItemSpec:

For EDA-Generated Files (netlist, gds):
- file_path, file_name, design_name, generator_tool, generator_version, generation_time

For Parasitic Files (spef):
- file_path, file_name, design_name, extractor_tool, extractor_version, extraction_time

For Library Files (liberty, lef):
- library_path, library_name, library_version, corner, process_node

## Four Scenario Framework

Include four scenario sections with fields:
- Scenario 1: req=N/A, waiver=N/A (existence check only)
- Scenario 2: req=N/A, waiver>0 (existence + waiver handling)
- Scenario 3: req>0, waiver=N/A (pattern matching)
- Scenario 4: req>0, waiver>0 (pattern + waiver)

Each scenario includes:
- found_desc, missing_desc
- found_reason, missing_reason
- waived_desc, unused_desc (for waiver scenarios)
- waived_reason, unused_reason (for waiver scenarios)

## Expected YAML Structure

```yaml
format_spec:
  item_id: "{{ITEM_ID}}"
  description: "{{DESCRIPTION}}"
  check_module: "{{CHECK_MODULE}}"
  vio_name_format: "item_name"
  requirement_items:
    - requirement_id: REQ1
      object_name: netlist                # Use "object_name"
      sub_item: file_path
      pattern: "*/dbs/*.v.gz"             # Reusable pattern
      comparator: glob
      source_evidence_ids: [EV1]
    - requirement_id: REQ2
      object_name: netlist
      sub_item: generator_tool
      pattern: "*Synthesis*"              # Tool pattern (not version)
      comparator: glob
      source_evidence_ids: [EV2]
    - requirement_id: REQ3
      object_name: netlist
      sub_item: generator_version
      pattern: "*.*-*"                    # Generic version pattern
      comparator: regex
      source_evidence_ids: [EV3]
  pattern_index_mapping:
    - index: 0
      requirement_id: REQ1
      target: "netlist.file_path"
  waiver_items:
    - "spef:*"                            # Object-level waiver
  waiver_keyword_taxonomy:
    - scenario: object_skipped
      waiver_item: "spef:*"
      keywords: ["skip", "not loaded", "N/A"]
      sample_reason: "SPEF loading skipped per project configuration"
  expected_outcomes:                       # MUST include S1, S2, S3, S4
    - scenario: S1
      requirements_value: "N/A"
      waivers_value: "N/A"
      decision_rule: "PASS if all mandatory sub-items extracted"
    - scenario: S2
      requirements_value: "N/A"
      waivers_value: ">0"
      decision_rule: "PASS if extracted or waived"
    - scenario: S3
      requirements_value: ">0"
      waivers_value: "N/A"
      decision_rule: "PASS if patterns match"
    - scenario: S4
      requirements_value: ">0"
      waivers_value: ">0"
      decision_rule: "PASS if patterns match or waived"
```

## Validation Rules (What the Validator Checks)

1. `expected_outcomes` MUST include all four scenarios: S1, S2, S3, S4
2. `requirement_items` must cover all mandatory sub-items from ItemSpec
3. Patterns must not be empty or `<missing>`
4. `design_name` patterns must not end with punctuation
5. `exact` comparator requires `source_evidence_ids`
6. All `object_name` values must exist in ItemSpec

Item context:
{{ITEM_CONTEXT}}

ItemSpec:
{{ITEMSPEC}}

ParsingSpec:
{{PARSING_SPEC}}

Evidence context:
{{EVIDENCE}}
```
