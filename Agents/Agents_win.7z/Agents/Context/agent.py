#!/usr/bin/env python3
"""CLI entry for Context Agent."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# Support direct execution.
AGENTS_DIR = Path(__file__).resolve().parents[1]
if str(AGENTS_DIR) not in sys.path:
    sys.path.insert(0, str(AGENTS_DIR))

from CodeGen.llm_client import LLMMode  # type: ignore

try:
    from .context_pipeline import ContextPipeline, ContextRunConfig
except ImportError:  # pragma: no cover
    from context_pipeline import ContextPipeline, ContextRunConfig


def _default_checklist_root() -> Path:
    # .../CHECKLIST/Agents/Context/agent.py -> .../CHECKLIST
    return Path(__file__).resolve().parents[2]


def _default_output_root() -> Path:
    return Path(__file__).resolve().parent / "outputs"


def main() -> int:
    parser = argparse.ArgumentParser(description="Context Agent")
    parser.add_argument("--item-id", required=True, help="Checker item ID, e.g. IMP-10-0-0-00")
    parser.add_argument("--item-yaml", help="Optional explicit item yaml path")
    parser.add_argument("--checklist-root", default=str(_default_checklist_root()), help="CHECKLIST root path")
    parser.add_argument("--output-root", default=str(_default_output_root()), help="Context collateral root path")
    parser.add_argument("--mode", choices=["jedai", "mock", "real", "interactive"], default="jedai")
    parser.add_argument("--jedai-model", default="claude-opus-4-5", help="JEDAI model name")
    parser.add_argument("--api-key", help="API key for real LLM mode")
    parser.add_argument("--mocks-dir", help="Mock response directory")
    parser.add_argument("--rag-index", help="Local RAG index directory")
    parser.add_argument("--compatibility", action="store_true", help="Enable legacy flat collateral copies")
    parser.add_argument("--max-lines", type=int, default=3000, help="Max lines to scan per input file")

    args = parser.parse_args()

    config = ContextRunConfig(
        item_id=args.item_id,
        checklist_root=Path(args.checklist_root),
        output_root=Path(args.output_root),
        item_yaml_path=Path(args.item_yaml) if args.item_yaml else None,
        llm_mode=LLMMode(args.mode),
        jedai_model=args.jedai_model,
        api_key=args.api_key,
        mocks_dir=Path(args.mocks_dir) if args.mocks_dir else None,
        rag_index_dir=Path(args.rag_index) if args.rag_index else None,
        compatibility_mode=bool(args.compatibility),
        max_lines_per_input=args.max_lines,
    )

    pipeline = ContextPipeline(config)
    artifacts = pipeline.run()

    summary = {
        "item_id": artifacts.item_id,
        "item_yaml": str(artifacts.item_yaml_path),
        "output_dir": str(artifacts.output_dir),
        "itemspec": str(artifacts.itemspec_path),
        "parsing_spec": str(artifacts.parsing_spec_path),
        "format_spec": str(artifacts.format_spec_path),
        "compatibility": {k: str(v) for k, v in artifacts.compatibility_paths.items()},
        "manifest": str(artifacts.manifest_path) if artifacts.manifest_path else None,
    }
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
