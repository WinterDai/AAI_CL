#!/usr/bin/env python3
"""
Build a local lexical RAG index from markdown knowledge files.

Outputs:
- chunks.jsonl: chunk store with metadata
- index.json: idf + postings + norms
- report.md: build summary
"""

from __future__ import annotations

import argparse
import json
import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

try:
    import yaml
except Exception as exc:  # pragma: no cover
    raise RuntimeError("PyYAML is required to run build_rag_index.py") from exc


STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "by",
    "for",
    "from",
    "has",
    "have",
    "if",
    "in",
    "into",
    "is",
    "it",
    "its",
    "of",
    "on",
    "or",
    "that",
    "the",
    "their",
    "this",
    "to",
    "used",
    "using",
    "with",
    "what",
    "when",
    "where",
    "which",
    "why",
}

TOKEN_RE = re.compile(r"[A-Za-z0-9_]+")


@dataclass
class Chunk:
    chunk_id: int
    source_file: str
    section: str
    text: str
    topics: List[str]
    source_ids: List[str]


def tokenize(text: str) -> List[str]:
    tokens = [t.lower() for t in TOKEN_RE.findall(text)]
    return [t for t in tokens if len(t) > 1 and t not in STOPWORDS]


def load_manifest(manifest_path: Path) -> Dict:
    if not manifest_path.exists():
        return {"sources": []}
    with manifest_path.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    return data


def map_file_to_sources(file_stem: str, manifest: Dict) -> Tuple[List[str], List[str]]:
    """Return source IDs and merged topics for a summary file."""
    source_ids: List[str] = []
    topics: List[str] = []
    stem_tokens = set(file_stem.lower().split("_"))

    for src in manifest.get("sources", []):
        src_topics = [str(t).lower() for t in src.get("topics", [])]
        if stem_tokens.intersection(src_topics) or file_stem.lower() in src_topics:
            source_ids.append(str(src.get("id", "")))
            topics.extend(src_topics)

    # keep deterministic order
    source_ids = sorted({s for s in source_ids if s})
    topics = sorted(set(topics))
    return source_ids, topics


def iter_markdown_sections(content: str, default_title: str) -> Iterable[Tuple[str, str]]:
    """Yield (section_title, section_text) from markdown headings."""
    current_title = default_title
    buf: List[str] = []

    for line in content.splitlines():
        if line.startswith("#"):
            if buf:
                text = "\n".join(buf).strip()
                if text:
                    yield current_title, text
            current_title = line.lstrip("#").strip() or default_title
            buf = []
        else:
            buf.append(line)

    if buf:
        text = "\n".join(buf).strip()
        if text:
            yield current_title, text


def chunk_text(section_text: str, max_words: int = 180, min_words: int = 40) -> List[str]:
    """Chunk section text by paragraphs with soft max_words."""
    paras = [p.strip() for p in section_text.split("\n\n") if p.strip()]
    if not paras:
        return []

    chunks: List[str] = []
    cur: List[str] = []
    cur_words = 0

    for para in paras:
        words = para.split()
        wlen = len(words)

        if cur and (cur_words + wlen > max_words):
            joined = "\n\n".join(cur).strip()
            if joined:
                chunks.append(joined)
            cur = [para]
            cur_words = wlen
        else:
            cur.append(para)
            cur_words += wlen

    if cur:
        joined = "\n\n".join(cur).strip()
        if joined:
            chunks.append(joined)

    # merge tiny tail chunks
    merged: List[str] = []
    for text in chunks:
        if merged and len(text.split()) < min_words:
            merged[-1] = merged[-1].rstrip() + "\n\n" + text
        else:
            merged.append(text)
    return merged


def collect_chunks(
    knowledge_root: Path,
    include_dirs: List[str],
    manifest: Dict,
) -> List[Chunk]:
    chunk_list: List[Chunk] = []
    cid = 0

    for subdir in include_dirs:
        src_dir = knowledge_root / subdir
        if not src_dir.exists():
            continue

        for md_path in sorted(src_dir.rglob("*.md")):
            content = md_path.read_text(encoding="utf-8", errors="ignore")
            rel = md_path.relative_to(knowledge_root)
            source_ids, topics = map_file_to_sources(md_path.stem, manifest)

            for section, section_text in iter_markdown_sections(content, md_path.stem):
                parts = chunk_text(section_text)
                for part_idx, part in enumerate(parts, start=1):
                    section_name = section if len(parts) == 1 else f"{section} (part {part_idx})"
                    chunk_list.append(
                        Chunk(
                            chunk_id=cid,
                            source_file=str(rel),
                            section=section_name,
                            text=part,
                            topics=topics,
                            source_ids=source_ids,
                        )
                    )
                    cid += 1

    return chunk_list


def build_tfidf_index(chunks: List[Chunk]) -> Dict:
    term_freqs: List[Counter] = []
    doc_freq: Counter = Counter()

    for chunk in chunks:
        tf = Counter(tokenize(chunk.text))
        term_freqs.append(tf)
        doc_freq.update(tf.keys())

    n_docs = max(len(chunks), 1)
    idf: Dict[str, float] = {}
    for term, df in doc_freq.items():
        idf[term] = math.log((n_docs + 1.0) / (df + 1.0)) + 1.0

    postings: Dict[str, List[Tuple[int, float]]] = defaultdict(list)
    doc_norms: List[float] = [0.0] * len(chunks)

    for doc_id, tf in enumerate(term_freqs):
        if not tf:
            continue
        max_tf = max(tf.values())
        for term, cnt in tf.items():
            tf_norm = 0.5 + 0.5 * (cnt / max_tf)
            weight = tf_norm * idf[term]
            postings[term].append((doc_id, weight))
            doc_norms[doc_id] += weight * weight

    for i in range(len(doc_norms)):
        doc_norms[i] = math.sqrt(doc_norms[i])

    serial_postings = {k: [[doc, round(w, 6)] for doc, w in v] for k, v in postings.items()}

    return {
        "version": "local-rag-v1",
        "built_at_utc": datetime.now(timezone.utc).isoformat(),
        "num_docs": len(chunks),
        "num_terms": len(idf),
        "idf": {k: round(v, 6) for k, v in idf.items()},
        "postings": serial_postings,
        "doc_norms": [round(v, 6) for v in doc_norms],
    }


def write_outputs(chunks: List[Chunk], index: Dict, out_dir: Path, include_dirs: List[str]) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)

    chunks_path = out_dir / "chunks.jsonl"
    with chunks_path.open("w", encoding="utf-8") as fh:
        for c in chunks:
            fh.write(
                json.dumps(
                    {
                        "chunk_id": c.chunk_id,
                        "source_file": c.source_file,
                        "section": c.section,
                        "text": c.text,
                        "topics": c.topics,
                        "source_ids": c.source_ids,
                    },
                    ensure_ascii=False,
                )
                + "\n"
            )

    index_path = out_dir / "index.json"
    index_path.write_text(json.dumps(index, indent=2, ensure_ascii=False), encoding="utf-8")

    source_counter = Counter(c.source_file for c in chunks)
    report_lines = [
        "# Local RAG Build Report",
        "",
        f"- Included dirs: {', '.join(include_dirs)}",
        f"- Chunks: {len(chunks)}",
        f"- Terms: {index.get('num_terms', 0)}",
        "",
        "## Source files",
        "",
    ]
    for source, count in sorted(source_counter.items()):
        report_lines.append(f"- `{source}`: {count} chunks")

    (out_dir / "report.md").write_text("\n".join(report_lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build local lexical RAG index")
    parser.add_argument(
        "--knowledge-root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="Path to knowledge root",
    )
    parser.add_argument(
        "--include-dirs",
        nargs="+",
        default=["summaries"],
        help="Subdirectories under knowledge root to include",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "rag" / "main",
        help="Output directory for index artifacts",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    knowledge_root = args.knowledge_root
    manifest = load_manifest(knowledge_root / "manifest.yaml")

    chunks = collect_chunks(knowledge_root, args.include_dirs, manifest)
    if not chunks:
        raise RuntimeError("No chunks collected. Check include directories and markdown files.")

    index = build_tfidf_index(chunks)
    write_outputs(chunks, index, args.output_dir, args.include_dirs)

    print(f"[OK] Built local RAG index: {args.output_dir}")
    print(f"[OK] Chunks: {len(chunks)} | Terms: {index.get('num_terms', 0)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
