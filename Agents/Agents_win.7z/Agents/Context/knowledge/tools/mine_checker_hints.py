#!/usr/bin/env python3
"""
Mine checker-specific hints from Check_modules and generate local ID_skill docs.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:
    import yaml
except Exception as exc:  # pragma: no cover
    raise RuntimeError("PyYAML is required to run mine_checker_hints.py") from exc


@dataclass
class ItemHint:
    row_index: int
    item_id: str
    check_module: str
    description: str
    intent: str
    knowledge_tags: List[str]
    candidate_objects: List[str]
    yaml_path: Optional[str]
    checker_script: Optional[str]
    input_files: List[str]
    requirement_value: str
    waiver_value: str
    regex_clues: List[str]
    keyword_clues: List[str]
    unique_skill_file: str


OBJ_PATTERNS = {
    "netlist": ["netlist", "verilog", "rtl"],
    "spef": ["spef", "parasitic", "rc extraction", "qrc"],
    "sdc": ["sdc", "constraint", "clock", "false path", "multicycle"],
    "sdf": ["sdf", "delay annotation"],
    "liberty": ["lib", "liberty", "library"],
    "lef_def": ["lef", "def", "tech lef", "tlef"],
    "gds": ["gds", "gdsii", "streamout"],
    "drc": ["drc", "rule deck", "antenna"],
    "lvs": ["lvs", "layout versus schematic"],
    "lec": ["lec", "equivalence", "formal"],
    "power_emir": ["power", "ir", "em", "voltage", "upf"],
    "timing": ["timing", "slack", "wns", "tns", "setup", "hold"],
}

TAG_PATTERNS = {
    "timing_signoff": ["timing", "slack", "wns", "tns", "setup", "hold", "sta"],
    "constraints": ["sdc", "constraint", "clock", "false path", "multicycle"],
    "parasitics": ["spef", "parasitic", "qrc", "rc extraction"],
    "libraries": ["library", "lib", "cell", "macro"],
    "layout_data": ["lef", "def", "gds", "tech lef"],
    "physical_verification": ["drc", "lvs", "rule deck", "antenna", "erc"],
    "power_integrity": ["power", "ir", "em", "upf", "voltage", "current"],
    "equivalence": ["lec", "equivalence", "formal"],
    "implementation_qor": ["qor", "area", "utilization", "congestion", "density"],
    "deliverables": ["delivery", "package", "final data", "release"],
}

INPUT_TAGS = {
    ".log": "logs",
    ".rpt": "reports",
    ".rep": "reports",
    ".txt": "text_reports",
    ".tcl": "scripts",
    ".v": "netlist",
    ".v.gz": "netlist",
    ".spef": "spef",
    ".spef.gz": "spef",
    ".sdc": "sdc",
    ".sdf": "sdf",
    ".lef": "lef",
    ".def": "def",
    ".lib": "liberty",
}

REGEX_PATTERN = re.compile(r"re\.(?:search|match|findall|finditer)\(\s*r?[\"'](.+?)[\"']")


def slugify_module(check_module: str) -> str:
    return check_module.replace(".", "_").replace("-", "_")


def classify_intent(description: str) -> str:
    text = description.strip().lower()
    if text.startswith("list"):
        return "inventory"
    if text.startswith("confirm"):
        return "verification"
    if text.startswith("is ") or text.startswith("are "):
        return "status_check"
    if text.startswith("document"):
        return "documentation"
    if text.startswith("recommend"):
        return "advisory"
    if text.startswith("if "):
        return "conditional_verification"
    return "verification"


def infer_candidate_objects(description: str) -> List[str]:
    text = description.lower()
    results: List[str] = []
    for obj, patterns in OBJ_PATTERNS.items():
        if any(p in text for p in patterns):
            results.append(obj)
    return sorted(set(results))


def infer_knowledge_tags(description: str, input_files: List[str], check_module: str) -> List[str]:
    text = f"{description} {check_module}".lower()
    tags: List[str] = []

    for tag, patterns in TAG_PATTERNS.items():
        if any(p in text for p in patterns):
            tags.append(tag)

    for file_pattern in input_files:
        lower_file = file_pattern.lower()
        for suffix, tag in INPUT_TAGS.items():
            if lower_file.endswith(suffix) or suffix in lower_file:
                tags.append(f"input_{tag}")

    return sorted(set(tags))


def find_item_yaml(module_dir: Path, item_id: str) -> Optional[Path]:
    items_dir = module_dir / "inputs" / "items"
    if not items_dir.exists():
        return None

    exact = items_dir / f"{item_id}.yaml"
    if exact.exists():
        return exact

    fuzzy = sorted(items_dir.glob(f"*{item_id}*.yaml"))
    return fuzzy[0] if fuzzy else None


def find_checker_script(module_dir: Path, item_id: str) -> Optional[Path]:
    checker_dir = module_dir / "scripts" / "checker"
    if not checker_dir.exists():
        return None

    exact = checker_dir / f"{item_id}.py"
    if exact.exists():
        return exact

    alt = checker_dir / f"{item_id.replace('-', '_')}.py"
    if alt.exists():
        return alt

    fuzzy = sorted(checker_dir.glob(f"*{item_id}*.py"))
    return fuzzy[0] if fuzzy else None


def read_item_yaml(yaml_path: Optional[Path]) -> Tuple[List[str], str, str]:
    if yaml_path is None or not yaml_path.exists():
        return [], "N/A", "N/A"

    data = yaml.safe_load(yaml_path.read_text(encoding="utf-8")) or {}
    input_files = data.get("input_files", [])
    if isinstance(input_files, str):
        input_files = [input_files]
    requirement_value = str((data.get("requirements") or {}).get("value", "N/A"))
    waiver_value = str((data.get("waivers") or {}).get("value", "N/A"))
    return input_files, requirement_value, waiver_value


def extract_script_clues(script_path: Optional[Path]) -> Tuple[List[str], List[str]]:
    if script_path is None or not script_path.exists():
        return [], []

    lines = script_path.read_text(encoding="utf-8", errors="ignore").splitlines()
    regex_clues: List[str] = []
    keyword_clues: List[str] = []

    for line in lines:
        for match in REGEX_PATTERN.findall(line):
            cleaned = match.strip()
            if cleaned and cleaned not in regex_clues:
                regex_clues.append(cleaned)

        lower = line.lower()
        if any(k in lower for k in ["read_", "pattern", "version", "top level", "waive", "parasitic"]):
            snippet = line.strip()
            if snippet and snippet not in keyword_clues:
                keyword_clues.append(snippet)

    return regex_clues[:12], keyword_clues[:12]


def build_retrieval_queries(item_id: str, description: str, tags: List[str], objects: List[str]) -> List[str]:
    queries = [
        f"{item_id} checker intent {description}",
        f"physical implementation {' '.join(objects)} evidence extraction",
    ]
    if tags:
        queries.append(f"{' '.join(tags[:4])} best practices")
    return queries


def render_skill_markdown(hint: ItemHint) -> str:
    query_lines = "\n".join([f"- {q}" for q in build_retrieval_queries(hint.item_id, hint.description, hint.knowledge_tags, hint.candidate_objects)])
    objects_line = ", ".join(hint.candidate_objects) if hint.candidate_objects else "not identified from description"
    tags_line = ", ".join(hint.knowledge_tags) if hint.knowledge_tags else "general_physical_implementation"
    regex_lines = "\n".join([f"- `{p}`" for p in hint.regex_clues]) or "- none"
    keyword_lines = "\n".join([f"- `{k}`" for k in hint.keyword_clues]) or "- none"
    input_lines = "\n".join([f"- `{f}`" for f in hint.input_files]) or "- none"

    schema = {
        "skill_schema": {
            "item_id": hint.item_id,
            "check_module": hint.check_module,
            "intent": hint.intent,
            "knowledge_tags": hint.knowledge_tags,
            "candidate_objects": hint.candidate_objects,
            "input_files": hint.input_files,
            "requirements_value": hint.requirement_value,
            "waiver_value": hint.waiver_value,
            "yaml_path": hint.yaml_path or "",
            "checker_script": hint.checker_script or "",
        }
    }

    yaml_block = yaml.safe_dump(schema, sort_keys=False, allow_unicode=False)

    return (
        f"# {hint.item_id} Skill Hint\n\n"
        f"## Description\n\n{hint.description}\n\n"
        f"## Module and Intent\n\n"
        f"- Module: `{hint.check_module}`\n"
        f"- Intent: `{hint.intent}`\n"
        f"- Candidate objects: {objects_line}\n"
        f"- Knowledge tags: {tags_line}\n\n"
        f"## Input and Existing Implementation Clues\n\n"
        f"- Item YAML: `{hint.yaml_path or 'not found'}`\n"
        f"- Checker script: `{hint.checker_script or 'not found'}`\n\n"
        f"### Input files\n\n{input_lines}\n\n"
        f"### Regex clues from existing checker\n\n{regex_lines}\n\n"
        f"### Keyword clues from existing checker\n\n{keyword_lines}\n\n"
        f"## Suggested retrieval queries\n\n{query_lines}\n\n"
        f"## Embedded schema\n\n```yaml\n{yaml_block}```\n"
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Mine checker hints and generate ID skill files")
    parser.add_argument(
        "--checklist-root",
        type=Path,
        default=Path(__file__).resolve().parents[4],
        help="Path to CHECKLIST root",
    )
    parser.add_argument(
        "--csv-path",
        type=Path,
        default=Path(__file__).resolve().parents[4]
        / "Project_config"
        / "collaterals"
        / "Initial"
        / "latest"
        / "CheckList.csv",
        help="Path to CheckList.csv",
    )
    parser.add_argument(
        "--knowledge-root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="Path to knowledge root",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    check_modules_root = args.checklist_root / "Check_modules"
    if not check_modules_root.exists():
        raise RuntimeError(f"Check_modules not found: {check_modules_root}")
    if not args.csv_path.exists():
        raise RuntimeError(f"CheckList.csv not found: {args.csv_path}")

    skills_dir = args.knowledge_root / "skills"
    hints_dir = args.knowledge_root / "checker_hints"
    skills_dir.mkdir(parents=True, exist_ok=True)
    hints_dir.mkdir(parents=True, exist_ok=True)

    # Clean previously generated skill docs to avoid stale collisions.
    for old_skill in skills_dir.glob("*_skill.md"):
        old_skill.unlink()

    hints: List[ItemHint] = []

    item_module_counter: Counter = Counter()

    with args.csv_path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        for row_index, row in enumerate(reader, start=1):
            item_id = (row.get("Item") or "").strip()
            check_module = (row.get("Check_modules") or "").strip()
            description = (row.get("Info") or "").strip()
            if not item_id or not check_module or not description:
                continue

            module_dir = check_modules_root / check_module
            yaml_path = find_item_yaml(module_dir, item_id)
            script_path = find_checker_script(module_dir, item_id)

            input_files, req_value, waiver_value = read_item_yaml(yaml_path)
            regex_clues, keyword_clues = extract_script_clues(script_path)
            intent = classify_intent(description)
            objects = infer_candidate_objects(description)
            tags = infer_knowledge_tags(description, input_files, check_module)
            item_module_counter[(item_id, check_module)] += 1
            variant_idx = item_module_counter[(item_id, check_module)]
            module_slug = slugify_module(check_module)
            unique_file = (
                f"{item_id}__{module_slug}_skill.md"
                if variant_idx == 1
                else f"{item_id}__{module_slug}__v{variant_idx}_skill.md"
            )

            hint = ItemHint(
                row_index=row_index,
                item_id=item_id,
                check_module=check_module,
                description=description,
                intent=intent,
                knowledge_tags=tags,
                candidate_objects=objects,
                yaml_path=str(yaml_path) if yaml_path else None,
                checker_script=str(script_path) if script_path else None,
                input_files=input_files,
                requirement_value=req_value,
                waiver_value=waiver_value,
                regex_clues=regex_clues,
                keyword_clues=keyword_clues,
                unique_skill_file=unique_file,
            )
            hints.append(hint)

            unique_skill_path = skills_dir / unique_file
            unique_skill_path.write_text(render_skill_markdown(hint), encoding="utf-8")

    # Create ID aliases: single-item alias for unique IDs, aggregate file for duplicates.
    by_item: Dict[str, List[ItemHint]] = defaultdict(list)
    for hint in hints:
        by_item[hint.item_id].append(hint)

    alias_map: Dict[int, str] = {}
    duplicate_item_ids = {item_id for item_id, group in by_item.items() if len(group) > 1}

    for item_id, group in by_item.items():
        if len(group) == 1:
            only = group[0]
            unique_file = only.unique_skill_file
            alias_file = f"{item_id}_skill.md"
            (skills_dir / alias_file).write_text((skills_dir / unique_file).read_text(encoding="utf-8"), encoding="utf-8")
            # For unique IDs keep only the alias name to avoid duplicate files.
            (skills_dir / unique_file).unlink(missing_ok=True)
            alias_map[only.row_index] = alias_file
            continue

        # Duplicate IDs across modules: provide an aggregator alias file.
        lines = [
            f"# {item_id} Skill Hint (Multi-module)",
            "",
            f"`{item_id}` appears in multiple check modules. Select module-specific hints below.",
            "",
            "## Variants",
            "",
        ]
        for h in sorted(group, key=lambda x: x.check_module):
            unique_file = h.unique_skill_file
            alias_map[h.row_index] = unique_file
            lines.append(f"- Module `{h.check_module}`: `{unique_file}`")
            lines.append(f"  - Intent: `{h.intent}`")
            lines.append(f"  - Description: {h.description}")

        alias_file = f"{item_id}_skill.md"
        (skills_dir / alias_file).write_text("\n".join(lines) + "\n", encoding="utf-8")

    # Write machine-readable hints
    jsonl_path = hints_dir / "checker_hints.jsonl"
    with jsonl_path.open("w", encoding="utf-8") as fh:
        for h in hints:
            fh.write(
                json.dumps(
                    {
                        "item_id": h.item_id,
                        "check_module": h.check_module,
                        "description": h.description,
                        "intent": h.intent,
                        "knowledge_tags": h.knowledge_tags,
                        "candidate_objects": h.candidate_objects,
                        "yaml_path": h.yaml_path,
                        "checker_script": h.checker_script,
                        "input_files": h.input_files,
                        "requirements_value": h.requirement_value,
                        "waiver_value": h.waiver_value,
                        "regex_clues": h.regex_clues,
                        "keyword_clues": h.keyword_clues,
                    },
                    ensure_ascii=False,
                )
                + "\n"
            )

    # CSV index for fast lookup
    index_csv_path = hints_dir / "skills_index.csv"
    with index_csv_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["item_id", "check_module", "intent", "knowledge_tags", "skill_file"])
        for h in hints:
            skill_file = alias_map.get(h.row_index)
            if not skill_file:
                skill_file = h.unique_skill_file
            writer.writerow([
                h.item_id,
                h.check_module,
                h.intent,
                ";".join(h.knowledge_tags),
                str((skills_dir / skill_file).relative_to(args.knowledge_root)),
            ])

    by_module = Counter(h.check_module for h in hints)
    by_intent = Counter(h.intent for h in hints)
    tag_counter = Counter(tag for h in hints for tag in h.knowledge_tags)

    report_lines = [
        "# Checker Hint Mining Report",
        "",
        f"- Total items processed: {len(hints)}",
        f"- Unique skill files generated: {len(list(skills_dir.glob('*_skill.md')))}",
        f"- Duplicate Item IDs handled: {len(duplicate_item_ids)}",
        f"- JSONL index: `{jsonl_path.relative_to(args.knowledge_root)}`",
        f"- Skills CSV index: `{index_csv_path.relative_to(args.knowledge_root)}`",
        "",
        "## Modules",
        "",
    ]
    for module, count in sorted(by_module.items()):
        report_lines.append(f"- `{module}`: {count}")

    report_lines.extend(["", "## Intents", ""])
    for intent, count in sorted(by_intent.items()):
        report_lines.append(f"- `{intent}`: {count}")

    report_lines.extend(["", "## Top knowledge tags", ""])
    for tag, count in tag_counter.most_common(20):
        report_lines.append(f"- `{tag}`: {count}")

    (hints_dir / "report.md").write_text("\n".join(report_lines) + "\n", encoding="utf-8")

    # Add a skills README for explicit usage
    readme_lines = [
        "# ID Skill Files",
        "",
        "Each file `<ITEM_ID>_skill.md` provides checker-specific context extracted from:",
        "- CheckList.csv description",
        "- inputs/items YAML",
        "- existing checker script clues (if available)",
        "",
        "Use these files as optional prompt augmentation for Context Agent stage A.",
    ]
    (skills_dir / "README.md").write_text("\n".join(readme_lines) + "\n", encoding="utf-8")

    print(f"[OK] Generated {len(hints)} skill files in {skills_dir}")
    print(f"[OK] Hint report: {hints_dir / 'report.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
