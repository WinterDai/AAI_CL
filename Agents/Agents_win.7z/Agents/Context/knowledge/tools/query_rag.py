#!/usr/bin/env python3
"""
Query local lexical RAG index built by build_rag_index.py.
"""

from __future__ import annotations

import argparse
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List

STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "by",
    "for",
    "from",
    "has",
    "have",
    "if",
    "in",
    "into",
    "is",
    "it",
    "its",
    "of",
    "on",
    "or",
    "that",
    "the",
    "their",
    "this",
    "to",
    "used",
    "using",
    "with",
    "what",
    "when",
    "where",
    "which",
    "why",
}
TOKEN_RE = re.compile(r"[A-Za-z0-9_]+")
ITEM_ID_RE = re.compile(r"[A-Z]+-IMP-\d+-\d+-\d+-\d+|IMP-\d+-\d+-\d+-\d+")


def tokenize(text: str) -> List[str]:
    return [t.lower() for t in TOKEN_RE.findall(text) if len(t) > 1 and t.lower() not in STOPWORDS]


def load_chunks(chunks_path: Path) -> Dict[int, Dict]:
    store = {}
    with chunks_path.open("r", encoding="utf-8") as fh:
        for line in fh:
            data = json.loads(line)
            store[int(data["chunk_id"])] = data
    return store


def main() -> int:
    ap = argparse.ArgumentParser(description="Query local RAG index")
    ap.add_argument("query", type=str)
    ap.add_argument("--index-dir", type=Path, required=True)
    ap.add_argument("--top-k", type=int, default=5)
    args = ap.parse_args()

    index = json.loads((args.index_dir / "index.json").read_text(encoding="utf-8"))
    chunks = load_chunks(args.index_dir / "chunks.jsonl")

    idf = index["idf"]
    postings = index["postings"]
    doc_norms = index["doc_norms"]

    q_tf = Counter(tokenize(args.query))
    if not q_tf:
        print("No valid query terms.")
        return 1

    max_tf = max(q_tf.values())
    q_weights = {}
    q_norm = 0.0
    for term, cnt in q_tf.items():
        if term not in idf:
            continue
        w = (0.5 + 0.5 * (cnt / max_tf)) * float(idf[term])
        q_weights[term] = w
        q_norm += w * w

    q_norm = math.sqrt(q_norm) if q_norm > 0 else 1.0

    scores = defaultdict(float)
    for term, q_w in q_weights.items():
        for doc_id, d_w in postings.get(term, []):
            scores[int(doc_id)] += q_w * float(d_w)

    query_item_ids = [m.group(0).lower() for m in ITEM_ID_RE.finditer(args.query.upper())]
    boosted = []
    for doc_id, raw_score in scores.items():
        chunk = chunks.get(int(doc_id), {})
        source_file = str(chunk.get("source_file", "")).lower()
        text = str(chunk.get("text", "")).lower()
        boost = 0.0
        for item_id in query_item_ids:
            if item_id in source_file:
                boost += 0.35
            elif item_id in text:
                boost += 0.15
        boosted.append((int(doc_id), raw_score + boost))

    ranked = sorted(boosted, key=lambda kv: kv[1], reverse=True)[: args.top_k]

    for rank, (doc_id, raw_score) in enumerate(ranked, start=1):
        d_norm = float(doc_norms[doc_id]) if doc_id < len(doc_norms) else 1.0
        sim = raw_score / (q_norm * (d_norm if d_norm > 0 else 1.0))
        chunk = chunks.get(doc_id, {})
        print(f"[{rank}] score={sim:.4f} file={chunk.get('source_file')} section={chunk.get('section')}")
        text = (chunk.get("text") or "").strip().replace("\n", " ")
        print(f"    {text[:220]}")

    if not ranked:
        print("No matches found.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
