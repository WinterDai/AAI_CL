#!/usr/bin/env python3
"""
Retrieve context snippets for Context Agent prompt augmentation.

Usage:
  python3 retrieve_context.py --index-dir ... --query "..." --item-id IMP-10-0-0-00
"""

from __future__ import annotations

import argparse
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Tuple

STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "by",
    "for",
    "from",
    "has",
    "have",
    "if",
    "in",
    "into",
    "is",
    "it",
    "its",
    "of",
    "on",
    "or",
    "that",
    "the",
    "their",
    "this",
    "to",
    "used",
    "using",
    "with",
    "what",
    "when",
    "where",
    "which",
    "why",
}
TOKEN_RE = re.compile(r"[A-Za-z0-9_]+")
ITEM_ID_RE = re.compile(r"[A-Z]+-IMP-\d+-\d+-\d+-\d+|IMP-\d+-\d+-\d+-\d+")


def tokenize(text: str) -> List[str]:
    return [t.lower() for t in TOKEN_RE.findall(text) if len(t) > 1 and t.lower() not in STOPWORDS]


def load_chunks(chunks_path: Path) -> Dict[int, Dict]:
    store: Dict[int, Dict] = {}
    with chunks_path.open("r", encoding="utf-8") as fh:
        for line in fh:
            row = json.loads(line)
            store[int(row["chunk_id"])] = row
    return store


def rank(index: Dict, chunks: Dict[int, Dict], query: str, top_k: int) -> List[Tuple[float, Dict]]:
    idf = index["idf"]
    postings = index["postings"]
    norms = index["doc_norms"]

    q_tf = Counter(tokenize(query))
    if not q_tf:
        return []

    max_tf = max(q_tf.values())
    q_weights: Dict[str, float] = {}
    q_norm = 0.0
    for term, cnt in q_tf.items():
        if term not in idf:
            continue
        w = (0.5 + 0.5 * (cnt / max_tf)) * float(idf[term])
        q_weights[term] = w
        q_norm += w * w

    q_norm = math.sqrt(q_norm) if q_norm > 0 else 1.0

    scores = defaultdict(float)
    for term, q_w in q_weights.items():
        for doc_id, d_w in postings.get(term, []):
            scores[int(doc_id)] += q_w * float(d_w)

    query_item_ids = [m.group(0).lower() for m in ITEM_ID_RE.finditer(query.upper())]
    ranked = []
    for doc_id, score in scores.items():
        d_norm = float(norms[doc_id]) if doc_id < len(norms) else 1.0
        sim = score / (q_norm * (d_norm if d_norm > 0 else 1.0))
        chunk = chunks.get(doc_id, {})
        source_file = str(chunk.get("source_file", "")).lower()
        text = str(chunk.get("text", "")).lower()
        for item_id in query_item_ids:
            if item_id in source_file:
                sim += 0.35
            elif item_id in text:
                sim += 0.15
        ranked.append((sim, chunk))

    ranked.sort(key=lambda x: x[0], reverse=True)
    return ranked[:top_k]


def main() -> int:
    ap = argparse.ArgumentParser(description="Retrieve markdown context snippets")
    ap.add_argument("--index-dir", type=Path, required=True)
    ap.add_argument("--query", type=str, required=True)
    ap.add_argument("--item-id", type=str, default="")
    ap.add_argument("--top-k", type=int, default=8)
    ap.add_argument("--output", type=Path, default=None)
    args = ap.parse_args()

    index = json.loads((args.index_dir / "index.json").read_text(encoding="utf-8"))
    chunks = load_chunks(args.index_dir / "chunks.jsonl")

    combined_query = args.query
    if args.item_id:
        combined_query = f"{args.item_id} {combined_query}"

    ranked = rank(index, chunks, combined_query, args.top_k)

    lines = ["# Retrieved Context", "", f"- Query: `{args.query}`"]
    if args.item_id:
        lines.append(f"- Item ID: `{args.item_id}`")
    lines.append("")

    for idx, (score, chunk) in enumerate(ranked, start=1):
        source = chunk.get("source_file", "")
        section = chunk.get("section", "")
        text = (chunk.get("text") or "").strip()
        lines.append(f"## Hit {idx}")
        lines.append("")
        lines.append(f"- Score: `{score:.4f}`")
        lines.append(f"- Source: `{source}`")
        lines.append(f"- Section: `{section}`")
        lines.append("")
        lines.append(text)
        lines.append("")

    content = "\n".join(lines) + "\n"

    if args.output:
        args.output.write_text(content, encoding="utf-8")
        print(f"[OK] Wrote retrieved context to {args.output}")
    else:
        print(content)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
