# Knowledge Tooling

## build_rag_index.py
Builds local lexical RAG index from markdown corpora.

## query_rag.py
Runs top-k retrieval against a built index.

## retrieve_context.py
Produces markdown context snippets for prompt injection.

## mine_checker_hints.py
Mines checker-specific hints from:
- `CheckList.csv`
- `Check_modules/*/inputs/items/*.yaml`
- `Check_modules/*/scripts/checker/*.py`

Outputs:
- `knowledge/skills/<ITEM_ID>_skill.md`
- `knowledge/checker_hints/checker_hints.jsonl`
- `knowledge/checker_hints/skills_index.csv`
- `knowledge/checker_hints/report.md`
