# Checker Hint Mining Report

- Total items processed: 354
- Unique skill files generated: 359
- Duplicate Item IDs handled: 5
- JSONL index: `checker_hints/checker_hints.jsonl`
- Skills CSV index: `checker_hints/skills_index.csv`

## Modules

- `1.0_LIBRARY_CHECK`: 5
- `10.0_STA_DCD_CHECK`: 28
- `10.1_STA_DCD_CHECK`: 11
- `10.2_STA_DCD_CHECK`: 4
- `10.3_STA_DCD_CHECK`: 5
- `11.0_POWER_EMIR_CHECK`: 28
- `11.1_POWER_EMIR_CHECK`: 6
- `11.2_POWER_EMIR_CHECK`: 1
- `11.3_POWER_EMIR_CHECK`: 7
- `12.0_PHYSICAL_VERIFICATION_CHECK`: 36
- `13.0_POST_PD_EQUIVALENCE_CHECK`: 8
- `14.0_CLP_CHECK`: 7
- `15.0_ESD_PERC_CHECK`: 6
- `16.0_IPTAG_CHECK`: 8
- `17.0_FINAL_DATA`: 5
- `17.1_FINAL_DATA`: 1
- `17.2_FINAL_DATA`: 2
- `17.3_FINAL_DATA`: 6
- `2.0_TECHFILE_AND_RULE_DECK_CHECK`: 16
- `3.0_TOOL_VERSION`: 6
- `4.0_CONSTRAINT_CHECK`: 11
- `5.0_SYNTHESIS_CHECK`: 20
- `6.0_POST_SYNTHESIS_LEC_CHECK`: 8
- `7.0_INNOVUS_DESIGN_IN_CHECK`: 8
- `7.1_INNOVUS_DESIGN_IN_CHECK`: 2
- `8.0_PHYSICAL_IMPLEMENTATION_CHECK`: 34
- `8.1_PHYSICAL_IMPLEMENTATION_CHECK`: 56
- `8.2_PHYSICAL_IMPLEMENTATION_CHECK`: 5
- `8.3_PHYSICAL_IMPLEMENTATION_CHECK`: 6
- `9.0_RC_EXTRACTION_CHECK`: 8

## Intents

- `advisory`: 1
- `conditional_verification`: 3
- `documentation`: 2
- `inventory`: 22
- `status_check`: 23
- `verification`: 303

## Top knowledge tags

- `power_integrity`: 325
- `timing_signoff`: 76
- `input_logs`: 65
- `input_reports`: 62
- `libraries`: 53
- `constraints`: 49
- `physical_verification`: 46
- `layout_data`: 29
- `deliverables`: 28
- `equivalence`: 21
- `parasitics`: 17
- `implementation_qor`: 10
- `input_scripts`: 8
- `input_text_reports`: 3
- `input_spef`: 1
