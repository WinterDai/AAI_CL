# Context Knowledge Pack (Physical Implementation)

This index lists curated offline references used by the Context Agent to interpret
checker descriptions in digital physical implementation.

## Topics and Summary Files

- Physical implementation flow: summaries/physical_flow.md
- LEF/DEF formats: summaries/lef_def.md
- GDSII layout database: summaries/gdsii.md
- STA input formats (Verilog, Liberty, SDC, SDF, SPEF): summaries/sta_formats.md
- SPEF parasitics format: summaries/spef.md
- SDC constraints (Tcl): summaries/sdc.md
- SDF timing annotation: summaries/sdf.md
- UPF power intent: summaries/upf.md
- DRC physical verification: summaries/drc.md
- LVS physical verification: summaries/lvs.md
- IR drop power integrity: summaries/ir_drop.md
- Electromigration reliability: summaries/electromigration.md

## Checker-derived Knowledge

- Item-level skills: `skills/<ITEM_ID>_skill.md`
- Duplicate-ID variants: `skills/<ITEM_ID>__<module>__vN_skill.md`
- Mined index: `checker_hints/checker_hints.jsonl`
- Skill lookup table: `checker_hints/skills_index.csv`
- Mining report: `checker_hints/report.md`

## Local RAG Indexes

- Baseline index: `rag/stage1_baseline/`
- Expanded index: `rag/main/`
- Build/query tools: `tools/README.md`

## Usage

- Stage A (ItemSpec) can retrieve concept summaries based on description semantics.
- Stage A (ItemSpec) should query `rag/main` with description + optional Item ID.
- Stage B (ParsingSpec) should use summaries only for guidance, not as evidence.
- Stage C (FormatSpec) uses summaries to choose pattern/waiver conventions.

See manifest.yaml for source metadata and licensing notes.
