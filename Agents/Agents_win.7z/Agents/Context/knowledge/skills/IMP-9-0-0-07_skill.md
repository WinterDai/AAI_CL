# IMP-9-0-0-07 Skill Hint

## Description

Confirm all Warning message in QRC log files can be waived.

## Module and Intent

- Module: `9.0_RC_EXTRACTION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir, spef
- Knowledge tags: input_logs, parasitics, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/9.0_RC_EXTRACTION_CHECK/inputs/items/IMP-9-0-0-07.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/9.0_RC_EXTRACTION_CHECK/scripts/checker/IMP-9-0-0-07.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/9.0/do_qrc*.log`

### Regex clues from existing checker

- `\nTOTAL\s+WARNINGS`

### Keyword clues from existing checker

- `#   Confirm all Warning message in QRC log files can be waived.`
- `#   - Validate that all warnings can be waived (either auto-waived or matched by waive_items)`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `#   status_check: pattern_items = items to CHECK STATUS (only output matched items)`
- `#     - found_items = patterns matched AND status correct`
- `#     - missing_items = patterns matched BUT status wrong`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`

## Suggested retrieval queries

- IMP-9-0-0-07 checker intent Confirm all Warning message in QRC log files can be waived.
- physical implementation power_emir spef evidence extraction
- input_logs parasitics power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-9-0-0-07
  check_module: 9.0_RC_EXTRACTION_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - parasitics
  - power_integrity
  candidate_objects:
  - power_emir
  - spef
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/9.0/do_qrc*.log
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/9.0_RC_EXTRACTION_CHECK/inputs/items/IMP-9-0-0-07.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/9.0_RC_EXTRACTION_CHECK/scripts/checker/IMP-9-0-0-07.py
```
