# MIG-IMP-8-1-2-01 Skill Hint

## Description

[BRCM special] Confirm the BRCM don’t_use cell list is correct. Pay attention that the BRCM don’t use list is keeping change. Please check whether you follow the latest one.(The BRCM don’t use file in workbench is based on old program and you need to overwrite or update that per project.) Latest BRCM dont_use cell list can be found in below path: N7: /process/tsmcN7/data/stdcell/tsmc/n7gp/BRCM/MISC_n7gp/docs/dont_use.info.latest N5: /process/tsmcN5/data/stdcell/n5/BRCM/MISC_BRCM_n5/docs/dont_use.info.latest

## Module and Intent

- Module: `8.1_PHYSICAL_IMPLEMENTATION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: libraries, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/MIG-IMP-8-1-2-01.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/MIG-IMP-8-1-2-01.py`

### Input files

- none

### Regex clues from existing checker

- `ERROR:\s+(.+)`
- `YOUR_PATTERN`

### Keyword clues from existing checker

- `#   - TODO: Parse [input_file_name] to extract [specific_data/patterns]`
- `#   - TODO: [Optional] Support waiver for [specific_cases]`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- MIG-IMP-8-1-2-01 checker intent [BRCM special] Confirm the BRCM don’t_use cell list is correct. Pay attention that the BRCM don’t use list is keeping change. Please check whether you follow the latest one.(The BRCM don’t use file in workbench is based on old program and you need to overwrite or update that per project.) Latest BRCM dont_use cell list can be found in below path: N7: /process/tsmcN7/data/stdcell/tsmc/n7gp/BRCM/MISC_n7gp/docs/dont_use.info.latest N5: /process/tsmcN5/data/stdcell/n5/BRCM/MISC_BRCM_n5/docs/dont_use.info.latest
- physical implementation power_emir evidence extraction
- libraries power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: MIG-IMP-8-1-2-01
  check_module: 8.1_PHYSICAL_IMPLEMENTATION_CHECK
  intent: verification
  knowledge_tags:
  - libraries
  - power_integrity
  candidate_objects:
  - power_emir
  input_files: []
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/MIG-IMP-8-1-2-01.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/MIG-IMP-8-1-2-01.py
```
