# IMP-9-0-0-05 Skill Hint

## Description

Confirm proper Quantus version is used for RC extraction(match to or mature than Foundry recommended Quantus version)

## Module and Intent

- Module: `9.0_RC_EXTRACTION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir, spef
- Knowledge tags: input_spef, parasitics, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/9.0_RC_EXTRACTION_CHECK/inputs/items/IMP-9-0-0-05.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/9.0_RC_EXTRACTION_CHECK/scripts/checker/IMP-9-0-0-05.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/9.0/*.spef.gz`

### Regex clues from existing checker

- `^\*VERSION\s+`
- `^\*DATE\s+`
- `\*DESIGN_FLOW.*`
- `^//\s*TECH_FILE\s+(.+)$`
- `^\*DESIGN\s+`

### Keyword clues from existing checker

- `#   Confirm proper Quantus version is used for RC extraction(match to or mature than Foundry recommended Quantus version)`
- `#   - Extract Quantus version from *VERSION line (format: major.minor.patch-build)`
- `#   - Identify foundry/technology from TECH_VERSION (*DESIGN_FLOW) or TECH_FILE comment`
- `#   - Map foundry identifier to minimum required Quantus version from configuration`
- `#   - Compare extracted version against required version using numeric comparison`
- `#   - Classify results: PASS if version >= required, FAIL if version < required or info missing`
- `#   - Report per-file results with file path, found version, required version, and foundry`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`

## Suggested retrieval queries

- IMP-9-0-0-05 checker intent Confirm proper Quantus version is used for RC extraction(match to or mature than Foundry recommended Quantus version)
- physical implementation power_emir spef evidence extraction
- input_spef parasitics power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-9-0-0-05
  check_module: 9.0_RC_EXTRACTION_CHECK
  intent: verification
  knowledge_tags:
  - input_spef
  - parasitics
  - power_integrity
  candidate_objects:
  - power_emir
  - spef
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/9.0/*.spef.gz
  requirements_value: '2'
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/9.0_RC_EXTRACTION_CHECK/inputs/items/IMP-9-0-0-05.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/9.0_RC_EXTRACTION_CHECK/scripts/checker/IMP-9-0-0-05.py
```
