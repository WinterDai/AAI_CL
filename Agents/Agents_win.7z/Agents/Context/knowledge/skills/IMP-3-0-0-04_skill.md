# IMP-3-0-0-04 Skill Hint

## Description

List Voltus power and EMIR signoff tool version (eg. quantus/231/23.11.000)

## Module and Intent

- Module: `3.0_TOOL_VERSION`
- Intent: `inventory`
- Candidate objects: power_emir
- Knowledge tags: input_scripts, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/3.0_TOOL_VERSION/inputs/items/IMP-3-0-0-04.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/3.0_TOOL_VERSION/scripts/checker/IMP-3-0-0-04.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/tcl/2.0/setup_vars.tcl`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   List Voltus power and EMIR signoff tool version (eg. quantus/231/23.11.000)`
- `#   - Extract module name, major version, and full version string`
- `#   - Format output as tool_name/major_version/full_version`
- `#   - Report all discovered tool versions as INFO items`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`

## Suggested retrieval queries

- IMP-3-0-0-04 checker intent List Voltus power and EMIR signoff tool version (eg. quantus/231/23.11.000)
- physical implementation power_emir evidence extraction
- input_scripts power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-3-0-0-04
  check_module: 3.0_TOOL_VERSION
  intent: inventory
  knowledge_tags:
  - input_scripts
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/tcl/2.0/setup_vars.tcl
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/3.0_TOOL_VERSION/inputs/items/IMP-3-0-0-04.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/3.0_TOOL_VERSION/scripts/checker/IMP-3-0-0-04.py
```
