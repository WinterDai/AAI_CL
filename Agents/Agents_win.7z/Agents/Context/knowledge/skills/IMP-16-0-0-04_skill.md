# IMP-16-0-0-04 Skill Hint

## Description

Confirm update the IPTAG if FIRM PHY slices are reused as FIRM PHY delivery for another project.

## Module and Intent

- Module: `16.0_IPTAG_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: deliverables, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/inputs/items/IMP-16-0-0-04.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/scripts/checker/IMP-16-0-0-04.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/16.0/cdn_hs_phy_top.csv`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `#   existence_check: pattern_items = items that SHOULD EXIST in input files`
- `#     - found_items = patterns found in file`
- `#     - missing_items = patterns NOT found in file`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`

## Suggested retrieval queries

- IMP-16-0-0-04 checker intent Confirm update the IPTAG if FIRM PHY slices are reused as FIRM PHY delivery for another project.
- physical implementation power_emir evidence extraction
- deliverables power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-16-0-0-04
  check_module: 16.0_IPTAG_CHECK
  intent: verification
  knowledge_tags:
  - deliverables
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/16.0/cdn_hs_phy_top.csv
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/inputs/items/IMP-16-0-0-04.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/scripts/checker/IMP-16-0-0-04.py
```
