# IMP-5-0-0-09 Skill Hint

## Description

Confirm Latches Inferred documented?

## Module and Intent

- Module: `5.0_SYNTHESIS_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_reports, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-09.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-09.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/latch.rpt`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   Supports 4 checking types based on requirements and waivers configuration.`
- `#   - Automatic type detection based on requirements.value and waivers.value`
- `#   - Support waiver for documented/approved latches`
- `- Type 1: requirements=N/A, waivers=N/A/0 → Always PASS (informational only)`
- `- Type 2: requirements>0, waivers=N/A/0 → FAIL if undocumented latches exist`
- `- Type 3: requirements>0, waivers>0 → FAIL if unwaived latches exist`
- `- Type 4: requirements=N/A, waivers>0 → FAIL if unwaived latches exist`
- `lines = self.read_file(latch_rpt_path)`
- `# Pattern: inst:<instance_path> <anything>/<LATCH_CELL_NAME>`
- `pattern = re.compile(r'^inst:(\S+)\s+(.+)/([A-Z0-9_]+)\s*$', re.IGNORECASE)`
- `match = pattern.match(stripped)`
- `# Type 1: Informational Check (requirements=N/A, waivers=N/A/0)`

## Suggested retrieval queries

- IMP-5-0-0-09 checker intent Confirm Latches Inferred documented?
- physical implementation power_emir evidence extraction
- input_reports power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-5-0-0-09
  check_module: 5.0_SYNTHESIS_CHECK
  intent: verification
  knowledge_tags:
  - input_reports
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/latch.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-09.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-09.py
```
