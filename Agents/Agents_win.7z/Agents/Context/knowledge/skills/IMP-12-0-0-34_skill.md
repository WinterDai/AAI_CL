# IMP-12-0-0-34 Skill Hint (Multi-module)

`IMP-12-0-0-34` appears in multiple check modules. Select module-specific hints below.

## Variants

- Module `12.0_PHYSICAL_VERIFICATION_CHECK`: `IMP-12-0-0-34__12_0_PHYSICAL_VERIFICATION_CHECK_skill.md`
  - Intent: `verification`
  - Description: Confirm RTO DRC result is clean for post-mask ECO if foundry has RTO DRC check requirement. (fill N/A is no RTO DRC check)
- Module `12.0_PHYSICAL_VERIFICATION_CHECK`: `IMP-12-0-0-34__12_0_PHYSICAL_VERIFICATION_CHECK__v2_skill.md`
  - Intent: `verification`
  - Description: Confirm all Warning message in RTO DRC log files can be waived. (for SEC process, for others fill N/A)
