# IMP-9-0-0-02 Skill Hint

## Description

Confirm SPEF extraction includes NDR rule lef file.

## Module and Intent

- Module: `9.0_RC_EXTRACTION_CHECK`
- Intent: `verification`
- Candidate objects: lef_def, power_emir, spef
- Knowledge tags: input_logs, layout_data, parasitics, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/9.0_RC_EXTRACTION_CHECK/inputs/items/IMP-9-0-0-02.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/9.0_RC_EXTRACTION_CHECK/scripts/checker/IMP-9-0-0-02.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/9.0/do_qrc*.log`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Detect version mismatch warnings between tech LEF and NDR LEF (EXTGRMP-728)`
- `#   - Report any version mismatches or critical errors`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- IMP-9-0-0-02 checker intent Confirm SPEF extraction includes NDR rule lef file.
- physical implementation lef_def power_emir spef evidence extraction
- input_logs layout_data parasitics power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-9-0-0-02
  check_module: 9.0_RC_EXTRACTION_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - layout_data
  - parasitics
  - power_integrity
  candidate_objects:
  - lef_def
  - power_emir
  - spef
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/9.0/do_qrc*.log
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/9.0_RC_EXTRACTION_CHECK/inputs/items/IMP-9-0-0-02.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/9.0_RC_EXTRACTION_CHECK/scripts/checker/IMP-9-0-0-02.py
```
