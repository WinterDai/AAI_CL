# IMP-15-0-0-04 Skill Hint

## Description

Confirm there is no issue about CNOD check if CNOD check is needed.

## Module and Intent

- Module: `15.0_ESD_PERC_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_reports, physical_verification, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/15.0_ESD_PERC_CHECK/inputs/items/IMP-15-0-0-04.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/15.0_ESD_PERC_CHECK/scripts/checker/IMP-15-0-0-04.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/15.0/cnod_perc.rep`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Search for "CHECK(s) PASS" pattern in the report`
- `#   - Report FAIL if CHECK(s) PASS pattern not found`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `#   existence_check: pattern_items = items that SHOULD EXIST in input files`
- `#     - found_items = patterns found in file`
- `#     - missing_items = patterns NOT found in file`
- `#   status_check: pattern_items = items to CHECK STATUS (only output matched items)`
- `#     - found_items = patterns matched AND status correct`
- `#     - missing_items = patterns matched BUT status wrong`

## Suggested retrieval queries

- IMP-15-0-0-04 checker intent Confirm there is no issue about CNOD check if CNOD check is needed.
- physical implementation power_emir evidence extraction
- input_reports physical_verification power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-15-0-0-04
  check_module: 15.0_ESD_PERC_CHECK
  intent: verification
  knowledge_tags:
  - input_reports
  - physical_verification
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/15.0/cnod_perc.rep
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/15.0_ESD_PERC_CHECK/inputs/items/IMP-15-0-0-04.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/15.0_ESD_PERC_CHECK/scripts/checker/IMP-15-0-0-04.py
```
