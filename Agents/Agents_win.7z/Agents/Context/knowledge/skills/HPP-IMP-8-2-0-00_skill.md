# HPP-IMP-8-2-0-00 Skill Hint

## Description

Confirm floorplan has been peer reviewed and agreed?

## Module and Intent

- Module: `8.2_PHYSICAL_IMPLEMENTATION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.2_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/HPP-IMP-8-2-0-00.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.2_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/HPP-IMP-8-2-0-00.py`

### Input files

- none

### Regex clues from existing checker

- `ERROR:\s+(.+)`
- `YOUR_PATTERN`

### Keyword clues from existing checker

- `#   - TODO: Parse [input_file_name] to extract [specific_data/patterns]`
- `#   - TODO: [Optional] Support waiver for [specific_cases]`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- HPP-IMP-8-2-0-00 checker intent Confirm floorplan has been peer reviewed and agreed?
- physical implementation power_emir evidence extraction
- power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: HPP-IMP-8-2-0-00
  check_module: 8.2_PHYSICAL_IMPLEMENTATION_CHECK
  intent: verification
  knowledge_tags:
  - power_integrity
  candidate_objects:
  - power_emir
  input_files: []
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.2_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/HPP-IMP-8-2-0-00.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.2_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/HPP-IMP-8-2-0-00.py
```
