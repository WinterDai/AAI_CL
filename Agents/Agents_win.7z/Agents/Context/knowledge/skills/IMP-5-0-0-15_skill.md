# IMP-5-0-0-15 Skill Hint

## Description

Confirm all DFT checks pass?

## Module and Intent

- Module: `5.0_SYNTHESIS_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_logs, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-15.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-15.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/dft_check_test.log`

### Regex clues from existing checker

- `(?:Fail|Info|Warn):\s*(.+?)\.\s+In line`

### Keyword clues from existing checker

- `#   - Support pattern matching for specific DFT violation types`
- `#   - Support waiver logic for approved violations`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `- Type 1: requirements.value=N/A AND waivers.value=N/A/0`
- `- Type 2: requirements.value>0 AND pattern_items AND waivers.value=N/A/0`
- `- Type 3: requirements.value>0 AND pattern_items AND waivers.value>0`
- `- Type 4: requirements.value=N/A AND waivers.value>0`
- `has_pattern_items=False,`
- `has_waiver_value=False,`

## Suggested retrieval queries

- IMP-5-0-0-15 checker intent Confirm all DFT checks pass?
- physical implementation power_emir evidence extraction
- input_logs power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-5-0-0-15
  check_module: 5.0_SYNTHESIS_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/dft_check_test.log
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-15.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-15.py
```
