# IMP-11-0-0-04 Skill Hint

## Description

Confirm proper rc/PVT corners were used for IR drop and EM analysis. List rc/PVT corners used in comments field.

## Module and Intent

- Module: `11.0_POWER_EMIR_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_logs, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/inputs/items/IMP-11-0-0-04.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/scripts/checker/IMP-11-0-0-04.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/*static*.log`
- `${CHECKLIST_ROOT}/IP_project_folder/logs/*dynamic*.log`
- `${CHECKLIST_ROOT}/IP_project_folder/logs/*EM*.log`

### Regex clues from existing checker

- `(\w+_\w+_\w+)\.tch`

### Keyword clues from existing checker

- `#   - Extract PVT corner from view definition basename pattern: {mode}_{process}_{voltage}v_{temp}c`
- `#   - Extract PA view definition from read_view_definition command`
- `#   - Validate corner specifications against expected pattern_items (Type 2/3)`
- `#   - Apply waiver logic for exempted corners (Type 3/4)`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `#   status_check: pattern_items = items to CHECK STATUS (only output matched items)`
- `#     - found_items = patterns matched AND status correct`
- `#     - missing_items = patterns matched BUT status wrong`
- `# Waiver Tag Rules:`

## Suggested retrieval queries

- IMP-11-0-0-04 checker intent Confirm proper rc/PVT corners were used for IR drop and EM analysis. List rc/PVT corners used in comments field.
- physical implementation power_emir evidence extraction
- input_logs power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-11-0-0-04
  check_module: 11.0_POWER_EMIR_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/*static*.log
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/*dynamic*.log
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/*EM*.log
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/inputs/items/IMP-11-0-0-04.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/scripts/checker/IMP-11-0-0-04.py
```
