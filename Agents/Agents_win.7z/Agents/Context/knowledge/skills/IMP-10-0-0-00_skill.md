# IMP-10-0-0-00 Skill Hint

## Description

Confirm the netlist/spef version is correct.

## Module and Intent

- Module: `10.0_STA_DCD_CHECK`
- Intent: `verification`
- Candidate objects: netlist, power_emir, spef
- Knowledge tags: input_logs, parasitics, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-00.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-00.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/sta_post_syn.log`

### Regex clues from existing checker

- `read_netlist\s+([^\s]+\.v(?:\.gz)?)`
- `\[INFO\]\s+Skipping SPEF reading as (.+)`
- `read_spef\s+([^\s]+\.spef(?:\.gz)?)`
- `#\s*Parasitics Mode:\s*(.+)`
- `Top level cell is\s+(\S+)`
- `Program version\s*=\s*([\d\.\-\w]+)`
- `Generated on:\s*(.+?)\s+\w+\s+\((.+?)\)`
- `Generated on:\s*(.+?)$`
- `DATE\s+`
- `DESIGN_FLOW\s+`

### Keyword clues from existing checker

- `#   Confirm the netlist/spef version is correct.`
- `#   - Extract netlist file path from read_netlist command`
- `#   - Open extracted netlist file to capture version timestamp from header (line 3)`
- `#   - Open extracted SPEF file (if present) to capture version timestamp`
- `#   - Verify parasitics mode consistency with SPEF status`
- `#   - Extract tool version and top-level design name for context`
- `#   - Validate that netlist and SPEF versions match expected configuration`
- `#   - Report version information with file paths and timestamps`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`

## Suggested retrieval queries

- IMP-10-0-0-00 checker intent Confirm the netlist/spef version is correct.
- physical implementation netlist power_emir spef evidence extraction
- input_logs parasitics power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-10-0-0-00
  check_module: 10.0_STA_DCD_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - parasitics
  - power_integrity
  - timing_signoff
  candidate_objects:
  - netlist
  - power_emir
  - spef
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/sta_post_syn.log
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-00.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-00.py
```
