# IMP-15-0-0-02 Skill Hint

## Description

Confirm the PERC voltage setting is correct.(check the Note)

## Module and Intent

- Module: `15.0_ESD_PERC_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_scripts, input_text_reports, physical_verification, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/15.0_ESD_PERC_CHECK/inputs/items/IMP-15-0-0-02.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/15.0_ESD_PERC_CHECK/scripts/checker/IMP-15-0-0-02.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/15.0/setup_vars.tcl`
- `${CHECKLIST_ROOT}/IP_project_folder/reports/15.0/voltage.txt`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Extract library file paths containing both "tt" and "ddrio" patterns`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `#   existence_check: pattern_items = items that SHOULD EXIST in input files`
- `#     - found_items = patterns found in file`
- `#     - missing_items = patterns NOT found in file`
- `#   status_check: pattern_items = items to CHECK STATUS (only output matched items)`
- `#     - found_items = patterns matched AND status correct`
- `#     - missing_items = patterns matched BUT status wrong`
- `# Waiver Tag Rules:`

## Suggested retrieval queries

- IMP-15-0-0-02 checker intent Confirm the PERC voltage setting is correct.(check the Note)
- physical implementation power_emir evidence extraction
- input_scripts input_text_reports physical_verification power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-15-0-0-02
  check_module: 15.0_ESD_PERC_CHECK
  intent: verification
  knowledge_tags:
  - input_scripts
  - input_text_reports
  - physical_verification
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/15.0/setup_vars.tcl
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/15.0/voltage.txt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/15.0_ESD_PERC_CHECK/inputs/items/IMP-15-0-0-02.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/15.0_ESD_PERC_CHECK/scripts/checker/IMP-15-0-0-02.py
```
