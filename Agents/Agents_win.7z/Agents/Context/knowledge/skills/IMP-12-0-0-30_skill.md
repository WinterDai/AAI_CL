# IMP-12-0-0-30 Skill Hint

## Description

Confirm DFM check result is clean. (for SEC process, for others fill N/A)

## Module and Intent

- Module: `12.0_PHYSICAL_VERIFICATION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-30.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-30.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Pegasus_DFM.sum`

### Regex clues from existing checker

- `^Total DRC Results\s*:\s*(\d+)\s*\((\d+)\)$`
- `^RULECHECK\s+(\S+)\s+\.+\s+Total Result\s+(\d+)\s*\(\s*\d+\)$`
- `^\s{4}RULECHECK\s+(\S+)\s+\.+\s+Total Result\s+(\d+)\s*\(\s*\d+\)$`
- `^(Execute on Date/Time|Pegasus VERSION|User Name)\s*:\s*(.+)$`

### Keyword clues from existing checker

- `#   - Support waiver for specific DFM rulechecks that are acceptable violations`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`
- `#     - FAIL/WARN converted to INFO with suffix: [WAIVED_AS_INFO]`

## Suggested retrieval queries

- IMP-12-0-0-30 checker intent Confirm DFM check result is clean. (for SEC process, for others fill N/A)
- physical implementation power_emir evidence extraction
- power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-12-0-0-30
  check_module: 12.0_PHYSICAL_VERIFICATION_CHECK
  intent: verification
  knowledge_tags:
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Pegasus_DFM.sum
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-30.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-30.py
```
