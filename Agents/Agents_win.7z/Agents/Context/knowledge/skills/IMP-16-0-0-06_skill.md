# IMP-16-0-0-06 Skill Hint

## Description

Confirm you followed the below document about IPTAG creation. If you have further question, please check with Tobing. HSPHY/HPPHY/DFPHY/GDDR/HBM: https://cadence.sharepoint.com/:w:/r/sites/IPGroup/DesignIP/Quality/_layouts/15/Doc.aspx?sourcedoc=%7B26DAB946-483A-415F-AC0C-C195C0838506%7D&file=IP%20Number%20Format%20-%20DDR%20PHY.docx&wdLOR=cF5835961-1465-461D-BAFD-3F0590F6A7F9&action=default&mobileredirect=true SERDES: https://cadence.sharepoint.com/:w:/r/sites/IPGroup/DesignIP/Quality/IP_Numbers/IP%20Number%20Format%20-%20SerDes.docx?d=wf015c37bca9b4d3d951589cf616333fe&csf=1&web=1

## Module and Intent

- Module: `16.0_IPTAG_CHECK`
- Intent: `verification`
- Candidate objects: lef_def, power_emir
- Knowledge tags: layout_data, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/inputs/items/IMP-16-0-0-06.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/scripts/checker/IMP-16-0-0-06.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/16.0/phy_iptag.prod`

### Regex clues from existing checker

- `([A-Z])\s*=`

### Keyword clues from existing checker

- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`
- `#     - FAIL/WARN converted to INFO with suffix: [WAIVED_AS_INFO]`
- `from checker_templates.waiver_handler_template import WaiverHandlerMixin`

## Suggested retrieval queries

- IMP-16-0-0-06 checker intent Confirm you followed the below document about IPTAG creation. If you have further question, please check with Tobing. HSPHY/HPPHY/DFPHY/GDDR/HBM: https://cadence.sharepoint.com/:w:/r/sites/IPGroup/DesignIP/Quality/_layouts/15/Doc.aspx?sourcedoc=%7B26DAB946-483A-415F-AC0C-C195C0838506%7D&file=IP%20Number%20Format%20-%20DDR%20PHY.docx&wdLOR=cF5835961-1465-461D-BAFD-3F0590F6A7F9&action=default&mobileredirect=true SERDES: https://cadence.sharepoint.com/:w:/r/sites/IPGroup/DesignIP/Quality/IP_Numbers/IP%20Number%20Format%20-%20SerDes.docx?d=wf015c37bca9b4d3d951589cf616333fe&csf=1&web=1
- physical implementation lef_def power_emir evidence extraction
- layout_data power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-16-0-0-06
  check_module: 16.0_IPTAG_CHECK
  intent: verification
  knowledge_tags:
  - layout_data
  - power_integrity
  candidate_objects:
  - lef_def
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/16.0/phy_iptag.prod
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/inputs/items/IMP-16-0-0-06.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/scripts/checker/IMP-16-0-0-06.py
```
