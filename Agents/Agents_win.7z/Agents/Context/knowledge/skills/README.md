# ID Skill Files

Each file `<ITEM_ID>_skill.md` provides checker-specific context extracted from:
- CheckList.csv description
- inputs/items YAML
- existing checker script clues (if available)

Use these files as optional prompt augmentation for Context Agent stage A.
