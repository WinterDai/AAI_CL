# IMP-8-0-0-02 Skill Hint

## Description

Confirm all ports status are Fixed.

## Module and Intent

- Module: `8.0_PHYSICAL_IMPLEMENTATION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_reports, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/IMP-8-0-0-02.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/IMP-8-0-0-02.py`

### Input files

- `C:\Users\chyao\Desktop\checklist_dev\CHECKLIST\CHECKLIST\IP_project_folder\reports\8.0\IMP-8-0-0-02\IMP-8-0-0-02_case3.rpt`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Extract port names and placement status using regex patterns`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `#   status_check: pattern_items = items to CHECK STATUS (only output matched items)`
- `#     - found_items = patterns matched AND status correct`
- `#     - missing_items = patterns matched BUT status wrong`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`

## Suggested retrieval queries

- IMP-8-0-0-02 checker intent Confirm all ports status are Fixed.
- physical implementation power_emir evidence extraction
- input_reports power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-8-0-0-02
  check_module: 8.0_PHYSICAL_IMPLEMENTATION_CHECK
  intent: verification
  knowledge_tags:
  - input_reports
  - power_integrity
  - timing_signoff
  candidate_objects:
  - power_emir
  input_files:
  - C:\Users\chyao\Desktop\checklist_dev\CHECKLIST\CHECKLIST\IP_project_folder\reports\8.0\IMP-8-0-0-02\IMP-8-0-0-02_case3.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/IMP-8-0-0-02.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/IMP-8-0-0-02.py
```
