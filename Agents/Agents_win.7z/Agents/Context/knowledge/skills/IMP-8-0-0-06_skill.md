# IMP-8-0-0-06 Skill Hint

## Description

Confirm the switch power pin is not in lef . (for non-PSO, please fill N/A)

## Module and Intent

- Module: `8.0_PHYSICAL_IMPLEMENTATION_CHECK`
- Intent: `verification`
- Candidate objects: lef_def, power_emir
- Knowledge tags: input_logs, input_reports, layout_data, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/IMP-8-0-0-06.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/IMP-8-0-0-06.py`

### Input files

- `${CHECKLIST_ROOT}\IP_project_folder\logs\8.0\do_innovusOUTwoD.logv2`
- `${CHECKLIST_ROOT}\IP_project_folder\reports\8.0\switch_power_layer.rpt`

### Regex clues from existing checker

- `write_lef_abstract.*OUTwoD\.lef.*-PGpinLayers\s+\{([^}]+)\}`
- `write_lef_abstract.*OUTwoD\.lef.*-PGpinLayers\s+(\S+)`
- `^Design Hierarchy:\s*(.+?)\s*$`
- `^Switch Power:\s*(.+?)\s*$`
- `^Switch Power Layer:\s*(.+?)(?:\s*#.*)?$`

### Keyword clues from existing checker

- `#   - For Type 2/3: Filter by design hierarchy (pattern_items), force PASS for sub-blocks`
- `#   - Support waiver for specific design hierarchies (Type 3/4)`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- IMP-8-0-0-06 checker intent Confirm the switch power pin is not in lef . (for non-PSO, please fill N/A)
- physical implementation lef_def power_emir evidence extraction
- input_logs input_reports layout_data power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-8-0-0-06
  check_module: 8.0_PHYSICAL_IMPLEMENTATION_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - input_reports
  - layout_data
  - power_integrity
  candidate_objects:
  - lef_def
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}\IP_project_folder\logs\8.0\do_innovusOUTwoD.logv2
  - ${CHECKLIST_ROOT}\IP_project_folder\reports\8.0\switch_power_layer.rpt
  requirements_value: '1'
  waiver_value: '1'
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/IMP-8-0-0-06.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/IMP-8-0-0-06.py
```
