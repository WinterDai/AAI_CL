# SRG-IMP-11-3-0-03 Skill Hint

## Description

Is the missing via check is clean

## Module and Intent

- Module: `11.3_POWER_EMIR_CHECK`
- Intent: `status_check`
- Candidate objects: not identified from description
- Knowledge tags: power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.3_POWER_EMIR_CHECK/inputs/items/SRG-IMP-11-3-0-03.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.3_POWER_EMIR_CHECK/scripts/checker/SRG-IMP-11-3-0-03.py`

### Input files

- none

### Regex clues from existing checker

- `ERROR:\s+(.+)`
- `YOUR_PATTERN`

### Keyword clues from existing checker

- `#   - TODO: Parse [input_file_name] to extract [specific_data/patterns]`
- `#   - TODO: [Optional] Support waiver for [specific_cases]`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- SRG-IMP-11-3-0-03 checker intent Is the missing via check is clean
- physical implementation  evidence extraction
- power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: SRG-IMP-11-3-0-03
  check_module: 11.3_POWER_EMIR_CHECK
  intent: status_check
  knowledge_tags:
  - power_integrity
  candidate_objects: []
  input_files: []
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.3_POWER_EMIR_CHECK/inputs/items/SRG-IMP-11-3-0-03.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.3_POWER_EMIR_CHECK/scripts/checker/SRG-IMP-11-3-0-03.py
```
