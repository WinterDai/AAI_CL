# IMP-10-0-0-16 Skill Hint

## Description

Confirm clock signal full swing result is clean if foundry timing signoff criteria has full swing requirement.

## Module and Intent

- Module: `10.0_STA_DCD_CHECK`
- Intent: `verification`
- Candidate objects: power_emir, sdc, timing
- Knowledge tags: constraints, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-16.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-16.py`

### Input files

- none

### Regex clues from existing checker

- `ERROR:\s+(.+)`
- `YOUR_PATTERN`

### Keyword clues from existing checker

- `#   - TODO: Parse [input_file_name] to extract [specific_data/patterns]`
- `#   - TODO: [Optional] Support waiver for [specific_cases]`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean Check with Waiver Logic`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`
- `#     - FAIL/WARN converted to INFO with suffix: [WAIVED_AS_INFO]`

## Suggested retrieval queries

- IMP-10-0-0-16 checker intent Confirm clock signal full swing result is clean if foundry timing signoff criteria has full swing requirement.
- physical implementation power_emir sdc timing evidence extraction
- constraints power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-10-0-0-16
  check_module: 10.0_STA_DCD_CHECK
  intent: verification
  knowledge_tags:
  - constraints
  - power_integrity
  - timing_signoff
  candidate_objects:
  - power_emir
  - sdc
  - timing
  input_files: []
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-16.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-16.py
```
