# MIG-IMP-8-1-1-19 Skill Hint

## Description

Confirm use the clock inverters and set NDR routing to the paths from PLL TESTOUT and OBS out. For HPPHY: the paths are from DESKEW PLL to pll_testout pad input pins or pll_testout DFI interface pins. For Dragonfly LPPHY: the paths are from PLL_clk_obs_out(DS/AS HM)-> phy_obs_pll_clk(phy_top) and PLL_refclk_obs_out(DS/AS HM)->phy_obs_pll_refclk(phy_top) For Dragonfly DDR5 PHY: the paths are : from top deskew PLL(phy_top)->pll_refclk_testout_top_pll/pll_testout_top_pll(phy_top) : from PLL_clk_obs_out(DS HM)->pll_testout_ds*_pll(phy_top), PLL_refclk_obs_out(DS HM)->pll_refclk_testout_ds*_pll(phy_top) : from PLL_clk_obs_out(cmn_cas)->pll_testout_cmn_pll(phy_top),PLL_refclk_obs_out(cmn_cas)->pll_refclk_testout_cmn_pll(phy_top) : from CMN_clk_obs_out(cmnhm)-> CMN_clk_obs_out(phy_top) For tv_chip level: Do similar things to paths which are for FRACN-PLL/DESKEW-PLL clock testing or observing.

## Module and Intent

- Module: `8.1_PHYSICAL_IMPLEMENTATION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir, sdc
- Knowledge tags: constraints, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/MIG-IMP-8-1-1-19.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/MIG-IMP-8-1-1-19.py`

### Input files

- none

### Regex clues from existing checker

- `ERROR:\s+(.+)`
- `YOUR_PATTERN`

### Keyword clues from existing checker

- `#   - TODO: Parse [input_file_name] to extract [specific_data/patterns]`
- `#   - TODO: [Optional] Support waiver for [specific_cases]`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- MIG-IMP-8-1-1-19 checker intent Confirm use the clock inverters and set NDR routing to the paths from PLL TESTOUT and OBS out. For HPPHY: the paths are from DESKEW PLL to pll_testout pad input pins or pll_testout DFI interface pins. For Dragonfly LPPHY: the paths are from PLL_clk_obs_out(DS/AS HM)-> phy_obs_pll_clk(phy_top) and PLL_refclk_obs_out(DS/AS HM)->phy_obs_pll_refclk(phy_top) For Dragonfly DDR5 PHY: the paths are : from top deskew PLL(phy_top)->pll_refclk_testout_top_pll/pll_testout_top_pll(phy_top) : from PLL_clk_obs_out(DS HM)->pll_testout_ds*_pll(phy_top), PLL_refclk_obs_out(DS HM)->pll_refclk_testout_ds*_pll(phy_top) : from PLL_clk_obs_out(cmn_cas)->pll_testout_cmn_pll(phy_top),PLL_refclk_obs_out(cmn_cas)->pll_refclk_testout_cmn_pll(phy_top) : from CMN_clk_obs_out(cmnhm)-> CMN_clk_obs_out(phy_top) For tv_chip level: Do similar things to paths which are for FRACN-PLL/DESKEW-PLL clock testing or observing.
- physical implementation power_emir sdc evidence extraction
- constraints power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: MIG-IMP-8-1-1-19
  check_module: 8.1_PHYSICAL_IMPLEMENTATION_CHECK
  intent: verification
  knowledge_tags:
  - constraints
  - power_integrity
  candidate_objects:
  - power_emir
  - sdc
  input_files: []
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/MIG-IMP-8-1-1-19.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/MIG-IMP-8-1-1-19.py
```
