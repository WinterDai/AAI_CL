# SRG-IMP-8-3-0-00 Skill Hint (Multi-module)

`SRG-IMP-8-3-0-00` appears in multiple check modules. Select module-specific hints below.

## Variants

- Module `8.3_PHYSICAL_IMPLEMENTATION_CHECK`: `SRG-IMP-8-3-0-00__8_3_PHYSICAL_IMPLEMENTATION_CHECK_skill.md`
  - Intent: `status_check`
  - Description: Are we adding a prefix to the Timing ECOs for tracking purpose?
- Module `8.3_PHYSICAL_IMPLEMENTATION_CHECK`: `SRG-IMP-8-3-0-00__8_3_PHYSICAL_IMPLEMENTATION_CHECK__v2_skill.md`
  - Intent: `status_check`
  - Description: Are the ECOs being implemented using only Metal ECO cells?
- Module `8.3_PHYSICAL_IMPLEMENTATION_CHECK`: `SRG-IMP-8-3-0-00__8_3_PHYSICAL_IMPLEMENTATION_CHECK__v3_skill.md`
  - Intent: `status_check`
  - Description: Are we running RTO DRC (if tsmc and <28nm project)?
- Module `8.3_PHYSICAL_IMPLEMENTATION_CHECK`: `SRG-IMP-8-3-0-00__8_3_PHYSICAL_IMPLEMENTATION_CHECK__v4_skill.md`
  - Intent: `conditional_verification`
  - Description: If shielding is required, is it done as per the customer/IP document inputs?
