# IMP-5-0-0-17 Skill Hint

## Description

Confirm CPF/UPF file has passed Conformal LP quality checks against post DFT insertion synthesis netlist?

## Module and Intent

- Module: `5.0_SYNTHESIS_CHECK`
- Intent: `verification`
- Candidate objects: lec, netlist, power_emir
- Knowledge tags: equivalence, input_reports, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-17.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-17.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/verify_power_structure_post_dft.rpt`

### Regex clues from existing checker

- `^([A-Z][A-Z0-9_\.]+)\s*:\s*(.+)$`
- `Severity\s*:\s*(\w+)`
- `^[A-Z][A-Z0-9_\.]+\s*:`
- `^(\d+):\s*(.+)$`

### Keyword clues from existing checker

- `#   - Support pattern matching for specific error types`
- `#   - Support waiver logic for approved errors`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `- Type 1: requirements.value=N/A AND waivers.value=N/A/0`
- `- Type 2: requirements.value>0 AND pattern_items AND waivers.value=N/A/0`
- `- Type 3: requirements.value>0 AND pattern_items AND waivers.value>0`
- `- Type 4: requirements.value=N/A AND waivers.value>0`
- `has_pattern_items=False,`
- `has_waiver_value=False,`

## Suggested retrieval queries

- IMP-5-0-0-17 checker intent Confirm CPF/UPF file has passed Conformal LP quality checks against post DFT insertion synthesis netlist?
- physical implementation lec netlist power_emir evidence extraction
- equivalence input_reports power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-5-0-0-17
  check_module: 5.0_SYNTHESIS_CHECK
  intent: verification
  knowledge_tags:
  - equivalence
  - input_reports
  - power_integrity
  candidate_objects:
  - lec
  - netlist
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/verify_power_structure_post_dft.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-17.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-17.py
```
