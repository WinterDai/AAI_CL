# IMP-11-0-0-26 Skill Hint

## Description

List the VT ratio (without physical cells): EG: TSMCN7/N6:SVT(50%)/LVT(40%)/ULVT(10%) TSMCN5/N4/N3/N2:SVT(50%)/LVTLL(20%)/LVT(20%)/ULVTLL(5%)/ULVT(5%)/ELVT(0%) SEC:RVT(50%)/LVT(40%)/SLVT(10%) INTl_I3/18A:ad(HVT 30%)/ac(SVT 20%)/ab(LVT 30%)/aa(ULVT 20%)

## Module and Intent

- Module: `11.0_POWER_EMIR_CHECK`
- Intent: `inventory`
- Candidate objects: not identified from description
- Knowledge tags: libraries, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/inputs/items/IMP-11-0-0-26.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/scripts/checker/IMP-11-0-0-26.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/11.0/vtratio.sum`

### Regex clues from existing checker

- `(\w+)\(((?:==|>=|<=|>|<)?\s*[\d.]+)%?\)`
- `(\w+)\(([\d.]+)%?\)`

### Keyword clues from existing checker

- `#   - For Type 2/3: Parse comparison operators from pattern_items (==, >, <, >=, <=)`
- `#   - Compare actual VT percentages against pattern thresholds using specified operators`
- `#   - For Type 3/4: Match violations against waive_items by VT type name`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `#   status_check: pattern_items = items to CHECK STATUS (only output matched items)`
- `#     - found_items = patterns matched AND status correct`
- `#     - missing_items = patterns matched BUT status wrong`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`

## Suggested retrieval queries

- IMP-11-0-0-26 checker intent List the VT ratio (without physical cells): EG: TSMCN7/N6:SVT(50%)/LVT(40%)/ULVT(10%) TSMCN5/N4/N3/N2:SVT(50%)/LVTLL(20%)/LVT(20%)/ULVTLL(5%)/ULVT(5%)/ELVT(0%) SEC:RVT(50%)/LVT(40%)/SLVT(10%) INTl_I3/18A:ad(HVT 30%)/ac(SVT 20%)/ab(LVT 30%)/aa(ULVT 20%)
- physical implementation  evidence extraction
- libraries power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-11-0-0-26
  check_module: 11.0_POWER_EMIR_CHECK
  intent: inventory
  knowledge_tags:
  - libraries
  - power_integrity
  candidate_objects: []
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/11.0/vtratio.sum
  requirements_value: '3'
  waiver_value: '2'
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/inputs/items/IMP-11-0-0-26.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/scripts/checker/IMP-11-0-0-26.py
```
