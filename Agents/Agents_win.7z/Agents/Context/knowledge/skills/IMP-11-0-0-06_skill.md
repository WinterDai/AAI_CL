# IMP-11-0-0-06 Skill Hint

## Description

Confirm use the proper spice model and spice netlist to generate the PGV views.(check the Note)

## Module and Intent

- Module: `11.0_POWER_EMIR_CHECK`
- Intent: `verification`
- Candidate objects: netlist, power_emir
- Knowledge tags: input_logs, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/inputs/items/IMP-11-0-0-06.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/scripts/checker/IMP-11-0-0-06.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/*LibGen.log`

### Regex clues from existing checker

- `-celltype\s+(\S+)`
- `-spice_models\s+(\S+)`
- `-spice_subckts\s+\{([^}]+)\}`

### Keyword clues from existing checker

- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `#   status_check: pattern_items = items to CHECK STATUS (only output matched items)`
- `#     - found_items = patterns matched AND status correct`
- `#     - missing_items = patterns matched BUT status wrong`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- IMP-11-0-0-06 checker intent Confirm use the proper spice model and spice netlist to generate the PGV views.(check the Note)
- physical implementation netlist power_emir evidence extraction
- input_logs power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-11-0-0-06
  check_module: 11.0_POWER_EMIR_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - power_integrity
  candidate_objects:
  - netlist
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/*LibGen.log
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/inputs/items/IMP-11-0-0-06.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/scripts/checker/IMP-11-0-0-06.py
```
