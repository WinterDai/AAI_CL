# IMP-10-0-0-04 Skill Hint

## Description

Confirm the SDC has no ideal clock networks.

## Module and Intent

- Module: `10.0_STA_DCD_CHECK`
- Intent: `verification`
- Candidate objects: power_emir, sdc
- Knowledge tags: constraints, input_reports, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-04.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-04.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/uncons_clocks.rpt.gz`

### Regex clues from existing checker

- `ideal_clock_waveform\s+.*?\s+(\d+)\s*$`

### Keyword clues from existing checker

- `#   - Support exact matching for pattern_items and waive_items`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`
- `#     - FAIL/WARN converted to INFO with suffix: [WAIVED_AS_INFO]`
- `- Type 1: requirements.value=N/A AND waivers.value=N/A/0`

## Suggested retrieval queries

- IMP-10-0-0-04 checker intent Confirm the SDC has no ideal clock networks.
- physical implementation power_emir sdc evidence extraction
- constraints input_reports power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-10-0-0-04
  check_module: 10.0_STA_DCD_CHECK
  intent: verification
  knowledge_tags:
  - constraints
  - input_reports
  - power_integrity
  - timing_signoff
  candidate_objects:
  - power_emir
  - sdc
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/uncons_clocks.rpt.gz
  requirements_value: '1'
  waiver_value: '1'
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-04.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-04.py
```
