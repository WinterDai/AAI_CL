# IMP-5-0-0-12 Skill Hint

## Description

Confirm synthesis Quality Of Results (QOR) meets requirements (timing, area, power)?

## Module and Intent

- Module: `5.0_SYNTHESIS_CHECK`
- Intent: `verification`
- Candidate objects: power_emir, timing
- Knowledge tags: implementation_qor, input_reports, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-12.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-12.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/qor.rpt`

### Regex clues from existing checker

- `([a-zA-Z]+):\s*([-\d.]+)`
- `(\w+):\s*([-\d.]+)`

### Keyword clues from existing checker

- `#   Supports 4 checking types based on requirements and waivers configuration.`
- `#   - Automatic type detection based on requirements.value and waivers.value`
- `- Type 1: requirements=N/A, waivers=N/A/0 → Always PASS (informational only)`
- `- Type 2: requirements>0, waivers=N/A/0 → FAIL if metrics don't meet thresholds`
- `- Type 3: requirements>0, waivers>0 → FAIL if unwaived metrics fail`
- `- Type 4: requirements=N/A, waivers>0 → FAIL if unwaived metrics fail`
- `def _parse_requirement(self, pattern: str) -> Tuple[str, float]:`
- `Parse requirement pattern like "TNS:0" or "Area:20000".`
- `match = re.match(r'([a-zA-Z]+):\s*([-\d.]+)', pattern.strip())`
- `def _build_waiver_reason_map(self) -> Dict[str, str]:`
- `Build a mapping from waiver pattern/name to reason.`
- `Dict of {pattern: reason}`

## Suggested retrieval queries

- IMP-5-0-0-12 checker intent Confirm synthesis Quality Of Results (QOR) meets requirements (timing, area, power)?
- physical implementation power_emir timing evidence extraction
- implementation_qor input_reports power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-5-0-0-12
  check_module: 5.0_SYNTHESIS_CHECK
  intent: verification
  knowledge_tags:
  - implementation_qor
  - input_reports
  - power_integrity
  - timing_signoff
  candidate_objects:
  - power_emir
  - timing
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/qor.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-12.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-12.py
```
