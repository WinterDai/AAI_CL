# IMP-12-0-0-06 Skill Hint

## Description

Confirm the MIM related check setting is correct. (Fill N/A if no MIMCAP inserted or no MIM related layers)

## Module and Intent

- Module: `12.0_PHYSICAL_VERIFICATION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_logs, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-06.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-06.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/do_pvs_ANT_MIM_pvl.log`
- `${CHECKLIST_ROOT}/IP_project_folder/logs/do_cmd_3star_ANT_MIM_sourceme`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Validate final configuration against pattern_items (expected switch states)`
- `#   - Support status_check mode: only report switches in pattern_items, compare actual vs expected state`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- IMP-12-0-0-06 checker intent Confirm the MIM related check setting is correct. (Fill N/A if no MIMCAP inserted or no MIM related layers)
- physical implementation power_emir evidence extraction
- input_logs power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-12-0-0-06
  check_module: 12.0_PHYSICAL_VERIFICATION_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/do_pvs_ANT_MIM_pvl.log
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/do_cmd_3star_ANT_MIM_sourceme
  requirements_value: '8'
  waiver_value: '1'
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-06.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-06.py
```
