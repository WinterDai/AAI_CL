# MIG-IMP-8-1-3-00 Skill Hint

## Description

[MIG-WB-Tracking] Confirm the workbench flow you are using. (Current latest one: /projects/workbench/versions/workbench_v0.8) Put the workbench flow dir in Comment and specify the reason why you don’t use the central workbench flow. The reason maybe as belows, -This process is new and not covered by the central workbench flow. -ECO based on old programs.

## Module and Intent

- Module: `8.1_PHYSICAL_IMPLEMENTATION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/MIG-IMP-8-1-3-00.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/MIG-IMP-8-1-3-00.py`

### Input files

- none

### Regex clues from existing checker

- `ERROR:\s+(.+)`
- `YOUR_PATTERN`

### Keyword clues from existing checker

- `#   [MIG-WB-Tracking] Confirm the workbench flow you are using. (Current latest one: /projects/workbench/versions/workbench_v0.8) Put the workbench flow dir in Comment and specify the reason why you don’t use the central workbench flow. The reason maybe as belows, -This process is new and not covered by the central workbench flow. -ECO based on old programs.`
- `#   - TODO: Parse [input_file_name] to extract [specific_data/patterns]`
- `#   - TODO: [Optional] Support waiver for [specific_cases]`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`

## Suggested retrieval queries

- MIG-IMP-8-1-3-00 checker intent [MIG-WB-Tracking] Confirm the workbench flow you are using. (Current latest one: /projects/workbench/versions/workbench_v0.8) Put the workbench flow dir in Comment and specify the reason why you don’t use the central workbench flow. The reason maybe as belows, -This process is new and not covered by the central workbench flow. -ECO based on old programs.
- physical implementation power_emir evidence extraction
- power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: MIG-IMP-8-1-3-00
  check_module: 8.1_PHYSICAL_IMPLEMENTATION_CHECK
  intent: verification
  knowledge_tags:
  - power_integrity
  candidate_objects:
  - power_emir
  input_files: []
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/MIG-IMP-8-1-3-00.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/MIG-IMP-8-1-3-00.py
```
