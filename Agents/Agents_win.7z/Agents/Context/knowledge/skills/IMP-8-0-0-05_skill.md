# IMP-8-0-0-05 Skill Hint

## Description

Confirm the power switches connection is correct . (for non-PSO, please fill N/A)

## Module and Intent

- Module: `8.0_PHYSICAL_IMPLEMENTATION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_logs, input_reports, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/IMP-8-0-0-05.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/IMP-8-0-0-05.py`

### Input files

- `${CHECKLIST_ROOT}\IP_project_folder\logs\8.0\do_fv.log`
- `${CHECKLIST_ROOT}\IP_project_folder\reports\8.0\check_power_switch_connection.pass.rpt`

### Regex clues from existing checker

- `(?:PSO|power[_\s]switch|UPF|CPF|power[_\s]domain)`
- `SUCCEEDED!`
- `//\s*(?:\*\*)?ERROR:\s*(?:\(([A-Z]+-[A-Z0-9]+)\))?\s*(.+)`
- `^#\s*Design:\s+(.+)\s*$`
- `^Begin Summary\s*$`
- `^End Summary\s*$`
- `^\s*Found no problems or warnings\.\s*$`
- `^\s*(?:ERROR|WARNING|Problem):\s*(.+)$`
- `^Verify Connectivity Report is created on (.+)$`

### Keyword clues from existing checker

- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`
- `#     - FAIL/WARN converted to INFO with suffix: [WAIVED_AS_INFO]`
- `from checker_templates.waiver_handler_template import WaiverHandlerMixin`

## Suggested retrieval queries

- IMP-8-0-0-05 checker intent Confirm the power switches connection is correct . (for non-PSO, please fill N/A)
- physical implementation power_emir evidence extraction
- input_logs input_reports power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-8-0-0-05
  check_module: 8.0_PHYSICAL_IMPLEMENTATION_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - input_reports
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}\IP_project_folder\logs\8.0\do_fv.log
  - ${CHECKLIST_ROOT}\IP_project_folder\reports\8.0\check_power_switch_connection.pass.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/IMP-8-0-0-05.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/IMP-8-0-0-05.py
```
