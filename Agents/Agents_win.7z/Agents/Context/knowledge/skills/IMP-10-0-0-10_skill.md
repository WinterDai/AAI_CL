# IMP-10-0-0-10 Skill Hint

## Description

Confirm check full path group timing reports (in2out/in2reg/reg2out/reg2reg/default/cgdefault).

## Module and Intent

- Module: `10.0_STA_DCD_CHECK`
- Intent: `verification`
- Candidate objects: lef_def, power_emir, timing
- Knowledge tags: input_logs, layout_data, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-10.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-10.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/sta_post_syn.log`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 â†’ Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 â†’ Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 â†’ Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 â†’ Boolean with waiver logic`
- `from checker_templates.waiver_handler_template import WaiverHandlerMixin`
- `class Check_10_0_0_10(BaseChecker, InputFileParserMixin, WaiverHandlerMixin, OutputBuilderMixin):`
- `- Type 1: requirements=N/A, waivers=N/A/0 â†’ Informational/Boolean check`
- `- Type 2: requirements>0, waivers=N/A/0 â†’ Value check without waivers`
- `- Type 3: requirements>0, waivers>0 â†’ Value check with waiver logic`
- `- Type 4: requirements=N/A, waivers>0 â†’ Boolean check with waiver logic`
- `Uses WaiverHandlerMixin for waiver processing.`
- `Uses InputFileParserMixin template for pattern matching.`

## Suggested retrieval queries

- IMP-10-0-0-10 checker intent Confirm check full path group timing reports (in2out/in2reg/reg2out/reg2reg/default/cgdefault).
- physical implementation lef_def power_emir timing evidence extraction
- input_logs layout_data power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-10-0-0-10
  check_module: 10.0_STA_DCD_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - layout_data
  - power_integrity
  - timing_signoff
  candidate_objects:
  - lef_def
  - power_emir
  - timing
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/sta_post_syn.log
  requirements_value: N/A
  waiver_value: '2'
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-10.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-10.py
```
