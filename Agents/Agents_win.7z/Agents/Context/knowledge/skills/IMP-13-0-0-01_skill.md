# IMP-13-0-0-01 Skill Hint

## Description

Confirm conformal log file has been peer reviewed and all warnings have a waiver/explanation?

## Module and Intent

- Module: `13.0_POST_PD_EQUIVALENCE_CHECK`
- Intent: `verification`
- Candidate objects: lec, power_emir
- Knowledge tags: equivalence, input_logs, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/13.0_POST_PD_EQUIVALENCE_CHECK/inputs/items/IMP-13-0-0-01.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/13.0_POST_PD_EQUIVALENCE_CHECK/scripts/checker/IMP-13-0-0-01.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/post_lec/syn_final_lec.log`
- `${CHECKLIST_ROOT}/IP_project_folder/logs/map_to_final.log`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Support waiver for reviewed warnings with explanations`
- `item_desc="Confirm conformal log file has been peer reviewed and all warnings have a waiver/explanation?"`
- `lines = self.read_file(file_path)`
- `def _get_waive_items_with_reasons(self) -> Dict[str, str]:`
- `"""Get waiver items with their reasons."""`
- `waivers = self.get_waivers()`
- `if not waivers:`
- `waive_items = waivers.get('waive_items', [])`
- `if waive_items and isinstance(waive_items[0], dict):`
- `return {item['name']: item.get('reason', '') for item in waive_items}`
- `return {item: '' for item in waive_items}`
- `waiver_value = waivers.get('value', 'N/A') if waivers else 'N/A'`

## Suggested retrieval queries

- IMP-13-0-0-01 checker intent Confirm conformal log file has been peer reviewed and all warnings have a waiver/explanation?
- physical implementation lec power_emir evidence extraction
- equivalence input_logs power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-13-0-0-01
  check_module: 13.0_POST_PD_EQUIVALENCE_CHECK
  intent: verification
  knowledge_tags:
  - equivalence
  - input_logs
  - power_integrity
  candidate_objects:
  - lec
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/post_lec/syn_final_lec.log
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/map_to_final.log
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/13.0_POST_PD_EQUIVALENCE_CHECK/inputs/items/IMP-13-0-0-01.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/13.0_POST_PD_EQUIVALENCE_CHECK/scripts/checker/IMP-13-0-0-01.py
```
