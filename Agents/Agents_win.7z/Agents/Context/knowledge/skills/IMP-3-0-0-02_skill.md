# IMP-3-0-0-02 Skill Hint

## Description

List Conformal LEC tool version (eg. confrml/241/24.10.100)

## Module and Intent

- Module: `3.0_TOOL_VERSION`
- Intent: `inventory`
- Candidate objects: lec
- Knowledge tags: equivalence, input_scripts

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/3.0_TOOL_VERSION/inputs/items/IMP-3-0-0-02.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/3.0_TOOL_VERSION/scripts/checker/IMP-3-0-0-02.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/tcl/2.0/setup_vars.tcl`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   List Conformal LEC tool version (eg. confrml/241/24.10.100)`
- `#   - Parse module load portion to extract confrml/XXX/YYY.YYY version pattern`
- `#   - Format version string as confrml/major_version/full_version`
- `#   - Report INFO01 if confrml version found, ERROR01 if no FV/CLP MODULE_CMD found`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`

## Suggested retrieval queries

- IMP-3-0-0-02 checker intent List Conformal LEC tool version (eg. confrml/241/24.10.100)
- physical implementation lec evidence extraction
- equivalence input_scripts best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-3-0-0-02
  check_module: 3.0_TOOL_VERSION
  intent: inventory
  knowledge_tags:
  - equivalence
  - input_scripts
  candidate_objects:
  - lec
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/tcl/2.0/setup_vars.tcl
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/3.0_TOOL_VERSION/inputs/items/IMP-3-0-0-02.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/3.0_TOOL_VERSION/scripts/checker/IMP-3-0-0-02.py
```
