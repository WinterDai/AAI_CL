# IMP-2-0-0-08 Skill Hint

## Description

Confirm latest BUMP rule deck(s) was used? List BUMP rule deck name in Comments. eg: PN3_CU_ROUND_BUMP_ON_PAD_17M_1Xa1Xb1Xc1Xd1Ya1Yb4Y2Yy2Yx2R_003.10a

## Module and Intent

- Module: `2.0_TECHFILE_AND_RULE_DECK_CHECK`
- Intent: `verification`
- Candidate objects: drc, power_emir
- Knowledge tags: input_logs, physical_verification, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/inputs/items/IMP-2-0-0-08.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/scripts/checker/IMP-2-0-0-08.py`

### Input files

- `${CHECKLIST_ROOT}\IP_project_folder\logs\2.0\BUMP_pvl.log`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Parse rule deck file to extract document name and version`
- `#   - For Type 1/4: Verify all three values (path, doc, version) exist`
- `#   - For Type 2/3: Compare current doc/version against expected pattern_items`
- `#   - Support waiver for version mismatches (Type 3/4)`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`

## Suggested retrieval queries

- IMP-2-0-0-08 checker intent Confirm latest BUMP rule deck(s) was used? List BUMP rule deck name in Comments. eg: PN3_CU_ROUND_BUMP_ON_PAD_17M_1Xa1Xb1Xc1Xd1Ya1Yb4Y2Yy2Yx2R_003.10a
- physical implementation drc power_emir evidence extraction
- input_logs physical_verification power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-2-0-0-08
  check_module: 2.0_TECHFILE_AND_RULE_DECK_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - physical_verification
  - power_integrity
  candidate_objects:
  - drc
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}\IP_project_folder\logs\2.0\BUMP_pvl.log
  requirements_value: '2'
  waiver_value: '1'
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/inputs/items/IMP-2-0-0-08.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/scripts/checker/IMP-2-0-0-08.py
```
