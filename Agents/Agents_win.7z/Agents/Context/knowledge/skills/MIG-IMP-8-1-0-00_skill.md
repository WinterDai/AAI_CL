# MIG-IMP-8-1-0-00 Skill Hint

## Description

Confirm followed the general slice top metal and top routing layer spec. (check the Note)

## Module and Intent

- Module: `8.1_PHYSICAL_IMPLEMENTATION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_reports, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/MIG-IMP-8-1-0-00.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/MIG-IMP-8-1-0-00.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/8.1/IMP-8-0-0-08.rpt`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`
- `#     - FAIL/WARN converted to INFO with suffix: [WAIVED_AS_INFO]`
- `from checker_templates.waiver_handler_template import WaiverHandlerMixin`

## Suggested retrieval queries

- MIG-IMP-8-1-0-00 checker intent Confirm followed the general slice top metal and top routing layer spec. (check the Note)
- physical implementation power_emir evidence extraction
- input_reports power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: MIG-IMP-8-1-0-00
  check_module: 8.1_PHYSICAL_IMPLEMENTATION_CHECK
  intent: verification
  knowledge_tags:
  - input_reports
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/8.1/IMP-8-0-0-08.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/MIG-IMP-8-1-0-00.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/MIG-IMP-8-1-0-00.py
```
