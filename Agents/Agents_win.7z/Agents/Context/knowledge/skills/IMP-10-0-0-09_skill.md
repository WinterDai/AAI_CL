# IMP-10-0-0-09 Skill Hint

## Description

Confirm no SPEF annotation issue in STA.

## Module and Intent

- Module: `10.0_STA_DCD_CHECK`
- Intent: `verification`
- Candidate objects: power_emir, spef
- Knowledge tags: input_logs, parasitics, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-09.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-09.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/sta_post_route.log`
- `${CHECKLIST_ROOT}/IP_project_folder/logs/func_rcss_0p675v_125c_pcss_cmax_pcff3_setup_sta_post_route.log`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Parse STA log to locate "report_annotated_parasitics" section`
- `#   - Extract parasitic annotation counts (Res, Cap, XCap) from statistics table`
- `#   - Support waiver for not-annotated nets (Type 3/4)`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- IMP-10-0-0-09 checker intent Confirm no SPEF annotation issue in STA.
- physical implementation power_emir spef evidence extraction
- input_logs parasitics power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-10-0-0-09
  check_module: 10.0_STA_DCD_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - parasitics
  - power_integrity
  - timing_signoff
  candidate_objects:
  - power_emir
  - spef
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/sta_post_route.log
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/func_rcss_0p675v_125c_pcss_cmax_pcff3_setup_sta_post_route.log
  requirements_value: '2'
  waiver_value: '0'
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-09.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-09.py
```
