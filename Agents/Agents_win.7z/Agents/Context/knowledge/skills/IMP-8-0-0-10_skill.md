# IMP-8-0-0-10 Skill Hint

## Description

Confirm you placed the discrete synchronizer flops close to each other (distance <= 10um) for process without dedicated 2/3 stage synchronizer library cell like TSMC. Make sure “no buffering on the Q->D path between sync flops” for the sync_regs falling under same hierarchy. Please fine tune clock tree for hold fixing. Please don't change the VT of synchronizer flops. (Check the Note. Fill N/A for library has 2/3 stages dedicated library cell)

## Module and Intent

- Module: `8.0_PHYSICAL_IMPLEMENTATION_CHECK`
- Intent: `verification`
- Candidate objects: liberty, power_emir, sdc, timing
- Knowledge tags: constraints, input_reports, libraries, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/IMP-8-0-0-10.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/IMP-8-0-0-10.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/8.0/IMP-8-0-0-10.rpt`

### Regex clues from existing checker

- `sync_reg(\d+)`

### Keyword clues from existing checker

- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `#   existence_check: pattern_items = items that SHOULD EXIST in input files`
- `#     - found_items = patterns found in file`
- `#     - missing_items = patterns NOT found in file`
- `#   status_check: pattern_items = items to CHECK STATUS (only output matched items)`
- `#     - found_items = patterns matched AND status correct`
- `#     - missing_items = patterns matched BUT status wrong`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`

## Suggested retrieval queries

- IMP-8-0-0-10 checker intent Confirm you placed the discrete synchronizer flops close to each other (distance <= 10um) for process without dedicated 2/3 stage synchronizer library cell like TSMC. Make sure “no buffering on the Q->D path between sync flops” for the sync_regs falling under same hierarchy. Please fine tune clock tree for hold fixing. Please don't change the VT of synchronizer flops. (Check the Note. Fill N/A for library has 2/3 stages dedicated library cell)
- physical implementation liberty power_emir sdc timing evidence extraction
- constraints input_reports libraries power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-8-0-0-10
  check_module: 8.0_PHYSICAL_IMPLEMENTATION_CHECK
  intent: verification
  knowledge_tags:
  - constraints
  - input_reports
  - libraries
  - power_integrity
  - timing_signoff
  candidate_objects:
  - liberty
  - power_emir
  - sdc
  - timing
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/8.0/IMP-8-0-0-10.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/IMP-8-0-0-10.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/IMP-8-0-0-10.py
```
