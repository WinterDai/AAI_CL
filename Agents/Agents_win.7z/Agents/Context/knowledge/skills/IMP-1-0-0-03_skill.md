# IMP-1-0-0-03 Skill Hint

## Description

List all other libraries used for implementation and signoff (eg: IO/PLL/DCC/BUMP/PLL/NoiseGen/ProcessMoniter/etc).

## Module and Intent

- Module: `1.0_LIBRARY_CHECK`
- Intent: `inventory`
- Candidate objects: liberty, power_emir
- Knowledge tags: input_logs, libraries, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/inputs/items/IMP-1-0-0-03.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/scripts/checker/IMP-1-0-0-03.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/genus.syn_generic.log`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `# Pattern to match "Reading file" lines`
- `reading_file_pattern = re.compile(r"Reading file\s+['\"]([^'\"]+)['\"]", re.IGNORECASE)`
- `# Standard cell library patterns to exclude`
- `std_cell_patterns = ['tcbn03e_bwp', '_base_', '_mb_']`
- `lines = self.read_file(file_path)`
- `match = reading_file_pattern.search(line)`
- `is_std_cell = any(pattern in part.lower() for pattern in std_cell_patterns)`
- `has_pattern_items=False,`
- `has_waiver_value=False,`

## Suggested retrieval queries

- IMP-1-0-0-03 checker intent List all other libraries used for implementation and signoff (eg: IO/PLL/DCC/BUMP/PLL/NoiseGen/ProcessMoniter/etc).
- physical implementation liberty power_emir evidence extraction
- input_logs libraries power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-1-0-0-03
  check_module: 1.0_LIBRARY_CHECK
  intent: inventory
  knowledge_tags:
  - input_logs
  - libraries
  - power_integrity
  candidate_objects:
  - liberty
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/genus.syn_generic.log
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/inputs/items/IMP-1-0-0-03.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/scripts/checker/IMP-1-0-0-03.py
```
