# MIG-IMP-8-1-1-13 Skill Hint

## Description

Confirm you have build the shortest clock tree to SOC level SRAM interface clock ports for Dragonfly LP/DDR5 PHY and build shortest tree to phy_pclk_out for Dragonfly DDR5 PHY. (Fill N/A for HPPHY) -For Dragonfly Automotive LPPHY , build shortest clock tree from phy_pclk input port to phy_uc_IRam0CLK and phy_uc_DRam00CLK output ports. -For Dragonfly DDR5, build shortest clock tree from clk_ctlr_sync input port to phy_pclk_div_out output port. -For Dragonfly DDR5, as controller will use phy_pclk_out as clock source, please build shortest tree from clk_ctlr_sync input port to phy_pclk_out output port. To achieve this, you need to place the top DESKEW PLL close to DFI boundary. As current DFPHY bump plan is handled by AMS team, please pay attention to the top DESKEW PLL bump location which needs to be assigned near to DFI boundary. Also, please optimize the SRAM interface data path(in2reg/reg2out related to phy_uc* ports) with tighter interface constraint and well balanced clock tree for these SRAM related registers to reserve more margin on SRAM path delay on SOC side.

## Module and Intent

- Module: `8.1_PHYSICAL_IMPLEMENTATION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir, sdc
- Knowledge tags: constraints, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/MIG-IMP-8-1-1-13.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/MIG-IMP-8-1-1-13.py`

### Input files

- none

### Regex clues from existing checker

- `ERROR:\s+(.+)`
- `YOUR_PATTERN`

### Keyword clues from existing checker

- `#   - TODO: Parse [input_file_name] to extract [specific_data/patterns]`
- `#   - TODO: [Optional] Support waiver for [specific_cases]`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- MIG-IMP-8-1-1-13 checker intent Confirm you have build the shortest clock tree to SOC level SRAM interface clock ports for Dragonfly LP/DDR5 PHY and build shortest tree to phy_pclk_out for Dragonfly DDR5 PHY. (Fill N/A for HPPHY) -For Dragonfly Automotive LPPHY , build shortest clock tree from phy_pclk input port to phy_uc_IRam0CLK and phy_uc_DRam00CLK output ports. -For Dragonfly DDR5, build shortest clock tree from clk_ctlr_sync input port to phy_pclk_div_out output port. -For Dragonfly DDR5, as controller will use phy_pclk_out as clock source, please build shortest tree from clk_ctlr_sync input port to phy_pclk_out output port. To achieve this, you need to place the top DESKEW PLL close to DFI boundary. As current DFPHY bump plan is handled by AMS team, please pay attention to the top DESKEW PLL bump location which needs to be assigned near to DFI boundary. Also, please optimize the SRAM interface data path(in2reg/reg2out related to phy_uc* ports) with tighter interface constraint and well balanced clock tree for these SRAM related registers to reserve more margin on SRAM path delay on SOC side.
- physical implementation power_emir sdc evidence extraction
- constraints power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: MIG-IMP-8-1-1-13
  check_module: 8.1_PHYSICAL_IMPLEMENTATION_CHECK
  intent: verification
  knowledge_tags:
  - constraints
  - power_integrity
  candidate_objects:
  - power_emir
  - sdc
  input_files: []
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/MIG-IMP-8-1-1-13.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/MIG-IMP-8-1-1-13.py
```
