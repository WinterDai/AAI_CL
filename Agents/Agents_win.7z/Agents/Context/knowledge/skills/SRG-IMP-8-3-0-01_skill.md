# SRG-IMP-8-3-0-01 Skill Hint (Multi-module)

`SRG-IMP-8-3-0-01` appears in multiple check modules. Select module-specific hints below.

## Variants

- Module `8.3_PHYSICAL_IMPLEMENTATION_CHECK`: `SRG-IMP-8-3-0-01__8_3_PHYSICAL_IMPLEMENTATION_CHECK_skill.md`
  - Intent: `status_check`
  - Description: Are we adding metal ECO filler cells in the design?
- Module `8.3_PHYSICAL_IMPLEMENTATION_CHECK`: `SRG-IMP-8-3-0-01__8_3_PHYSICAL_IMPLEMENTATION_CHECK__v2_skill.md`
  - Intent: `status_check`
  - Description: Is the base XOR is clean?
