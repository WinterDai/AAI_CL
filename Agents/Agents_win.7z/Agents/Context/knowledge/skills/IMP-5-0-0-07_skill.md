# IMP-5-0-0-07 Skill Hint

## Description

Confirm SDC Read Failures clean?

## Module and Intent

- Module: `5.0_SYNTHESIS_CHECK`
- Intent: `verification`
- Candidate objects: power_emir, sdc
- Knowledge tags: constraints, input_logs, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-07.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-07.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/genus.syn_generic.log`

### Regex clues from existing checker

- `Error\s*:\s*(.+?)\s*\[`
- `on line`
- `Total failed commands during read_sdc are (\d+)`

### Keyword clues from existing checker

- `#   Supports 4 checking types based on requirements and waivers configuration.`
- `#   - Automatic type detection based on requirements.value and waivers.value`
- `Parses synthesis log files to detect read_sdc command failures and violations.`
- `- Type 1: requirements=N/A, waivers=N/A/0 → Always PASS (informational only)`
- `- Type 2: requirements>0, waivers=N/A/0 → FAIL if any violations found`
- `- Type 3: requirements>0, waivers>0 → FAIL if unwaived violations found`
- `- Type 4: requirements=N/A, waivers>0 → FAIL if unwaived violations found`
- `lines = self.read_file(log_file)`
- `violations_dict, has_violations, has_sections = self._check_read_sdc_violations(lines, log_file)`
- `# Type 1: Informational Check (requirements=N/A, waivers=N/A/0)`
- `has_pattern_items=False,`
- `has_waiver_value=False,`

## Suggested retrieval queries

- IMP-5-0-0-07 checker intent Confirm SDC Read Failures clean?
- physical implementation power_emir sdc evidence extraction
- constraints input_logs power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-5-0-0-07
  check_module: 5.0_SYNTHESIS_CHECK
  intent: verification
  knowledge_tags:
  - constraints
  - input_logs
  - power_integrity
  candidate_objects:
  - power_emir
  - sdc
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/genus.syn_generic.log
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-07.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-07.py
```
