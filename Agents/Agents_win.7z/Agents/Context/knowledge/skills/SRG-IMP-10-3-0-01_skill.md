# SRG-IMP-10-3-0-01 Skill Hint (Multi-module)

`SRG-IMP-10-3-0-01` appears in multiple check modules. Select module-specific hints below.

## Variants

- Module `10.3_STA_DCD_CHECK`: `SRG-IMP-10-3-0-01__10_3_STA_DCD_CHECK_skill.md`
  - Intent: `status_check`
  - Description: Are the clock-crossing reports verified with the customer?
- Module `10.3_STA_DCD_CHECK`: `SRG-IMP-10-3-0-01__10_3_STA_DCD_CHECK__v2_skill.md`
  - Intent: `verification`
  - Description: All the clock definitions should be defined on the clock sources only
