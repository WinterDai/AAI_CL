# IMP-10-0-0-21 Skill Hint

## Description

Confirm all Warning message in the STA log files can be waived.

## Module and Intent

- Module: `10.0_STA_DCD_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_logs, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-21.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-21.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/10.0/tempus_1.log`
- `${CHECKLIST_ROOT}/IP_project_folder/reports/10.0/tempus_2.log`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   Confirm all Warning message in the STA log files can be waived.`
- `#   - Verify all warnings are either acceptable or explicitly waived`
- `#   - Report unwaived warnings as failures requiring review`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- IMP-10-0-0-21 checker intent Confirm all Warning message in the STA log files can be waived.
- physical implementation power_emir evidence extraction
- input_logs power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-10-0-0-21
  check_module: 10.0_STA_DCD_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - power_integrity
  - timing_signoff
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/10.0/tempus_1.log
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/10.0/tempus_2.log
  requirements_value: '2'
  waiver_value: '0'
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-21.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-21.py
```
