# IMP-2-0-0-13 Skill Hint

## Description

List Spice Model used for PGV generation. eg: tsmc3gp.a.4/models/spectre_v1d0_2p6/ir_em.scs

## Module and Intent

- Module: `2.0_TECHFILE_AND_RULE_DECK_CHECK`
- Intent: `inventory`
- Candidate objects: power_emir
- Knowledge tags: power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/inputs/items/IMP-2-0-0-13.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/scripts/checker/IMP-2-0-0-13.py`

### Input files

- `${CHECKLIST_ROOT}\IP_project_folder\logs\2.0\command_list.btxt`

### Regex clues from existing checker

- `spice_models\s+(.+)`
- `PDK/(.+)$`

### Keyword clues from existing checker

- `#   - Extract model version identifier from absolute path (substring after "PDK/")`
- `#   - For Type 2/3: Compare extracted model version against golden reference from pattern_items`
- `#   - Support waiver for model version mismatches (Type 3/4)`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`

## Suggested retrieval queries

- IMP-2-0-0-13 checker intent List Spice Model used for PGV generation. eg: tsmc3gp.a.4/models/spectre_v1d0_2p6/ir_em.scs
- physical implementation power_emir evidence extraction
- power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-2-0-0-13
  check_module: 2.0_TECHFILE_AND_RULE_DECK_CHECK
  intent: inventory
  knowledge_tags:
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}\IP_project_folder\logs\2.0\command_list.btxt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/inputs/items/IMP-2-0-0-13.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/scripts/checker/IMP-2-0-0-13.py
```
