# IMP-8-0-0-14 Skill Hint

## Description

Confirm no VT mixing on clock tree for all modes. For some instances has clock attribute but used as data, please list that into Waiver list.

## Module and Intent

- Module: `8.0_PHYSICAL_IMPLEMENTATION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir, sdc
- Knowledge tags: constraints, input_reports, input_text_reports, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/IMP-8-0-0-14.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/IMP-8-0-0-14.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/8.0/clock_cells_with_cell_type.txt`
- `${CHECKLIST_ROOT}/IP_project_folder/reports/8.0/IMP-8-0-0-14.rpt`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   Confirm no VT mixing on clock tree for all modes. For some instances has clock attribute but used as data, please list that into Waiver list.`
- `#   - Extract VT type from cell names using regex pattern (LVT/ULVT/SVT/HVT/RVT)`
- `#   - Match violations against waiver list using instance path patterns`
- `#   - Report unwaived VT mixing violations as FAIL, waived items as INFO`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `#   pattern_items = clock trees to CHECK VT CONSISTENCY (only output matched trees)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`

## Suggested retrieval queries

- IMP-8-0-0-14 checker intent Confirm no VT mixing on clock tree for all modes. For some instances has clock attribute but used as data, please list that into Waiver list.
- physical implementation power_emir sdc evidence extraction
- constraints input_reports input_text_reports power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-8-0-0-14
  check_module: 8.0_PHYSICAL_IMPLEMENTATION_CHECK
  intent: verification
  knowledge_tags:
  - constraints
  - input_reports
  - input_text_reports
  - power_integrity
  - timing_signoff
  candidate_objects:
  - power_emir
  - sdc
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/8.0/clock_cells_with_cell_type.txt
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/8.0/IMP-8-0-0-14.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/IMP-8-0-0-14.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.0_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/IMP-8-0-0-14.py
```
