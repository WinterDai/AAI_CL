# HPP-IMP-17-1-0-00 Skill Hint

## Description

If IP under DR3 review implements a register containing the revision/version of the IP, please confirm that this register contains the correct revision/version of the IP w.r.t this DR3 Review?

## Module and Intent

- Module: `17.1_FINAL_DATA`
- Intent: `conditional_verification`
- Candidate objects: power_emir
- Knowledge tags: power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/17.1_FINAL_DATA/inputs/items/HPP-IMP-17-1-0-00.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/17.1_FINAL_DATA/scripts/checker/HPP-IMP-17-1-0-00.py`

### Input files

- none

### Regex clues from existing checker

- `ERROR:\s+(.+)`
- `YOUR_PATTERN`

### Keyword clues from existing checker

- `#   If IP under DR3 review implements a register containing the revision/version of the IP, please confirm that this register contains the correct revision/version of the IP w.r.t this DR3 Review?`
- `#   - TODO: Parse [input_file_name] to extract [specific_data/patterns]`
- `#   - TODO: [Optional] Support waiver for [specific_cases]`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`

## Suggested retrieval queries

- HPP-IMP-17-1-0-00 checker intent If IP under DR3 review implements a register containing the revision/version of the IP, please confirm that this register contains the correct revision/version of the IP w.r.t this DR3 Review?
- physical implementation power_emir evidence extraction
- power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: HPP-IMP-17-1-0-00
  check_module: 17.1_FINAL_DATA
  intent: conditional_verification
  knowledge_tags:
  - power_integrity
  candidate_objects:
  - power_emir
  input_files: []
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/17.1_FINAL_DATA/inputs/items/HPP-IMP-17-1-0-00.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/17.1_FINAL_DATA/scripts/checker/HPP-IMP-17-1-0-00.py
```
