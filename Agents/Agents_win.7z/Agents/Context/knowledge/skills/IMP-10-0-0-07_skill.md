# IMP-10-0-0-07 Skill Hint

## Description

Confirm the OCV setting is correct (matches to latest foundary recommendation or addendum).

## Module and Intent

- Module: `10.0_STA_DCD_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_logs, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-07.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-07.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/sta_post_syn.log`

### Regex clues from existing checker

- `to\s+(\w+)`
- `set_socv_rc_variation_factor\s+([\d.]+)`

### Keyword clues from existing checker

- `#   - Type 2/3: Pattern matching with optional waiver logic`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `- Type 1: requirements.value=N/A AND waivers.value=N/A/0`
- `- Type 2: requirements.value>0 AND pattern_items AND waivers.value=N/A/0`
- `- Type 3: requirements.value>0 AND pattern_items AND waivers.value>0`
- `- Type 4: requirements.value=N/A AND waivers.value>0`
- `self._pattern_items: List[str] = []`
- `def _map_pattern_to_indicator(self, pattern: str) -> Optional[str]:`
- `"""Map a pattern string to one of the OCV indicator names."""`

## Suggested retrieval queries

- IMP-10-0-0-07 checker intent Confirm the OCV setting is correct (matches to latest foundary recommendation or addendum).
- physical implementation power_emir evidence extraction
- input_logs power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-10-0-0-07
  check_module: 10.0_STA_DCD_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - power_integrity
  - timing_signoff
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/sta_post_syn.log
  requirements_value: N/A
  waiver_value: '2'
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-07.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-07.py
```
