# IMP-5-0-0-13 Skill Hint

## Description

Confirm scan is successfully inserted and non-scannable flops have been peer reviewed and waived?

## Module and Intent

- Module: `5.0_SYNTHESIS_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_reports, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-13.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-13.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/dft_chainRegs.rpt`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   peer reviewed and waived.`
- `#   - Type 2/3: Check against pattern_items (category patterns)`
- `#   - Type 3/4: Support waiver logic with category-specific reasons`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `# Summary line patterns`
- `SUMMARY_PATTERNS = {`
- `# Section header patterns`
- `have been peer reviewed and waived`
- `- Type 1: requirements.value=N/A AND waivers.value=N/A/0`

## Suggested retrieval queries

- IMP-5-0-0-13 checker intent Confirm scan is successfully inserted and non-scannable flops have been peer reviewed and waived?
- physical implementation power_emir evidence extraction
- input_reports power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-5-0-0-13
  check_module: 5.0_SYNTHESIS_CHECK
  intent: verification
  knowledge_tags:
  - input_reports
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/dft_chainRegs.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-13.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-13.py
```
