# IMP-11-0-0-20 Skill Hint

## Description

Confirm wake-up time meet customer's requirement. (For non-PSO, please fill N/A)

## Module and Intent

- Module: `11.0_POWER_EMIR_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_reports, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/inputs/items/IMP-11-0-0-20.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/scripts/checker/IMP-11-0-0-20.py`

### Input files

- `${CHECKLIST_ROOT}\IP_project_folder\reports\11.0\Powerup.rpt`

### Regex clues from existing checker

- `Measured wake-up time for switched net\s*=\s*([0-9.eE+-]+)s`
- `Number of power switches turned on in this simulation\s*=\s*(\d+)\s*\[of total\s*(\d+)\]`
- `Simulation time\s*=\s*([0-9.eE+-]+)s`
- `Threshold \(Vt\)\s*=\s*([0-9.]+)V`
- `Measured maximum rush current\s*=\s*([0-9.eE+-]+)A`
- `Last power switch to turn-on in this simulation is`
- `Wake-up time:\s*([0-9.eE+-]+)s`

### Keyword clues from existing checker

- `#   - Support waiver for wake-up time violations`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`
- `#     - FAIL/WARN converted to INFO with suffix: [WAIVED_AS_INFO]`

## Suggested retrieval queries

- IMP-11-0-0-20 checker intent Confirm wake-up time meet customer's requirement. (For non-PSO, please fill N/A)
- physical implementation power_emir evidence extraction
- input_reports power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-11-0-0-20
  check_module: 11.0_POWER_EMIR_CHECK
  intent: verification
  knowledge_tags:
  - input_reports
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}\IP_project_folder\reports\11.0\Powerup.rpt
  requirements_value: '1'
  waiver_value: '2'
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/inputs/items/IMP-11-0-0-20.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/scripts/checker/IMP-11-0-0-20.py
```
