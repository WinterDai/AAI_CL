# MIG-IMP-10-1-0-00 Skill Hint

## Description

Confirm the the cel list specified in library_setup/set_instance_voltage.tcl in STA environment matches to the real physical implemention for projects with regulator. Please do local update for VDDR domain cell list in the file when needed.

## Module and Intent

- Module: `10.1_STA_DCD_CHECK`
- Intent: `verification`
- Candidate objects: liberty, power_emir, timing
- Knowledge tags: libraries, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.1_STA_DCD_CHECK/inputs/items/MIG-IMP-10-1-0-00.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.1_STA_DCD_CHECK/scripts/checker/MIG-IMP-10-1-0-00.py`

### Input files

- none

### Regex clues from existing checker

- `ERROR:\s+(.+)`
- `YOUR_PATTERN`

### Keyword clues from existing checker

- `#   - TODO: Parse [input_file_name] to extract [specific_data/patterns]`
- `#   - TODO: [Optional] Support waiver for [specific_cases]`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- MIG-IMP-10-1-0-00 checker intent Confirm the the cel list specified in library_setup/set_instance_voltage.tcl in STA environment matches to the real physical implemention for projects with regulator. Please do local update for VDDR domain cell list in the file when needed.
- physical implementation liberty power_emir timing evidence extraction
- libraries power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: MIG-IMP-10-1-0-00
  check_module: 10.1_STA_DCD_CHECK
  intent: verification
  knowledge_tags:
  - libraries
  - power_integrity
  - timing_signoff
  candidate_objects:
  - liberty
  - power_emir
  - timing
  input_files: []
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.1_STA_DCD_CHECK/inputs/items/MIG-IMP-10-1-0-00.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.1_STA_DCD_CHECK/scripts/checker/MIG-IMP-10-1-0-00.py
```
