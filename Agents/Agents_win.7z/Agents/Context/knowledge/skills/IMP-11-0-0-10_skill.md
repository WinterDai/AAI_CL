# IMP-11-0-0-10 Skill Hint

## Description

Confirm static power analysis results matches the requirement.

## Module and Intent

- Module: `11.0_POWER_EMIR_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/inputs/items/IMP-11-0-0-10.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/scripts/checker/IMP-11-0-0-10.py`

### Input files

- `C:\Users\zhihan\projects\check_development\CHECKLIST\CHECKLIST\IP_project_folder\reports\11.0\VDD_VSS_div.iv`
- `C:\Users\zhihan\projects\check_development\CHECKLIST\CHECKLIST\IP_project_folder\reports\11.0\results_VDD`
- `C:\Users\zhihan\projects\check_development\CHECKLIST\CHECKLIST\IP_project_folder\reports\11.0\results_VSS`

### Regex clues from existing checker

- `^NOMINAL_VOLTAGE\s+([\d.]+)`
- `^BEGIN\s*$`
- `^-\s+(\S+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s*$`
- `^Results for rj`
- `Minimum, Average, Maximum Current Density \(J/JMAX\):\s*([\d.eE+-]+),\s*([\d.eE+-]+),\s*([\d.eE+-]+)`
- `results?[_-]?(\w+)`

### Keyword clues from existing checker

- `#   - Support waiver logic for Type 3/4 to exempt specific metric violations`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check (data extraction only)`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `#   status_check: pattern_items = metric thresholds to CHECK STATUS (only output matched metrics)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`
- `#     - FAIL/WARN converted to INFO with suffix: [WAIVED_AS_INFO]`

## Suggested retrieval queries

- IMP-11-0-0-10 checker intent Confirm static power analysis results matches the requirement.
- physical implementation power_emir evidence extraction
- power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-11-0-0-10
  check_module: 11.0_POWER_EMIR_CHECK
  intent: verification
  knowledge_tags:
  - power_integrity
  - timing_signoff
  candidate_objects:
  - power_emir
  input_files:
  - C:\Users\zhihan\projects\check_development\CHECKLIST\CHECKLIST\IP_project_folder\reports\11.0\VDD_VSS_div.iv
  - C:\Users\zhihan\projects\check_development\CHECKLIST\CHECKLIST\IP_project_folder\reports\11.0\results_VDD
  - C:\Users\zhihan\projects\check_development\CHECKLIST\CHECKLIST\IP_project_folder\reports\11.0\results_VSS
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/inputs/items/IMP-11-0-0-10.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/scripts/checker/IMP-11-0-0-10.py
```
