# MIG-IMP-8-1-1-01 Skill Hint

## Description

Confirm meet a resistance less than 0.5Ω(not exceed 0.8Ω) and a capacitance less than 350fF from pad opening to signal bump. (check the Note)

## Module and Intent

- Module: `8.1_PHYSICAL_IMPLEMENTATION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_reports, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/MIG-IMP-8-1-1-01.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/MIG-IMP-8-1-1-01.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/8.1/MIG-IMP-8-1-1-01.rpt`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Apply waiver logic if configured (Type 3/4)`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `#   status_check: pattern_items = items to CHECK STATUS (only output matched items)`
- `#     - found_items = patterns matched AND status correct`
- `#     - missing_items = patterns matched BUT status wrong`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`

## Suggested retrieval queries

- MIG-IMP-8-1-1-01 checker intent Confirm meet a resistance less than 0.5Ω(not exceed 0.8Ω) and a capacitance less than 350fF from pad opening to signal bump. (check the Note)
- physical implementation power_emir evidence extraction
- input_reports power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: MIG-IMP-8-1-1-01
  check_module: 8.1_PHYSICAL_IMPLEMENTATION_CHECK
  intent: verification
  knowledge_tags:
  - input_reports
  - power_integrity
  - timing_signoff
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/8.1/MIG-IMP-8-1-1-01.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/inputs/items/MIG-IMP-8-1-1-01.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/8.1_PHYSICAL_IMPLEMENTATION_CHECK/scripts/checker/MIG-IMP-8-1-1-01.py
```
