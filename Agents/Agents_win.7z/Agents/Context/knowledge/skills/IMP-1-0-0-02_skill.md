# IMP-1-0-0-02 Skill Hint

## Description

List any forbidden cells (special request from foundry or customers).

## Module and Intent

- Module: `1.0_LIBRARY_CHECK`
- Intent: `inventory`
- Candidate objects: not identified from description
- Knowledge tags: libraries

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/inputs/items/IMP-1-0-0-02.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/scripts/checker/IMP-1-0-0-02.py`

### Input files

- none

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   This is an informational checker that displays configured forbidden cell patterns.`
- `This checker doesn't parse input files - it just displays pattern_items`
- `# Get pattern_items (forbidden cell patterns)`
- `pattern_items = requirements.get('pattern_items', []) if requirements else []`
- `if not pattern_items:`
- `has_pattern_items=False,`
- `has_waiver_value=False,`
- `for cell_pattern in pattern_items:`
- `name=cell_pattern,`
- `value=len(pattern_items),`
- `has_pattern_items=True,`
- `"items": pattern_items`

## Suggested retrieval queries

- IMP-1-0-0-02 checker intent List any forbidden cells (special request from foundry or customers).
- physical implementation  evidence extraction
- libraries best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-1-0-0-02
  check_module: 1.0_LIBRARY_CHECK
  intent: inventory
  knowledge_tags:
  - libraries
  candidate_objects: []
  input_files: []
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/inputs/items/IMP-1-0-0-02.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/scripts/checker/IMP-1-0-0-02.py
```
