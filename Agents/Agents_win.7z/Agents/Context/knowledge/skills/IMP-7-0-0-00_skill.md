# IMP-7-0-0-00 Skill Hint

## Description

Block name (e.g: cdn_hs_phy_data_slice)

## Module and Intent

- Module: `7.0_INNOVUS_DESIGN_IN_CHECK`
- Intent: `verification`
- Candidate objects: not identified from description
- Knowledge tags: input_reports

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/7.0_INNOVUS_DESIGN_IN_CHECK/inputs/items/IMP-7-0-0-00.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/7.0_INNOVUS_DESIGN_IN_CHECK/scripts/checker/IMP-7-0-0-00.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/7.0/IMP-7-0-0-00.rpt`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `lib_pattern = re.compile(r'^\s*(\S+)\s+\S+$')`
- `lines = self.read_file(file_path)`
- `match = lib_pattern.match(lib_line)`
- `match = lib_pattern.match(stripped)`
- `if any(pattern in lib_name for pattern in ['tcbn', 'lib', '_', 'cpd', 'bwp']):`
- `has_pattern_items=False,`
- `has_waiver_value=False,`

## Suggested retrieval queries

- IMP-7-0-0-00 checker intent Block name (e.g: cdn_hs_phy_data_slice)
- physical implementation  evidence extraction
- input_reports best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-7-0-0-00
  check_module: 7.0_INNOVUS_DESIGN_IN_CHECK
  intent: verification
  knowledge_tags:
  - input_reports
  candidate_objects: []
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/7.0/IMP-7-0-0-00.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/7.0_INNOVUS_DESIGN_IN_CHECK/inputs/items/IMP-7-0-0-00.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/7.0_INNOVUS_DESIGN_IN_CHECK/scripts/checker/IMP-7-0-0-00.py
```
