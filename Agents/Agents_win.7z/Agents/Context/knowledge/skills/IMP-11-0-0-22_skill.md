# IMP-11-0-0-22 Skill Hint

## Description

Confirm no ERROR message in power analysis log files.

## Module and Intent

- Module: `11.0_POWER_EMIR_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_logs, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/inputs/items/IMP-11-0-0-22.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/scripts/checker/IMP-11-0-0-22.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/11.0/func_func_ffgnp_0p825v_125c_cbest_CCbest_T_cworst_CCworst_hold_static.logv`
- `${CHECKLIST_ROOT}/IP_project_folder/logs/11.0/func_func_ssgnp_0p675v_125c_cworst_CCworst_T_cworst_CCworst_T_setup_static.logv`
- `${CHECKLIST_ROOT}/IP_project_folder/logs/11.0/func_func_tt_0p75v_85c_typical_typical_setup_dynamic.logv`
- `${CHECKLIST_ROOT}/IP_project_folder/logs/11.0/noerror.logv`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Support waiver for specific error codes if configured`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`
- `#     - FAIL/WARN converted to INFO with suffix: [WAIVED_AS_INFO]`

## Suggested retrieval queries

- IMP-11-0-0-22 checker intent Confirm no ERROR message in power analysis log files.
- physical implementation power_emir evidence extraction
- input_logs power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-11-0-0-22
  check_module: 11.0_POWER_EMIR_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/11.0/func_func_ffgnp_0p825v_125c_cbest_CCbest_T_cworst_CCworst_hold_static.logv
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/11.0/func_func_ssgnp_0p675v_125c_cworst_CCworst_T_cworst_CCworst_T_setup_static.logv
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/11.0/func_func_tt_0p75v_85c_typical_typical_setup_dynamic.logv
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/11.0/noerror.logv
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/inputs/items/IMP-11-0-0-22.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/11.0_POWER_EMIR_CHECK/scripts/checker/IMP-11-0-0-22.py
```
