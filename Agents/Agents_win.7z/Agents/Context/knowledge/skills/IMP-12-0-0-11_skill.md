# IMP-12-0-0-11 Skill Hint

## Description

Confirm the DRC check result is clean. (fill the confidence level of not touching floorplan again in comment if fill no, for example, 90%~100%)

## Module and Intent

- Module: `12.0_PHYSICAL_VERIFICATION_CHECK`
- Intent: `verification`
- Candidate objects: drc, power_emir
- Knowledge tags: input_reports, physical_verification, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-11.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-11.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Calibre_DRC.rep`
- `${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Pegasus_DRC.rep`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Detect report type (Calibre vs Pegasus) by parsing format patterns`
- `#   - For Type 3/4: Match violations against waive_items by rule name and count`
- `#   - Classify violations as waived/unwaived based on waiver configuration`
- `#   - Determine DRC clean status: PASS if total violations = 0 or all waived`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `#   status_check: pattern_items = items to CHECK STATUS (only output matched items)`
- `#     - found_items = patterns matched AND status correct`
- `#     - missing_items = patterns matched BUT status wrong`
- `# Waiver Tag Rules:`

## Suggested retrieval queries

- IMP-12-0-0-11 checker intent Confirm the DRC check result is clean. (fill the confidence level of not touching floorplan again in comment if fill no, for example, 90%~100%)
- physical implementation drc power_emir evidence extraction
- input_reports physical_verification power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-12-0-0-11
  check_module: 12.0_PHYSICAL_VERIFICATION_CHECK
  intent: verification
  knowledge_tags:
  - input_reports
  - physical_verification
  - power_integrity
  candidate_objects:
  - drc
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Calibre_DRC.rep
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Pegasus_DRC.rep
  requirements_value: N/A
  waiver_value: '2'
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-11.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-11.py
```
