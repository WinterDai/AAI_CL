# IMP-2-0-0-14 Skill Hint

## Description

List EM irxc rule deck name. eg: ICT_EM_v1d0p1a/cln3p_1p17m+ut-alrdl_1xa1xb1xc1xd1ya1yb4y2yy2yx2r_shdmim.ictem

## Module and Intent

- Module: `2.0_TECHFILE_AND_RULE_DECK_CHECK`
- Intent: `inventory`
- Candidate objects: drc, power_emir
- Knowledge tags: input_logs, physical_verification, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/inputs/items/IMP-2-0-0-14.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/scripts/checker/IMP-2-0-0-14.py`

### Input files

- `${CHECKLIST_ROOT}\IP_project_folder\logs\2.0\func_func_ssgnp_0p675v_125c_cworst_CCworst_T_cworst_CCworst_hold_static.log`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Parse Voltus log files to extract EM rule deck path using pattern "Info: Using EM Rules from : '<path>'"`
- `#   - Extract version directory and filename from absolute path (last two path components)`
- `#   - For Type 2/3: Validate extracted EM rule deck matches expected pattern_items (golden EM rule deck)`
- `#   - Support waiver for EM rule deck version mismatches (Type 3/4)`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`

## Suggested retrieval queries

- IMP-2-0-0-14 checker intent List EM irxc rule deck name. eg: ICT_EM_v1d0p1a/cln3p_1p17m+ut-alrdl_1xa1xb1xc1xd1ya1yb4y2yy2yx2r_shdmim.ictem
- physical implementation drc power_emir evidence extraction
- input_logs physical_verification power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-2-0-0-14
  check_module: 2.0_TECHFILE_AND_RULE_DECK_CHECK
  intent: inventory
  knowledge_tags:
  - input_logs
  - physical_verification
  - power_integrity
  candidate_objects:
  - drc
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}\IP_project_folder\logs\2.0\func_func_ssgnp_0p675v_125c_cworst_CCworst_T_cworst_CCworst_hold_static.log
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/inputs/items/IMP-2-0-0-14.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/scripts/checker/IMP-2-0-0-14.py
```
