# MIG-IMP-10-1-0-04 Skill Hint

## Description

Confirm have provided verification team post-simulation related files to set post-sim environment. (TT corner,Timing violations within uncertainty, skew no impact post-sim) in stable stage and close to final version (SS/TT/FF corners,Timing violations within uncertainty, skew violations less than 10ps) post-simulation related files 2 weeks for slices (4 weeks for phy_top) before final delivery.

## Module and Intent

- Module: `10.1_STA_DCD_CHECK`
- Intent: `verification`
- Candidate objects: power_emir, timing
- Knowledge tags: deliverables, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.1_STA_DCD_CHECK/inputs/items/MIG-IMP-10-1-0-04.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.1_STA_DCD_CHECK/scripts/checker/MIG-IMP-10-1-0-04.py`

### Input files

- none

### Regex clues from existing checker

- `ERROR:\s+(.+)`
- `YOUR_PATTERN`

### Keyword clues from existing checker

- `#   Confirm have provided verification team post-simulation related files to set post-sim environment. (TT corner,Timing violations within uncertainty, skew no impact post-sim) in stable stage and close to final version (SS/TT/FF corners,Timing violations within uncertainty, skew violations less than 10ps) post-simulation related files 2 weeks for slices (4 weeks for phy_top) before final delivery.`
- `#   - TODO: Parse [input_file_name] to extract [specific_data/patterns]`
- `#   - TODO: [Optional] Support waiver for [specific_cases]`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`

## Suggested retrieval queries

- MIG-IMP-10-1-0-04 checker intent Confirm have provided verification team post-simulation related files to set post-sim environment. (TT corner,Timing violations within uncertainty, skew no impact post-sim) in stable stage and close to final version (SS/TT/FF corners,Timing violations within uncertainty, skew violations less than 10ps) post-simulation related files 2 weeks for slices (4 weeks for phy_top) before final delivery.
- physical implementation power_emir timing evidence extraction
- deliverables power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: MIG-IMP-10-1-0-04
  check_module: 10.1_STA_DCD_CHECK
  intent: verification
  knowledge_tags:
  - deliverables
  - power_integrity
  - timing_signoff
  candidate_objects:
  - power_emir
  - timing
  input_files: []
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.1_STA_DCD_CHECK/inputs/items/MIG-IMP-10-1-0-04.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.1_STA_DCD_CHECK/scripts/checker/MIG-IMP-10-1-0-04.py
```
