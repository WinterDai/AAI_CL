# IMP-16-0-0-07 Skill Hint

## Description

Confirm the Final GDS have the IPTAG information?

## Module and Intent

- Module: `16.0_IPTAG_CHECK`
- Intent: `verification`
- Candidate objects: gds, power_emir
- Knowledge tags: layout_data, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/inputs/items/IMP-16-0-0-07.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/scripts/checker/IMP-16-0-0-07.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/16.0/cdn_hs_phy_top.csv`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Extract IP_checker tool path/version from metadata line`
- `#   - Validate CSV header structure (GDS,Vendor,Product,Version,Metric,Instance,Instance_tag)`
- `#   - Parse IPTAG data rows to extract vendor, product, version, and instance information`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`

## Suggested retrieval queries

- IMP-16-0-0-07 checker intent Confirm the Final GDS have the IPTAG information?
- physical implementation gds power_emir evidence extraction
- layout_data power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-16-0-0-07
  check_module: 16.0_IPTAG_CHECK
  intent: verification
  knowledge_tags:
  - layout_data
  - power_integrity
  candidate_objects:
  - gds
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/16.0/cdn_hs_phy_top.csv
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/inputs/items/IMP-16-0-0-07.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/scripts/checker/IMP-16-0-0-07.py
```
