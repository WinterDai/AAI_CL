# IMP-16-0-0-03 Skill Hint

## Description

Confirm use IP Type code for PHY - "P" in the slices IPTAG for FIRM PHY delivery.

## Module and Intent

- Module: `16.0_IPTAG_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: deliverables, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/inputs/items/IMP-16-0-0-03.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/scripts/checker/IMP-16-0-0-03.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/16.0/cdn_hs_phy_top.csv`

### Regex clues from existing checker

- `^GDS\s*,\s*Vendor\s*,\s*Product`

### Keyword clues from existing checker

- `#   - Extract GDS file, vendor, product, version, metric, instance, and instance_tag`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `#   status_check: pattern_items = items to CHECK STATUS (only output matched items)`
- `#     - found_items = patterns matched AND status correct`
- `#     - missing_items = patterns matched BUT status wrong`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`

## Suggested retrieval queries

- IMP-16-0-0-03 checker intent Confirm use IP Type code for PHY - "P" in the slices IPTAG for FIRM PHY delivery.
- physical implementation power_emir evidence extraction
- deliverables power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-16-0-0-03
  check_module: 16.0_IPTAG_CHECK
  intent: verification
  knowledge_tags:
  - deliverables
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/16.0/cdn_hs_phy_top.csv
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/inputs/items/IMP-16-0-0-03.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/16.0_IPTAG_CHECK/scripts/checker/IMP-16-0-0-03.py
```
