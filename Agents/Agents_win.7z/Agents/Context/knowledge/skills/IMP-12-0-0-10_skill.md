# IMP-12-0-0-10 Skill Hint

## Description

Confirm turn-off the VIRTUAL_CONNECT in LVS setting.

## Module and Intent

- Module: `12.0_PHYSICAL_VERIFICATION_CHECK`
- Intent: `verification`
- Candidate objects: lvs, power_emir
- Knowledge tags: input_logs, physical_verification, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-10.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-10.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/do_pvs_LVS_pvl.log`
- `${CHECKLIST_ROOT}/IP_project_folder/logs/do_cmd_3star_LVS_sourceme`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Search for VIRTUAL_CONNECT setting using tool-specific patterns`
- `#   - Support waiver logic for Type 3/4 if configured`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- IMP-12-0-0-10 checker intent Confirm turn-off the VIRTUAL_CONNECT in LVS setting.
- physical implementation lvs power_emir evidence extraction
- input_logs physical_verification power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-12-0-0-10
  check_module: 12.0_PHYSICAL_VERIFICATION_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - physical_verification
  - power_integrity
  candidate_objects:
  - lvs
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/do_pvs_LVS_pvl.log
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/do_cmd_3star_LVS_sourceme
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-10.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-10.py
```
