# IMP-5-0-0-10 Skill Hint

## Description

Confirm don't use cell list includes forbidden cells specified in IMP-1-0-0-02?

## Module and Intent

- Module: `5.0_SYNTHESIS_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_reports, libraries, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-10.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-10.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/gates.rpt`

### Regex clues from existing checker

- `^(\S+)\s+\d+`

### Keyword clues from existing checker

- `#   - Forbidden cells from IMP-1-0-0-02 pattern_items (supports regex)`
- `#   - Match using regex patterns`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `Forbidden Cells Source: IMP-1-0-0-02.yaml pattern_items`
- `- Type 1: requirements.value=N/A AND waivers.value=N/A/0`
- `- Type 2: requirements.value>0 AND pattern_items AND waivers.value=N/A/0`
- `- Type 3: requirements.value>0 AND pattern_items AND waivers.value>0`
- `- Type 4: requirements.value=N/A AND waivers.value>0`
- `- Use regex to match cell names against forbidden patterns`

## Suggested retrieval queries

- IMP-5-0-0-10 checker intent Confirm don't use cell list includes forbidden cells specified in IMP-1-0-0-02?
- physical implementation power_emir evidence extraction
- input_reports libraries power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-5-0-0-10
  check_module: 5.0_SYNTHESIS_CHECK
  intent: verification
  knowledge_tags:
  - input_reports
  - libraries
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/gates.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-10.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-10.py
```
