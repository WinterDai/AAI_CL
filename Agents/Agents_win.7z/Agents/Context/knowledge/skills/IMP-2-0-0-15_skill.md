# IMP-2-0-0-15 Skill Hint

## Description

List QRC techfile name. eg: 17M1Xa1Xb1Xc1Xd1Ya1Yb4Y2Yy2Yx2R_SHDMIM_UT/fs_v1d0p1a

## Module and Intent

- Module: `2.0_TECHFILE_AND_RULE_DECK_CHECK`
- Intent: `inventory`
- Candidate objects: spef
- Knowledge tags: input_logs, parasitics

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/inputs/items/IMP-2-0-0-15.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/scripts/checker/IMP-2-0-0-15.py`

### Input files

- `${CHECKLIST_ROOT}\IP_project_folder\logs\2.0\do_qrcrcbest_CCbest_125c.log`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - For Type 2/3: Compare extracted QRC tech against golden reference in pattern_items`
- `#   - Support waiver for techfile version mismatches (Type 3/4)`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- IMP-2-0-0-15 checker intent List QRC techfile name. eg: 17M1Xa1Xb1Xc1Xd1Ya1Yb4Y2Yy2Yx2R_SHDMIM_UT/fs_v1d0p1a
- physical implementation spef evidence extraction
- input_logs parasitics best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-2-0-0-15
  check_module: 2.0_TECHFILE_AND_RULE_DECK_CHECK
  intent: inventory
  knowledge_tags:
  - input_logs
  - parasitics
  candidate_objects:
  - spef
  input_files:
  - ${CHECKLIST_ROOT}\IP_project_folder\logs\2.0\do_qrcrcbest_CCbest_125c.log
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/inputs/items/IMP-2-0-0-15.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/scripts/checker/IMP-2-0-0-15.py
```
