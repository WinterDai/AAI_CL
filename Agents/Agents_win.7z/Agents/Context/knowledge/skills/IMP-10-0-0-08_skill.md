# IMP-10-0-0-08 Skill Hint

## Description

Confirm set the correct clock transition and data transition.

## Module and Intent

- Module: `10.0_STA_DCD_CHECK`
- Intent: `verification`
- Candidate objects: power_emir, sdc
- Knowledge tags: constraints, input_reports, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-08.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-08.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/constr.rpt`

### Regex clues from existing checker

- `get_clocks\s+\{([^}]+)\}`

### Keyword clues from existing checker

- `#   - Type 2/3: Pattern matching with optional waiver logic`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Pattern matching`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Pattern with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `- Type 1: requirements.value=N/A AND waivers.value=N/A/0`
- `- Type 2: requirements.value>0 AND pattern_items AND waivers.value=N/A/0`
- `- Type 3: requirements.value>0 AND pattern_items AND waivers.value>0`
- `- Type 4: requirements.value=N/A AND waivers.value>0`
- `self._pattern_items: List[str] = []`
- `# Patterns`
- `pattern_clock = re.compile(r'set_max_transition\s+-clock_path\s+([\d.]+).*get_clocks\s+\{([^}]+)\}', re.IGNORECASE)`

## Suggested retrieval queries

- IMP-10-0-0-08 checker intent Confirm set the correct clock transition and data transition.
- physical implementation power_emir sdc evidence extraction
- constraints input_reports power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-10-0-0-08
  check_module: 10.0_STA_DCD_CHECK
  intent: verification
  knowledge_tags:
  - constraints
  - input_reports
  - power_integrity
  - timing_signoff
  candidate_objects:
  - power_emir
  - sdc
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/constr.rpt
  requirements_value: N/A
  waiver_value: '1'
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-08.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-08.py
```
