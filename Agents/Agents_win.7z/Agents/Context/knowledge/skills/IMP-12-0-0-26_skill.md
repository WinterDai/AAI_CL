# IMP-12-0-0-26 Skill Hint

## Description

Confirm BUMP rule DRC result is clean.

## Module and Intent

- Module: `12.0_PHYSICAL_VERIFICATION_CHECK`
- Intent: `verification`
- Candidate objects: drc, power_emir
- Knowledge tags: input_reports, physical_verification, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-26.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-26.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Calibre_BUMP.rep`
- `${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Pegasus_BUMP.rep`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Classify violations: Separate waived vs unwaived based on waive_items`
- `#   - Determine pass/fail: PASS if total violations == 0 (Type 1/2) or all waived (Type 3/4)`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `#   status_check: pattern_items = DRC rules to CHECK STATUS (only output matched items)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`

## Suggested retrieval queries

- IMP-12-0-0-26 checker intent Confirm BUMP rule DRC result is clean.
- physical implementation drc power_emir evidence extraction
- input_reports physical_verification power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-12-0-0-26
  check_module: 12.0_PHYSICAL_VERIFICATION_CHECK
  intent: verification
  knowledge_tags:
  - input_reports
  - physical_verification
  - power_integrity
  candidate_objects:
  - drc
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Calibre_BUMP.rep
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Pegasus_BUMP.rep
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-26.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-26.py
```
