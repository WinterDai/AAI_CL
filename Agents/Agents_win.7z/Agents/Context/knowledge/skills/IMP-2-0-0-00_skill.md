# IMP-2-0-0-00 Skill Hint

## Description

List Innovus Tech Lef name. eg:N16_Encounter_11M_2Xa1Xd3Xe2Y2R_UTRDL_9T_PODE_1.2a.tlef

## Module and Intent

- Module: `2.0_TECHFILE_AND_RULE_DECK_CHECK`
- Intent: `inventory`
- Candidate objects: lef_def
- Knowledge tags: input_logs, layout_data

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/inputs/items/IMP-2-0-0-00.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/scripts/checker/IMP-2-0-0-00.py`

### Input files

- `${CHECKLIST_ROOT}\IP_project_folder\logs\2.0\do_innovusOUTwoD.logv`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Extract tech LEF path using pattern: r'\[.*?\]\s+Loading LEF file\s+([^\s]+\.tlef)'`
- `#   - For Type 2/3: Compare extracted tech LEF against golden reference from pattern_items`
- `#   - Support waiver for tech LEF filename mismatches (Type 3/4)`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`

## Suggested retrieval queries

- IMP-2-0-0-00 checker intent List Innovus Tech Lef name. eg:N16_Encounter_11M_2Xa1Xd3Xe2Y2R_UTRDL_9T_PODE_1.2a.tlef
- physical implementation lef_def evidence extraction
- input_logs layout_data best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-2-0-0-00
  check_module: 2.0_TECHFILE_AND_RULE_DECK_CHECK
  intent: inventory
  knowledge_tags:
  - input_logs
  - layout_data
  candidate_objects:
  - lef_def
  input_files:
  - ${CHECKLIST_ROOT}\IP_project_folder\logs\2.0\do_innovusOUTwoD.logv
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/inputs/items/IMP-2-0-0-00.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/2.0_TECHFILE_AND_RULE_DECK_CHECK/scripts/checker/IMP-2-0-0-00.py
```
