# IMP-1-0-0-04 Skill Hint

## Description

Confirm the versions of analog cells/macros are correct with AMS/Analog team.

## Module and Intent

- Module: `1.0_LIBRARY_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_logs, libraries, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/inputs/items/IMP-1-0-0-04.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/scripts/checker/IMP-1-0-0-04.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/genus.syn_generic.log`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   Confirm the versions of analog cells/macros are correct with AMS/Analog team.`
- `#   - Parse synthesis log to extract analog cell/macro versions`
- `#   - Verify versions match AMS/Analog team specifications`
- `#   - Document version confirmation status`
- `class AnalogCellVersionChecker(BaseChecker):`
- `"""IMP-1-0-0-04: Confirm analog cell/macro versions."""`
- `item_desc="Confirm the versions of analog cells/macros are correct with AMS/Analog team."`
- `# Store analog library info: {version_key: {lib_name, version, line_num, file_path}}`
- `def _extract_version_from_lib(self, lib_path: Path) -> str:`
- `Extract VERSION from analog library file.`
- `Look for patterns:`
- `- /* VERSION            : 101 */`

## Suggested retrieval queries

- IMP-1-0-0-04 checker intent Confirm the versions of analog cells/macros are correct with AMS/Analog team.
- physical implementation power_emir evidence extraction
- input_logs libraries power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-1-0-0-04
  check_module: 1.0_LIBRARY_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - libraries
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/genus.syn_generic.log
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/inputs/items/IMP-1-0-0-04.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/scripts/checker/IMP-1-0-0-04.py
```
