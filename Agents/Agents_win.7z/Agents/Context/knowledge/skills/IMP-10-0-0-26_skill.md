# IMP-10-0-0-26 Skill Hint

## Description

Confirm check_design report has no issue.

## Module and Intent

- Module: `10.0_STA_DCD_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_reports, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-26.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-26.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/10.0/check_design_func.rpt`

### Regex clues from existing checker

- `^={30,}\s*$`
- `.+:\s*\d+`
- `^\s+-{30,}\s*$`
- `^\s*([A-Za-z][A-Za-z0-9 /()-]+?):\s*(\d+%?|\d+\.\d+%)`
- `^\s*([A-Za-z][A-Za-z0-9 /()-]+?)\s{2,}(\d+)`

### Keyword clues from existing checker

- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`
- `#     - FAIL/WARN converted to INFO with suffix: [WAIVED_AS_INFO]`
- `from checker_templates.waiver_handler_template import WaiverHandlerMixin`
- `class Check_10_0_0_26(InputFileParserMixin, OutputBuilderMixin, WaiverHandlerMixin, BaseChecker):`

## Suggested retrieval queries

- IMP-10-0-0-26 checker intent Confirm check_design report has no issue.
- physical implementation power_emir evidence extraction
- input_reports power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-10-0-0-26
  check_module: 10.0_STA_DCD_CHECK
  intent: verification
  knowledge_tags:
  - input_reports
  - power_integrity
  - timing_signoff
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/10.0/check_design_func.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-26.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-26.py
```
