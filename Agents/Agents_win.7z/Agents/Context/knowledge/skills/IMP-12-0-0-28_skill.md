# IMP-12-0-0-28 Skill Hint

## Description

Confirm ARC check result is clean. (For BRCM project only, for others fill N/A)

## Module and Intent

- Module: `12.0_PHYSICAL_VERIFICATION_CHECK`
- Intent: `verification`
- Candidate objects: power_emir
- Knowledge tags: input_reports, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-28.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-28.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Calibre_ARC.rep`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Detect report format (Calibre vs Pegasus) based on pattern matching`
- `#   - For Type 2/3: Filter violations to monitored rules (pattern_items)`
- `#   - For Type 3/4: Apply waiver logic to classify violations`
- `#   Type 1: requirements.value=N/A, waivers.value=N/A/0 → Boolean check`
- `#   Type 2: requirements.value>0, pattern_items exists, waivers.value=N/A/0 → Value comparison`
- `#   Type 3: requirements.value>0, pattern_items exists, waivers.value>0 → Value with waiver logic`
- `#   Type 4: requirements.value=N/A, waivers.value>0 → Boolean with waiver logic`
- `#   status_check: pattern_items = ARC rule names to monitor (only output matched items)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`

## Suggested retrieval queries

- IMP-12-0-0-28 checker intent Confirm ARC check result is clean. (For BRCM project only, for others fill N/A)
- physical implementation power_emir evidence extraction
- input_reports power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-12-0-0-28
  check_module: 12.0_PHYSICAL_VERIFICATION_CHECK
  intent: verification
  knowledge_tags:
  - input_reports
  - power_integrity
  candidate_objects:
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Calibre_ARC.rep
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-28.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-28.py
```
