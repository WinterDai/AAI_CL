# IMP-12-0-0-12 Skill Hint

## Description

Confirm the MIM related check is clean. (Need to check and Fill N/A if no MIMCAP inserted or no MIM related layers in PHY or SOC level) - If PHY needs to insert MIMCAP. 1. Need to pay attention to the MIMCAP KOZ rule during MIMCAP insertion after check with customer about the SOC die size, substrate layer number and PHY placement/location in SOC level. 2. Pay attention to the option setting related to MIM DRC check like KOZ_High_subst_layer, SHDMIM_KOZ_AP_SPACE_5um(on/off will impact the checking rule) etc in TSMC rule deck(need to align these settings with customer). -If PHY doesn't insert MIMCAP but SOC level inserts MIMCAP. 1. Need to open SHDMIM switching in DRC rule deck. 2. Need to check with customer whether PHY need to meet SHDMIM_KOZ_AP_SPACE_5um rule (if SOC level this DRC switching setting is ON) in PHY area which falls into SOC KOZ area for TSMC process. 3. May need to insert MIM dummy in PHY level to meet SOC level MIM dummy density rule (you can sync with customer whether PHY MIM dummy is needed and the KOZ information on PHY to make sure there is no dummy added in KOZ area on PHY by adding MIM EXCL layer).

## Module and Intent

- Module: `12.0_PHYSICAL_VERIFICATION_CHECK`
- Intent: `verification`
- Candidate objects: drc, power_emir
- Knowledge tags: implementation_qor, input_reports, physical_verification, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-12.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-12.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Calibre_ANTMIM.rep`
- `${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Pegasus_ANTMIM.rep`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Support waiver for specific MIM rule violations`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`
- `#     - FAIL/WARN converted to INFO with suffix: [WAIVED_AS_INFO]`

## Suggested retrieval queries

- IMP-12-0-0-12 checker intent Confirm the MIM related check is clean. (Need to check and Fill N/A if no MIMCAP inserted or no MIM related layers in PHY or SOC level) - If PHY needs to insert MIMCAP. 1. Need to pay attention to the MIMCAP KOZ rule during MIMCAP insertion after check with customer about the SOC die size, substrate layer number and PHY placement/location in SOC level. 2. Pay attention to the option setting related to MIM DRC check like KOZ_High_subst_layer, SHDMIM_KOZ_AP_SPACE_5um(on/off will impact the checking rule) etc in TSMC rule deck(need to align these settings with customer). -If PHY doesn't insert MIMCAP but SOC level inserts MIMCAP. 1. Need to open SHDMIM switching in DRC rule deck. 2. Need to check with customer whether PHY need to meet SHDMIM_KOZ_AP_SPACE_5um rule (if SOC level this DRC switching setting is ON) in PHY area which falls into SOC KOZ area for TSMC process. 3. May need to insert MIM dummy in PHY level to meet SOC level MIM dummy density rule (you can sync with customer whether PHY MIM dummy is needed and the KOZ information on PHY to make sure there is no dummy added in KOZ area on PHY by adding MIM EXCL layer).
- physical implementation drc power_emir evidence extraction
- implementation_qor input_reports physical_verification power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-12-0-0-12
  check_module: 12.0_PHYSICAL_VERIFICATION_CHECK
  intent: verification
  knowledge_tags:
  - implementation_qor
  - input_reports
  - physical_verification
  - power_integrity
  candidate_objects:
  - drc
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Calibre_ANTMIM.rep
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/pv/Pegasus_ANTMIM.rep
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-12.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-12.py
```
