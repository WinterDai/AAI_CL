# IMP-1-0-0-01 Skill Hint

## Description

List standard cell libraries used for implementation and signoff.

## Module and Intent

- Module: `1.0_LIBRARY_CHECK`
- Intent: `inventory`
- Candidate objects: liberty, power_emir
- Knowledge tags: input_reports, libraries, power_integrity, timing_signoff

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/inputs/items/IMP-1-0-0-01.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/scripts/checker/IMP-1-0-0-01.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/qor.rpt`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `lib_pattern = re.compile(r'^\s*(\S+)\s+\S+$')`
- `lines = self.read_file(file_path)`
- `match = lib_pattern.match(lib_line)`
- `match = lib_pattern.match(stripped)`
- `if any(pattern in lib_name for pattern in ['tcbn', 'lib', '_', 'cpd', 'bwp']):`
- `has_pattern_items=False,`
- `has_waiver_value=False,`

## Suggested retrieval queries

- IMP-1-0-0-01 checker intent List standard cell libraries used for implementation and signoff.
- physical implementation liberty power_emir evidence extraction
- input_reports libraries power_integrity timing_signoff best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-1-0-0-01
  check_module: 1.0_LIBRARY_CHECK
  intent: inventory
  knowledge_tags:
  - input_reports
  - libraries
  - power_integrity
  - timing_signoff
  candidate_objects:
  - liberty
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/qor.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/inputs/items/IMP-1-0-0-01.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/scripts/checker/IMP-1-0-0-01.py
```
