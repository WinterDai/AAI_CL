# IMP-6-0-0-07 Skill Hint

## Description

Confirm "set flatten model -library_pin_verification" in LEC flow.

## Module and Intent

- Module: `6.0_POST_SYNTHESIS_LEC_CHECK`
- Intent: `verification`
- Candidate objects: lec, liberty, power_emir
- Knowledge tags: equivalence, input_logs, libraries, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/6.0_POST_SYNTHESIS_LEC_CHECK/inputs/items/IMP-6-0-0-07.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/6.0_POST_SYNTHESIS_LEC_CHECK/scripts/checker/IMP-6-0-0-07.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/map_to_final.log`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `lines = self.read_file(file_path)`
- `def _get_waive_items_with_reasons(self) -> Dict[str, str]:`
- `"""Get waiver items with their reasons."""`
- `waivers = self.get_waivers()`
- `if not waivers:`
- `waive_items = waivers.get('waive_items', [])`
- `if waive_items and isinstance(waive_items[0], dict):`
- `return {item['name']: item.get('reason', '') for item in waive_items}`
- `return {item: '' for item in waive_items}`
- `has_pattern_items=False,`
- `has_waiver_value=False,`
- `"""Type 3: Value with waiver logic (not typically used for this check)."""`

## Suggested retrieval queries

- IMP-6-0-0-07 checker intent Confirm "set flatten model -library_pin_verification" in LEC flow.
- physical implementation lec liberty power_emir evidence extraction
- equivalence input_logs libraries power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-6-0-0-07
  check_module: 6.0_POST_SYNTHESIS_LEC_CHECK
  intent: verification
  knowledge_tags:
  - equivalence
  - input_logs
  - libraries
  - power_integrity
  candidate_objects:
  - lec
  - liberty
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/map_to_final.log
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/6.0_POST_SYNTHESIS_LEC_CHECK/inputs/items/IMP-6-0-0-07.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/6.0_POST_SYNTHESIS_LEC_CHECK/scripts/checker/IMP-6-0-0-07.py
```
