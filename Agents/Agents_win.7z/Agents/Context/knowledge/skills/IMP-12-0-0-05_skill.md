# IMP-12-0-0-05 Skill Hint

## Description

Confirm open the IP_TIGHTEN_DENSITY switch in DRC rule deck.

## Module and Intent

- Module: `12.0_PHYSICAL_VERIFICATION_CHECK`
- Intent: `verification`
- Candidate objects: drc, power_emir
- Knowledge tags: implementation_qor, input_logs, physical_verification, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-05.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-05.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/logs/do_pvs_DRC_pvl.log`
- `${CHECKLIST_ROOT}/IP_project_folder/logs/do_cmd_3star_DRC_sourceme`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   - Search for IP_TIGHTEN_DENSITY #DEFINE directive using regex patterns`
- `#   Type 1: requirements.value=N/A, pattern_items [] (empty), waivers.value=N/A/0 → Boolean Check`
- `#   Type 2: requirements.value>0, pattern_items [...] (defined), waivers.value=N/A/0 → Value Check`
- `#   Type 3: requirements.value>0, pattern_items [...] (defined), waivers.value>0 → Value Check with Waiver Logic`
- `#   Type 4: requirements.value=N/A, pattern_items [] (empty), waivers.value>0 → Boolean Check with Waiver Logic`
- `#   Note: requirements.value indicates number of patterns for config validation (doesn't affect PASS/FAIL)`
- `# Waiver Tag Rules:`
- `#   When waivers.value > 0 (Type 3/4):`
- `#     - All waive_items related INFO/FAIL/WARN reason suffix: [WAIVER]`
- `#   When waivers.value = 0 (Type 1/2):`
- `#     - waive_items output as INFO with suffix: [WAIVED_INFO]`
- `#     - FAIL/WARN converted to INFO with suffix: [WAIVED_AS_INFO]`

## Suggested retrieval queries

- IMP-12-0-0-05 checker intent Confirm open the IP_TIGHTEN_DENSITY switch in DRC rule deck.
- physical implementation drc power_emir evidence extraction
- implementation_qor input_logs physical_verification power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-12-0-0-05
  check_module: 12.0_PHYSICAL_VERIFICATION_CHECK
  intent: verification
  knowledge_tags:
  - implementation_qor
  - input_logs
  - physical_verification
  - power_integrity
  candidate_objects:
  - drc
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/do_pvs_DRC_pvl.log
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/do_cmd_3star_DRC_sourceme
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/inputs/items/IMP-12-0-0-05.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/12.0_PHYSICAL_VERIFICATION_CHECK/scripts/checker/IMP-12-0-0-05.py
```
