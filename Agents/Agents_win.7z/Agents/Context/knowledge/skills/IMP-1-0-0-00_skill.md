# IMP-1-0-0-00 Skill Hint

## Description

Confirm the version of all the libraries used for this project are correct and match to addendum.

## Module and Intent

- Module: `1.0_LIBRARY_CHECK`
- Intent: `verification`
- Candidate objects: liberty, power_emir
- Knowledge tags: input_reports, libraries, power_integrity

## Input and Existing Implementation Clues

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/inputs/items/IMP-1-0-0-00.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/scripts/checker/IMP-1-0-0-00.py`

### Input files

- `${CHECKLIST_ROOT}/IP_project_folder/reports/qor.rpt`

### Regex clues from existing checker

- none

### Keyword clues from existing checker

- `#   Confirm the version of all the libraries used for this project are correct`
- `#   - Parse qor.rpt to extract all library versions`
- `#   - Compare extracted versions with expected versions from addendum`
- `#   - Verify all libraries match required versions`
- `class LibraryVersionChecker(BaseChecker):`
- `"""IMP-1-0-0-00: Confirm library versions match addendum."""`
- `item_desc="Confirm the version of all the libraries used for this project are correct and match to addendum."`
- `# Store version metadata: {version: {line_number, file_path}}`
- `Parse input files to extract library versions.`
- `List of version strings (deduplicated)`
- `all_versions = []`
- `lib_pattern = re.compile(r'^\s*(\S+)\s+(\S+)$')`

## Suggested retrieval queries

- IMP-1-0-0-00 checker intent Confirm the version of all the libraries used for this project are correct and match to addendum.
- physical implementation liberty power_emir evidence extraction
- input_reports libraries power_integrity best practices

## Embedded schema

```yaml
skill_schema:
  item_id: IMP-1-0-0-00
  check_module: 1.0_LIBRARY_CHECK
  intent: verification
  knowledge_tags:
  - input_reports
  - libraries
  - power_integrity
  candidate_objects:
  - liberty
  - power_emir
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/qor.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/inputs/items/IMP-1-0-0-00.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/1.0_LIBRARY_CHECK/scripts/checker/IMP-1-0-0-00.py
```
