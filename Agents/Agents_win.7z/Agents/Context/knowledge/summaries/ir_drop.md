# IR Drop (Power Integrity)

## What it is
IR drop is the voltage drop across the power delivery network due to resistance.
Excessive IR drop can cause functional failure or timing degradation.

## Typical evidence
- IR drop analysis reports and maps.
- Power integrity logs and summary tables.

## Relevance to checkers
Used for power integrity signoff and EM/IR checks.
