# LVS (Layout Versus Schematic)

## What it is
LVS compares the extracted layout netlist to the schematic or source netlist
and checks that devices and connectivity match.

## Typical evidence
- LVS report files with pass/fail summary.
- Logs indicating extraction and comparison steps.

## Relevance to checkers
Used to confirm netlist-to-layout consistency and signoff readiness.
