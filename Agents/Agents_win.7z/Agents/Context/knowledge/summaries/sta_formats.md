# STA Input Formats (Overview)

## What STA tools typically consume
- Verilog netlists for connectivity.
- Liberty (.lib) for cell timing and power models.
- SDC for timing constraints (Tcl-based).
- SDF for delay annotation.
- SPEF for parasitic extraction.

## Evidence sources
- STA tool logs showing read commands (read_verilog, read_liberty,
  read_sdc, read_sdf, read_spef).
- STA reports listing loaded libraries, constraints, and parasitics.

## Relevance to checkers
Use to interpret descriptions involving timing signoff, constraint checking,
parasitic correctness, or tool version alignment.
