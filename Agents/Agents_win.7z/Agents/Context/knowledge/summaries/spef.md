# SPEF (Standard Parasitic Exchange Format)

## What it is
SPEF is a text format for interconnect parasitics used by STA and signoff tools.
It includes headers and detailed net parasitic data.

## Typical header fields
- *SPEF
- *DESIGN
- *DATE
- *VENDOR
- *PROGRAM
- *VERSION
- *DIVIDER, *DELIMITER, *BUS_DELIMITER

## Evidence sources
- SPEF file header lines.
- STA logs indicating SPEF read or skipped.

## Relevance to checkers
Checkers often verify SPEF existence, version fields, and that SPEF matches
the intended design or flow stage.
