# UPF (Unified Power Format / IEEE 1801)

## What it is
UPF is the IEEE 1801 standard for specifying low-power intent. It defines power
states, power domains, supply nets, isolation, and level shifters.

## Typical content
- create_power_domain, create_supply_net, create_supply_port
- set_isolation, set_level_shifter

## Evidence sources
- UPF files and their version headers.
- Tool logs showing read_upf or power-intent steps.

## Relevance to checkers
Used in power-integrity and low-power checks for correct intent definition.
