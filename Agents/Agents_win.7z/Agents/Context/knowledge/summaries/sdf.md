# SDF (Standard Delay Format)

## What it is
SDF is a text format for back-annotated delay and timing data, commonly used
in simulation and verification.

## Typical content
- DELAY and TIMINGCHECK sections
- Cell instance paths and delay values

## Evidence sources
- SDF file headers and timestamps.
- STA or simulation logs referencing read_sdf or annotation steps.

## Relevance to checkers
Used when verifying that post-synthesis or post-route delay data exists and
is aligned with the intended flow stage.
