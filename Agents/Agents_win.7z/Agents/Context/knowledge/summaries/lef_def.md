# LEF and DEF (Layout Exchange Formats)

## What they are
- LEF (Library Exchange Format) describes technology layers, routing rules,
  and abstract cell or macro geometry.
- DEF (Design Exchange Format) describes a placed/routed design instance
  using references to LEF definitions.

## Typical content
- LEF: layer definitions, vias, site/row, macro pins, block outlines.
- DEF: components, placement coordinates, nets, routing, special nets.

## Evidence sources
- LEF/DEF file headers and version lines.
- Tool logs showing read_lef/read_def commands.
- Reports listing technology or routing rules in use.

## Relevance to checkers
Checkers may verify LEF/DEF versions, presence, or that correct tech files
were used for placement and routing.
