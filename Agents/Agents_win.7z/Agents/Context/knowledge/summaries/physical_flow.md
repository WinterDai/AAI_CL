# Physical Implementation Flow (Overview)

## What it is
Physical implementation transforms RTL/netlists into a placed and routed layout
and produces signoff artifacts. Common stages include floorplan, placement, CTS,
routing, extraction, and signoff checks.

## Typical stages and artifacts
- Inputs: RTL/netlist, Liberty libraries, LEF/DEF, SDC constraints.
- Floorplan: define die/core, rows, IO placement.
- Placement: place standard cells and macros.
- CTS: build clock tree to control skew.
- Routing: connect nets with metal layers.
- Extraction: produce parasitics (SPEF).
- Signoff: STA, DRC, LVS, power integrity.

## Evidence sources
- Tool logs for stage commands and versions.
- Reports for placement/utilization, CTS skew, routing DRC, STA timing.
- Layout databases (DEF/GDSII) and parasitics (SPEF).

## Relevance to checkers
Use to interpret descriptions that reference flow stages or signoff expectations.
