# Electromigration (Interconnect Reliability)

## What it is
Electromigration is mass transport in metal interconnects driven by high current
density. It can cause voids or hillocks that lead to opens or shorts over time.

## Typical evidence
- EM analysis reports (current density, lifetime margins).
- Tool logs indicating EM checks completed.

## Relevance to checkers
Used in power integrity and reliability signoff checks (often paired with IR drop).
