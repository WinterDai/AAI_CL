# SDC (Synopsys Design Constraints)

## What it is
SDC is a Tcl-based text format used to define timing constraints such as clocks,
IO delays, false paths, and multicycle paths.

## Typical content
- create_clock, set_clock_uncertainty
- set_input_delay, set_output_delay
- set_false_path, set_multicycle_path

## Evidence sources
- SDC file content and timestamps.
- STA logs showing read_sdc commands.

## Relevance to checkers
Use for checks that validate constraint presence, version, or expected clock
definitions.
