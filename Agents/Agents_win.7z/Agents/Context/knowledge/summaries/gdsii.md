# GDSII (Layout Database)

## What it is
GDSII is a binary layout exchange format used to deliver final IC layout to
foundries and signoff tools. It represents shapes, layers, and hierarchy.

## Typical content
- Cells (hierarchy), polygons, paths, text labels.
- Layer numbers and datatypes for geometry and markers.

## Evidence sources
- GDSII file headers (if available) and file timestamps.
- Tool logs or reports showing gdsout or streamout steps.

## Relevance to checkers
Checkers may verify GDSII generation, versioning, or that layout delivery files
exist and correspond to the intended design.
