# DRC (Design Rule Check)

## What it is
DRC verifies that a physical layout obeys manufacturing rules such as minimum
width, spacing, enclosure, density, and antenna constraints.

## Typical evidence
- DRC report files listing violations.
- DRC rule deck names and versions in logs.

## Relevance to checkers
Checkers may verify that the latest rule decks were used, that DRC ran, and
that violation counts meet project criteria.
