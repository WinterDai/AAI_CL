# Local RAG Artifacts

This directory stores lexical RAG indexes for Context Agent.

## Index sets

- `stage1_baseline/`: built from `summaries/` only.
- `main/`: built from `summaries/ + skills/ + checker_hints/`.

## Files per index set

- `chunks.jsonl`: text chunks with metadata.
- `index.json`: TF-IDF postings, IDF table, and document norms.
- `report.md`: build summary.

## Rebuild commands

```bash
python3 /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Context/knowledge/tools/build_rag_index.py \
  --knowledge-root /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Context/knowledge \
  --include-dirs summaries \
  --output-dir /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Context/knowledge/rag/stage1_baseline

python3 /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Context/knowledge/tools/build_rag_index.py \
  --knowledge-root /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Context/knowledge \
  --include-dirs summaries skills checker_hints \
  --output-dir /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Context/knowledge/rag/main
```
