# Local RAG Build Report

- Included dirs: summaries
- Chunks: 43
- Terms: 297

## Source files

- `summaries/drc.md`: 3 chunks
- `summaries/electromigration.md`: 3 chunks
- `summaries/gdsii.md`: 4 chunks
- `summaries/ir_drop.md`: 3 chunks
- `summaries/lef_def.md`: 4 chunks
- `summaries/lvs.md`: 3 chunks
- `summaries/physical_flow.md`: 4 chunks
- `summaries/sdc.md`: 4 chunks
- `summaries/sdf.md`: 4 chunks
- `summaries/spef.md`: 4 chunks
- `summaries/sta_formats.md`: 3 chunks
- `summaries/upf.md`: 4 chunks
