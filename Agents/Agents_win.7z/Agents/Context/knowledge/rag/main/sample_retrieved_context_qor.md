# Retrieved Context

- Query: `synthesis qor timing area power`
- Item ID: `IMP-5-0-0-12`

## Hit 1

- Score: `1.0268`
- Source: `skills/IMP-5-0-0-12_skill.md`
- Section: `Description`

Confirm synthesis Quality Of Results (QOR) meets requirements (timing, area, power)?

## Hit 2

- Score: `0.9812`
- Source: `skills/IMP-5-0-0-12_skill.md`
- Section: `Suggested retrieval queries`

- IMP-5-0-0-12 checker intent Confirm synthesis Quality Of Results (QOR) meets requirements (timing, area, power)?
- physical implementation power_emir timing evidence extraction
- implementation_qor input_reports power_integrity timing_signoff best practices

## Hit 3

- Score: `0.6571`
- Source: `skills/IMP-5-0-0-12_skill.md`
- Section: `Input files`

- `${CHECKLIST_ROOT}/IP_project_folder/reports/qor.rpt`

## Hit 4

- Score: `0.6409`
- Source: `skills/IMP-5-0-0-12_skill.md`
- Section: `Embedded schema`

```yaml
skill_schema:
  item_id: IMP-5-0-0-12
  check_module: 5.0_SYNTHESIS_CHECK
  intent: verification
  knowledge_tags:
  - implementation_qor
  - input_reports
  - power_integrity
  - timing_signoff
  candidate_objects:
  - power_emir
  - timing
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/reports/qor.rpt
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-12.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-12.py
```

## Hit 5

- Score: `0.4728`
- Source: `skills/IMP-5-0-0-12_skill.md`
- Section: `Input and Existing Implementation Clues`

- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/inputs/items/IMP-5-0-0-12.yaml`
- Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/5.0_SYNTHESIS_CHECK/scripts/checker/IMP-5-0-0-12.py`

