# Retrieved Context

- Query: `confirm netlist spef version`
- Item ID: `IMP-10-0-0-00`

## Hit 1

- Score: `0.7392`
- Source: `skills/IMP-10-0-0-00_skill.md`
- Section: `Description`

Confirm the netlist/spef version is correct.

## Hit 2

- Score: `0.6969`
- Source: `skills/IMP-10-0-0-00_skill.md`
- Section: `Suggested retrieval queries`

- IMP-10-0-0-00 checker intent Confirm the netlist/spef version is correct.
- physical implementation netlist power_emir spef evidence extraction
- input_logs parasitics power_integrity timing_signoff best practices

## Hit 3

- Score: `0.3991`
- Source: `skills/IMP-10-0-0-00_skill.md`
- Section: `Module and Intent`

- Module: `10.0_STA_DCD_CHECK`
- Intent: `verification`
- Candidate objects: netlist, power_emir, spef
- Knowledge tags: input_logs, parasitics, power_integrity, timing_signoff

## Hit 4

- Score: `0.3937`
- Source: `skills/IMP-10-0-0-00_skill.md`
- Section: `Embedded schema`

```yaml
skill_schema:
  item_id: IMP-10-0-0-00
  check_module: 10.0_STA_DCD_CHECK
  intent: verification
  knowledge_tags:
  - input_logs
  - parasitics
  - power_integrity
  - timing_signoff
  candidate_objects:
  - netlist
  - power_emir
  - spef
  input_files:
  - ${CHECKLIST_ROOT}/IP_project_folder/logs/sta_post_syn.log
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-00.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/scripts/checker/IMP-10-0-0-00.py
```

## Hit 5

- Score: `0.3525`
- Source: `skills/IMP-14-0-0-00_skill.md`
- Section: `Suggested retrieval queries`

- IMP-14-0-0-00 checker intent Confirm set the correct golden netlist.
- physical implementation netlist power_emir evidence extraction
- power_integrity best practices

## Hit 6

- Score: `0.3430`
- Source: `skills/MIG-IMP-10-1-1-00_skill.md`
- Section: `Embedded schema`

```yaml
skill_schema:
  item_id: MIG-IMP-10-1-1-00
  check_module: 10.1_STA_DCD_CHECK
  intent: verification
  knowledge_tags:
  - power_integrity
  - timing_signoff
  candidate_objects:
  - netlist
  - power_emir
  input_files: []
  requirements_value: N/A
  waiver_value: N/A
  yaml_path: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.1_STA_DCD_CHECK/inputs/items/MIG-IMP-10-1-1-00.yaml
  checker_script: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.1_STA_DCD_CHECK/scripts/checker/MIG-IMP-10-1-1-00.py
```

