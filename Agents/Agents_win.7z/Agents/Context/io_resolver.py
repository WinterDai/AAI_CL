#!/usr/bin/env python3
"""I/O resolution and evidence extraction for Context Agent."""

from __future__ import annotations

import csv
import gzip
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import yaml


CHECKLIST_TOKEN_RE = re.compile(r"\$\{CHECKLIST_ROOT\}|\$CHECKLIST_ROOT")
ITEM_ID_RE = re.compile(r"[A-Z]+-IMP-\d+-\d+-\d+-\d+|IMP-\d+-\d+-\d+-\d+")
PATH_HINT_RE = re.compile(
    r"([A-Za-z]:[\\/][^\s\"']+\.(?:v|sv|sdf|spef|log|rpt|txt|lib|lef|def|tcl|csv|yaml|yml|md|gz)"
    r"|/[^\s\"']+\.(?:v|sv|sdf|spef|log|rpt|txt|lib|lef|def|tcl|csv|yaml|yml|md|gz))"
)
GENERIC_EVIDENCE_PATTERNS = [
    r"read_netlist\s+([^\s]+)",
    r"read_spef\s+([^\s]+)",
    r"Top level cell is\s+(\S+)",
    r"Program version\s*=\s*([\w\.-]+)",
    r"Generated on:\s*(.+)",
    r"\*DATE\s+\"?([^\"]+)\"?",
    r"\*DESIGN\s+\"?([^\"]+)\"?",
    r"Skipping SPEF reading as\s+(.+)",
]


@dataclass
class ChecklistRow:
    check_module: str = ""
    item: str = ""
    info: str = ""


@dataclass
class ItemContext:
    item_id: str
    description: str
    requirements_value: Any
    pattern_items: List[str]
    waiver_value: Any
    waive_items: List[str]
    input_files_raw: List[str]
    input_files_resolved: List[Path]
    missing_input_files: List[str]
    item_yaml_path: Path
    check_module: str
    checklist_row: ChecklistRow = field(default_factory=ChecklistRow)
    skill_hint_path: Optional[Path] = None
    skill_hint_markdown: str = ""
    regex_clues: List[str] = field(default_factory=list)
    keyword_clues: List[str] = field(default_factory=list)
    candidate_objects: List[str] = field(default_factory=list)


@dataclass
class EvidenceRecord:
    source_file: Path
    line_number: int
    pattern: str
    line_text: str
    extracted_values: List[str] = field(default_factory=list)


@dataclass
class EvidenceBundle:
    resolved_inputs: List[Path] = field(default_factory=list)
    missing_inputs: List[str] = field(default_factory=list)
    input_records: List[EvidenceRecord] = field(default_factory=list)
    referenced_records: List[EvidenceRecord] = field(default_factory=list)
    referenced_files: List[Path] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)


class ContextIOResolver:
    """Resolve item metadata, input files, and evidence snippets."""

    def __init__(self, checklist_root: Path, context_root: Optional[Path] = None):
        self.checklist_root = Path(checklist_root)
        self.context_root = Path(context_root) if context_root else Path(__file__).resolve().parent

    def resolve_item_yaml(self, item_id: str, item_yaml_path: Optional[Path] = None) -> Path:
        if item_yaml_path:
            explicit = Path(item_yaml_path)
            if explicit.exists():
                return explicit.resolve()
            raise FileNotFoundError(f"Item YAML not found: {explicit}")

        search_root = self.checklist_root / "Check_modules"
        if not search_root.exists():
            raise FileNotFoundError(f"Check_modules not found under {self.checklist_root}")

        candidates = sorted(search_root.rglob(f"{item_id}.yaml"))
        if not candidates:
            raise FileNotFoundError(f"Unable to find item YAML for {item_id}")
        return candidates[0].resolve()

    def load_item_context(self, item_id: str, item_yaml_path: Optional[Path] = None) -> ItemContext:
        yaml_path = self.resolve_item_yaml(item_id=item_id, item_yaml_path=item_yaml_path)
        payload = yaml.safe_load(yaml_path.read_text(encoding="utf-8")) or {}

        desc = str(payload.get("description", "")).strip()
        requirements = payload.get("requirements", {}) or {}
        waivers = payload.get("waivers", {}) or {}
        raw_inputs = payload.get("input_files", []) or []

        resolved_inputs: List[Path] = []
        missing_inputs: List[str] = []
        for raw in raw_inputs:
            resolved = self.resolve_input_path(str(raw), yaml_path.parent)
            if resolved and resolved.exists():
                resolved_inputs.append(resolved)
            else:
                missing_inputs.append(str(raw))

        check_module = self._extract_check_module(yaml_path)
        checklist_row = self._load_checklist_row(item_id=item_id)
        skill_path, skill_text = self._load_skill_hint(item_id=item_id)
        regex_clues = self._extract_bulleted_block(skill_text, "Regex clues from existing checker")
        keyword_clues = self._extract_bulleted_block(skill_text, "Keyword clues from existing checker")
        candidate_objects = self._extract_candidate_objects(skill_text)

        # Prefer CSV info if item yaml description is empty.
        if not desc and checklist_row.info:
            desc = checklist_row.info

        return ItemContext(
            item_id=item_id,
            description=desc,
            requirements_value=requirements.get("value", "N/A"),
            pattern_items=[str(x) for x in requirements.get("pattern_items", []) or []],
            waiver_value=waivers.get("value", "N/A"),
            waive_items=[str(x) for x in waivers.get("waive_items", []) or []],
            input_files_raw=[str(x) for x in raw_inputs],
            input_files_resolved=resolved_inputs,
            missing_input_files=missing_inputs,
            item_yaml_path=yaml_path,
            check_module=check_module,
            checklist_row=checklist_row,
            skill_hint_path=skill_path,
            skill_hint_markdown=skill_text,
            regex_clues=regex_clues,
            keyword_clues=keyword_clues,
            candidate_objects=candidate_objects,
        )

    def resolve_input_path(self, raw_path: str, base_dir: Path) -> Optional[Path]:
        # Use lambda to avoid regex escape issues with Windows paths (e.g., \Users)
        expanded = CHECKLIST_TOKEN_RE.sub(lambda m: str(self.checklist_root), raw_path)
        expanded = os.path.expandvars(expanded)
        expanded = expanded.strip().strip("\"'")

        if not expanded:
            return None

        path = Path(expanded)
        if path.exists():
            return path.resolve()
        if path.is_absolute():
            return path

        # Try relative to checklist root.
        candidate = (self.checklist_root / expanded).resolve()
        if candidate.exists():
            return candidate

        # Try relative to current yaml directory.
        candidate = (base_dir / expanded).resolve()
        if candidate.exists():
            return candidate

        # Return a best-effort absolute path even if missing.
        if path.is_absolute():
            return path
        return (self.checklist_root / expanded).resolve()

    def extract_evidence(
        self,
        context: ItemContext,
        max_lines_per_input: int = 3000,
        max_records_per_file: int = 40,
        max_records_per_pattern: int = 8,
        max_referenced_files: int = 8,
    ) -> EvidenceBundle:
        bundle = EvidenceBundle(
            resolved_inputs=list(context.input_files_resolved),
            missing_inputs=list(context.missing_input_files),
        )

        patterns = self._build_evidence_patterns(context)
        referenced_paths: List[Tuple[str, Path]] = []

        for input_path in context.input_files_resolved:
            lines = self._read_text_lines(input_path, max_lines=max_lines_per_input)
            if not lines:
                bundle.notes.append(f"No readable text extracted from {input_path}")
                continue

            per_pattern_hits: Dict[str, int] = {pat: 0 for pat in patterns}
            total_hits = 0

            for lineno, line in enumerate(lines, start=1):
                text = line.rstrip("\n")
                if not text.strip():
                    continue

                for pat in patterns:
                    if total_hits >= max_records_per_file:
                        break
                    if per_pattern_hits[pat] >= max_records_per_pattern:
                        continue

                    match = re.search(pat, text)
                    if not match:
                        continue

                    values = [x.strip() for x in match.groups() if x and x.strip()]
                    bundle.input_records.append(
                        EvidenceRecord(
                            source_file=input_path,
                            line_number=lineno,
                            pattern=pat,
                            line_text=text,
                            extracted_values=values,
                        )
                    )
                    per_pattern_hits[pat] += 1
                    total_hits += 1

                    for value in values:
                        ref = self._resolve_possible_reference(value=value, source_file=input_path)
                        if ref is not None:
                            referenced_paths.append((value, ref))

                if total_hits >= max_records_per_file:
                    break

                for m in PATH_HINT_RE.finditer(text):
                    ref_val = m.group(1)
                    ref = self._resolve_possible_reference(value=ref_val, source_file=input_path)
                    if ref is not None:
                        referenced_paths.append((ref_val, ref))

        # Deduplicate referenced files while preserving order.
        dedup_refs: List[Path] = []
        seen: set[str] = set()
        for _, ref in referenced_paths:
            key = str(ref)
            if key in seen:
                continue
            seen.add(key)
            dedup_refs.append(ref)

        bundle.referenced_files = dedup_refs[:max_referenced_files]

        header_patterns = [
            r"Generated by\s+(.+)",
            r"Generated on:\s+(.+)",
            r"Program version\s*=\s*([\w\.-]+)",
            r"\*DESIGN\s+\"?([^\"]+)\"?",
            r"\*DATE\s+\"?([^\"]+)\"?",
        ]

        for ref_file in bundle.referenced_files:
            lines = self._read_text_lines(ref_file, max_lines=120)
            if not lines:
                continue
            for lineno, line in enumerate(lines, start=1):
                text = line.rstrip("\n")
                if not text.strip():
                    continue
                for pat in header_patterns:
                    match = re.search(pat, text)
                    if not match:
                        continue
                    values = [x.strip() for x in match.groups() if x and x.strip()]
                    bundle.referenced_records.append(
                        EvidenceRecord(
                            source_file=ref_file,
                            line_number=lineno,
                            pattern=pat,
                            line_text=text,
                            extracted_values=values,
                        )
                    )

        if not bundle.input_records:
            bundle.notes.append("No evidence records matched current pattern set.")

        return bundle

    def _extract_check_module(self, yaml_path: Path) -> str:
        # Expected shape: .../Check_modules/<module>/inputs/items/<item>.yaml
        parts = list(yaml_path.parts)
        if "Check_modules" in parts:
            idx = parts.index("Check_modules")
            if idx + 1 < len(parts):
                return parts[idx + 1]
        return ""

    def _load_checklist_row(self, item_id: str) -> ChecklistRow:
        csv_path = self.checklist_root / "Project_config" / "collaterals" / "Initial" / "latest" / "CheckList.csv"
        if not csv_path.exists():
            return ChecklistRow(item=item_id)

        with csv_path.open("r", encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                if str(row.get("Item", "")).strip() == item_id:
                    return ChecklistRow(
                        check_module=str(row.get("Check_modules", "")).strip(),
                        item=item_id,
                        info=str(row.get("Info", "")).strip(),
                    )
        return ChecklistRow(item=item_id)

    def _load_skill_hint(self, item_id: str) -> Tuple[Optional[Path], str]:
        skill_dir = self.context_root / "knowledge" / "skills"
        if not skill_dir.exists():
            return None, ""

        exact = skill_dir / f"{item_id}_skill.md"
        if exact.exists():
            return exact, exact.read_text(encoding="utf-8")

        matches = sorted(skill_dir.glob(f"{item_id}*_skill.md"), key=lambda p: (len(p.name), p.name))
        if not matches:
            return None, ""

        chosen = matches[0]
        return chosen, chosen.read_text(encoding="utf-8")

    def _extract_bulleted_block(self, markdown: str, heading: str) -> List[str]:
        if not markdown:
            return []

        pattern = re.compile(rf"###\s+{re.escape(heading)}\n(.*?)(?:\n###\s+|\Z)", re.DOTALL)
        match = pattern.search(markdown)
        if not match:
            return []

        lines = []
        for raw in match.group(1).splitlines():
            line = raw.strip()
            if not line.startswith("-"):
                continue
            payload = line[1:].strip()
            payload = payload.strip("`")
            if payload:
                lines.append(payload)
        return lines

    def _extract_candidate_objects(self, markdown: str) -> List[str]:
        if not markdown:
            return []

        match = re.search(r"Candidate objects:\s*(.+)", markdown)
        if not match:
            return []

        raw = match.group(1)
        tokens = [x.strip().lower() for x in raw.split(",") if x.strip()]
        return [self._normalize_token(x) for x in tokens if self._normalize_token(x)]

    def _build_evidence_patterns(self, context: ItemContext) -> List[str]:
        patterns: List[str] = []
        for clue in context.regex_clues:
            if clue not in patterns:
                patterns.append(clue)

        for pat in GENERIC_EVIDENCE_PATTERNS:
            if pat not in patterns:
                patterns.append(pat)

        for token in self._description_tokens(context.description):
            escaped = re.escape(token)
            patterns.append(rf"\b{escaped}\b")

        return patterns

    def _resolve_possible_reference(self, value: str, source_file: Path) -> Optional[Path]:
        candidate = value.strip().strip("\"'.,:;()[]{}")
        if not candidate:
            return None

        if not re.search(r"\.[A-Za-z0-9]+$", candidate):
            return None

        # Use lambda to avoid regex escape issues with Windows paths (e.g., \Users)
        expanded = CHECKLIST_TOKEN_RE.sub(lambda m: str(self.checklist_root), candidate)
        expanded = os.path.expandvars(expanded)
        path = Path(expanded)

        if path.is_absolute() and path.exists():
            return path.resolve()

        rel_source = (source_file.parent / expanded).resolve()
        if rel_source.exists():
            return rel_source

        rel_root = (self.checklist_root / expanded).resolve()
        if rel_root.exists():
            return rel_root

        # Cross-environment path mapping: extract relative path from CHECKLIST marker
        # e.g., /Users/daiwt/.../CHECKLIST/IP_project_folder/dbs/file.v.gz
        #    -> ${CHECKLIST_ROOT}/IP_project_folder/dbs/file.v.gz
        checklist_markers = ["CHECKLIST/", "checklist/", "/CHECKLIST/", "/checklist/"]
        for marker in checklist_markers:
            if marker in candidate:
                # Extract the part after CHECKLIST/
                idx = candidate.find(marker) + len(marker)
                rel_path = candidate[idx:]
                mapped = (self.checklist_root / rel_path).resolve()
                if mapped.exists():
                    return mapped
                # Also try with IP_project_folder prefix if not already there
                if not rel_path.startswith("IP_project_folder"):
                    mapped_ip = (self.checklist_root / "IP_project_folder" / rel_path).resolve()
                    if mapped_ip.exists():
                        return mapped_ip

        # If there is an item-id like token and path does not exist, ignore it.
        if ITEM_ID_RE.fullmatch(candidate):
            return None

        return None

    def _read_text_lines(self, file_path: Path, max_lines: int) -> List[str]:
        if not file_path.exists() or not file_path.is_file():
            return []

        # Try plain text first.
        try:
            with file_path.open("r", encoding="utf-8", errors="ignore") as fh:
                lines = []
                for idx, line in enumerate(fh):
                    if idx >= max_lines:
                        break
                    lines.append(line)
                return lines
        except Exception:
            pass

        # Fall back to gzip text stream if needed.
        try:
            with gzip.open(file_path, "rt", encoding="utf-8", errors="ignore") as fh:
                lines = []
                for idx, line in enumerate(fh):
                    if idx >= max_lines:
                        break
                    lines.append(line)
                return lines
        except Exception:
            return []

    @staticmethod
    def _description_tokens(description: str) -> List[str]:
        stop = {
            "confirm", "the", "is", "are", "of", "for", "to", "and", "or", "a", "an", "in",
            "on", "with", "this", "that", "be", "by", "from", "all", "no", "correct", "match",
        }
        chunks = re.findall(r"[A-Za-z0-9_/-]+", description or "")
        tokens: List[str] = []
        for token in chunks:
            for part in token.replace("/", " ").replace("-", " ").split():
                norm = part.strip().lower()
                if len(norm) < 3 or norm in stop:
                    continue
                tokens.append(norm)
        # Keep stable order and uniqueness.
        seen: set[str] = set()
        ordered: List[str] = []
        for t in tokens:
            if t in seen:
                continue
            seen.add(t)
            ordered.append(t)
        return ordered[:12]

    @staticmethod
    def _normalize_token(token: str) -> str:
        return re.sub(r"[^a-z0-9_]+", "_", token.strip().lower()).strip("_")


def stringify_records(records: Sequence[EvidenceRecord], max_rows: int = 30) -> str:
    """Render evidence records into compact markdown table rows."""
    rows: List[str] = []
    for rec in records[:max_rows]:
        values = ", ".join(rec.extracted_values) if rec.extracted_values else "-"
        text = rec.line_text.strip().replace("|", "\\|")
        source = str(rec.source_file)
        rows.append(f"| {source} | {rec.line_number} | `{rec.pattern}` | `{values}` | `{text}` |")
    return "\n".join(rows)
