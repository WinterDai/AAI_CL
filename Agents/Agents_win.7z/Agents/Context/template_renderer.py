#!/usr/bin/env python3
"""Markdown renderers for Context Agent contracts."""

from __future__ import annotations

from typing import List, Sequence

try:
    from .spec_contracts import (
        DecisionScenario,
        FormatSpecContract,
        ItemSpecContract,
        ParsingSpecContract,
        dump_root_yaml,
    )
except ImportError:  # pragma: no cover
    from spec_contracts import (
        DecisionScenario,
        FormatSpecContract,
        ItemSpecContract,
        ParsingSpecContract,
        dump_root_yaml,
    )


def _md_table(headers: Sequence[str], rows: Sequence[Sequence[str]]) -> str:
    head = "| " + " | ".join(headers) + " |"
    sep = "| " + " | ".join(["---"] * len(headers)) + " |"
    body = "\n".join(["| " + " | ".join([str(x) for x in row]) + " |" for row in rows])
    return "\n".join([head, sep, body] if body else [head, sep])


def _sanitize_markdown_text(value: str) -> str:
    return value.replace("|", "\\|").strip()


def render_itemspec(contract: ItemSpecContract) -> str:
    interpretation_rules = contract.interpretation_rules or [
        "Slash notation defaults to logical AND across objects unless explicit `or` is present.",
        "Explicit `or` denotes alternatives where at least one branch must satisfy the requirement.",
        "Optional components are modeled as optional sub-items and may be governed by waiver contracts.",
    ]
    semantic_rows: List[List[str]] = []
    sub_item_rows: List[List[str]] = []
    for target in contract.semantic_targets:
        semantic_rows.append(
            [
                target.target_id,
                target.object_name,
                _sanitize_markdown_text(target.semantic_intent),
                _sanitize_markdown_text("; ".join(target.pass_when) or "All mandatory sub-items are semantically supported."),
                _sanitize_markdown_text("; ".join(target.fail_when) or "Any mandatory sub-item is missing or semantically conflicting."),
            ]
        )
        for sub in target.sub_items:
            sub_item_rows.append(
                [
                    target.object_name,
                    f"`{sub.name}`",
                    "mandatory" if sub.required else "optional",
                    _sanitize_markdown_text(sub.semantics),
                    _sanitize_markdown_text(sub.pass_condition),
                    _sanitize_markdown_text(sub.fail_condition),
                ]
            )

    rule_rows = [
        [
            x.rule_id,
            _sanitize_markdown_text(x.expression),
            "true" if x.required else "false",
            _sanitize_markdown_text("; ".join(x.pass_when)),
            _sanitize_markdown_text("; ".join(x.fail_when)),
        ]
        for x in contract.cross_object_rules
    ]
    waiver_scope_rows = [
        [
            _sanitize_markdown_text(x.granularity),
            f"`{_sanitize_markdown_text(x.token_format)}`",
            _sanitize_markdown_text(x.effect_scope),
        ]
        for x in contract.waiver_scopes
    ]
    decision_rows = [
        [x.scenario, x.requirements_value, x.waivers_value, _sanitize_markdown_text(x.decision_rule)]
        for x in (contract.decision_matrix or _default_decision_matrix())
    ]
    source_rows = [
        [x.priority, _sanitize_markdown_text(x.source), _sanitize_markdown_text(x.expected_evidence)]
        for x in contract.evidence_source_priority
    ]
    evidence_field_rows = [[f"`{f}`", "Required downstream evidence field."] for f in contract.mandatory_evidence_fields]

    knowledge_lines = "\n".join([f"- {x}" for x in contract.knowledge_notes]) if contract.knowledge_notes else "- No RAG hit available."

    yaml_block = dump_root_yaml("itemspec", contract.to_schema_dict())

    return (
        f"# {contract.item_id} ItemSpec\n\n"
        f"Description: {contract.description or 'N/A'}\n"
        f"Check Module: {contract.check_module or 'N/A'}\n"
        f"Role: {contract.role}\n\n"
        "## Scope\n"
        f"This specification defines what must be checked semantically for `{contract.item_id}`.\n"
        "This stage must not parse runtime input files.\n\n"
        "- Define semantic intent and check boundaries.\n"
        "- Define objects and sub-items to validate.\n"
        "- Define PASS/FAIL and waiver boundary rules.\n\n"
        "## Description Interpretation Rules\n"
        + "\n".join([f"- {x}" for x in interpretation_rules])
        + "\n\n"
        "## Semantic Targets\n\n"
        "### Semantic Target Table\n"
        + _md_table(
            ["Target ID", "Object", "Required Semantic Intent", "PASS Condition", "FAIL Condition"],
            semantic_rows,
        )
        + "\n\n### Object/Sub-Item Contract\n"
        + _md_table(
            ["Object", "Sub-Item", "Required", "Semantic Meaning", "PASS Condition", "FAIL Condition"],
            sub_item_rows,
        )
        + "\n\n### Cross-Object Consistency Rules\n"
        + _md_table(
            ["Rule ID", "Expression", "Required", "PASS Condition", "FAIL Condition"],
            rule_rows,
        )
        + "\n\n### Waiver Scope Contract\n"
        + _md_table(
            ["Waiver Granularity", "Token Format", "Effect Scope"],
            waiver_scope_rows,
        )
        + "\n\n## Check Criteria\n"
        + f"- Requirement value observed in item yaml: `{contract.requirement_value_observed}`\n"
        + f"- Waiver value observed in item yaml: `{contract.waiver_value_observed}`\n"
        + "- Any mandatory sub-item missing triggers FAIL unless covered by a valid waiver.\n"
        + "- Any required cross-object rule violation triggers FAIL unless covered by a valid waiver.\n\n"
        + "### Decision Matrix (Requirement/Waiver)\n"
        + _md_table(
            ["Scenario", "requirements.value", "waivers.value", "Decision Rule"],
            decision_rows,
        )
        + "\n\n## Evidence Plan\n"
        + "### Data Source Priority\n"
        + _md_table(
            ["Priority", "Source", "Expected Evidence"],
            source_rows,
        )
        + "\n\n### Stage Responsibilities\n"
        + "- Stage A (ItemSpec): semantic contract only; no runtime file reads.\n"
        + "- Stage B (ParsingSpec): locate concrete evidence with file path and line number.\n"
        + "- Stage C (FormatSpec): normalize evidence into requirement and waiver formats.\n\n"
        + "### Mandatory Evidence Fields for Downstream\n"
        + _md_table(["Field", "Meaning"], evidence_field_rows)
        + "\n\n### Knowledge Notes\n"
        + knowledge_lines
        + "\n\n## Embedded Schema\n```yaml\n"
        + yaml_block
        + "\n```\n"
    )


def render_parsing_spec(contract: ParsingSpecContract) -> str:
    resolved_inputs = "\n".join([f"- {x}" for x in contract.resolved_inputs]) if contract.resolved_inputs else "- (none)"
    missing_inputs = "\n".join([f"- {x}" for x in contract.missing_inputs]) if contract.missing_inputs else "- (none)"

    evidence_rows = [
        [
            r.evidence_id,
            r.source_file,
            str(r.line_number),
            f"`{_sanitize_markdown_text(r.pattern)}`",
            f"`{_sanitize_markdown_text(r.extracted_value or '-')}`",
            f"`{_sanitize_markdown_text(r.raw_line or '-')}`",
            f"{r.confidence:.2f}",
        ]
        for r in contract.evidence_records
    ]
    referenced_rows = [
        [
            r.evidence_id,
            r.source_file,
            str(r.line_number),
            f"`{_sanitize_markdown_text(r.pattern)}`",
            f"`{_sanitize_markdown_text(r.extracted_value or '-')}`",
            f"`{_sanitize_markdown_text(r.raw_line or '-')}`",
        ]
        for r in contract.referenced_file_records
    ]
    mapping_rows = [
        [
            m.evidence_id,
            m.object_name,
            f"`{m.sub_item}`",
            "true" if m.required else "false",
            m.mapping_status,
            _sanitize_markdown_text(m.rationale),
        ]
        for m in contract.evidence_to_sub_item
    ]
    object_status_rows = [
        [
            x.object_name,
            str(x.mandatory_found),
            str(x.mandatory_total),
            x.status,
            _sanitize_markdown_text(x.blocker_reason or "none"),
        ]
        for x in contract.object_status_summary
    ]
    gap_rows = [
        [
            x.object_name,
            f"`{x.sub_item}`",
            x.gap_type,
            _sanitize_markdown_text(x.detail),
            _sanitize_markdown_text(x.suggested_resolution),
        ]
        for x in contract.extraction_gaps
    ]
    conflict_rows = [
        [
            x.object_name,
            f"`{x.sub_item}`",
            x.conflict_type,
            _sanitize_markdown_text(", ".join(x.candidates)),
            _sanitize_markdown_text(x.resolution_hint),
        ]
        for x in contract.conflicts
    ]
    ratio = f"{contract.mandatory_found}/{contract.mandatory_total}" if contract.mandatory_total > 0 else "0/0"
    blockers = [x.object_name for x in contract.object_status_summary if x.status in {"FAIL", "PARTIAL"}]
    blockers_text = ", ".join(blockers) if blockers else "none"

    yaml_block = dump_root_yaml("parsing_spec", contract.to_schema_dict())

    return (
        f"# {contract.item_id} ParsingSpec\n\n"
        f"Description: {contract.description or 'N/A'}\n"
        f"Check Module: {contract.check_module or 'N/A'}\n\n"
        "## Input Resolution\n"
        "Resolved inputs:\n"
        + resolved_inputs
        + "\n\nMissing inputs:\n"
        + missing_inputs
        + "\n\nResolution notes:\n"
        + "- ParsingSpec is generated only after ItemSpec is finalized.\n"
        + "- Runtime evidence collection starts in this stage.\n\n"
        + "## Evidence Inventory\n"
        + _md_table(
            ["Evidence ID", "Source File", "Line", "Pattern", "Extracted Values", "Raw Line", "Confidence"],
            evidence_rows,
        )
        + "\n\n## Referenced Files\n"
        + _md_table(
            ["Evidence ID", "Source File", "Line", "Pattern", "Extracted Values", "Raw Line"],
            referenced_rows,
        )
        + "\n\n## Evidence to Sub-Item Mapping\n"
        + _md_table(
            ["Evidence ID", "Object", "Sub-Item", "Required", "Mapping Status", "Rationale"],
            mapping_rows,
        )
        + "\n\n### Object Status Summary\n"
        + _md_table(
            ["Object", "mandatory_found", "mandatory_total", "status", "blocker_reason"],
            object_status_rows,
        )
        + "\n\n## Extraction Gaps\n"
        + "### Mandatory Missing Evidence\n"
        + _md_table(
            ["Object", "Sub-Item", "Gap Type", "Detail", "Suggested Resolution"],
            gap_rows,
        )
        + "\n\n### Conflicts and Ambiguities\n"
        + _md_table(
            ["Object", "Sub-Item", "Conflict Type", "Candidates", "Resolution Hint"],
            conflict_rows,
        )
        + "\n\n### Coverage Summary\n"
        + f"- mandatory_coverage_ratio: `{ratio}`\n"
        + f"- objects_with_blockers: `{blockers_text}`\n\n"
        + "## Embedded Schema\n```yaml\n"
        + yaml_block
        + "\n```\n"
    )


def render_format_spec(contract: FormatSpecContract) -> str:
    pattern_strategy = "\n".join([f"- {x}" for x in contract.pattern_strategy]) if contract.pattern_strategy else "- No explicit reusable pattern could be inferred."
    requirement_rows = [
        [
            r.requirement_id,
            r.object_name,
            f"`{r.sub_item}`",
            f"`{_sanitize_markdown_text(r.pattern)}`",
            r.comparator,
            ", ".join(r.source_evidence_ids) if r.source_evidence_ids else "-",
        ]
        for r in contract.requirement_items
    ]
    mapping_rows = [
        [
            f"`pattern_items[{x.index}]`",
            f"`{x.requirement_id}`",
            _sanitize_markdown_text(x.target),
        ]
        for x in contract.pattern_index_mapping
    ]
    waiver_items = "\n".join([f"- `{x}`" for x in contract.waiver_items]) if contract.waiver_items else "- `*`"
    waiver_taxonomy_rows = [
        [
            x.scenario,
            f"`{x.waiver_item}`",
            _sanitize_markdown_text(", ".join(x.keywords)),
            _sanitize_markdown_text(x.sample_reason),
        ]
        for x in contract.waiver_keyword_taxonomy
    ]

    scenario_texts: List[str] = []
    ordered = [("scenario_1", "Scenario 1 (req=N/A, waiver=N/A)"),
               ("scenario_2", "Scenario 2 (req=N/A, waiver>0)"),
               ("scenario_3", "Scenario 3 (req>0, waiver=N/A)"),
               ("scenario_4", "Scenario 4 (req>0, waiver>0)")]
    for key, title in ordered:
        cfg = contract.scenario_config.get(key)
        if cfg is None:
            continue
        lines = [
            f"### {title}",
            f"- found_desc: \"{cfg.found_desc}\"",
            f"- missing_desc: \"{cfg.missing_desc}\"",
        ]
        if cfg.waived_desc:
            lines.append(f"- waived_desc: \"{cfg.waived_desc}\"")
        if cfg.unused_desc:
            lines.append(f"- unused_desc: \"{cfg.unused_desc}\"")
        lines.extend([
            f"- found_reason: \"{cfg.found_reason}\"",
            f"- missing_reason: \"{cfg.missing_reason}\"",
        ])
        if cfg.waived_reason:
            lines.append(f"- waived_reason: \"{cfg.waived_reason}\"")
        if cfg.unused_reason:
            lines.append(f"- unused_reason: \"{cfg.unused_reason}\"")
        scenario_texts.append("\n".join(lines))
    scenario_block = "\n\n".join(scenario_texts)

    outcome_rows = [
        [
            o.scenario,
            o.requirements_value,
            o.waivers_value,
            _sanitize_markdown_text(o.decision_rule),
            o.expected_result_with_current_evidence,
        ]
        for o in contract.expected_outcomes
    ]
    required_waivers = ", ".join(contract.required_waivers_to_pass) if contract.required_waivers_to_pass else "none"
    preferred = contract.preferred_scenario or "N/A"

    yaml_block = dump_root_yaml("format_spec", contract.to_schema_dict())

    return (
        f"# {contract.item_id} FormatSpec\n\n"
        f"Description: {contract.description or 'N/A'}\n"
        f"Check Module: {contract.check_module or 'N/A'}\n"
        f"vio_name_format: \"{contract.vio_name_format}\"\n\n"
        "## Pattern Strategy\n"
        + pattern_strategy
        + "\n\n## Requirement Items\n"
        + _md_table(
            ["Requirement ID", "Object", "Sub-Item", "Pattern", "Comparator", "Source Evidence IDs"],
            requirement_rows,
        )
        + "\n\n## Pattern Index Mapping\n"
        + _md_table(
            ["Pattern Index", "Requirement ID", "Validation Target"],
            mapping_rows,
        )
        + "\n\n## Waiver Items\n"
        + waiver_items
        + "\n\n## Waiver Keyword Taxonomy\n"
        + _md_table(
            ["Scenario", "Waiver Item", "Keywords", "Sample Reason"],
            waiver_taxonomy_rows,
        )
        + "\n\n## Scenario Matrix\n"
        + scenario_block
        + "\n\n## Expected Outcomes\n"
        + _md_table(
            ["Scenario", "requirements.value", "waivers.value", "Decision Rule", "Expected Result with Current Evidence"],
            outcome_rows,
        )
        + "\n\nCurrent evidence recommendation:\n"
        + f"- Preferred scenario under current evidence: `{preferred}`\n"
        + f"- Required waiver items to PASS (if any): `{required_waivers}`\n\n"
        + "## Embedded Schema\n```yaml\n"
        + yaml_block
        + "\n```\n"
    )


def _default_decision_matrix() -> List[DecisionScenario]:
    return [
        DecisionScenario(
            scenario="S1",
            requirements_value="N/A",
            waivers_value="N/A",
            decision_rule="Semantic presence and consistency only, no waiver allowed.",
        ),
        DecisionScenario(
            scenario="S2",
            requirements_value="N/A",
            waivers_value=">0",
            decision_rule="Semantic presence and consistency; violations can be waived.",
        ),
        DecisionScenario(
            scenario="S3",
            requirements_value=">0",
            waivers_value="N/A",
            decision_rule="Requirement pattern matching without waiver.",
        ),
        DecisionScenario(
            scenario="S4",
            requirements_value=">0",
            waivers_value=">0",
            decision_rule="Requirement pattern matching with waiver handling.",
        ),
    ]
