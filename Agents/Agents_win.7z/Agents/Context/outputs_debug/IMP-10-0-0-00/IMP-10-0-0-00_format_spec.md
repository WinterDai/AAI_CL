# IMP-10-0-0-00 FormatSpec

Description: Confirm the netlist/spef version is correct.
Check Module: 10.0_STA_DCD_CHECK
vio_name_format: "item_name"

## Pattern Strategy
- `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` -> `*/dbs/*.v.gz`

## Requirement Items
| Requirement ID | Object | Sub-Item | Pattern | Comparator | Source Evidence IDs |
| --- | --- | --- | --- | --- | --- |
| R1 | netlist | `status` | `(?i).*netlist.*` | regex | EV3, EV4 |
| R2 | netlist | `source_reference` | `*/logs/*.log:7` | glob | DV1 |
| R3 | netlist | `file_path` | `*/dbs/*.v.gz` | glob | EV1, EV2 |
| R4 | netlist | `file_name` | `phy_cmn_phase_align_digtop.v.gz` | exact | DV2 |
| R5 | netlist | `version_token` | `<version_token>` | regex | - |
| R6 | netlist | `design_name` | `phy_cmn_phase_align_digtop` | exact | EV5 |
| R7 | spef | `status` | `we are writing post-synthesis SDF files` | exact | EV6, EV7 |
| R8 | spef | `source_reference` | `*/logs/*.log:24` | glob | DV3 |
| R9 | spef | `file_path` | `*.spef*` | glob | - |
| R10 | spef | `file_name` | `*.spef*` | glob | - |
| R11 | spef | `version_token` | `<version_token>` | regex | - |
| R12 | spef | `design_name` | `<design_name>` | regex | - |

## Pattern Index Mapping
| Pattern Index | Requirement ID | Validation Target |
| --- | --- | --- |
| `pattern_items[0]` | `R1` | netlist.status |
| `pattern_items[1]` | `R2` | netlist.source_reference |
| `pattern_items[2]` | `R3` | netlist.file_path |
| `pattern_items[3]` | `R4` | netlist.file_name |
| `pattern_items[4]` | `R5` | netlist.version_token |
| `pattern_items[5]` | `R6` | netlist.design_name |
| `pattern_items[6]` | `R7` | spef.status |
| `pattern_items[7]` | `R8` | spef.source_reference |
| `pattern_items[8]` | `R9` | spef.file_path |
| `pattern_items[9]` | `R10` | spef.file_name |
| `pattern_items[10]` | `R11` | spef.version_token |
| `pattern_items[11]` | `R12` | spef.design_name |

## Waiver Items
- `netlist:*`
- `spef:*`

## Waiver Keyword Taxonomy
| Scenario | Waiver Item | Keywords | Sample Reason |
| --- | --- | --- | --- |
| object_missing_1 | `netlist:*` | netlist, waive, exception, approved, configured_waiver | netlist mismatch accepted by stage-specific design review. |
| object_missing_2 | `spef:*` | spef, waive, exception, approved, configured_waiver | spef mismatch accepted by stage-specific design review. |

## Scenario Matrix
### Scenario 1 (req=N/A, waiver=N/A)
- found_desc: "Required evidence extracted and semantically valid"
- missing_desc: "Required evidence missing or semantically invalid"
- found_reason: "Parsing evidence supports checker intent"
- missing_reason: "Parsing evidence does not satisfy checker intent"

### Scenario 2 (req=N/A, waiver>0)
- found_desc: "Required evidence extracted and semantically valid"
- missing_desc: "Required evidence missing or semantically invalid"
- waived_desc: "Violation waived by configured waiver items"
- unused_desc: "Unused waiver entries"
- found_reason: "Parsing evidence supports checker intent"
- missing_reason: "Parsing evidence does not satisfy checker intent"
- waived_reason: "Waiver item matched violation context"
- unused_reason: "Waiver item has no matching violation"

### Scenario 3 (req>0, waiver=N/A)
- found_desc: "Requirement pattern items matched"
- missing_desc: "Requirement pattern items not matched"
- found_reason: "All required pattern comparisons satisfied"
- missing_reason: "At least one required pattern comparison failed"

### Scenario 4 (req>0, waiver>0)
- found_desc: "Requirement pattern items matched"
- missing_desc: "Requirement pattern items not matched"
- waived_desc: "Violation waived by configured waiver items"
- unused_desc: "Unused waiver entries"
- found_reason: "All required pattern comparisons satisfied"
- missing_reason: "At least one required pattern comparison failed"
- waived_reason: "Waiver item matched violation context"
- unused_reason: "Waiver item has no matching violation"

## Expected Outcomes
| Scenario | requirements.value | waivers.value | Decision Rule | Expected Result with Current Evidence |
| --- | --- | --- | --- | --- |
| S1 | N/A | N/A | Missing mandatory evidence -> FAIL | FAIL |
| S2 | N/A | >0 | Mandatory miss can be waived | PASS |
| S3 | >0 | N/A | Required pattern mismatch -> FAIL | FAIL |
| S4 | >0 | >0 | Pattern mismatch can be waived | PASS |

Current evidence recommendation:
- Preferred scenario under current evidence: `S2`
- Required waiver items to PASS (if any): `netlist:*, spef:*`

## Embedded Schema
```yaml
format_spec:
  item_id: IMP-10-0-0-00
  description: Confirm the netlist/spef version is correct.
  check_module: 10.0_STA_DCD_CHECK
  vio_name_format: item_name
  stage_boundary:
    reads_input_files: true
    depends_on_itemspec: true
    depends_on_parsing_spec: true
  requirement_items:
  - requirement_id: R1
    object: netlist
    sub_item: status
    pattern: (?i).*netlist.*
    comparator: regex
    source_evidence_ids:
    - EV3
    - EV4
  - requirement_id: R2
    object: netlist
    sub_item: source_reference
    pattern: '*/logs/*.log:7'
    comparator: glob
    source_evidence_ids:
    - DV1
  - requirement_id: R3
    object: netlist
    sub_item: file_path
    pattern: '*/dbs/*.v.gz'
    comparator: glob
    source_evidence_ids:
    - EV1
    - EV2
  - requirement_id: R4
    object: netlist
    sub_item: file_name
    pattern: phy_cmn_phase_align_digtop.v.gz
    comparator: exact
    source_evidence_ids:
    - DV2
  - requirement_id: R5
    object: netlist
    sub_item: version_token
    pattern: <version_token>
    comparator: regex
    source_evidence_ids: []
  - requirement_id: R6
    object: netlist
    sub_item: design_name
    pattern: phy_cmn_phase_align_digtop
    comparator: exact
    source_evidence_ids:
    - EV5
  - requirement_id: R7
    object: spef
    sub_item: status
    pattern: we are writing post-synthesis SDF files
    comparator: exact
    source_evidence_ids:
    - EV6
    - EV7
  - requirement_id: R8
    object: spef
    sub_item: source_reference
    pattern: '*/logs/*.log:24'
    comparator: glob
    source_evidence_ids:
    - DV3
  - requirement_id: R9
    object: spef
    sub_item: file_path
    pattern: '*.spef*'
    comparator: glob
    source_evidence_ids: []
  - requirement_id: R10
    object: spef
    sub_item: file_name
    pattern: '*.spef*'
    comparator: glob
    source_evidence_ids: []
  - requirement_id: R11
    object: spef
    sub_item: version_token
    pattern: <version_token>
    comparator: regex
    source_evidence_ids: []
  - requirement_id: R12
    object: spef
    sub_item: design_name
    pattern: <design_name>
    comparator: regex
    source_evidence_ids: []
  pattern_index_mapping:
  - index: 0
    requirement_id: R1
    target: netlist.status
  - index: 1
    requirement_id: R2
    target: netlist.source_reference
  - index: 2
    requirement_id: R3
    target: netlist.file_path
  - index: 3
    requirement_id: R4
    target: netlist.file_name
  - index: 4
    requirement_id: R5
    target: netlist.version_token
  - index: 5
    requirement_id: R6
    target: netlist.design_name
  - index: 6
    requirement_id: R7
    target: spef.status
  - index: 7
    requirement_id: R8
    target: spef.source_reference
  - index: 8
    requirement_id: R9
    target: spef.file_path
  - index: 9
    requirement_id: R10
    target: spef.file_name
  - index: 10
    requirement_id: R11
    target: spef.version_token
  - index: 11
    requirement_id: R12
    target: spef.design_name
  waiver_items:
  - netlist:*
  - spef:*
  waiver_keyword_taxonomy:
  - scenario: object_missing_1
    waiver_item: netlist:*
    keywords:
    - netlist
    - waive
    - exception
    - approved
    - configured_waiver
    sample_reason: netlist mismatch accepted by stage-specific design review.
  - scenario: object_missing_2
    waiver_item: spef:*
    keywords:
    - spef
    - waive
    - exception
    - approved
    - configured_waiver
    sample_reason: spef mismatch accepted by stage-specific design review.
  scenario_config:
    scenario_1:
      found_desc: Required evidence extracted and semantically valid
      missing_desc: Required evidence missing or semantically invalid
      found_reason: Parsing evidence supports checker intent
      missing_reason: Parsing evidence does not satisfy checker intent
    scenario_2:
      found_desc: Required evidence extracted and semantically valid
      missing_desc: Required evidence missing or semantically invalid
      found_reason: Parsing evidence supports checker intent
      missing_reason: Parsing evidence does not satisfy checker intent
      waived_desc: Violation waived by configured waiver items
      unused_desc: Unused waiver entries
      waived_reason: Waiver item matched violation context
      unused_reason: Waiver item has no matching violation
    scenario_3:
      found_desc: Requirement pattern items matched
      missing_desc: Requirement pattern items not matched
      found_reason: All required pattern comparisons satisfied
      missing_reason: At least one required pattern comparison failed
    scenario_4:
      found_desc: Requirement pattern items matched
      missing_desc: Requirement pattern items not matched
      found_reason: All required pattern comparisons satisfied
      missing_reason: At least one required pattern comparison failed
      waived_desc: Violation waived by configured waiver items
      unused_desc: Unused waiver entries
      waived_reason: Waiver item matched violation context
      unused_reason: Waiver item has no matching violation
  expected_outcomes:
  - scenario: S1
    requirements_value: N/A
    waivers_value: N/A
    decision_rule: Missing mandatory evidence -> FAIL
    expected_result_with_current_evidence: FAIL
  - scenario: S2
    requirements_value: N/A
    waivers_value: '>0'
    decision_rule: Mandatory miss can be waived
    expected_result_with_current_evidence: PASS
  - scenario: S3
    requirements_value: '>0'
    waivers_value: N/A
    decision_rule: Required pattern mismatch -> FAIL
    expected_result_with_current_evidence: FAIL
  - scenario: S4
    requirements_value: '>0'
    waivers_value: '>0'
    decision_rule: Pattern mismatch can be waived
    expected_result_with_current_evidence: PASS
  current_evidence_recommendation:
    preferred_scenario: S2
    required_waivers_to_pass:
    - netlist:*
    - spef:*
```
