# IMP-10-0-0-00 ParsingSpec

Description: Confirm the netlist/spef version is correct.
Check Module: 10.0_STA_DCD_CHECK

## Input Resolution
Resolved inputs:
- C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log

Missing inputs:
- (none)

Resolution notes:
- ParsingSpec is generated only after ItemSpec is finalized.
- Runtime evidence collection starts in this stage.

## Evidence Inventory
| Evidence ID | Source File | Line | Pattern | Extracted Values | Raw Line | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| EV1 | C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 7 | `read_netlist\s+([^\s]+\.v(?:\.gz)?)` | `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | 1.00 |
| EV2 | C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 7 | `read_netlist\s+([^\s]+)` | `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | 1.00 |
| EV3 | C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 8 | `\bnetlist\b` | `[INFO] Reading netlist file...` | `[INFO] Reading netlist file...` | 1.00 |
| EV4 | C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 11 | `\bnetlist\b` | `[INFO] Decompressing and parsing netlist...` | `[INFO] Decompressing and parsing netlist...` | 1.00 |
| EV5 | C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 14 | `Top level cell is\s+(\S+)` | `phy_cmn_phase_align_digtop.` | `Top level cell is phy_cmn_phase_align_digtop.` | 1.00 |
| EV6 | C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 24 | `\[INFO\]\s+Skipping SPEF reading as (.+)` | `we are writing post-synthesis SDF files` | `[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files` | 1.00 |
| EV7 | C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 24 | `Skipping SPEF reading as\s+(.+)` | `we are writing post-synthesis SDF files` | `[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files` | 1.00 |
| DV1 | C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 7 | `<derived:source_reference>` | `C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log:7` | `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | 0.95 |
| DV2 | C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 7 | `<derived:file_name_from_file_path>` | `phy_cmn_phase_align_digtop.v.gz` | `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | 0.95 |
| DV3 | C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 24 | `<derived:source_reference>` | `C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log:24` | `[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files` | 0.95 |

## Referenced Files
| Evidence ID | Source File | Line | Pattern | Extracted Values | Raw Line |
| --- | --- | --- | --- | --- | --- |

## Evidence to Sub-Item Mapping
| Evidence ID | Object | Sub-Item | Required | Mapping Status | Rationale |
| --- | --- | --- | --- | --- | --- |
| EV1 | netlist | `file_path` | true | mapped | Object mapped by lexical match: `netlist`. Sub-item mapped by pattern semantics: `file_path`. |
| EV2 | netlist | `file_path` | true | mapped | Object mapped by lexical match: `netlist`. Sub-item mapped by pattern semantics: `file_path`. |
| EV3 | netlist | `status` | true | mapped | Object mapped by lexical match: `netlist`. Sub-item mapped by pattern semantics: `status`. |
| EV4 | netlist | `status` | true | mapped | Object mapped by lexical match: `netlist`. Sub-item mapped by pattern semantics: `status`. |
| EV5 | netlist | `design_name` | true | mapped_with_fallback | Object fallback applied: `netlist` selected as default. Sub-item mapped by pattern semantics: `design_name`. |
| EV6 | spef | `status` | true | mapped | Object mapped by lexical match: `spef`. Sub-item mapped by pattern semantics: `status`. |
| EV7 | spef | `status` | true | mapped | Object mapped by lexical match: `spef`. Sub-item mapped by pattern semantics: `status`. |
| DV1 | netlist | `source_reference` | true | mapped_derived | Derived source_reference from first mapped evidence source and line. |
| DV2 | netlist | `file_name` | true | mapped_derived | Derived file_name from mapped file_path evidence. |
| DV3 | spef | `source_reference` | true | mapped_derived | Derived source_reference from first mapped evidence source and line. |

### Object Status Summary
| Object | mandatory_found | mandatory_total | status | blocker_reason |
| --- | --- | --- | --- | --- |
| netlist | 5 | 6 | PARTIAL | Missing mandatory sub-items: version_token |
| spef | 2 | 6 | PARTIAL | Missing mandatory sub-items: file_path, file_name, version_token, design_name |

## Extraction Gaps
### Mandatory Missing Evidence
| Object | Sub-Item | Gap Type | Detail | Suggested Resolution |
| --- | --- | --- | --- | --- |
| netlist | `version_token` | mandatory_missing | No mapped evidence for mandatory sub-item `version_token`. | Provide waiver `netlist:*` or add valid evidence. |
| spef | `file_path` | mandatory_missing | No mapped evidence for mandatory sub-item `file_path`. | Provide waiver `spef:*` or add valid evidence. |
| spef | `file_name` | mandatory_missing | No mapped evidence for mandatory sub-item `file_name`. | Provide waiver `spef:*` or add valid evidence. |
| spef | `version_token` | mandatory_missing | No mapped evidence for mandatory sub-item `version_token`. | Provide waiver `spef:*` or add valid evidence. |
| spef | `design_name` | mandatory_missing | No mapped evidence for mandatory sub-item `design_name`. | Provide waiver `spef:*` or add valid evidence. |

### Conflicts and Ambiguities
| Object | Sub-Item | Conflict Type | Candidates | Resolution Hint |
| --- | --- | --- | --- | --- |
| netlist | `status` | conflicting_values | [INFO] Decompressing and parsing netlist..., [INFO] Reading netlist file... | Prefer value from highest-priority source or earliest explicit command. |

### Coverage Summary
- mandatory_coverage_ratio: `7/12`
- objects_with_blockers: `netlist, spef`

## Embedded Schema
```yaml
parsing_spec:
  item_id: IMP-10-0-0-00
  description: Confirm the netlist/spef version is correct.
  check_module: 10.0_STA_DCD_CHECK
  stage_boundary:
    reads_input_files: true
    depends_on_itemspec: true
  resolved_inputs:
  - C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log
  missing_inputs: []
  evidence_records:
  - evidence_id: EV1
    source_file: C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log
    line_number: 7
    pattern: read_netlist\s+([^\s]+\.v(?:\.gz)?)
    extracted_value: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    raw_line: <CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    confidence: 1.0
  - evidence_id: EV2
    source_file: C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log
    line_number: 7
    pattern: read_netlist\s+([^\s]+)
    extracted_value: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    raw_line: <CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    confidence: 1.0
  - evidence_id: EV3
    source_file: C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log
    line_number: 8
    pattern: \bnetlist\b
    extracted_value: '[INFO] Reading netlist file...'
    raw_line: '[INFO] Reading netlist file...'
    confidence: 1.0
  - evidence_id: EV4
    source_file: C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log
    line_number: 11
    pattern: \bnetlist\b
    extracted_value: '[INFO] Decompressing and parsing netlist...'
    raw_line: '[INFO] Decompressing and parsing netlist...'
    confidence: 1.0
  - evidence_id: EV5
    source_file: C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log
    line_number: 14
    pattern: Top level cell is\s+(\S+)
    extracted_value: phy_cmn_phase_align_digtop.
    raw_line: Top level cell is phy_cmn_phase_align_digtop.
    confidence: 1.0
  - evidence_id: EV6
    source_file: C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log
    line_number: 24
    pattern: \[INFO\]\s+Skipping SPEF reading as (.+)
    extracted_value: we are writing post-synthesis SDF files
    raw_line: '[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files'
    confidence: 1.0
  - evidence_id: EV7
    source_file: C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log
    line_number: 24
    pattern: Skipping SPEF reading as\s+(.+)
    extracted_value: we are writing post-synthesis SDF files
    raw_line: '[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files'
    confidence: 1.0
  - evidence_id: DV1
    source_file: C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log
    line_number: 7
    pattern: <derived:source_reference>
    extracted_value: C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log:7
    raw_line: <CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    confidence: 0.95
  - evidence_id: DV2
    source_file: C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log
    line_number: 7
    pattern: <derived:file_name_from_file_path>
    extracted_value: phy_cmn_phase_align_digtop.v.gz
    raw_line: <CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    confidence: 0.95
  - evidence_id: DV3
    source_file: C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log
    line_number: 24
    pattern: <derived:source_reference>
    extracted_value: C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log:24
    raw_line: '[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files'
    confidence: 0.95
  referenced_file_records: []
  evidence_to_sub_item:
  - evidence_id: EV1
    object: netlist
    sub_item: file_path
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `netlist`. Sub-item mapped by pattern
      semantics: `file_path`.'
  - evidence_id: EV2
    object: netlist
    sub_item: file_path
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `netlist`. Sub-item mapped by pattern
      semantics: `file_path`.'
  - evidence_id: EV3
    object: netlist
    sub_item: status
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `netlist`. Sub-item mapped by pattern
      semantics: `status`.'
  - evidence_id: EV4
    object: netlist
    sub_item: status
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `netlist`. Sub-item mapped by pattern
      semantics: `status`.'
  - evidence_id: EV5
    object: netlist
    sub_item: design_name
    required: true
    mapping_status: mapped_with_fallback
    rationale: 'Object fallback applied: `netlist` selected as default. Sub-item mapped
      by pattern semantics: `design_name`.'
  - evidence_id: EV6
    object: spef
    sub_item: status
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `spef`. Sub-item mapped by pattern
      semantics: `status`.'
  - evidence_id: EV7
    object: spef
    sub_item: status
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `spef`. Sub-item mapped by pattern
      semantics: `status`.'
  - evidence_id: DV1
    object: netlist
    sub_item: source_reference
    required: true
    mapping_status: mapped_derived
    rationale: Derived source_reference from first mapped evidence source and line.
  - evidence_id: DV2
    object: netlist
    sub_item: file_name
    required: true
    mapping_status: mapped_derived
    rationale: Derived file_name from mapped file_path evidence.
  - evidence_id: DV3
    object: spef
    sub_item: source_reference
    required: true
    mapping_status: mapped_derived
    rationale: Derived source_reference from first mapped evidence source and line.
  object_status_summary:
  - object: netlist
    mandatory_found: 5
    mandatory_total: 6
    status: PARTIAL
    blocker_reason: 'Missing mandatory sub-items: version_token'
  - object: spef
    mandatory_found: 2
    mandatory_total: 6
    status: PARTIAL
    blocker_reason: 'Missing mandatory sub-items: file_path, file_name, version_token,
      design_name'
  extraction_gaps:
  - object: netlist
    sub_item: version_token
    gap_type: mandatory_missing
    detail: No mapped evidence for mandatory sub-item `version_token`.
    suggested_resolution: Provide waiver `netlist:*` or add valid evidence.
  - object: spef
    sub_item: file_path
    gap_type: mandatory_missing
    detail: No mapped evidence for mandatory sub-item `file_path`.
    suggested_resolution: Provide waiver `spef:*` or add valid evidence.
  - object: spef
    sub_item: file_name
    gap_type: mandatory_missing
    detail: No mapped evidence for mandatory sub-item `file_name`.
    suggested_resolution: Provide waiver `spef:*` or add valid evidence.
  - object: spef
    sub_item: version_token
    gap_type: mandatory_missing
    detail: No mapped evidence for mandatory sub-item `version_token`.
    suggested_resolution: Provide waiver `spef:*` or add valid evidence.
  - object: spef
    sub_item: design_name
    gap_type: mandatory_missing
    detail: No mapped evidence for mandatory sub-item `design_name`.
    suggested_resolution: Provide waiver `spef:*` or add valid evidence.
  conflicts:
  - object: netlist
    sub_item: status
    conflict_type: conflicting_values
    candidates:
    - '[INFO] Decompressing and parsing netlist...'
    - '[INFO] Reading netlist file...'
    resolution_hint: Prefer value from highest-priority source or earliest explicit
      command.
  coverage_summary:
    mandatory_found: 7
    mandatory_total: 12
    mandatory_coverage_ratio: 7/12
```
