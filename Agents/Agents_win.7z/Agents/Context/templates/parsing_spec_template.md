# <ITEM_ID> ParsingSpec

Description: <DESCRIPTION>
Check Module: <CHECK_MODULE>

## Input Resolution
Resolved inputs:
- <absolute_path_to_primary_log>

Missing inputs:
- (none)

Resolution notes:
- ParsingSpec is generated only after ItemSpec is finalized.
- Runtime evidence collection starts in this stage.

## Evidence Inventory
| Evidence ID | Source File | Line | Pattern | Extracted Values | Raw Line | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| EV1 | <absolute_path> | <line_number> | `<regex_or_rule>` | `<value_or_values>` | `<raw_line_text>` | <0.0_to_1.0> |

## Referenced Files
| Evidence ID | Source File | Line | Pattern | Extracted Values | Raw Line |
| --- | --- | --- | --- | --- | --- |
| RF1 | <referenced_file_path> | <line_number> | `<regex_or_rule>` | `<value_or_values>` | `<raw_line_text>` |

## Evidence to Sub-Item Mapping
| Evidence ID | Object | Sub-Item | Required | Mapping Status | Rationale |
| --- | --- | --- | --- | --- | --- |
| EV1 | <object_1> | `file_path` | true | mapped | Path evidence from object load command. |

### Object Status Summary
| Object | mandatory_found | mandatory_total | status | blocker_reason |
| --- | --- | --- | --- | --- |
| <object_1> | <n> | <m> | <PASS|FAIL|PARTIAL> | <reason_or_none> |
| <object_2> | <n> | <m> | <PASS|FAIL|PARTIAL> | <reason_or_none> |

## Extraction Gaps
### Mandatory Missing Evidence
| Object | Sub-Item | Gap Type | Detail | Suggested Resolution |
| --- | --- | --- | --- | --- |
| <object_2> | `file_path` | object_missing | No object load evidence found. | Provide waiver `<object_2>:*` or supply runtime artifact. |

### Conflicts and Ambiguities
| Object | Sub-Item | Conflict Type | Candidates | Resolution Hint |
| --- | --- | --- | --- | --- |
| <object_1> | `version_token` | conflicting_values | `<value_a>`, `<value_b>` | Prefer value from highest-priority source. |

### Coverage Summary
- mandatory_coverage_ratio: `<found>/<total>`
- objects_with_blockers: `<comma_separated_objects_or_none>`

## Embedded Schema
```yaml
parsing_spec:
  item_id: "<ITEM_ID>"
  description: "<DESCRIPTION>"
  check_module: "<CHECK_MODULE>"
  stage_boundary:
    reads_input_files: true
    depends_on_itemspec: true
  resolved_inputs:
    - "<absolute_path_to_primary_log>"
  missing_inputs: []
  evidence_records:
    - evidence_id: "EV1"
      source_file: "<absolute_path>"
      line_number: <line_number>
      pattern: "<regex_or_rule>"
      extracted_value: "<scalar_or_joined_values>"
      raw_line: "<raw_line_text>"
      confidence: <0.0_to_1.0>
  referenced_file_records:
    - evidence_id: "RF1"
      source_file: "<referenced_file_path>"
      line_number: <line_number>
      pattern: "<regex_or_rule>"
      extracted_value: "<scalar_or_joined_values>"
      raw_line: "<raw_line_text>"
  evidence_to_sub_item:
    - evidence_id: "EV1"
      object: "<object_1>"
      sub_item: "file_path"
      required: true
      mapping_status: "mapped"
      rationale: "Path evidence from object load command."
  object_status_summary:
    - object: "<object_1>"
      mandatory_found: <n>
      mandatory_total: <m>
      status: "<PASS|FAIL|PARTIAL>"
      blocker_reason: "<reason_or_none>"
    - object: "<object_2>"
      mandatory_found: <n>
      mandatory_total: <m>
      status: "<PASS|FAIL|PARTIAL>"
      blocker_reason: "<reason_or_none>"
  extraction_gaps:
    - object: "<object_2>"
      sub_item: "file_path"
      gap_type: "object_missing"
      detail: "No object load evidence found."
      suggested_resolution: "Provide waiver '<object_2>:*' or supply runtime artifact."
  conflicts:
    - object: "<object_1>"
      sub_item: "version_token"
      conflict_type: "conflicting_values"
      candidates:
        - "<value_a>"
        - "<value_b>"
      resolution_hint: "Prefer value from highest-priority source."
  coverage_summary:
    mandatory_found: <found>
    mandatory_total: <total>
    mandatory_coverage_ratio: "<found>/<total>"
```
