# <ITEM_ID> FormatSpec

Description: <DESCRIPTION>
Check Module: <CHECK_MODULE>
vio_name_format: "item_name"

## Pattern Strategy
- `<raw evidence value A>` -> `<normalized pattern A>`
- `<raw evidence value B>` -> `<normalized pattern B>`
- Normalize only after traceability to `evidence_id` is confirmed.

## Requirement Items
| Requirement ID | Object | Sub-Item | Pattern | Comparator | Source Evidence IDs |
| --- | --- | --- | --- | --- | --- |
| R1 | <object_1> | `file_path` | `*/dbs/*.v.gz` | glob | EV1 |
| R2 | <object_1> | `version_token` | `<version_token>` | regex | EV2 |
| R3 | <object_2> | `file_path` | `*.spef*` | glob | EV10 |

## Pattern Index Mapping
- `pattern_items[0]` -> `R1 (<object_1>.file_path)`
- `pattern_items[1]` -> `R2 (<object_1>.version_token)`
- `pattern_items[2]` -> `R3 (<object_2>.file_path)`

## Waiver Items
- `<object_1>:*`
- `<object_2>:*`
- `<object_1>:<sub_item>`
- `<object_2>:<sub_item>`

## Waiver Keyword Taxonomy
| Scenario | Waiver Item | Keywords | Sample Reason |
| --- | --- | --- | --- |
| object_missing | `<object_2>:*` | `<object_2>, missing, waived, stage, approved` | "<object_2> is not produced in this stage; waiver approved by project policy." |
| field_exception | `<object_1>:version_token` | `version, mismatch, approved, temporary` | "Known version token exception approved for transition window." |
| configured_object_waiver | `<object_1>:*` | `configured_waiver, item_yaml` | "Configured object-level waiver provided by item yaml." |

## Scenario Matrix
### Scenario 1 (req=N/A, waiver=N/A)
- found_desc: "Required evidence extracted and semantically valid."
- missing_desc: "Required evidence missing or semantically invalid."
- found_reason: "Parsing evidence supports checker intent."
- missing_reason: "Parsing evidence does not satisfy checker intent."

### Scenario 2 (req=N/A, waiver>0)
- found_desc: "Required evidence extracted and semantically valid."
- missing_desc: "Required evidence missing or semantically invalid."
- waived_desc: "Violation waived by configured waiver items."
- unused_desc: "Unused waiver entries."
- found_reason: "Parsing evidence supports checker intent."
- missing_reason: "Parsing evidence does not satisfy checker intent."
- waived_reason: "Waiver item matched violation context."
- unused_reason: "Waiver item has no matching violation."

### Scenario 3 (req>0, waiver=N/A)
- found_desc: "Requirement pattern items matched."
- missing_desc: "Requirement pattern items not matched."
- found_reason: "All required pattern comparisons satisfied."
- missing_reason: "At least one required pattern comparison failed."

### Scenario 4 (req>0, waiver>0)
- found_desc: "Requirement pattern items matched."
- missing_desc: "Requirement pattern items not matched."
- waived_desc: "Violation waived by configured waiver items."
- unused_desc: "Unused waiver entries."
- found_reason: "All required pattern comparisons satisfied."
- missing_reason: "At least one required pattern comparison failed."
- waived_reason: "Waiver item matched violation context."
- unused_reason: "Waiver item has no matching violation."

## Expected Outcomes
| Scenario | requirements.value | waivers.value | Decision Rule | Expected Result with Current Evidence |
| --- | --- | --- | --- | --- |
| S1 | N/A | N/A | Any mandatory semantic miss -> FAIL | <PASS_OR_FAIL> |
| S2 | N/A | >0 | Mandatory miss can be waived if waiver matches | <PASS_OR_FAIL> |
| S3 | >0 | N/A | Any requirement pattern mismatch -> FAIL | <PASS_OR_FAIL> |
| S4 | >0 | >0 | Pattern mismatch can be waived if waiver matches | <PASS_OR_FAIL> |

Current evidence recommendation:
- Preferred scenario under current evidence: `<S1|S2|S3|S4>`
- Required waiver items to PASS (if any): `<comma_separated_items_or_none>`

## Embedded Schema
```yaml
format_spec:
  item_id: "<ITEM_ID>"
  description: "<DESCRIPTION>"
  check_module: "<CHECK_MODULE>"
  vio_name_format: "item_name"
  stage_boundary:
    reads_input_files: true
    depends_on_itemspec: true
    depends_on_parsing_spec: true
  requirement_items:
    - requirement_id: "R1"
      object: "<object_1>"
      sub_item: "file_path"
      pattern: "*/dbs/*.v.gz"
      comparator: "glob"
      source_evidence_ids:
        - "EV1"
    - requirement_id: "R2"
      object: "<object_1>"
      sub_item: "version_token"
      pattern: "<version_token>"
      comparator: "regex"
      source_evidence_ids:
        - "EV2"
    - requirement_id: "R3"
      object: "<object_2>"
      sub_item: "file_path"
      pattern: "*.spef*"
      comparator: "glob"
      source_evidence_ids:
        - "EV10"
  pattern_index_mapping:
    - index: 0
      requirement_id: "R1"
      target: "<object_1>.file_path"
    - index: 1
      requirement_id: "R2"
      target: "<object_1>.version_token"
    - index: 2
      requirement_id: "R3"
      target: "<object_2>.file_path"
  waiver_items:
    - "<object_1>:*"
    - "<object_2>:*"
    - "<object_1>:<sub_item>"
    - "<object_2>:<sub_item>"
  waiver_keyword_taxonomy:
    - scenario: "object_missing"
      waiver_item: "<object_2>:*"
      keywords:
        - "<object_2>"
        - "missing"
        - "waived"
      sample_reason: "<object_2> is not produced in this stage; waiver approved by project policy."
    - scenario: "field_exception"
      waiver_item: "<object_1>:version_token"
      keywords:
        - "version"
        - "mismatch"
        - "approved"
      sample_reason: "Known version token exception approved for transition window."
  scenario_config:
    scenario_1:
      found_desc: "Required evidence extracted and semantically valid."
      missing_desc: "Required evidence missing or semantically invalid."
      found_reason: "Parsing evidence supports checker intent."
      missing_reason: "Parsing evidence does not satisfy checker intent."
    scenario_2:
      found_desc: "Required evidence extracted and semantically valid."
      missing_desc: "Required evidence missing or semantically invalid."
      waived_desc: "Violation waived by configured waiver items."
      unused_desc: "Unused waiver entries."
      found_reason: "Parsing evidence supports checker intent."
      missing_reason: "Parsing evidence does not satisfy checker intent."
      waived_reason: "Waiver item matched violation context."
      unused_reason: "Waiver item has no matching violation."
    scenario_3:
      found_desc: "Requirement pattern items matched."
      missing_desc: "Requirement pattern items not matched."
      found_reason: "All required pattern comparisons satisfied."
      missing_reason: "At least one required pattern comparison failed."
    scenario_4:
      found_desc: "Requirement pattern items matched."
      missing_desc: "Requirement pattern items not matched."
      waived_desc: "Violation waived by configured waiver items."
      unused_desc: "Unused waiver entries."
      found_reason: "All required pattern comparisons satisfied."
      missing_reason: "At least one required pattern comparison failed."
      waived_reason: "Waiver item matched violation context."
      unused_reason: "Waiver item has no matching violation."
  expected_outcomes:
    - scenario: "S1"
      requirements_value: "N/A"
      waivers_value: "N/A"
      decision_rule: "Any mandatory semantic miss -> FAIL"
      expected_result_with_current_evidence: "<PASS_OR_FAIL>"
    - scenario: "S2"
      requirements_value: "N/A"
      waivers_value: ">0"
      decision_rule: "Mandatory miss can be waived if waiver matches"
      expected_result_with_current_evidence: "<PASS_OR_FAIL>"
    - scenario: "S3"
      requirements_value: ">0"
      waivers_value: "N/A"
      decision_rule: "Any requirement pattern mismatch -> FAIL"
      expected_result_with_current_evidence: "<PASS_OR_FAIL>"
    - scenario: "S4"
      requirements_value: ">0"
      waivers_value: ">0"
      decision_rule: "Pattern mismatch can be waived if waiver matches"
      expected_result_with_current_evidence: "<PASS_OR_FAIL>"
```
