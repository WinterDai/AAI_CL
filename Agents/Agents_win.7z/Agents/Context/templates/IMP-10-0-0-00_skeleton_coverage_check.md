# IMP-10-0-0-00 Skeleton Coverage Check

This document verifies that the new skeletons preserve all critical information categories from the old implementation:

- `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Work/IMP_10_0_0_00_DryRun/itemspec.md`
- `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Work/IMP_10_0_0_00_DryRun/parsing_spec.md`
- `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Work/IMP_10_0_0_00_DryRun/format_spec.md`

Target skeletons:

- `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Context/templates/itemspec_template.md`
- `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Context/templates/parsing_spec_template.md`
- `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Context/templates/format_spec_template.md`

## Coverage Matrix: Old ItemSpec -> New Skeleton

| Old ItemSpec Content | Old Reference | New Skeleton Coverage | New Reference | Status |
| --- | --- | --- | --- | --- |
| Item metadata (ID, description) | itemspec.md:1, itemspec.md:3 | Title + metadata lines retained | itemspec_template.md:1, itemspec_template.md:3 | Covered |
| Expert semantic decomposition (existence/consistency/version/time) | itemspec.md:9-13 | Semantic axes explicitly retained | itemspec_template.md:19-23 | Covered |
| Data source priority model | itemspec.md:21-25 | Data source priority table retained | itemspec_template.md:76-81 | Covered |
| Netlist object contract fields | itemspec.md:33-38 | Object/Sub-Item Contract table retained | itemspec_template.md:36-41 | Covered |
| SPEF object contract fields | itemspec.md:44-49 | Object/Sub-Item Contract table retained | itemspec_template.md:42-47 | Covered |
| Mandatory missing -> error semantics | itemspec.md:53 | Check criteria retains mandatory miss fail rule | itemspec_template.md:63 | Covered |
| Missing object requires waiver semantics | itemspec.md:54 | Waiver scope + check criteria retained | itemspec_template.md:54-58, itemspec_template.md:63-64 | Covered |
| Requirement list structure by object | itemspec.md:62-68 | Requirement/waiver scenario boundary retained in decision matrix + schema | itemspec_template.md:66-72, itemspec_template.md:186-198 | Covered |
| Cross-object consistency (`design_name` equality) | itemspec.md:72 | Explicit cross-object consistency rule retained | itemspec_template.md:49-52, itemspec_template.md:175-182 | Covered |
| Waiver granularity (`object:*`, `object:sub_item`) | itemspec.md:80-83 | Waiver scope contract retained | itemspec_template.md:54-58, itemspec_template.md:183-185 | Covered |
| Typical waiver examples (post-synthesis/header unavailable) | itemspec.md:87-90 | Captured via waiver model + downstream taxonomy in FormatSpec skeleton | itemspec_template.md:54-58, format_spec_template.md:30-35 | Covered |
| Requirement/Waiver result combinations | itemspec.md:96-117 | Retained as decision matrix in ItemSpec and detailed expected outcomes in FormatSpec | itemspec_template.md:66-72, format_spec_template.md:70-76 | Covered |
| Current scenario recommendation | itemspec.md:118-123 | Retained in FormatSpec recommendation area | format_spec_template.md:78-80 | Covered |

## Coverage Matrix: Old ParsingSpec -> New Skeleton

| Old ParsingSpec Content | Old Reference | New Skeleton Coverage | New Reference | Status |
| --- | --- | --- | --- | --- |
| Stage role statement | parsing_spec.md:3-5 | Input resolution notes retain stage role | parsing_spec_template.md:13-15 | Covered |
| Source file declaration | parsing_spec.md:11-13 | Resolved/missing input sections retained | parsing_spec_template.md:6-11, parsing_spec_template.md:62-64 | Covered |
| Per-sub-item extraction status table | parsing_spec.md:21-41 | Evidence-to-sub-item mapping + object status summary retained | parsing_spec_template.md:27-36, parsing_spec_template.md:80-97 | Covered |
| Explicit object-level missing reason | parsing_spec.md:43-44 | Mandatory missing evidence table retained | parsing_spec_template.md:39-43, parsing_spec_template.md:98-103 | Covered |
| Raw extracted text snippets | parsing_spec.md:48-78 | Evidence inventory includes raw line + extracted value + pattern | parsing_spec_template.md:17-20, parsing_spec_template.md:65-72 | Covered |
| Referenced file evidence (netlist header) | parsing_spec.md:62-72 | Referenced files section retained | parsing_spec_template.md:22-25, parsing_spec_template.md:73-79 | Covered |
| Extraction summary counts | parsing_spec.md:84-90 | Coverage summary retained | parsing_spec_template.md:49-51, parsing_spec_template.md:112-115 | Covered |
| Conflict handling not explicit in old | n/a | Added conflicts/ambiguities to prevent silent mismatches | parsing_spec_template.md:44-47, parsing_spec_template.md:104-111 | Added (improvement) |

## Coverage Matrix: Old FormatSpec -> New Skeleton

| Old FormatSpec Content | Old Reference | New Skeleton Coverage | New Reference | Status |
| --- | --- | --- | --- | --- |
| Parsing actual result summary | format_spec.md:9-15 | Expected outcomes + current evidence recommendation retained | format_spec_template.md:70-80 | Covered |
| Field-level pattern characteristics | format_spec.md:20-29 | Requirement items include object/sub-item/pattern/comparator mapping | format_spec_template.md:12-17, format_spec_template.md:93-114 | Covered |
| Four scenario configurations | format_spec.md:35-147 | Four scenario matrix blocks retained | format_spec_template.md:37-68, format_spec_template.md:145-173 | Covered |
| Scenario description/reason fields | format_spec.md:48-55, format_spec.md:75-86, format_spec.md:107-114, format_spec.md:136-147 | All required desc/reason fields retained | format_spec_template.md:39-68, format_spec_template.md:146-173 | Covered |
| Requirement/waiver combination outcomes | format_spec.md:57, format_spec.md:88, format_spec.md:116, format_spec.md:149 | Expected outcomes table retained | format_spec_template.md:70-76, format_spec_template.md:174-194 | Covered |
| Recommended pass path under current evidence | format_spec.md:153-158 | Recommendation block retained | format_spec_template.md:78-80 | Covered |
| Violation naming format | implicit in legacy converter flow | Explicit `vio_name_format` line retained | format_spec_template.md:5, format_spec_template.md:88 | Covered |
| Pattern index to validation target mapping | partially implicit in old | Explicit mapping retained and normalized | format_spec_template.md:19-22, format_spec_template.md:115-124 | Added (improvement) |
| Waiver keyword taxonomy | partially implicit in old | Explicit taxonomy retained for validation and searchability | format_spec_template.md:30-35, format_spec_template.md:130-144 | Added (improvement) |

## Final Assessment

- All critical information categories from old `IMP-10-0-0-00` specs are preserved in the new skeleton set.
- No critical semantic category from old ItemSpec/ParsingSpec/FormatSpec is missing.
- The skeletons also add explicit contracts for:
  - conflict handling in parsing
  - pattern-index traceability
  - waiver keyword taxonomy
  - explicit cross-object consistency and evidence field contracts
