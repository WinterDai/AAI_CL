# <ITEM_ID> ItemSpec

Description: <DESCRIPTION>
Check Module: <CHECK_MODULE>
Role: Senior digital physical implementation expert

## Scope
This specification defines what must be checked semantically for `<ITEM_ID>`.
This stage must not parse runtime input files.

- Define semantic intent and check boundaries.
- Define objects and sub-items to validate.
- Define PASS/FAIL and waiver boundary rules.

## Description Interpretation Rules
- Slash notation defaults to logical AND across objects unless explicit `or` is present.
- Explicit `or` denotes alternatives where at least one branch must satisfy the requirement.
- Optional components are modeled as optional sub-items and may be governed by waiver contracts.
- Broad wording should be decomposed into semantic axes:
  - existence and load status
  - cross-object consistency
  - version and tool correctness
  - timestamp and recency correctness

## Semantic Targets

### Semantic Target Table
| Target ID | Object | Required Semantic Intent | PASS Condition | FAIL Condition |
| --- | --- | --- | --- | --- |
| T1 | <object_1> | <semantic intent> | <pass condition> | <fail condition> |
| T2 | <object_2> | <semantic intent> | <pass condition> | <fail condition> |

### Object/Sub-Item Contract
| Object | Sub-Item | Required | Semantic Meaning | PASS Condition | FAIL Condition |
| --- | --- | --- | --- | --- | --- |
| <object_1> | `file_path` | mandatory | Resolved path for object evidence. | Evidence proves path is valid. | Evidence missing or conflicting. |
| <object_1> | `file_name` | mandatory | File name derived from resolved path. | Evidence proves file name is valid. | Evidence missing or conflicting. |
| <object_1> | `design_name` | mandatory | Design identity for consistency checks. | Evidence proves design identity. | Evidence missing or conflicting. |
| <object_1> | `generator_tool` | <mandatory\|optional> | Tool identity for provenance checks. | Evidence proves tool identity. | Evidence missing or conflicting. |
| <object_1> | `generator_version` | <mandatory\|optional> | Tool version for provenance checks. | Evidence proves version identity. | Evidence missing or conflicting. |
| <object_1> | `generation_time` | <mandatory\|optional> | Generation timestamp for recency checks. | Evidence proves timestamp validity. | Evidence missing or conflicting. |
| <object_2> | `file_path` | mandatory | Resolved path for object evidence. | Evidence proves path is valid. | Evidence missing or conflicting. |
| <object_2> | `file_name` | mandatory | File name derived from resolved path. | Evidence proves file name is valid. | Evidence missing or conflicting. |
| <object_2> | `design_name` | mandatory | Design identity for consistency checks. | Evidence proves design identity. | Evidence missing or conflicting. |
| <object_2> | `extractor_tool` | <mandatory\|optional> | Tool identity for provenance checks. | Evidence proves tool identity. | Evidence missing or conflicting. |
| <object_2> | `extractor_version` | <mandatory\|optional> | Tool version for provenance checks. | Evidence proves version identity. | Evidence missing or conflicting. |
| <object_2> | `extraction_time` | <mandatory\|optional> | Extraction timestamp for recency checks. | Evidence proves timestamp validity. | Evidence missing or conflicting. |

### Cross-Object Consistency Rules
| Rule ID | Expression | Required | PASS Condition | FAIL Condition |
| --- | --- | --- | --- | --- |
| CR1 | `<object_1>.design_name == <object_2>.design_name` | true | Both values exist and are equal. | One value missing or values mismatch. |

### Waiver Scope Contract
| Waiver Granularity | Token Format | Effect Scope |
| --- | --- | --- |
| object-level | `<object>:*` | Waive all mandatory sub-items for one object. |
| sub-item-level | `<object>:<sub_item>` | Waive one explicit sub-item only. |

## Check Criteria
- Requirement value observed in item yaml: `<N/A|number>`
- Waiver value observed in item yaml: `<N/A|number>`
- Any mandatory sub-item missing triggers FAIL unless covered by a valid waiver.
- Any required cross-object rule violation triggers FAIL unless covered by a valid waiver.

### Decision Matrix (Requirement/Waiver)
| Scenario | requirements.value | waivers.value | Decision Rule |
| --- | --- | --- | --- |
| S1 | N/A | N/A | Semantic presence and consistency only, no waiver allowed. |
| S2 | N/A | >0 | Semantic presence and consistency; violations can be waived. |
| S3 | >0 | N/A | Requirement pattern matching without waiver. |
| S4 | >0 | >0 | Requirement pattern matching with waiver handling. |

## Evidence Plan

### Data Source Priority
| Priority | Source | Expected Evidence |
| --- | --- | --- |
| Primary | Runtime log files | Object load status, key commands, top-level design identity. |
| Secondary | Referenced netlist header | Generator tool/version/time provenance. |
| Secondary | Referenced SPEF header | Extractor tool/version/time provenance. |

### Stage Responsibilities
- Stage A (ItemSpec): semantic contract only; no runtime file reads.
- Stage B (ParsingSpec): locate concrete evidence with file path and line number.
- Stage C (FormatSpec): normalize evidence into requirement and waiver formats.

### Mandatory Evidence Fields for Downstream
| Field | Meaning |
| --- | --- |
| `evidence_id` | Stable identifier for traceability. |
| `source_file` | Absolute path to source file. |
| `line_number` | 1-based source line number. |
| `raw_line` | Original text line as captured. |
| `pattern` | Matching expression used to extract value. |
| `extracted_value` | Extracted scalar or normalized token. |

## Embedded Schema
```yaml
itemspec:
  item_id: "<ITEM_ID>"
  description: "<DESCRIPTION>"
  check_module: "<CHECK_MODULE>"
  role: "Senior digital physical implementation expert"
  stage_boundary:
    reads_input_files: false
    depends_on_input_snippets: false
  semantic_targets:
    - target_id: "T1"
      object_name: "<object_1>"
      semantic_intent: "<semantic intent>"
      sub_items:
        - name: "file_path"
          required: true
          semantics: "Resolved path for object evidence."
        - name: "file_name"
          required: true
          semantics: "File name derived from resolved path."
        - name: "design_name"
          required: true
          semantics: "Design identity for consistency checks."
        - name: "generator_tool"
          required: true  # set true/false based on checker semantics
          semantics: "Tool identity for provenance checks."
        - name: "generator_version"
          required: true  # set true/false based on checker semantics
          semantics: "Tool version for provenance checks."
        - name: "generation_time"
          required: true  # set true/false based on checker semantics
          semantics: "Generation timestamp for recency checks."
      required_evidence:
        - "evidence_id"
        - "source_file"
        - "line_number"
        - "raw_line"
        - "pattern"
        - "extracted_value"
      pass_when:
        - "All mandatory sub-items are semantically supported."
      fail_when:
        - "Any mandatory sub-item is missing or semantically conflicting."
    - target_id: "T2"
      object_name: "<object_2>"
      semantic_intent: "<semantic intent>"
      sub_items:
        - name: "file_path"
          required: true
          semantics: "Resolved path for object evidence."
        - name: "file_name"
          required: true
          semantics: "File name derived from resolved path."
        - name: "design_name"
          required: true
          semantics: "Design identity for consistency checks."
        - name: "extractor_tool"
          required: true  # set true/false based on checker semantics
          semantics: "Tool identity for provenance checks."
        - name: "extractor_version"
          required: true  # set true/false based on checker semantics
          semantics: "Tool version for provenance checks."
        - name: "extraction_time"
          required: true  # set true/false based on checker semantics
          semantics: "Extraction timestamp for recency checks."
      required_evidence:
        - "evidence_id"
        - "source_file"
        - "line_number"
        - "raw_line"
        - "pattern"
        - "extracted_value"
      pass_when:
        - "All mandatory sub-items are semantically supported."
      fail_when:
        - "Any mandatory sub-item is missing or semantically conflicting."
  cross_object_rules:
    - rule_id: "CR1"
      expression: "<object_1>.design_name == <object_2>.design_name"
      required: true
      pass_when:
        - "Both design_name values exist and are equal."
      fail_when:
        - "Any design_name value is missing or mismatch exists."
  waiver_model:
    object_level_token: "<object>:*"
    sub_item_token: "<object>:<sub_item>"
  decision_matrix:
    - scenario: "S1"
      requirements_value: "N/A"
      waivers_value: "N/A"
    - scenario: "S2"
      requirements_value: "N/A"
      waivers_value: ">0"
    - scenario: "S3"
      requirements_value: ">0"
      waivers_value: "N/A"
    - scenario: "S4"
      requirements_value: ">0"
      waivers_value: ">0"
  pass_rule: "All mandatory semantic targets and required cross-object rules pass."
  fail_rule: "Any mandatory semantic target or required cross-object rule fails without valid waiver."
```
