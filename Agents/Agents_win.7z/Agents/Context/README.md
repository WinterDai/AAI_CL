# Context Agent

Context Agent generates three collateral documents for each checker item:

1. `ItemSpec` (semantic target definition)
2. `ParsingSpec` (evidence extraction contract from real input files)
3. `FormatSpec` (requirement/waiver formatting and scenario contract)

## Stage Boundaries

- Stage A (`ItemSpec`) does not read runtime input files.
- Stage B (`ParsingSpec`) reads input files resolved from item yaml.
- Stage C (`FormatSpec`) depends on `ItemSpec` + `ParsingSpec` + valid evidence snippets.

## Output Contract

- Output root uses per-item subfolder: `outputs/<ITEM_ID>/`.
- File names include ID prefix:
  - `<ITEM_ID>_itemspec.md`
  - `<ITEM_ID>_parsing_spec.md`
  - `<ITEM_ID>_format_spec.md`
- Language requirement: pure English.

## LLM Modes

Context Agent reuses `CodeGen.llm_client` and supports:

- `mock`
- `real`
- `interactive`

If LLM output is missing/invalid, Context Agent falls back to deterministic local generation.

## Compatibility Mode

- Default: OFF.
- When enabled, additional flat copies are emitted to:
  - `outputs/itemspec.md`
  - `outputs/parsing_spec.md`
  - `outputs/format_spec.md`

## CLI

```bash
python -m CHECKLIST.Agents.Context.agent \
  --item-id IMP-10-0-0-00 \
  --mode mock
```

Direct script execution is also supported:

```bash
python CHECKLIST/Agents/Context/agent.py \
  --item-id IMP-10-0-0-00 \
  --mode mock
```
