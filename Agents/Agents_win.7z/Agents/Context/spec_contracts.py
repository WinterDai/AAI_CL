#!/usr/bin/env python3
"""Structured spec contracts and embedded-yaml helpers for Context Agent."""

from __future__ import annotations

from dataclasses import dataclass, field
import re
from typing import Any, Dict, List, Optional, Sequence, Tuple

import yaml


YAML_BLOCK_RE = re.compile(
    r"(?ms)^```yaml[ \t]*\n(.*?)^```[ \t]*$",
    re.IGNORECASE,
)

# =============================================================================
# OBJECT TYPE TEMPLATES - Defines sub-items based on object semantic type
# =============================================================================
# Each template defines: (sub_item_name, required, semantics)

OBJECT_TYPE_TEMPLATES: Dict[str, List[Tuple[str, bool, str]]] = {
    # Type A: EDA-Generated Files (netlist, gds, def, oasis, lef_macro)
    "generated_file": [
        ("file_path", True, "Full path to the file"),
        ("file_name", True, "Filename extracted from path"),
        ("design_name", True, "Top-level design/module name"),
        ("generator_tool", True, "EDA tool that created the file"),
        ("generator_version", True, "Tool version string"),
        ("generation_time", True, "File creation timestamp"),
    ],
    # Type B: Parasitic Files (spef, spf)
    "parasitic_file": [
        ("file_path", True, "Full path to the file"),
        ("file_name", True, "Filename extracted from path"),
        ("design_name", True, "Top-level design/module name"),
        ("extractor_tool", True, "Parasitic extraction tool name"),
        ("extractor_version", True, "Extraction tool version"),
        ("extraction_time", True, "SPEF creation timestamp"),
    ],
    # Type C: Library Files (liberty, lef_tech, db)
    "library_file": [
        ("library_path", True, "Full path to library file"),
        ("library_name", True, "Library identifier"),
        ("library_version", True, "Version string"),
        ("corner", False, "PVT corner (fast/slow/typical)"),
        ("process_node", False, "Technology node"),
    ],
    # Type D: Constraint Files (sdc, upf, cpf)
    "constraint_file": [
        ("file_path", True, "Full path to constraint file"),
        ("file_name", True, "Filename"),
        ("design_scope", False, "Design/module scope"),
        ("content_hash", False, "Integrity hash if available"),
    ],
}

# Mapping from object name to object type
OBJECT_NAME_TO_TYPE: Dict[str, str] = {
    # Generated files
    "netlist": "generated_file",
    "gds": "generated_file",
    "gdsii": "generated_file",
    "def": "generated_file",
    "oasis": "generated_file",
    "lef_macro": "generated_file",
    "verilog": "generated_file",
    # Parasitic files
    "spef": "parasitic_file",
    "spf": "parasitic_file",
    # Library files
    "liberty": "library_file",
    "lib": "library_file",
    "db": "library_file",
    "lef": "library_file",
    "lef_tech": "library_file",
    "tech_file": "library_file",
    # Constraint files
    "sdc": "constraint_file",
    "upf": "constraint_file",
    "cpf": "constraint_file",
}


def get_object_type(object_name: str) -> str:
    """Get the semantic type for an object name."""
    name_lower = object_name.lower()
    if name_lower in OBJECT_NAME_TO_TYPE:
        return OBJECT_NAME_TO_TYPE[name_lower]
    # Heuristic fallback
    if "lib" in name_lower or "lef" in name_lower:
        return "library_file"
    if "spef" in name_lower or "spf" in name_lower:
        return "parasitic_file"
    if "sdc" in name_lower or "upf" in name_lower or "cpf" in name_lower:
        return "constraint_file"
    # Default to generated_file
    return "generated_file"


def get_subitems_for_object(object_name: str) -> List[Tuple[str, bool, str]]:
    """Get the standard sub-items for an object based on its semantic type."""
    obj_type = get_object_type(object_name)
    return OBJECT_TYPE_TEMPLATES.get(obj_type, OBJECT_TYPE_TEMPLATES["generated_file"])


def _as_str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value)


def _as_list(value: Any) -> List[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def extract_embedded_yaml_blocks(markdown: str) -> List[Dict[str, Any]]:
    """Extract all embedded yaml blocks as parsed dictionaries."""
    docs: List[Dict[str, Any]] = []
    for match in YAML_BLOCK_RE.finditer(markdown or ""):
        block = match.group(1).strip()
        if not block:
            continue
        try:
            parsed = yaml.safe_load(block)
        except Exception:
            continue
        if isinstance(parsed, dict):
            docs.append(parsed)
    return docs


def extract_root_yaml(markdown: str, root_key: str) -> Optional[Dict[str, Any]]:
    """Return the first yaml block containing root_key."""
    for doc in extract_embedded_yaml_blocks(markdown):
        if root_key in doc and isinstance(doc[root_key], dict):
            return doc[root_key]
    return None


def dump_root_yaml(root_key: str, payload: Dict[str, Any]) -> str:
    """Render one embedded yaml block string."""
    material = {root_key: payload}
    return yaml.safe_dump(material, sort_keys=False, allow_unicode=False).strip()


@dataclass
class SubItemContract:
    name: str
    required: bool
    semantics: str
    pass_condition: str = "Evidence confirms semantics."
    fail_condition: str = "Missing evidence or conflicting evidence."

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "required": bool(self.required),
            "semantics": self.semantics,
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "SubItemContract":
        return cls(
            name=_as_str(payload.get("name")),
            required=bool(payload.get("required", False)),
            semantics=_as_str(payload.get("semantics")),
        )


@dataclass
class SemanticTarget:
    target_id: str
    object_name: str
    semantic_intent: str
    sub_items: List[SubItemContract] = field(default_factory=list)
    required_evidence: List[str] = field(default_factory=lambda: ["evidence_id", "source_file", "line_number", "raw_line", "pattern", "extracted_value"])
    pass_when: List[str] = field(default_factory=lambda: ["All mandatory sub-items are semantically supported."])
    fail_when: List[str] = field(default_factory=lambda: ["Any mandatory sub-item is missing or semantically conflicting."])

    def to_dict(self) -> Dict[str, Any]:
        return {
            "target_id": self.target_id,
            "object_name": self.object_name,
            "semantic_intent": self.semantic_intent,
            "sub_items": [x.to_dict() for x in self.sub_items],
            "required_evidence": list(self.required_evidence),
            "pass_when": list(self.pass_when),
            "fail_when": list(self.fail_when),
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "SemanticTarget":
        sub_items = [SubItemContract.from_dict(x) for x in _as_list(payload.get("sub_items")) if isinstance(x, dict)]
        return cls(
            target_id=_as_str(payload.get("target_id")),
            object_name=_as_str(payload.get("object_name")),
            semantic_intent=_as_str(payload.get("semantic_intent")),
            sub_items=sub_items,
            required_evidence=[_as_str(x) for x in _as_list(payload.get("required_evidence"))],
            pass_when=[_as_str(x) for x in _as_list(payload.get("pass_when"))] or ["All mandatory sub-items are semantically supported."],
            fail_when=[_as_str(x) for x in _as_list(payload.get("fail_when"))] or ["Any mandatory sub-item is missing or semantically conflicting."],
        )


@dataclass
class CrossObjectRule:
    rule_id: str
    expression: str
    required: bool
    pass_when: List[str]
    fail_when: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "expression": self.expression,
            "required": bool(self.required),
            "pass_when": list(self.pass_when),
            "fail_when": list(self.fail_when),
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "CrossObjectRule":
        return cls(
            rule_id=_as_str(payload.get("rule_id")),
            expression=_as_str(payload.get("expression")),
            required=bool(payload.get("required", True)),
            pass_when=[_as_str(x) for x in _as_list(payload.get("pass_when"))],
            fail_when=[_as_str(x) for x in _as_list(payload.get("fail_when"))],
        )


@dataclass
class WaiverScope:
    granularity: str
    token_format: str
    effect_scope: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "granularity": self.granularity,
            "token_format": self.token_format,
            "effect_scope": self.effect_scope,
        }


@dataclass
class DecisionScenario:
    scenario: str
    requirements_value: str
    waivers_value: str
    decision_rule: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "scenario": self.scenario,
            "requirements_value": self.requirements_value,
            "waivers_value": self.waivers_value,
            "decision_rule": self.decision_rule,
        }


@dataclass
class EvidenceSourcePriority:
    priority: str
    source: str
    expected_evidence: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "priority": self.priority,
            "source": self.source,
            "expected_evidence": self.expected_evidence,
        }


@dataclass
class ItemSpecContract:
    item_id: str
    description: str
    check_module: str
    role: str = "Senior digital physical implementation expert"
    interpretation_rules: List[str] = field(default_factory=list)
    semantic_targets: List[SemanticTarget] = field(default_factory=list)
    cross_object_rules: List[CrossObjectRule] = field(default_factory=list)
    waiver_scopes: List[WaiverScope] = field(default_factory=list)
    decision_matrix: List[DecisionScenario] = field(default_factory=list)
    evidence_source_priority: List[EvidenceSourcePriority] = field(default_factory=list)
    mandatory_evidence_fields: List[str] = field(default_factory=lambda: ["evidence_id", "source_file", "line_number", "raw_line", "pattern", "extracted_value"])
    requirement_value_observed: str = "N/A"
    waiver_value_observed: str = "N/A"
    pass_rule: str = "All mandatory semantic targets and required cross-object rules pass."
    fail_rule: str = "Any mandatory semantic target or required cross-object rule fails without valid waiver."
    knowledge_notes: List[str] = field(default_factory=list)

    def to_schema_dict(self) -> Dict[str, Any]:
        return {
            "item_id": self.item_id,
            "description": self.description,
            "check_module": self.check_module,
            "role": self.role,
            "stage_boundary": {
                "reads_input_files": False,
                "depends_on_input_snippets": False,
            },
            "semantic_targets": [x.to_dict() for x in self.semantic_targets],
            "cross_object_rules": [x.to_dict() for x in self.cross_object_rules],
            "waiver_model": {
                "scopes": [x.to_dict() for x in self.waiver_scopes],
            },
            "decision_matrix": [x.to_dict() for x in self.decision_matrix],
            "mandatory_evidence_fields": list(self.mandatory_evidence_fields),
            "pass_rule": self.pass_rule,
            "fail_rule": self.fail_rule,
        }

    @classmethod
    def from_embedded_yaml(cls, markdown: str) -> Optional["ItemSpecContract"]:
        root = extract_root_yaml(markdown, "itemspec")
        if not root:
            return None
        targets = [SemanticTarget.from_dict(x) for x in _as_list(root.get("semantic_targets")) if isinstance(x, dict)]
        cross_rules = [CrossObjectRule.from_dict(x) for x in _as_list(root.get("cross_object_rules")) if isinstance(x, dict)]
        
        # Handle nested "objects" or "check_objects" format from LLM output
        # Convert objects[].sub_items[] to semantic_targets[]
        objects_list = _as_list(root.get("objects")) or _as_list(root.get("check_objects"))
        for idx, obj in enumerate(objects_list):
            if not isinstance(obj, dict):
                continue
            # Support both "name" and "object_id" as object name field
            obj_name = _as_str(obj.get("name") or obj.get("object_id"))
            obj_mandatory = bool(obj.get("mandatory", True))
            
            # Skip if object name is empty or already exists
            if not obj_name or any(t.object_name == obj_name for t in targets):
                continue
            
            # Build sub_items list
            sub_items = []
            for si in _as_list(obj.get("sub_items")):
                if not isinstance(si, dict):
                    continue
                sub_items.append(SubItemContract(
                    name=_as_str(si.get("name")),
                    required=bool(si.get("required", True)),
                    semantics=_as_str(si.get("semantic", si.get("semantics", ""))),
                    pass_condition=_as_str(si.get("pass_condition", "Evidence confirms semantics.")),
                    fail_condition=_as_str(si.get("fail_condition", "Missing evidence or conflicting evidence."))
                ))
            
            # Create SemanticTarget for this object
            targets.append(SemanticTarget(
                target_id=f"T{idx+1}",
                object_name=obj_name,
                semantic_intent=f"Validate {obj_name} version metadata",
                sub_items=sub_items,
                required_evidence=["evidence_id", "source_file", "line_number", "raw_line", "pattern", "extracted_value"],
                pass_when=["All mandatory sub-items are semantically supported."] if obj_mandatory else ["Object is optional."],
                fail_when=["Any mandatory sub-item is missing or semantically conflicting."] if obj_mandatory else ["Object is optional; absence is acceptable."],
            ))
        
        scopes = []
        waiver_model = root.get("waiver_model", {})
        for row in _as_list(waiver_model.get("scopes")):
            if isinstance(row, dict):
                scopes.append(
                    WaiverScope(
                        granularity=_as_str(row.get("granularity")),
                        token_format=_as_str(row.get("token_format")),
                        effect_scope=_as_str(row.get("effect_scope")),
                    )
                )
        matrix = []
        for row in _as_list(root.get("decision_matrix")):
            if isinstance(row, dict):
                matrix.append(
                    DecisionScenario(
                        scenario=_as_str(row.get("scenario")),
                        requirements_value=_as_str(row.get("requirements_value")),
                        waivers_value=_as_str(row.get("waivers_value")),
                        decision_rule=_as_str(row.get("decision_rule")),
                    )
                )

        return cls(
            item_id=_as_str(root.get("item_id")),
            description=_as_str(root.get("description")),
            check_module=_as_str(root.get("check_module")),
            role=_as_str(root.get("role"), "Senior digital physical implementation expert"),
            semantic_targets=targets,
            cross_object_rules=cross_rules,
            waiver_scopes=scopes,
            decision_matrix=matrix,
            mandatory_evidence_fields=[_as_str(x) for x in _as_list(root.get("mandatory_evidence_fields"))],
            pass_rule=_as_str(root.get("pass_rule"), "All mandatory semantic targets and required cross-object rules pass."),
            fail_rule=_as_str(root.get("fail_rule"), "Any mandatory semantic target or required cross-object rule fails without valid waiver."),
        )


def _parse_confidence(value: Any) -> float:
    """Parse confidence value, handling both float and string formats."""
    if value is None:
        return 1.0
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        value_lower = value.lower().strip()
        if value_lower in ("high", "h"):
            return 0.9
        if value_lower in ("medium", "med", "m"):
            return 0.7
        if value_lower in ("low", "l"):
            return 0.5
        try:
            return float(value)
        except ValueError:
            return 1.0
    return 1.0


@dataclass
class EvidenceRecordModel:
    evidence_id: str
    source_file: str
    line_number: int
    pattern: str
    extracted_value: str
    raw_line: str
    confidence: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "evidence_id": self.evidence_id,
            "source_file": self.source_file,
            "line_number": int(self.line_number),
            "pattern": self.pattern,
            "extracted_value": self.extracted_value,
            "raw_line": self.raw_line,
            "confidence": float(self.confidence),
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "EvidenceRecordModel":
        return cls(
            evidence_id=_as_str(payload.get("evidence_id")),
            source_file=_as_str(payload.get("source_file")),
            line_number=int(payload.get("line_number", 0) or 0),
            pattern=_as_str(payload.get("pattern")),
            extracted_value=_as_str(payload.get("extracted_value") or payload.get("extracted") or ""),
            raw_line=_as_str(payload.get("raw_line") or ""),
            confidence=_parse_confidence(payload.get("confidence")),
        )


@dataclass
class EvidenceMapping:
    evidence_id: str
    object_name: str
    sub_item: str
    required: bool
    mapping_status: str
    rationale: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "evidence_id": self.evidence_id,
            "object": self.object_name,
            "sub_item": self.sub_item,
            "required": bool(self.required),
            "mapping_status": self.mapping_status,
            "rationale": self.rationale,
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "EvidenceMapping":
        return cls(
            evidence_id=_as_str(payload.get("evidence_id")),
            object_name=_as_str(payload.get("object") or payload.get("object_name")),
            sub_item=_as_str(payload.get("sub_item")),
            required=bool(payload.get("required", False)),
            mapping_status=_as_str(payload.get("mapping_status"), "mapped"),
            rationale=_as_str(payload.get("rationale")),
        )


@dataclass
class ObjectStatusSummary:
    object_name: str
    mandatory_found: int
    mandatory_total: int
    status: str
    blocker_reason: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "object": self.object_name,
            "mandatory_found": int(self.mandatory_found),
            "mandatory_total": int(self.mandatory_total),
            "status": self.status,
            "blocker_reason": self.blocker_reason,
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "ObjectStatusSummary":
        return cls(
            object_name=_as_str(payload.get("object") or payload.get("object_name")),
            mandatory_found=int(payload.get("mandatory_found", 0) or 0),
            mandatory_total=int(payload.get("mandatory_total", 0) or 0),
            status=_as_str(payload.get("status")),
            blocker_reason=_as_str(payload.get("blocker_reason")),
        )


@dataclass
class ExtractionGap:
    object_name: str
    sub_item: str
    gap_type: str
    detail: str
    suggested_resolution: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "object": self.object_name,
            "sub_item": self.sub_item,
            "gap_type": self.gap_type,
            "detail": self.detail,
            "suggested_resolution": self.suggested_resolution,
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "ExtractionGap":
        return cls(
            object_name=_as_str(payload.get("object") or payload.get("object_name")),
            sub_item=_as_str(payload.get("sub_item")),
            gap_type=_as_str(payload.get("gap_type")),
            detail=_as_str(payload.get("detail")),
            suggested_resolution=_as_str(payload.get("suggested_resolution")),
        )


@dataclass
class ExtractionConflict:
    object_name: str
    sub_item: str
    conflict_type: str
    candidates: List[str]
    resolution_hint: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "object": self.object_name,
            "sub_item": self.sub_item,
            "conflict_type": self.conflict_type,
            "candidates": list(self.candidates),
            "resolution_hint": self.resolution_hint,
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "ExtractionConflict":
        return cls(
            object_name=_as_str(payload.get("object") or payload.get("object_name")),
            sub_item=_as_str(payload.get("sub_item")),
            conflict_type=_as_str(payload.get("conflict_type")),
            candidates=[_as_str(x) for x in _as_list(payload.get("candidates"))],
            resolution_hint=_as_str(payload.get("resolution_hint")),
        )


@dataclass
class ParsingSpecContract:
    item_id: str
    description: str
    check_module: str
    resolved_inputs: List[str] = field(default_factory=list)
    missing_inputs: List[str] = field(default_factory=list)
    evidence_records: List[EvidenceRecordModel] = field(default_factory=list)
    referenced_file_records: List[EvidenceRecordModel] = field(default_factory=list)
    evidence_to_sub_item: List[EvidenceMapping] = field(default_factory=list)
    object_status_summary: List[ObjectStatusSummary] = field(default_factory=list)
    extraction_gaps: List[ExtractionGap] = field(default_factory=list)
    conflicts: List[ExtractionConflict] = field(default_factory=list)
    mandatory_found: int = 0
    mandatory_total: int = 0

    def to_schema_dict(self) -> Dict[str, Any]:
        ratio = f"{self.mandatory_found}/{self.mandatory_total}" if self.mandatory_total > 0 else "0/0"
        return {
            "item_id": self.item_id,
            "description": self.description,
            "check_module": self.check_module,
            "stage_boundary": {
                "reads_input_files": True,
                "depends_on_itemspec": True,
            },
            "resolved_inputs": list(self.resolved_inputs),
            "missing_inputs": list(self.missing_inputs),
            "evidence_records": [x.to_dict() for x in self.evidence_records],
            "referenced_file_records": [x.to_dict() for x in self.referenced_file_records],
            "evidence_to_sub_item": [x.to_dict() for x in self.evidence_to_sub_item],
            "object_status_summary": [x.to_dict() for x in self.object_status_summary],
            "extraction_gaps": [x.to_dict() for x in self.extraction_gaps],
            "conflicts": [x.to_dict() for x in self.conflicts],
            "coverage_summary": {
                "mandatory_found": int(self.mandatory_found),
                "mandatory_total": int(self.mandatory_total),
                "mandatory_coverage_ratio": ratio,
            },
        }

    @classmethod
    def from_embedded_yaml(cls, markdown: str) -> Optional["ParsingSpecContract"]:
        root = extract_root_yaml(markdown, "parsing_spec")
        if not root:
            return None
        evidence = [EvidenceRecordModel.from_dict(x) for x in _as_list(root.get("evidence_records")) if isinstance(x, dict)]
        refs = [EvidenceRecordModel.from_dict(x) for x in _as_list(root.get("referenced_file_records")) if isinstance(x, dict)]
        mappings = [EvidenceMapping.from_dict(x) for x in _as_list(root.get("evidence_to_sub_item")) if isinstance(x, dict)]
        statuses = [ObjectStatusSummary.from_dict(x) for x in _as_list(root.get("object_status_summary")) if isinstance(x, dict)]
        gaps = [ExtractionGap.from_dict(x) for x in _as_list(root.get("extraction_gaps")) if isinstance(x, dict)]
        conflicts = [ExtractionConflict.from_dict(x) for x in _as_list(root.get("conflicts")) if isinstance(x, dict)]

        # Handle nested "objects" format from LLM output
        # Convert objects[].sub_items[] to flat evidence_to_sub_item and extraction_gaps
        objects_list = _as_list(root.get("objects"))
        total_mandatory = 0
        found_mandatory = 0
        for obj in objects_list:
            if not isinstance(obj, dict):
                continue
            obj_name = _as_str(obj.get("name"))
            extraction_status = _as_str(obj.get("extraction_status"))
            extracted_count = int(obj.get("extracted_count", 0) or 0)
            total_count = int(obj.get("total_count", 0) or 0)
            
            # Build ObjectStatusSummary if not already present
            if obj_name and not any(s.object_name == obj_name for s in statuses):
                status_str = "PASS" if extraction_status == "complete" else "PARTIAL" if extraction_status == "partial" else "FAIL"
                if extraction_status == "skipped":
                    status_str = "SKIPPED"
                statuses.append(ObjectStatusSummary(
                    object_name=obj_name,
                    mandatory_found=extracted_count,
                    mandatory_total=total_count,
                    status=status_str,
                    blocker_reason=_as_str(obj.get("skip_reason", ""))
                ))
            
            total_mandatory += total_count
            found_mandatory += extracted_count
            
            sub_items = _as_list(obj.get("sub_items"))
            for idx, si in enumerate(sub_items):
                if not isinstance(si, dict):
                    continue
                si_name = _as_str(si.get("name"))
                si_status = _as_str(si.get("status"))
                si_value = si.get("value")
                
                # Create evidence mapping for extracted sub-items
                if si_status in ("extracted", "satisfied"):
                    ev_id = f"EV_{obj_name}_{si_name}"
                    if not any(m.object_name == obj_name and m.sub_item == si_name for m in mappings):
                        mappings.append(EvidenceMapping(
                            evidence_id=ev_id,
                            object_name=obj_name,
                            sub_item=si_name,
                            required=True,
                            mapping_status="mapped",
                            rationale=f"Extracted from {_as_str(si.get('source', 'unknown source'))}"
                        ))
                # Create extraction gap for missing sub-items
                elif si_status in ("not_applicable", "error", "missing", None) or si_value is None:
                    if not any(g.object_name == obj_name and g.sub_item == si_name for g in gaps):
                        gaps.append(ExtractionGap(
                            object_name=obj_name,
                            sub_item=si_name,
                            gap_type="mandatory_missing" if si_status != "not_applicable" else "skipped",
                            detail=_as_str(obj.get("skip_reason", f"Sub-item {si_name} not extracted")),
                            suggested_resolution=f"Provide waiver or add valid evidence for {obj_name}.{si_name}"
                        ))
        
        # Also handle extraction_gaps in nested format: [{object: x, sub_items: [...]}]
        nested_gaps = _as_list(root.get("extraction_gaps"))
        for ng in nested_gaps:
            if not isinstance(ng, dict):
                continue
            ng_obj = _as_str(ng.get("object"))
            ng_sub_items = _as_list(ng.get("sub_items"))
            ng_reason = _as_str(ng.get("reason", ""))
            for si_name in ng_sub_items:
                si_str = _as_str(si_name) if not isinstance(si_name, dict) else _as_str(si_name.get("name", si_name))
                if ng_obj and si_str and not any(g.object_name == ng_obj and g.sub_item == si_str for g in gaps):
                    gaps.append(ExtractionGap(
                        object_name=ng_obj,
                        sub_item=si_str,
                        gap_type="mandatory_missing",
                        detail=ng_reason,
                        suggested_resolution=f"Provide waiver or add evidence for {ng_obj}.{si_str}"
                    ))

        # Handle "extracted_values" format: {netlist: {file_path: {value, status, evidence_id}, ...}}
        extracted_values = root.get("extracted_values", {}) or {}
        if isinstance(extracted_values, dict):
            for obj_name, obj_data in extracted_values.items():
                if not isinstance(obj_data, dict):
                    continue
                for si_name, si_data in obj_data.items():
                    if not isinstance(si_data, dict):
                        continue
                    si_status = _as_str(si_data.get("status", ""))
                    si_value = si_data.get("value")
                    ev_id = _as_str(si_data.get("evidence_id", f"EV_{obj_name}_{si_name}"))
                    
                    # Create evidence mapping for extracted sub-items
                    if si_status in ("success", "extracted", "satisfied") and si_value is not None:
                        if not any(m.object_name == obj_name and m.sub_item == si_name for m in mappings):
                            mappings.append(EvidenceMapping(
                                evidence_id=ev_id,
                                object_name=obj_name,
                                sub_item=si_name,
                                required=True,
                                mapping_status="mapped",
                                rationale=_as_str(si_data.get("derivation", f"Extracted from {ev_id}"))
                            ))
                    # Create extraction gap for error/missing sub-items
                    elif si_status in ("error", "missing", "not_applicable") or si_value is None:
                        if not any(g.object_name == obj_name and g.sub_item == si_name for g in gaps):
                            gaps.append(ExtractionGap(
                                object_name=obj_name,
                                sub_item=si_name,
                                gap_type="mandatory_missing",
                                detail=_as_str(si_data.get("reason", f"Sub-item {si_name} not extracted")),
                                suggested_resolution=f"Provide waiver or add evidence for {obj_name}.{si_name}"
                            ))
        
        # Handle "object_status" format: {netlist: {extracted_count, total_count, status}, ...}
        object_status = root.get("object_status", {}) or {}
        if isinstance(object_status, dict):
            for obj_name, obj_data in object_status.items():
                if not isinstance(obj_data, dict):
                    continue
                if not any(s.object_name == obj_name for s in statuses):
                    extracted_count = int(obj_data.get("extracted_count", 0) or 0)
                    total_count_val = int(obj_data.get("total_count", 0) or 0)
                    status_str = _as_str(obj_data.get("status", "")).upper()
                    if status_str not in ("PASS", "FAIL", "PARTIAL", "SKIPPED"):
                        status_str = "PASS" if extracted_count == total_count_val and total_count_val > 0 else "FAIL"
                    statuses.append(ObjectStatusSummary(
                        object_name=obj_name,
                        mandatory_found=extracted_count,
                        mandatory_total=total_count_val,
                        status=status_str,
                        blocker_reason=_as_str(obj_data.get("skip_reason", ""))
                    ))
                    total_mandatory += total_count_val
                    found_mandatory += extracted_count

        cov = root.get("coverage_summary", {}) or {}
        return cls(
            item_id=_as_str(root.get("item_id")),
            description=_as_str(root.get("description")),
            check_module=_as_str(root.get("check_module")),
            resolved_inputs=[_as_str(x) for x in _as_list(root.get("resolved_inputs"))],
            missing_inputs=[_as_str(x) for x in _as_list(root.get("missing_inputs"))],
            evidence_records=evidence,
            referenced_file_records=refs,
            evidence_to_sub_item=mappings,
            object_status_summary=statuses,
            extraction_gaps=gaps,
            conflicts=conflicts,
            mandatory_found=int(cov.get("mandatory_found", 0) or found_mandatory),
            mandatory_total=int(cov.get("mandatory_total", 0) or total_mandatory),
        )


@dataclass
class RequirementItem:
    requirement_id: str
    object_name: str
    sub_item: str
    pattern: str
    comparator: str
    source_evidence_ids: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "requirement_id": self.requirement_id,
            "object": self.object_name,
            "sub_item": self.sub_item,
            "pattern": self.pattern,
            "comparator": self.comparator,
            "source_evidence_ids": list(self.source_evidence_ids),
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "RequirementItem":
        return cls(
            requirement_id=_as_str(payload.get("requirement_id")),
            object_name=_as_str(payload.get("object") or payload.get("object_name")),
            sub_item=_as_str(payload.get("sub_item")),
            pattern=_as_str(payload.get("pattern")),
            comparator=_as_str(payload.get("comparator")),
            source_evidence_ids=[_as_str(x) for x in _as_list(payload.get("source_evidence_ids"))],
        )


@dataclass
class PatternIndexMapping:
    index: int
    requirement_id: str
    target: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "index": int(self.index),
            "requirement_id": self.requirement_id,
            "target": self.target,
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "PatternIndexMapping":
        return cls(
            index=int(payload.get("index", 0) or 0),
            requirement_id=_as_str(payload.get("requirement_id")),
            target=_as_str(payload.get("target")),
        )


@dataclass
class WaiverKeywordTaxonomy:
    scenario: str
    waiver_item: str
    keywords: List[str]
    sample_reason: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "scenario": self.scenario,
            "waiver_item": self.waiver_item,
            "keywords": list(self.keywords),
            "sample_reason": self.sample_reason,
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "WaiverKeywordTaxonomy":
        return cls(
            scenario=_as_str(payload.get("scenario")),
            waiver_item=_as_str(payload.get("waiver_item")),
            keywords=[_as_str(x) for x in _as_list(payload.get("keywords"))],
            sample_reason=_as_str(payload.get("sample_reason")),
        )


@dataclass
class ScenarioText:
    found_desc: str = ""
    missing_desc: str = ""
    found_reason: str = ""
    missing_reason: str = ""
    waived_desc: str = ""
    unused_desc: str = ""
    waived_reason: str = ""
    unused_reason: str = ""

    def to_dict(self) -> Dict[str, Any]:
        payload = {
            "found_desc": self.found_desc,
            "missing_desc": self.missing_desc,
            "found_reason": self.found_reason,
            "missing_reason": self.missing_reason,
        }
        if self.waived_desc:
            payload["waived_desc"] = self.waived_desc
        if self.unused_desc:
            payload["unused_desc"] = self.unused_desc
        if self.waived_reason:
            payload["waived_reason"] = self.waived_reason
        if self.unused_reason:
            payload["unused_reason"] = self.unused_reason
        return payload

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "ScenarioText":
        return cls(
            found_desc=_as_str(payload.get("found_desc")),
            missing_desc=_as_str(payload.get("missing_desc")),
            found_reason=_as_str(payload.get("found_reason")),
            missing_reason=_as_str(payload.get("missing_reason")),
            waived_desc=_as_str(payload.get("waived_desc")),
            unused_desc=_as_str(payload.get("unused_desc")),
            waived_reason=_as_str(payload.get("waived_reason")),
            unused_reason=_as_str(payload.get("unused_reason")),
        )


@dataclass
class ExpectedOutcome:
    scenario: str
    requirements_value: str
    waivers_value: str
    decision_rule: str
    expected_result_with_current_evidence: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "scenario": self.scenario,
            "requirements_value": self.requirements_value,
            "waivers_value": self.waivers_value,
            "decision_rule": self.decision_rule,
            "expected_result_with_current_evidence": self.expected_result_with_current_evidence,
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "ExpectedOutcome":
        return cls(
            scenario=_as_str(payload.get("scenario")),
            requirements_value=_as_str(payload.get("requirements_value")),
            waivers_value=_as_str(payload.get("waivers_value")),
            decision_rule=_as_str(payload.get("decision_rule")),
            expected_result_with_current_evidence=_as_str(payload.get("expected_result_with_current_evidence")),
        )


@dataclass
class FormatSpecContract:
    item_id: str
    description: str
    check_module: str
    vio_name_format: str = "item_name"
    pattern_strategy: List[str] = field(default_factory=list)
    requirement_items: List[RequirementItem] = field(default_factory=list)
    pattern_index_mapping: List[PatternIndexMapping] = field(default_factory=list)
    waiver_items: List[str] = field(default_factory=list)
    waiver_keyword_taxonomy: List[WaiverKeywordTaxonomy] = field(default_factory=list)
    scenario_config: Dict[str, ScenarioText] = field(default_factory=dict)
    expected_outcomes: List[ExpectedOutcome] = field(default_factory=list)
    preferred_scenario: str = ""
    required_waivers_to_pass: List[str] = field(default_factory=list)

    def to_schema_dict(self) -> Dict[str, Any]:
        return {
            "item_id": self.item_id,
            "description": self.description,
            "check_module": self.check_module,
            "vio_name_format": self.vio_name_format,
            "stage_boundary": {
                "reads_input_files": True,
                "depends_on_itemspec": True,
                "depends_on_parsing_spec": True,
            },
            "requirement_items": [x.to_dict() for x in self.requirement_items],
            "pattern_index_mapping": [x.to_dict() for x in self.pattern_index_mapping],
            "waiver_items": list(self.waiver_items),
            "waiver_keyword_taxonomy": [x.to_dict() for x in self.waiver_keyword_taxonomy],
            "scenario_config": {k: v.to_dict() for k, v in self.scenario_config.items()},
            "expected_outcomes": [x.to_dict() for x in self.expected_outcomes],
            "current_evidence_recommendation": {
                "preferred_scenario": self.preferred_scenario,
                "required_waivers_to_pass": list(self.required_waivers_to_pass),
            },
        }

    @classmethod
    def from_embedded_yaml(cls, markdown: str) -> Optional["FormatSpecContract"]:
        root = extract_root_yaml(markdown, "format_spec")
        if not root:
            return None
        reqs = [RequirementItem.from_dict(x) for x in _as_list(root.get("requirement_items")) if isinstance(x, dict)]
        mapping = [PatternIndexMapping.from_dict(x) for x in _as_list(root.get("pattern_index_mapping")) if isinstance(x, dict)]
        taxonomy = [WaiverKeywordTaxonomy.from_dict(x) for x in _as_list(root.get("waiver_keyword_taxonomy")) if isinstance(x, dict)]
        
        # Handle nested pattern_index_mapping format with sub_items
        # Convert pattern_index_mapping[].sub_items[] to requirement_items[]
        for pim in _as_list(root.get("pattern_index_mapping")):
            if not isinstance(pim, dict):
                continue
            obj_name = _as_str(pim.get("target"))
            idx = int(pim.get("index", len(reqs)) or len(reqs))
            for si in _as_list(pim.get("sub_items")):
                if not isinstance(si, dict):
                    continue
                si_name = _as_str(si.get("name"))
                pattern = _as_str(si.get("pattern", "*"))
                if obj_name and si_name and not any(r.object_name == obj_name and r.sub_item == si_name for r in reqs):
                    reqs.append(RequirementItem(
                        requirement_id=f"R{len(reqs)+1}",
                        object_name=obj_name,
                        sub_item=si_name,
                        pattern=pattern,
                        comparator="glob",
                        source_evidence_ids=[]
                    ))
        
        # Also handle waiver_items in dict format: [{id, object, pattern, condition}]
        waiver_items_list = []
        for wi in _as_list(root.get("waiver_items")):
            if isinstance(wi, str):
                waiver_items_list.append(wi)
            elif isinstance(wi, dict):
                # Convert dict format to string format: "object:*" or use pattern
                wi_obj = _as_str(wi.get("object", ""))
                wi_pattern = _as_str(wi.get("pattern", "*"))
                if wi_obj:
                    waiver_items_list.append(f"{wi_obj}:*")
        
        scenario_payload = root.get("scenario_config", {}) or {}
        scenario_cfg: Dict[str, ScenarioText] = {}
        if isinstance(scenario_payload, dict):
            for key, value in scenario_payload.items():
                if isinstance(value, dict):
                    scenario_cfg[_as_str(key)] = ScenarioText.from_dict(value)
        outcomes = [ExpectedOutcome.from_dict(x) for x in _as_list(root.get("expected_outcomes")) if isinstance(x, dict)]

        recommendation = root.get("current_evidence_recommendation", {}) or {}
        return cls(
            item_id=_as_str(root.get("item_id")),
            description=_as_str(root.get("description")),
            check_module=_as_str(root.get("check_module")),
            vio_name_format=_as_str(root.get("vio_name_format"), "item_name"),
            requirement_items=reqs,
            pattern_index_mapping=mapping,
            waiver_items=waiver_items_list if waiver_items_list else [_as_str(x) for x in _as_list(root.get("waiver_items"))],
            waiver_keyword_taxonomy=taxonomy,
            scenario_config=scenario_cfg,
            expected_outcomes=outcomes,
            preferred_scenario=_as_str(recommendation.get("preferred_scenario")),
            required_waivers_to_pass=[_as_str(x) for x in _as_list(recommendation.get("required_waivers_to_pass"))],
        )


def collect_itemspec_subitem_contract(itemspec: ItemSpecContract) -> Dict[str, Dict[str, bool]]:
    """Return object -> sub_item -> required."""
    contract: Dict[str, Dict[str, bool]] = {}
    for target in itemspec.semantic_targets:
        rows = contract.setdefault(target.object_name, {})
        for sub in target.sub_items:
            rows[sub.name] = bool(sub.required)
    return contract


def collect_required_itemspec_subitems(itemspec: ItemSpecContract) -> List[Tuple[str, str]]:
    pairs: List[Tuple[str, str]] = []
    for target in itemspec.semantic_targets:
        for sub in target.sub_items:
            if sub.required:
                pairs.append((target.object_name, sub.name))
    return pairs
