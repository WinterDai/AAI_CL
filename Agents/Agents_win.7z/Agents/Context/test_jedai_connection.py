#!/usr/bin/env python3
"""
Test script to verify JEDAI LLM connection is working.
Run this script to confirm JEDAI gateway is accessible and responding.
"""

import sys
from pathlib import Path

# Add Agents root for imports
AGENTS_DIR = Path(__file__).resolve().parents[1]
if str(AGENTS_DIR) not in sys.path:
    sys.path.insert(0, str(AGENTS_DIR))

def test_jedai_basic():
    """Test basic JEDAI connection with a simple prompt."""
    print("=" * 60)
    print("JEDAI Connection Test")
    print("=" * 60)
    
    # Test 1: Import JedaiClient
    print("\n[Test 1] Importing JedaiClient...")
    try:
        from CodeGen.llm_client import JedaiClient
        print("  ✓ JedaiClient imported successfully")
    except ImportError as e:
        print(f"  ✗ Failed to import JedaiClient: {e}")
        return False
    
    # Test 2: Create client
    print("\n[Test 2] Creating JedaiClient...")
    try:
        client = JedaiClient(model="claude-opus-4-5")
        print(f"  ✓ JedaiClient created with model: claude-opus-4-5")
        print(f"    Base URL: {client.base_url if hasattr(client, 'base_url') else 'N/A'}")
    except Exception as e:
        print(f"  ✗ Failed to create JedaiClient: {e}")
        return False
    
    # Test 3: Simple generation
    print("\n[Test 3] Testing simple LLM call...")
    system_prompt = "You are a helpful assistant. Answer very briefly."
    user_prompt = "What is 2+2? Reply with just the number."
    
    print(f"  System: {system_prompt}")
    print(f"  User: {user_prompt}")
    print("  Calling JEDAI...")
    
    try:
        response = client.generate(system_prompt=system_prompt, user_prompt=user_prompt)
        print(f"  ✓ Response received!")
        print(f"  Response: {response[:200]}..." if len(response) > 200 else f"  Response: {response}")
    except Exception as e:
        print(f"  ✗ LLM call failed: {type(e).__name__}: {e}")
        return False
    
    # Test 4: Check response is reasonable
    print("\n[Test 4] Validating response...")
    if response and "4" in response:
        print("  ✓ Response contains expected answer '4'")
    else:
        print(f"  ? Response may not be correct (expected '4')")
    
    print("\n" + "=" * 60)
    print("All JEDAI tests PASSED!")
    print("=" * 60)
    return True


def test_jedai_markdown_generation():
    """Test JEDAI with a markdown generation task similar to Context Agent."""
    print("\n" + "=" * 60)
    print("JEDAI Markdown Generation Test")
    print("=" * 60)
    
    from CodeGen.llm_client import JedaiClient
    
    client = JedaiClient(model="claude-opus-4-5")
    
    system_prompt = """You are a technical documentation generator.
Generate a brief spec document in markdown format.
Include an embedded YAML block at the end."""

    user_prompt = """Generate a simple ItemSpec for a checker that verifies "file exists".

Requirements:
- Object: config_file
- Sub-items: file_path, file_size
- Keep it very brief (under 50 lines)
- Include embedded YAML at the end with:
  ```yaml
  itemspec:
    item_id: "TEST-001"
    objects:
      - name: "config_file"
  ```"""

    print("  Calling JEDAI for markdown generation...")
    
    try:
        response = client.generate(system_prompt=system_prompt, user_prompt=user_prompt)
        print(f"  ✓ Response received! Length: {len(response)} chars")
        
        # Check for expected content
        has_yaml = "```yaml" in response or "yaml" in response.lower()
        has_itemspec = "itemspec" in response.lower() or "item" in response.lower()
        
        print(f"  Has YAML block: {'✓' if has_yaml else '✗'}")
        print(f"  Has itemspec content: {'✓' if has_itemspec else '✗'}")
        
        print("\n--- Response Preview ---")
        lines = response.split('\n')
        for i, line in enumerate(lines[:30]):
            print(f"  {i+1:3}: {line}")
        if len(lines) > 30:
            print(f"  ... ({len(lines) - 30} more lines)")
        print("--- End Preview ---")
        
        return True
    except Exception as e:
        print(f"  ✗ Failed: {type(e).__name__}: {e}")
        return False


if __name__ == "__main__":
    print("\n" + "#" * 60)
    print("# JEDAI Integration Test Suite")
    print("#" * 60)
    
    # Run basic test
    basic_ok = test_jedai_basic()
    
    if basic_ok:
        # Run markdown generation test
        markdown_ok = test_jedai_markdown_generation()
    else:
        print("\nSkipping markdown test due to basic test failure.")
        markdown_ok = False
    
    print("\n" + "#" * 60)
    print("# Final Results")
    print("#" * 60)
    print(f"  Basic Connection: {'PASS' if basic_ok else 'FAIL'}")
    print(f"  Markdown Generation: {'PASS' if markdown_ok else 'FAIL'}")
    
    sys.exit(0 if (basic_ok and markdown_ok) else 1)
