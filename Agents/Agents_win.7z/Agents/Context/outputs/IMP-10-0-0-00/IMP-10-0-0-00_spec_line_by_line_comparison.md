# IMP-10-0-0-00 Full Line-by-Line Spec Comparison

This report covers every line mapping between old and new specs.

## Summary
| Spec | Old Lines | New Lines | SAME | REPLACE | OLD_ONLY | NEW_ONLY |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| itemspec | 128 | 145 | 11 | 23 | 94 | 111 |
| parsing_spec | 94 | 207 | 1 | 51 | 42 | 155 |
| format_spec | 162 | 100 | 14 | 38 | 110 | 48 |

## itemspec
| Status | Old# | New# | Old Text | New Text |
| --- | ---: | ---: | --- | --- |
| REPLACE | 1 | 1 | # ItemSpec: IMP-10-0-0-00 | # IMP-10-0-0-00 ItemSpec |
| SAME | 2 | 2 |  |  |
| REPLACE | 3 | 3 | **Description**: Confirm the netlist/spef version is correct. | Description: Confirm the netlist/spef version is correct. |
| NEW_ONLY |  | 4 |  | Check Module: 10.0_STA_DCD_CHECK |
| NEW_ONLY |  | 5 |  | Role: Senior digital physical implementation expert |
| SAME | 4 | 6 |  |  |
| REPLACE | 5 | 7 | --- | ## Scope |
| NEW_ONLY |  | 8 |  | This specification defines what must be checked semantically. It intentionally does not parse input files in this stage. |
| SAME | 6 | 9 |  |  |
| REPLACE | 7 | 10 | ## 专家视角解读 | ## Description Interpretation Rules |
| NEW_ONLY |  | 11 |  | - Slash notation defaults to logical AND across objects unless explicit `or` is present. |
| NEW_ONLY |  | 12 |  | - Explicit `or` denotes alternatives where at least one branch must satisfy the requirement. |
| NEW_ONLY |  | 13 |  | - Optional components are modeled as optional sub-items and may be governed by waiver contracts. |
| SAME | 8 | 14 |  |  |
| REPLACE | 9 | 15 | 基于 Context Agent 设计原则，"version is correct" 包含以下语义： | ## Semantic Targets |
| REPLACE | 10 | 16 | - **存在性**: 文件是否加载成功 (file_path, file_name) | \| Target ID \| Object \| Required Semantic Intent \| PASS Condition \| FAIL Condition \| |
| REPLACE | 11 | 17 | - **一致性**: netlist 和 SPEF 是否对应同一设计 (design_name) | \| --- \| --- \| --- \| --- \| --- \| |
| REPLACE | 12 | 18 | - **版本正确性**: 是否用正确工具/版本生成 (generator_tool/version) | \| T1 \| netlist \| Validate that `netlist` version-related evidence supports: Confirm the netlist/spef version is correct. \| Presence and semantic correctness are both supported by evidence. \| Missing evidence or conflicting evidence. \| |
| REPLACE | 13 | 19 | - **时效性**: 是否是当前 milestone 版本 (generation_time) | \| T2 \| spef \| Validate that `spef` version-related evidence supports: Confirm the netlist/spef version is correct. \| Presence and semantic correctness are both supported by evidence. \| Missing evidence or conflicting evidence. \| |
| SAME | 14 | 20 |  |  |
| REPLACE | 15 | 21 | --- | ### Object/Sub-Item Contract |
| NEW_ONLY |  | 22 |  | \| Object \| Sub-Item \| Required \| Semantic Meaning \| PASS Condition \| FAIL Condition \| |
| NEW_ONLY |  | 23 |  | \| --- \| --- \| --- \| --- \| --- \| --- \| |
| NEW_ONLY |  | 24 |  | \| netlist \| `status` \| mandatory \| Object has explicit load/check status \| Evidence confirms `status` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 25 |  | \| netlist \| `source_reference` \| mandatory \| Object can be traced to source file and line \| Evidence confirms `source_reference` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 26 |  | \| netlist \| `file_path` \| mandatory \| Resolved file path for this object \| Evidence confirms `file_path` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 27 |  | \| netlist \| `file_name` \| mandatory \| File name derived from file path \| Evidence confirms `file_name` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 28 |  | \| netlist \| `version_token` \| mandatory \| Version-like identifier for object correctness \| Evidence confirms `version_token` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 29 |  | \| netlist \| `generation_time` \| optional \| Timestamp used for version traceability \| Evidence confirms `generation_time` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 30 |  | \| netlist \| `generator_tool` \| optional \| Tool generating the netlist \| Evidence confirms `generator_tool` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 31 |  | \| netlist \| `generator_version` \| optional \| Tool version generating the netlist \| Evidence confirms `generator_version` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 32 |  | \| spef \| `status` \| mandatory \| Object has explicit load/check status \| Evidence confirms `status` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 33 |  | \| spef \| `source_reference` \| mandatory \| Object can be traced to source file and line \| Evidence confirms `source_reference` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 34 |  | \| spef \| `file_path` \| mandatory \| Resolved file path for this object \| Evidence confirms `file_path` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 35 |  | \| spef \| `file_name` \| mandatory \| File name derived from file path \| Evidence confirms `file_name` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 36 |  | \| spef \| `version_token` \| mandatory \| Version-like identifier for object correctness \| Evidence confirms `version_token` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 37 |  | \| spef \| `generation_time` \| optional \| Timestamp used for version traceability \| Evidence confirms `generation_time` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 38 |  | \| spef \| `extractor_tool` \| optional \| Tool generating SPEF extraction \| Evidence confirms `extractor_tool` semantics. \| Missing evidence or inconsistent semantics. \| |
| NEW_ONLY |  | 39 |  | \| spef \| `extractor_version` \| optional \| Tool version for SPEF extraction \| Evidence confirms `extractor_version` semantics. \| Missing evidence or inconsistent semantics. \| |
| SAME | 16 | 40 |  |  |
| REPLACE | 17 | 41 | ## Section 1: Parsing Logic | ## Check Criteria |
| NEW_ONLY |  | 42 |  | - Requirement value observed in item yaml: `N/A` |
| NEW_ONLY |  | 43 |  | - Waiver value observed in item yaml: `N/A` |
| NEW_ONLY |  | 44 |  | - A checker PASS requires every mandatory semantic target to satisfy its PASS condition. |
| NEW_ONLY |  | 45 |  | - A checker FAIL is triggered when any mandatory target fails and no valid waiver contract applies. |
| SAME | 18 | 46 |  |  |
| REPLACE | 19 | 47 | ### 1.1 数据源 | ## Evidence Plan |
| NEW_ONLY |  | 48 |  | - Stage B (ParsingSpec) must locate file-level evidence with line numbers. |
| NEW_ONLY |  | 49 |  | - Stage C (FormatSpec) must map extracted evidence into reusable requirement/waiver formats. |
| NEW_ONLY |  | 50 |  | - No direct input file reads are allowed in this stage. |
| SAME | 20 | 51 |  |  |
| REPLACE | 21 | 52 | \| 优先级 \| 数据源 \| 提取内容 \| | ## Knowledge Notes |
| REPLACE | 22 | 53 | \|--------\|--------\|----------\| | - score=1.484 source=`skills/IMP-10-0-0-00_skill.md` section=`Description` snippet="Confirm the netlist/spef version is correct." |
| REPLACE | 23 | 54 | \| Primary \| STA 日志 \| 加载命令、状态、top design \| | - score=1.430 source=`skills/IMP-10-0-0-00_skill.md` section=`Suggested retrieval queries` snippet="- IMP-10-0-0-00 checker intent Confirm the netlist/spef version is correct. - physical implementation netlist power_emir spef evidence extraction - input_logs parasitics power_integrity timing_signoff best practices" |
| REPLACE | 24 | 55 | \| Secondary \| netlist 文件头 \| generator_tool, generator_version, generation_time \| | - score=1.086 source=`skills/IMP-10-0-0-00_skill.md` section=`Embedded schema` snippet="```yaml skill_schema: item_id: IMP-10-0-0-00 check_module: 10.0_STA_DCD_CHECK intent: verification knowledge_tags: - input_logs - parasitics - power_integrity - timing_signoff candidate_objects: - netlist - power_emir - ..." |
| REPLACE | 25 | 56 | \| Secondary \| SPEF 文件头 \| extractor_tool, extractor_version, extraction_time \| | - score=1.058 source=`skills/IMP-10-0-0-00_skill.md` section=`Module and Intent` snippet="- Module: `10.0_STA_DCD_CHECK` - Intent: `verification` - Candidate objects: netlist, power_emir, spef - Knowledge tags: input_logs, parasitics, power_integrity, timing_signoff" |
| NEW_ONLY |  | 57 |  | - score=1.016 source=`skills/IMP-10-0-0-00_skill.md` section=`Input and Existing Implementation Clues` snippet="- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-00.yaml` - Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLI..." |
| NEW_ONLY |  | 58 |  | - score=0.931 source=`skills/IMP-10-0-0-00_skill.md` section=`Keyword clues from existing checker` snippet="- `# Confirm the netlist/spef version is correct.` - `# - Extract netlist file path from read_netlist command` - `# - Open extracted netlist file to capture version timestamp from header (line 3)` - `# - Open extracted S..." |
| NEW_ONLY |  | 59 |  | - score=0.848 source=`skills/IMP-10-0-0-00_skill.md` section=`Regex clues from existing checker` snippet="- `read_netlist\\s+([^\\s]+\\.v(?:\\.gz)?)` - `\\[INFO\\]\\s+Skipping SPEF reading as (.+)` - `read_spef\\s+([^\\s]+\\.spef(?:\\.gz)?)` - `#\\s*Parasitics Mode:\\s*(.+)` - `Top level cell is\\s+(\\S+)` - `Program version\\s*=\\s*([\\d\\.\\-..." |
| NEW_ONLY |  | 60 |  | - score=0.429 source=`skills/IMP-14-0-0-00_skill.md` section=`Suggested retrieval queries` snippet="- IMP-14-0-0-00 checker intent Confirm set the correct golden netlist. - physical implementation netlist power_emir evidence extraction - power_integrity best practices" |
| SAME | 26 | 61 |  |  |
| REPLACE | 27 | 62 | ### 1.2 检查对象和子项（全部必须） | ## Embedded Schema |
| OLD_ONLY | 28 |  |  |  |
| OLD_ONLY | 29 |  | #### 对象 1: netlist |  |
| OLD_ONLY | 30 |  |  |  |
| OLD_ONLY | 31 |  | \| 子项 \| 语义 \| 必须/可选 \| 提取来源 \| |  |
| OLD_ONLY | 32 |  | \|------\|------\|----------\|----------\| |  |
| OLD_ONLY | 33 |  | \| `file_path` \| 文件路径 \| **必须** \| STA日志 `read_netlist` \| |  |
| OLD_ONLY | 34 |  | \| `file_name` \| 文件名 \| **必须** \| 从 file_path 提取 \| |  |
| OLD_ONLY | 35 |  | \| `design_name` \| 顶层模块名 \| **必须** \| STA日志 `Top level cell` \| |  |
| OLD_ONLY | 36 |  | \| `generator_tool` \| 综合工具名 \| **必须** \| netlist 文件头 \| |  |
| OLD_ONLY | 37 |  | \| `generator_version` \| 综合工具版本 \| **必须** \| netlist 文件头 \| |  |
| OLD_ONLY | 38 |  | \| `generation_time` \| 生成时间 \| **必须** \| netlist 文件头 \| |  |
| OLD_ONLY | 39 |  |  |  |
| OLD_ONLY | 40 |  | #### 对象 2: spef |  |
| OLD_ONLY | 41 |  |  |  |
| OLD_ONLY | 42 |  | \| 子项 \| 语义 \| 必须/可选 \| 提取来源 \| |  |
| OLD_ONLY | 43 |  | \|------\|------\|----------\|----------\| |  |
| OLD_ONLY | 44 |  | \| `file_path` \| 文件路径 \| **必须** \| STA日志 `read_spef` \| |  |
| OLD_ONLY | 45 |  | \| `file_name` \| 文件名 \| **必须** \| 从 file_path 提取 \| |  |
| OLD_ONLY | 46 |  | \| `design_name` \| 设计名 \| **必须** \| SPEF 文件头 `*DESIGN` \| |  |
| OLD_ONLY | 47 |  | \| `extractor_tool` \| 提取工具名 \| **必须** \| SPEF 文件头 `*PROGRAM` \| |  |
| OLD_ONLY | 48 |  | \| `extractor_version` \| 提取工具版本 \| **必须** \| SPEF 文件头 `*VERSION` \| |  |
| OLD_ONLY | 49 |  | \| `extraction_time` \| 提取时间 \| **必须** \| SPEF 文件头 `*DATE` \| |  |
| OLD_ONLY | 50 |  |  |  |
| OLD_ONLY | 51 |  | ### 1.3 Parsing 规则 |  |
| OLD_ONLY | 52 |  |  |  |
| OLD_ONLY | 53 |  | - **任何必须项缺失** → ERROR |  |
| OLD_ONLY | 54 |  | - **对象整体缺失** (如 SPEF 被 skip) → 标记状态和原因，需 waiver |  |
| OLD_ONLY | 55 |  |  |  |
| OLD_ONLY | 56 |  | --- |  |
| OLD_ONLY | 57 |  |  |  |
| OLD_ONLY | 58 |  | ## Section 2: Requirement Definition |  |
| OLD_ONLY | 59 |  |  |  |
| OLD_ONLY | 60 |  | ### Requirement 格式 |  |
| OLD_ONLY | 61 |  |  |  |
| SAME | 62 | 63 | ```yaml | ```yaml |
| REPLACE | 63 | 64 | requirements: | itemspec: |
| REPLACE | 64 | 65 |   value: 2  # 2 个检查对象 |   item_id: IMP-10-0-0-00 |
| REPLACE | 65 | 66 |   items: |   description: "Confirm the netlist/spef version is correct." |
| REPLACE | 66 | 67 |     - "netlist: file_path; file_name; design_name; generator_tool; generator_version; generation_time" |   stage_boundary: |
| REPLACE | 67 | 68 |     - "spef: file_path; file_name; design_name; extractor_tool; extractor_version; extraction_time" |     reads_input_files: false |
| NEW_ONLY |  | 69 |  |     depends_on_input_snippets: false |
| NEW_ONLY |  | 70 |  |   semantic_targets: |
| NEW_ONLY |  | 71 |  |     - target_id: T1 |
| NEW_ONLY |  | 72 |  |       object_name: netlist |
| NEW_ONLY |  | 73 |  |       semantic_intent: "Validate that `netlist` version-related evidence supports: Confirm the netlist/spef version is correct." |
| NEW_ONLY |  | 74 |  |       sub_items: |
| NEW_ONLY |  | 75 |  |         - name: status |
| NEW_ONLY |  | 76 |  |           required: true |
| NEW_ONLY |  | 77 |  |           semantics: "Object has explicit load/check status" |
| NEW_ONLY |  | 78 |  |         - name: source_reference |
| NEW_ONLY |  | 79 |  |           required: true |
| NEW_ONLY |  | 80 |  |           semantics: "Object can be traced to source file and line" |
| NEW_ONLY |  | 81 |  |         - name: file_path |
| NEW_ONLY |  | 82 |  |           required: true |
| NEW_ONLY |  | 83 |  |           semantics: "Resolved file path for this object" |
| NEW_ONLY |  | 84 |  |         - name: file_name |
| NEW_ONLY |  | 85 |  |           required: true |
| NEW_ONLY |  | 86 |  |           semantics: "File name derived from file path" |
| NEW_ONLY |  | 87 |  |         - name: version_token |
| NEW_ONLY |  | 88 |  |           required: true |
| NEW_ONLY |  | 89 |  |           semantics: "Version-like identifier for object correctness" |
| NEW_ONLY |  | 90 |  |         - name: generation_time |
| NEW_ONLY |  | 91 |  |           required: false |
| NEW_ONLY |  | 92 |  |           semantics: "Timestamp used for version traceability" |
| NEW_ONLY |  | 93 |  |         - name: generator_tool |
| NEW_ONLY |  | 94 |  |           required: false |
| NEW_ONLY |  | 95 |  |           semantics: "Tool generating the netlist" |
| NEW_ONLY |  | 96 |  |         - name: generator_version |
| NEW_ONLY |  | 97 |  |           required: false |
| NEW_ONLY |  | 98 |  |           semantics: "Tool version generating the netlist" |
| NEW_ONLY |  | 99 |  |       required_evidence: |
| NEW_ONLY |  | 100 |  |         - source_file |
| NEW_ONLY |  | 101 |  |         - line_number |
| NEW_ONLY |  | 102 |  |         - extracted_value |
| NEW_ONLY |  | 103 |  |       pass_when: |
| NEW_ONLY |  | 104 |  |         - Required evidence exists and semantics are consistent |
| NEW_ONLY |  | 105 |  |       fail_when: |
| NEW_ONLY |  | 106 |  |         - Required evidence is missing or inconsistent |
| NEW_ONLY |  | 107 |  |     - target_id: T2 |
| NEW_ONLY |  | 108 |  |       object_name: spef |
| NEW_ONLY |  | 109 |  |       semantic_intent: "Validate that `spef` version-related evidence supports: Confirm the netlist/spef version is correct." |
| NEW_ONLY |  | 110 |  |       sub_items: |
| NEW_ONLY |  | 111 |  |         - name: status |
| NEW_ONLY |  | 112 |  |           required: true |
| NEW_ONLY |  | 113 |  |           semantics: "Object has explicit load/check status" |
| NEW_ONLY |  | 114 |  |         - name: source_reference |
| NEW_ONLY |  | 115 |  |           required: true |
| NEW_ONLY |  | 116 |  |           semantics: "Object can be traced to source file and line" |
| NEW_ONLY |  | 117 |  |         - name: file_path |
| NEW_ONLY |  | 118 |  |           required: true |
| NEW_ONLY |  | 119 |  |           semantics: "Resolved file path for this object" |
| NEW_ONLY |  | 120 |  |         - name: file_name |
| NEW_ONLY |  | 121 |  |           required: true |
| NEW_ONLY |  | 122 |  |           semantics: "File name derived from file path" |
| NEW_ONLY |  | 123 |  |         - name: version_token |
| NEW_ONLY |  | 124 |  |           required: true |
| NEW_ONLY |  | 125 |  |           semantics: "Version-like identifier for object correctness" |
| NEW_ONLY |  | 126 |  |         - name: generation_time |
| NEW_ONLY |  | 127 |  |           required: false |
| NEW_ONLY |  | 128 |  |           semantics: "Timestamp used for version traceability" |
| NEW_ONLY |  | 129 |  |         - name: extractor_tool |
| NEW_ONLY |  | 130 |  |           required: false |
| NEW_ONLY |  | 131 |  |           semantics: "Tool generating SPEF extraction" |
| NEW_ONLY |  | 132 |  |         - name: extractor_version |
| NEW_ONLY |  | 133 |  |           required: false |
| NEW_ONLY |  | 134 |  |           semantics: "Tool version for SPEF extraction" |
| NEW_ONLY |  | 135 |  |       required_evidence: |
| NEW_ONLY |  | 136 |  |         - source_file |
| NEW_ONLY |  | 137 |  |         - line_number |
| NEW_ONLY |  | 138 |  |         - extracted_value |
| NEW_ONLY |  | 139 |  |       pass_when: |
| NEW_ONLY |  | 140 |  |         - Required evidence exists and semantics are consistent |
| NEW_ONLY |  | 141 |  |       fail_when: |
| NEW_ONLY |  | 142 |  |         - Required evidence is missing or inconsistent |
| NEW_ONLY |  | 143 |  |   pass_rule: all mandatory semantic targets satisfy pass_when |
| NEW_ONLY |  | 144 |  |   fail_rule: any mandatory semantic target triggers fail_when |
| SAME | 68 | 145 | ``` | ``` |
| OLD_ONLY | 69 |  |  |  |
| OLD_ONLY | 70 |  | ### 一致性检查 |  |
| OLD_ONLY | 71 |  |  |  |
| OLD_ONLY | 72 |  | **关键**: `netlist.design_name` == `spef.design_name` |  |
| OLD_ONLY | 73 |  |  |  |
| OLD_ONLY | 74 |  | --- |  |
| OLD_ONLY | 75 |  |  |  |
| OLD_ONLY | 76 |  | ## Section 3: Waiver Logic |  |
| OLD_ONLY | 77 |  |  |  |
| OLD_ONLY | 78 |  | ### Waiver 与 Requirement 的关系 |  |
| OLD_ONLY | 79 |  |  |  |
| OLD_ONLY | 80 |  | \| Waiver 粒度 \| 格式 \| 示例 \| |  |
| OLD_ONLY | 81 |  | \|-------------\|------\|------\| |  |
| OLD_ONLY | 82 |  | \| 整个对象 \| `{object}:*` \| `spef:*` \| |  |
| OLD_ONLY | 83 |  | \| 特定子项 \| `{object}: {sub_item}` \| `netlist: generator_tool` \| |  |
| OLD_ONLY | 84 |  |  |  |
| OLD_ONLY | 85 |  | ### 典型场景 |  |
| OLD_ONLY | 86 |  |  |  |
| OLD_ONLY | 87 |  | \| 场景 \| Waiver \| 适用情况 \| |  |
| OLD_ONLY | 88 |  | \|------\|--------\|----------\| |  |
| OLD_ONLY | 89 |  | \| Post-synthesis \| `spef:*` \| SPEF 不存在 \| |  |
| OLD_ONLY | 90 |  | \| 无法读取文件头 \| `netlist: generator_*` \| 只能从日志提取 \| |  |
| OLD_ONLY | 91 |  |  |  |
| OLD_ONLY | 92 |  | --- |  |
| OLD_ONLY | 93 |  |  |  |
| OLD_ONLY | 94 |  | ## Section 4: 预期结果（Requirement & Waiver 组合） |  |
| OLD_ONLY | 95 |  |  |  |
| OLD_ONLY | 96 |  | ### 存在性检查 (Requirement = N/A) |  |
| OLD_ONLY | 97 |  |  |  |
| OLD_ONLY | 98 |  | \| Waiver \| netlist 状态 \| spef 状态 \| 结果 \| |  |
| OLD_ONLY | 99 |  | \|--------\|-------------\|----------\|------\| |  |
| OLD_ONLY | 100 |  | \| N/A \| 6/6 ✓ \| 6/6 ✓ \| PASS \| |  |
| OLD_ONLY | 101 |  | \| N/A \| 6/6 ✓ \| 0/6 ✗ \| FAIL \| |  |
| OLD_ONLY | 102 |  | \| N/A \| 0/6 ✗ \| 6/6 ✓ \| FAIL \| |  |
| OLD_ONLY | 103 |  | \| N/A \| 0/6 ✗ \| 0/6 ✗ \| FAIL \| |  |
| OLD_ONLY | 104 |  | \| `spef:*` \| 6/6 ✓ \| 0/6 ✗ \| PASS \| |  |
| OLD_ONLY | 105 |  | \| `netlist:*` \| 0/6 ✗ \| 6/6 ✓ \| PASS \| |  |
| OLD_ONLY | 106 |  | \| `spef:*` + `netlist:*` \| 0/6 ✗ \| 0/6 ✗ \| PASS \| |  |
| OLD_ONLY | 107 |  |  |  |
| OLD_ONLY | 108 |  | ### 匹配性检查 (Requirement = value:2) |  |
| OLD_ONLY | 109 |  |  |  |
| OLD_ONLY | 110 |  | \| Waiver \| netlist 状态 \| spef 状态 \| 结果 \| |  |
| OLD_ONLY | 111 |  | \|--------\|-------------\|----------\|------\| |  |
| OLD_ONLY | 112 |  | \| N/A \| 匹配 \| 匹配 \| PASS \| |  |
| OLD_ONLY | 113 |  | \| N/A \| 匹配 \| 不匹配 \| FAIL \| |  |
| OLD_ONLY | 114 |  | \| N/A \| 不匹配 \| 匹配 \| FAIL \| |  |
| OLD_ONLY | 115 |  | \| `spef:*` \| 匹配 \| 不匹配 \| PASS \| |  |
| OLD_ONLY | 116 |  | \| `netlist:*` \| 不匹配 \| 匹配 \| PASS \| |  |
| OLD_ONLY | 117 |  |  |  |
| OLD_ONLY | 118 |  | ### 当前测试场景 |  |
| OLD_ONLY | 119 |  |  |  |
| OLD_ONLY | 120 |  | - netlist: 6/6 ✓ |  |
| OLD_ONLY | 121 |  | - spef: 0/6 ✗ (Post-synthesis) |  |
| OLD_ONLY | 122 |  | - 推荐 waiver: `spef:*` |  |
| OLD_ONLY | 123 |  | - 预期结果: PASS |  |
| OLD_ONLY | 124 |  |  |  |
| OLD_ONLY | 125 |  | --- |  |
| OLD_ONLY | 126 |  |  |  |
| OLD_ONLY | 127 |  | *Generated by Context Agent* |  |
| OLD_ONLY | 128 |  | *Date: 2026-02-05* |  |

## parsing_spec
| Status | Old# | New# | Old Text | New Text |
| --- | ---: | ---: | --- | --- |
| REPLACE | 1 | 1 | # Parsing Spec: IMP-10-0-0-00 | # IMP-10-0-0-00 ParsingSpec |
| REPLACE | 2 | 2 |  |  |
| REPLACE | 3 | 3 | ## 概述 | Description: Confirm the netlist/spef version is correct. |
| REPLACE | 4 | 4 |  | Check Module: 10.0_STA_DCD_CHECK |
| REPLACE | 5 | 5 | 基于 **ItemSpec** 定义的检查对象和子项，从 input file 中提取实际文本。 |  |
| REPLACE | 6 | 6 |  | ## Input Resolution |
| REPLACE | 7 | 7 | --- | Resolved inputs: |
| REPLACE | 8 | 8 |  | - /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| REPLACE | 9 | 9 | ## 源文件信息 |  |
| REPLACE | 10 | 10 |  | Missing inputs: |
| REPLACE | 11 | 11 | **STA 日志**: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log` (127 lines) | - (none) |
| REPLACE | 12 | 12 |  |  |
| REPLACE | 13 | 13 | **Netlist 文件**: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | ## Evidence Inventory |
| REPLACE | 14 | 14 |  | \| Source File \| Line \| Pattern \| Extracted Values \| Raw Line \| |
| REPLACE | 15 | 15 | --- | \| --- \| --- \| --- \| --- \| --- \| |
| REPLACE | 16 | 16 |  | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 6 \| `read_netlist\s+([^\s]+\.v(?:\.gz)?)` \| `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` \| `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` \| |
| REPLACE | 17 | 17 | ## ItemSpec 要求 vs 实际提取 | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 6 \| `read_netlist\s+([^\s]+)` \| `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` \| `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` \| |
| REPLACE | 18 | 18 |  | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 7 \| `\bnetlist\b` \| `-` \| `#% Begin Load netlist data ... (date=11/17 14:24:59, mem=1874.7M)` \| |
| REPLACE | 19 | 19 | ### netlist 对象 (6 个必须子项) | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 8 \| `\bnetlist\b` \| `-` \| `*** Begin netlist parsing (mem=2584.0M) ***` \| |
| REPLACE | 20 | 20 |  | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 9 \| `\bnetlist\b` \| `-` \| `Reading verilog netlist '/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz'` \| |
| REPLACE | 21 | 21 | \| 子项 \| 必须 \| 提取状态 \| 来源 \| 行号 \| 提取值 \| | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 12 \| `\bnetlist\b` \| `-` \| `*** End netlist parsing (cpu=0:00:00.2, real=0:00:00.0, mem=2924.0M) ***` \| |
| REPLACE | 22 | 22 | \|------\|------\|----------\|------\|------\|--------\| | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 13 \| `\bnetlist\b` \| `-` \| `#% End Load netlist data ... (date=11/17 14:24:59, total cpu=0:00:00.6, real=0:00:00.0, peak res=2395.9M, current mem=2395.9M)` \| |
| REPLACE | 23 | 23 | \| `file_path` \| ✓ \| ✓ 已提取 \| STA日志 \| 6 \| `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` \| | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 14 \| `Top level cell is\s+(\S+)` \| `phy_cmn_phase_align_digtop.` \| `Top level cell is phy_cmn_phase_align_digtop.` \| |
| REPLACE | 24 | 24 | \| `file_name` \| ✓ \| ✓ 已提取 \| STA日志 \| 6 \| `phy_cmn_phase_align_digtop.v.gz` \| | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 15 \| `\bnetlist\b` \| `-` \| `Building hierarchical netlist for Cell phy_cmn_phase_align_digtop ...` \| |
| REPLACE | 25 | 25 | \| `design_name` \| ✓ \| ✓ 已提取 \| STA日志 \| 14 \| `phy_cmn_phase_align_digtop` \| | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 22 \| `\[INFO\]\s+Skipping SPEF reading as (.+)` \| `we are writing post-synthesis SDF files` \| `[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files` \| |
| REPLACE | 26 | 26 | \| `generator_tool` \| ✓ \| ✓ 已提取 \| netlist头 \| 1 \| `Cadence Genus(TM) Synthesis Solution` \| | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 22 \| `Skipping SPEF reading as\s+(.+)` \| `we are writing post-synthesis SDF files` \| `[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files` \| |
| REPLACE | 27 | 27 | \| `generator_version` \| ✓ \| ✓ 已提取 \| netlist头 \| 1 \| `23.15-s099_1` \| | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 44 \| `Program version\s*=\s*([\d\.\-\w]+)` \| `23.15-s108_1` \| `Program version = 23.15-s108_1` \| |
| REPLACE | 28 | 28 | \| `generation_time` \| ✓ \| ✓ 已提取 \| netlist头 \| 2 \| `Nov 18 2025 15:58:15 IST` \| | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 44 \| `Program version\s*=\s*([\w\.-]+)` \| `23.15-s108_1` \| `Program version = 23.15-s108_1` \| |
| REPLACE | 29 | 29 |  | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 44 \| `\bversion\b` \| `-` \| `Program version = 23.15-s108_1` \| |
| REPLACE | 30 | 30 | **netlist 状态**: 6/6 必须项提取成功 ✓ | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log \| 62 \| `#\s*Parasitics Mode:\s*(.+)` \| `No SPEF/RCDB` \| `# Parasitics Mode: No SPEF/RCDB` \| |
| REPLACE | 31 | 31 |  |  |
| REPLACE | 32 | 32 | ### spef 对象 (6 个必须子项) | ## Referenced Files |
| REPLACE | 33 | 33 |  | \| Source File \| Line \| Pattern \| Extracted Values \| Raw Line \| |
| REPLACE | 34 | 34 | \| 子项 \| 必须 \| 提取状态 \| 来源 \| 行号 \| 提取值 \| | \| --- \| --- \| --- \| --- \| --- \| |
| REPLACE | 35 | 35 | \|------\|------\|----------\|------\|------\|--------\| | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz \| 2 \| `Generated by\s+(.+)` \| `Cadence Genus(TM) Synthesis Solution 23.15-s099_1` \| `// Generated by Cadence Genus(TM) Synthesis Solution 23.15-s099_1` \| |
| REPLACE | 36 | 36 | \| `file_path` \| ✓ \| ✗ ERROR \| STA日志 \| 22 \| (SPEF 被 skip) \| | \| /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz \| 3 \| `Generated on:\s+(.+)` \| `Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC)` \| `// Generated on: Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC)` \| |
| REPLACE | 37 | 37 | \| `file_name` \| ✓ \| ✗ ERROR \| - \| - \| (SPEF 被 skip) \| |  |
| REPLACE | 38 | 38 | \| `design_name` \| ✓ \| ✗ ERROR \| - \| - \| (SPEF 被 skip) \| | ## Evidence to Sub-Item Mapping |
| REPLACE | 39 | 39 | \| `extractor_tool` \| ✓ \| ✗ ERROR \| - \| - \| (SPEF 被 skip) \| | \| Evidence ID \| Candidate Object \| Candidate Sub-Item \| Rationale \| |
| REPLACE | 40 | 40 | \| `extractor_version` \| ✓ \| ✗ ERROR \| - \| - \| (SPEF 被 skip) \| | \| --- \| --- \| --- \| --- \| |
| REPLACE | 41 | 41 | \| `extraction_time` \| ✓ \| ✗ ERROR \| - \| - \| (SPEF 被 skip) \| | \| EV1 \| `netlist` \| `file_path` \| Path-like evidence from read_netlist command. \| |
| REPLACE | 42 | 42 |  | \| EV2 \| `netlist` \| `file_path` \| Path-like evidence from read_netlist command. \| |
| REPLACE | 43 | 43 | **spef 状态**: 0/6 必须项提取成功，对象整体缺失 | \| EV3 \| `netlist` \| `status` \| Default mapping based on generic status evidence. \| |
| REPLACE | 44 | 44 | **缺失原因**: `we are writing post-synthesis SDF files` | \| EV4 \| `netlist` \| `status` \| Default mapping based on generic status evidence. \| |
| REPLACE | 45 | 45 |  | \| EV5 \| `netlist` \| `file_path` \| Path-like evidence from read_netlist command. \| |
| REPLACE | 46 | 46 | --- | \| EV6 \| `netlist` \| `status` \| Default mapping based on generic status evidence. \| |
| REPLACE | 47 | 47 |  | \| EV7 \| `netlist` \| `status` \| Default mapping based on generic status evidence. \| |
| REPLACE | 48 | 48 | ## 提取的实际文本 | \| EV8 \| `netlist` \| `design_name` \| Design identity evidence from top-level cell message. \| |
| REPLACE | 49 | 49 |  | \| EV9 \| `netlist` \| `status` \| Default mapping based on generic status evidence. \| |
| REPLACE | 50 | 50 | ### netlist.file_path, netlist.file_name (STA日志 Line 6) | \| EV10 \| `spef` \| `status_reason` \| Failure/missing indicator requiring waiver or failure handling. \| |
| REPLACE | 51 | 51 |  | \| EV11 \| `spef` \| `status_reason` \| Failure/missing indicator requiring waiver or failure handling. \| |
| NEW_ONLY |  | 52 |  | \| EV12 \| `netlist` \| `tool_version` \| Tool version extracted from STA log metadata. \| |
| NEW_ONLY |  | 53 |  | \| EV13 \| `netlist` \| `tool_version` \| Tool version extracted from STA log metadata. \| |
| NEW_ONLY |  | 54 |  | \| EV14 \| `netlist` \| `tool_version` \| Tool version extracted from STA log metadata. \| |
| NEW_ONLY |  | 55 |  | \| EV15 \| `spef` \| `status` \| Default mapping based on generic status evidence. \| |
| NEW_ONLY |  | 56 |  |  |
| NEW_ONLY |  | 57 |  | ## Extraction Gaps |
| NEW_ONLY |  | 58 |  | - (none) |
| NEW_ONLY |  | 59 |  |  |
| NEW_ONLY |  | 60 |  | ## Embedded Schema |
| NEW_ONLY |  | 61 |  | ```yaml |
| NEW_ONLY |  | 62 |  | parsing_spec: |
| NEW_ONLY |  | 63 |  |   item_id: IMP-10-0-0-00 |
| NEW_ONLY |  | 64 |  |   stage_boundary: |
| NEW_ONLY |  | 65 |  |     reads_input_files: true |
| NEW_ONLY |  | 66 |  |     depends_on_itemspec: true |
| NEW_ONLY |  | 67 |  |   resolved_inputs: |
| NEW_ONLY |  | 68 |  |     - /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 69 |  |   missing_inputs: [] |
| NEW_ONLY |  | 70 |  |   evidence_records: |
| NEW_ONLY |  | 71 |  |     - evidence_id: EV1 |
| NEW_ONLY |  | 72 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 73 |  |       line_number: 6 |
| NEW_ONLY |  | 74 |  |       pattern: "read_netlist\\s+([^\\s]+\\.v(?:\\.gz)?)" |
| NEW_ONLY |  | 75 |  |       extracted: "/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz" |
| NEW_ONLY |  | 76 |  |     - evidence_id: EV2 |
| NEW_ONLY |  | 77 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 78 |  |       line_number: 6 |
| NEW_ONLY |  | 79 |  |       pattern: "read_netlist\\s+([^\\s]+)" |
| NEW_ONLY |  | 80 |  |       extracted: "/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz" |
| NEW_ONLY |  | 81 |  |     - evidence_id: EV3 |
| NEW_ONLY |  | 82 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 83 |  |       line_number: 7 |
| NEW_ONLY |  | 84 |  |       pattern: "\\bnetlist\\b" |
| NEW_ONLY |  | 85 |  |       extracted: "#% Begin Load netlist data ... (date=11/17 14:24:59, mem=1874.7M)" |
| NEW_ONLY |  | 86 |  |     - evidence_id: EV4 |
| NEW_ONLY |  | 87 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 88 |  |       line_number: 8 |
| NEW_ONLY |  | 89 |  |       pattern: "\\bnetlist\\b" |
| NEW_ONLY |  | 90 |  |       extracted: "*** Begin netlist parsing (mem=2584.0M) ***" |
| NEW_ONLY |  | 91 |  |     - evidence_id: EV5 |
| NEW_ONLY |  | 92 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 93 |  |       line_number: 9 |
| NEW_ONLY |  | 94 |  |       pattern: "\\bnetlist\\b" |
| NEW_ONLY |  | 95 |  |       extracted: "Reading verilog netlist '/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz'" |
| NEW_ONLY |  | 96 |  |     - evidence_id: EV6 |
| NEW_ONLY |  | 97 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 98 |  |       line_number: 12 |
| NEW_ONLY |  | 99 |  |       pattern: "\\bnetlist\\b" |
| NEW_ONLY |  | 100 |  |       extracted: "*** End netlist parsing (cpu=0:00:00.2, real=0:00:00.0, mem=2924.0M) ***" |
| NEW_ONLY |  | 101 |  |     - evidence_id: EV7 |
| NEW_ONLY |  | 102 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 103 |  |       line_number: 13 |
| NEW_ONLY |  | 104 |  |       pattern: "\\bnetlist\\b" |
| NEW_ONLY |  | 105 |  |       extracted: "#% End Load netlist data ... (date=11/17 14:24:59, total cpu=0:00:00.6, real=0:00:00.0, peak res=2395.9M, current mem=2395.9M)" |
| NEW_ONLY |  | 106 |  |     - evidence_id: EV8 |
| NEW_ONLY |  | 107 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 108 |  |       line_number: 14 |
| NEW_ONLY |  | 109 |  |       pattern: "Top level cell is\\s+(\\S+)" |
| NEW_ONLY |  | 110 |  |       extracted: "phy_cmn_phase_align_digtop." |
| NEW_ONLY |  | 111 |  |     - evidence_id: EV9 |
| NEW_ONLY |  | 112 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 113 |  |       line_number: 15 |
| NEW_ONLY |  | 114 |  |       pattern: "\\bnetlist\\b" |
| NEW_ONLY |  | 115 |  |       extracted: "Building hierarchical netlist for Cell phy_cmn_phase_align_digtop ..." |
| NEW_ONLY |  | 116 |  |     - evidence_id: EV10 |
| NEW_ONLY |  | 117 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 118 |  |       line_number: 22 |
| NEW_ONLY |  | 119 |  |       pattern: "\\[INFO\\]\\s+Skipping SPEF reading as (.+)" |
| NEW_ONLY |  | 120 |  |       extracted: "we are writing post-synthesis SDF files" |
| NEW_ONLY |  | 121 |  |     - evidence_id: EV11 |
| NEW_ONLY |  | 122 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 123 |  |       line_number: 22 |
| NEW_ONLY |  | 124 |  |       pattern: "Skipping SPEF reading as\\s+(.+)" |
| NEW_ONLY |  | 125 |  |       extracted: "we are writing post-synthesis SDF files" |
| NEW_ONLY |  | 126 |  |     - evidence_id: EV12 |
| NEW_ONLY |  | 127 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 128 |  |       line_number: 44 |
| NEW_ONLY |  | 129 |  |       pattern: "Program version\\s*=\\s*([\\d\\.\\-\\w]+)" |
| NEW_ONLY |  | 130 |  |       extracted: "23.15-s108_1" |
| NEW_ONLY |  | 131 |  |     - evidence_id: EV13 |
| NEW_ONLY |  | 132 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 133 |  |       line_number: 44 |
| NEW_ONLY |  | 134 |  |       pattern: "Program version\\s*=\\s*([\\w\\.-]+)" |
| NEW_ONLY |  | 135 |  |       extracted: "23.15-s108_1" |
| NEW_ONLY |  | 136 |  |     - evidence_id: EV14 |
| NEW_ONLY |  | 137 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 138 |  |       line_number: 44 |
| NEW_ONLY |  | 139 |  |       pattern: "\\bversion\\b" |
| NEW_ONLY |  | 140 |  |       extracted: "Program version = 23.15-s108_1" |
| NEW_ONLY |  | 141 |  |     - evidence_id: EV15 |
| NEW_ONLY |  | 142 |  |       source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log |
| NEW_ONLY |  | 143 |  |       line_number: 62 |
| NEW_ONLY |  | 144 |  |       pattern: "#\\s*Parasitics Mode:\\s*(.+)" |
| NEW_ONLY |  | 145 |  |       extracted: "No SPEF/RCDB" |
| NEW_ONLY |  | 146 |  |   evidence_to_sub_item: |
| NEW_ONLY |  | 147 |  |     - evidence_id: EV1 |
| NEW_ONLY |  | 148 |  |       object: netlist |
| NEW_ONLY |  | 149 |  |       sub_item: file_path |
| NEW_ONLY |  | 150 |  |       rationale: "Path-like evidence from read_netlist command." |
| NEW_ONLY |  | 151 |  |     - evidence_id: EV2 |
| NEW_ONLY |  | 152 |  |       object: netlist |
| NEW_ONLY |  | 153 |  |       sub_item: file_path |
| NEW_ONLY |  | 154 |  |       rationale: "Path-like evidence from read_netlist command." |
| NEW_ONLY |  | 155 |  |     - evidence_id: EV3 |
| NEW_ONLY |  | 156 |  |       object: netlist |
| NEW_ONLY |  | 157 |  |       sub_item: status |
| NEW_ONLY |  | 158 |  |       rationale: "Default mapping based on generic status evidence." |
| NEW_ONLY |  | 159 |  |     - evidence_id: EV4 |
| NEW_ONLY |  | 160 |  |       object: netlist |
| NEW_ONLY |  | 161 |  |       sub_item: status |
| NEW_ONLY |  | 162 |  |       rationale: "Default mapping based on generic status evidence." |
| NEW_ONLY |  | 163 |  |     - evidence_id: EV5 |
| NEW_ONLY |  | 164 |  |       object: netlist |
| NEW_ONLY |  | 165 |  |       sub_item: file_path |
| NEW_ONLY |  | 166 |  |       rationale: "Path-like evidence from read_netlist command." |
| NEW_ONLY |  | 167 |  |     - evidence_id: EV6 |
| NEW_ONLY |  | 168 |  |       object: netlist |
| NEW_ONLY |  | 169 |  |       sub_item: status |
| NEW_ONLY |  | 170 |  |       rationale: "Default mapping based on generic status evidence." |
| NEW_ONLY |  | 171 |  |     - evidence_id: EV7 |
| NEW_ONLY |  | 172 |  |       object: netlist |
| NEW_ONLY |  | 173 |  |       sub_item: status |
| NEW_ONLY |  | 174 |  |       rationale: "Default mapping based on generic status evidence." |
| NEW_ONLY |  | 175 |  |     - evidence_id: EV8 |
| NEW_ONLY |  | 176 |  |       object: netlist |
| NEW_ONLY |  | 177 |  |       sub_item: design_name |
| NEW_ONLY |  | 178 |  |       rationale: "Design identity evidence from top-level cell message." |
| NEW_ONLY |  | 179 |  |     - evidence_id: EV9 |
| NEW_ONLY |  | 180 |  |       object: netlist |
| NEW_ONLY |  | 181 |  |       sub_item: status |
| NEW_ONLY |  | 182 |  |       rationale: "Default mapping based on generic status evidence." |
| NEW_ONLY |  | 183 |  |     - evidence_id: EV10 |
| NEW_ONLY |  | 184 |  |       object: spef |
| NEW_ONLY |  | 185 |  |       sub_item: status_reason |
| NEW_ONLY |  | 186 |  |       rationale: "Failure/missing indicator requiring waiver or failure handling." |
| NEW_ONLY |  | 187 |  |     - evidence_id: EV11 |
| NEW_ONLY |  | 188 |  |       object: spef |
| NEW_ONLY |  | 189 |  |       sub_item: status_reason |
| NEW_ONLY |  | 190 |  |       rationale: "Failure/missing indicator requiring waiver or failure handling." |
| NEW_ONLY |  | 191 |  |     - evidence_id: EV12 |
| NEW_ONLY |  | 192 |  |       object: netlist |
| NEW_ONLY |  | 193 |  |       sub_item: tool_version |
| NEW_ONLY |  | 194 |  |       rationale: "Tool version extracted from STA log metadata." |
| NEW_ONLY |  | 195 |  |     - evidence_id: EV13 |
| NEW_ONLY |  | 196 |  |       object: netlist |
| NEW_ONLY |  | 197 |  |       sub_item: tool_version |
| NEW_ONLY |  | 198 |  |       rationale: "Tool version extracted from STA log metadata." |
| NEW_ONLY |  | 199 |  |     - evidence_id: EV14 |
| NEW_ONLY |  | 200 |  |       object: netlist |
| NEW_ONLY |  | 201 |  |       sub_item: tool_version |
| NEW_ONLY |  | 202 |  |       rationale: "Tool version extracted from STA log metadata." |
| NEW_ONLY |  | 203 |  |     - evidence_id: EV15 |
| NEW_ONLY |  | 204 |  |       object: spef |
| NEW_ONLY |  | 205 |  |       sub_item: status |
| NEW_ONLY |  | 206 |  |       rationale: "Default mapping based on generic status evidence." |
| SAME | 52 | 207 | ``` | ``` |
| OLD_ONLY | 53 |  | <CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz |  |
| OLD_ONLY | 54 |  | ``` |  |
| OLD_ONLY | 55 |  |  |  |
| OLD_ONLY | 56 |  | ### netlist.design_name (STA日志 Line 14) |  |
| OLD_ONLY | 57 |  |  |  |
| OLD_ONLY | 58 |  | ``` |  |
| OLD_ONLY | 59 |  | Top level cell is phy_cmn_phase_align_digtop. |  |
| OLD_ONLY | 60 |  | ``` |  |
| OLD_ONLY | 61 |  |  |  |
| OLD_ONLY | 62 |  | ### netlist.generator_tool, generator_version (netlist文件 Line 1) |  |
| OLD_ONLY | 63 |  |  |  |
| OLD_ONLY | 64 |  | ``` |  |
| OLD_ONLY | 65 |  | // Generated by Cadence Genus(TM) Synthesis Solution 23.15-s099_1 |  |
| OLD_ONLY | 66 |  | ``` |  |
| OLD_ONLY | 67 |  |  |  |
| OLD_ONLY | 68 |  | ### netlist.generation_time (netlist文件 Line 2) |  |
| OLD_ONLY | 69 |  |  |  |
| OLD_ONLY | 70 |  | ``` |  |
| OLD_ONLY | 71 |  | // Generated on: Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC) |  |
| OLD_ONLY | 72 |  | ``` |  |
| OLD_ONLY | 73 |  |  |  |
| OLD_ONLY | 74 |  | ### spef 状态 (STA日志 Line 22) |  |
| OLD_ONLY | 75 |  |  |  |
| OLD_ONLY | 76 |  | ``` |  |
| OLD_ONLY | 77 |  | [INFO] Skipping SPEF reading as we are writing post-synthesis SDF files |  |
| OLD_ONLY | 78 |  | ``` |  |
| OLD_ONLY | 79 |  |  |  |
| OLD_ONLY | 80 |  | --- |  |
| OLD_ONLY | 81 |  |  |  |
| OLD_ONLY | 82 |  | ## 提取状态总结 |  |
| OLD_ONLY | 83 |  |  |  |
| OLD_ONLY | 84 |  | \| 类别 \| 对象 \| 子项 \| 数量 \| |  |
| OLD_ONLY | 85 |  | \|------\|------\|------\|------\| |  |
| OLD_ONLY | 86 |  | \| ✓ 成功 \| netlist \| file_path, file_name, design_name, generator_tool/version/time \| 6 \| |  |
| OLD_ONLY | 87 |  | \| ✗ ERROR \| spef \| 全部 \| 6 \| |  |
| OLD_ONLY | 88 |  |  |  |
| OLD_ONLY | 89 |  | **总计**: 6/12 必须项提取成功 |  |
| OLD_ONLY | 90 |  |  |  |
| OLD_ONLY | 91 |  | --- |  |
| OLD_ONLY | 92 |  |  |  |
| OLD_ONLY | 93 |  | *Generated by CodeGen Agent* |  |
| OLD_ONLY | 94 |  | *Date: 2026-02-04* |  |

## format_spec
| Status | Old# | New# | Old Text | New Text |
| --- | ---: | ---: | --- | --- |
| REPLACE | 1 | 1 | # Format Spec: IMP-10-0-0-00 | # IMP-10-0-0-00 FormatSpec |
| SAME | 2 | 2 |  |  |
| REPLACE | 3 | 3 | ## 概述 | Description: Confirm the netlist/spef version is correct. |
| NEW_ONLY |  | 4 |  | Check Module: 10.0_STA_DCD_CHECK |
| NEW_ONLY |  | 5 |  | vio_name_format: "item_name" |
| SAME | 4 | 6 |  |  |
| REPLACE | 5 | 7 | 基于 **ItemSpec Section 4** 预期结果和 **Parsing Spec** 实际提取结果，生成四种场景的具体配置。 | ## Pattern Strategy |
| NEW_ONLY |  | 8 |  | - `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` -> `*/dbs/*.v.gz` |
| NEW_ONLY |  | 9 |  | - `23.15-s108_1` -> `<version_token>` |
| SAME | 6 | 10 |  |  |
| REPLACE | 7 | 11 | --- | ## Requirement Items |
| NEW_ONLY |  | 12 |  | - `*/dbs/*.v.gz` |
| NEW_ONLY |  | 13 |  | - `<version_token>` |
| NEW_ONLY |  | 14 |  | - `<timestamp>` |
| SAME | 8 | 15 |  |  |
| REPLACE | 9 | 16 | ## Parsing 实际结果 | ## Pattern Index Mapping |
| NEW_ONLY |  | 17 |  | - `pattern_items[0]` -> */dbs/*.v.gz |
| NEW_ONLY |  | 18 |  | - `pattern_items[1]` -> <version_token> |
| NEW_ONLY |  | 19 |  | - `pattern_items[2]` -> <timestamp> |
| SAME | 10 | 20 |  |  |
| REPLACE | 11 | 21 | \| 对象 \| 状态 \| 结论 \| | ## Waiver Items |
| REPLACE | 12 | 22 | \|------\|------\|------\| | - `netlist:*` |
| REPLACE | 13 | 23 | \| netlist \| 6/6 ✓ \| 提取成功 \| | - `spef:*` |
| OLD_ONLY | 14 |  | \| spef \| 0/6 ✗ \| 整体缺失 (Post-synthesis) \| |  |
| SAME | 15 | 24 |  |  |
| REPLACE | 16 | 25 | --- | ## Waiver Keyword Taxonomy |
| NEW_ONLY |  | 26 |  | - scenario: `netlist_waiver` \| keywords: `netlist, waive, exception, approved, version` \| sample_reason: "netlist mismatch accepted by stage-specific design review." |
| NEW_ONLY |  | 27 |  | - scenario: `spef_waiver` \| keywords: `spef, waive, exception, approved, version, post-synthesis` \| sample_reason: "spef mismatch accepted by stage-specific design review." |
| NEW_ONLY |  | 28 |  | - scenario: `configured_netlist_all` \| keywords: `netlist:*, configured_waiver` \| sample_reason: "Configured waiver item provided by item yaml." |
| NEW_ONLY |  | 29 |  | - scenario: `configured_spef_all` \| keywords: `spef:*, configured_waiver` \| sample_reason: "Configured waiver item provided by item yaml." |
| SAME | 17 | 30 |  |  |
| REPLACE | 18 | 31 | ## 格式特征（基于 Parsing 提取值） | ## Scenario Matrix |
| NEW_ONLY |  | 32 |  | ### Scenario 1 (req=N/A, waiver=N/A) |
| NEW_ONLY |  | 33 |  | - found_desc: "Required evidence extracted and semantically valid" |
| NEW_ONLY |  | 34 |  | - missing_desc: "Required evidence missing or semantically invalid" |
| NEW_ONLY |  | 35 |  | - found_reason: "Parsing evidence supports checker intent" |
| NEW_ONLY |  | 36 |  | - missing_reason: "Parsing evidence does not satisfy checker intent" |
| SAME | 19 | 37 |  |  |
| REPLACE | 20 | 38 | \| 对象 \| 子项 \| 格式特征 \| | ### Scenario 2 (req=N/A, waiver>0) |
| REPLACE | 21 | 39 | \|------\|------\|----------\| | - found_desc: "Required evidence extracted and semantically valid" |
| REPLACE | 22 | 40 | \| netlist \| file_path \| `*/dbs/*.v.gz` \| | - missing_desc: "Required evidence missing or semantically invalid" |
| REPLACE | 23 | 41 | \| netlist \| file_name \| `*.v.gz` \| | - waived_desc: "Violation waived by configured waiver items" |
| REPLACE | 24 | 42 | \| netlist \| design_name \| (模块名) \| | - unused_desc: "Unused waiver entries" |
| REPLACE | 25 | 43 | \| netlist \| generator_tool \| `*Synthesis*` \| | - found_reason: "Parsing evidence supports checker intent" |
| REPLACE | 26 | 44 | \| netlist \| generator_version \| `*.*-*` \| | - missing_reason: "Parsing evidence does not satisfy checker intent" |
| REPLACE | 27 | 45 | \| netlist \| generation_time \| (日期格式) \| | - waived_reason: "Waiver item matched violation context" |
| REPLACE | 28 | 46 | \| spef \| file_path \| `*.spef*` \| | - unused_reason: "Waiver item has no matching violation" |
| OLD_ONLY | 29 |  | \| spef \| file_name \| `*.spef*` \| |  |
| SAME | 30 | 47 |  |  |
| REPLACE | 31 | 48 | --- | ### Scenario 3 (req>0, waiver=N/A) |
| NEW_ONLY |  | 49 |  | - found_desc: "Requirement pattern items matched" |
| NEW_ONLY |  | 50 |  | - missing_desc: "Requirement pattern items not matched" |
| NEW_ONLY |  | 51 |  | - found_reason: "All required pattern comparisons satisfied" |
| NEW_ONLY |  | 52 |  | - missing_reason: "At least one required pattern comparison failed" |
| SAME | 32 | 53 |  |  |
| REPLACE | 33 | 54 | ## 四种场景配置 | ### Scenario 4 (req>0, waiver>0) |
| NEW_ONLY |  | 55 |  | - found_desc: "Requirement pattern items matched" |
| NEW_ONLY |  | 56 |  | - missing_desc: "Requirement pattern items not matched" |
| NEW_ONLY |  | 57 |  | - waived_desc: "Violation waived by configured waiver items" |
| NEW_ONLY |  | 58 |  | - unused_desc: "Unused waiver entries" |
| NEW_ONLY |  | 59 |  | - found_reason: "All required pattern comparisons satisfied" |
| NEW_ONLY |  | 60 |  | - missing_reason: "At least one required pattern comparison failed" |
| NEW_ONLY |  | 61 |  | - waived_reason: "Waiver item matched violation context" |
| NEW_ONLY |  | 62 |  | - unused_reason: "Waiver item has no matching violation" |
| SAME | 34 | 63 |  |  |
| REPLACE | 35 | 64 | ### 场景 1: Requirement=N/A, Waiver=N/A | ## Expected Outcomes |
| NEW_ONLY |  | 65 |  | \| Scenario \| requirements.value \| waivers.value \| Decision Rule \| Expected Result with Current Evidence \| |
| NEW_ONLY |  | 66 |  | \| --- \| --- \| --- \| --- \| --- \| |
| NEW_ONLY |  | 67 |  | \| S1 \| N/A \| N/A \| Missing mandatory evidence -> FAIL \| FAIL \| |
| NEW_ONLY |  | 68 |  | \| S2 \| N/A \| >0 \| Mandatory miss can be waived \| PASS \| |
| NEW_ONLY |  | 69 |  | \| S3 \| >0 \| N/A \| Required pattern mismatch -> FAIL \| FAIL \| |
| NEW_ONLY |  | 70 |  | \| S4 \| >0 \| >0 \| Pattern mismatch can be waived \| PASS \| |
| SAME | 36 | 71 |  |  |
| REPLACE | 37 | 72 | **语义**: 存在性检查，无 waiver | ## Embedded Schema |
| OLD_ONLY | 38 |  |  |  |
| SAME | 39 | 73 | ```yaml | ```yaml |
| REPLACE | 40 | 74 | requirements: | format_spec: |
| REPLACE | 41 | 75 |   value: N/A |   item_id: IMP-10-0-0-00 |
| REPLACE | 42 | 76 |   pattern_items: [] |   vio_name_format: "item_name" |
| REPLACE | 43 | 77 |  |   stage_boundary: |
| REPLACE | 44 | 78 | waivers: |     reads_input_files: true |
| REPLACE | 45 | 79 |   value: N/A |     depends_on_itemspec: true |
| REPLACE | 46 | 80 |   waive_items: [] |     depends_on_parsing_spec: true |
| REPLACE | 47 | 81 |  |   type_map: |
| REPLACE | 48 | 82 | descriptions: |     type_1: req=N/A, waiver=N/A |
| REPLACE | 49 | 83 |   found_desc: "Netlist and SPEF version information extracted and verified" |     type_2: req>0, waiver=N/A |
| REPLACE | 50 | 84 |   missing_desc: "Netlist or SPEF version information missing or incomplete" |     type_3: req>0, waiver>0 |
| REPLACE | 51 | 85 |  |     type_4: req=N/A, waiver>0 |
| REPLACE | 52 | 86 | reasons: |   requirement_items: |
| REPLACE | 53 | 87 |   found_reason: "Version information found in log and file headers" |     - */dbs/*.v.gz |
| REPLACE | 54 | 88 |   missing_reason: "Version information not found in expected locations" |     - <version_token> |
| NEW_ONLY |  | 89 |  |     - <timestamp> |
| NEW_ONLY |  | 90 |  |   pattern_index_mapping: |
| NEW_ONLY |  | 91 |  |     - index: 0 |
| NEW_ONLY |  | 92 |  |       target: */dbs/*.v.gz |
| NEW_ONLY |  | 93 |  |     - index: 1 |
| NEW_ONLY |  | 94 |  |       target: <version_token> |
| NEW_ONLY |  | 95 |  |     - index: 2 |
| NEW_ONLY |  | 96 |  |       target: <timestamp> |
| NEW_ONLY |  | 97 |  |   waiver_items: |
| NEW_ONLY |  | 98 |  |     - netlist:* |
| NEW_ONLY |  | 99 |  |     - spef:* |
| SAME | 55 | 100 | ``` | ``` |
| OLD_ONLY | 56 |  |  |  |
| OLD_ONLY | 57 |  | **当前 Parsing 结果下的预期**: FAIL (spef 缺失) |  |
| OLD_ONLY | 58 |  |  |  |
| OLD_ONLY | 59 |  | --- |  |
| OLD_ONLY | 60 |  |  |  |
| OLD_ONLY | 61 |  | ### 场景 2: Requirement=N/A, Waiver=value>0 |  |
| OLD_ONLY | 62 |  |  |  |
| OLD_ONLY | 63 |  | **语义**: 存在性检查 + waiver 处理 |  |
| OLD_ONLY | 64 |  |  |  |
| OLD_ONLY | 65 |  | ```yaml |  |
| OLD_ONLY | 66 |  | requirements: |  |
| OLD_ONLY | 67 |  |   value: N/A |  |
| OLD_ONLY | 68 |  |   pattern_items: [] |  |
| OLD_ONLY | 69 |  |  |  |
| OLD_ONLY | 70 |  | waivers: |  |
| OLD_ONLY | 71 |  |   value: 1 |  |
| OLD_ONLY | 72 |  |   waive_items: |  |
| OLD_ONLY | 73 |  |     - "spef:*" |  |
| OLD_ONLY | 74 |  |  |  |
| OLD_ONLY | 75 |  | descriptions: |  |
| OLD_ONLY | 76 |  |   found_desc: "Netlist and SPEF version information extracted and verified" |  |
| OLD_ONLY | 77 |  |   missing_desc: "Netlist or SPEF version information missing or incomplete" |  |
| OLD_ONLY | 78 |  |   waived_desc: "Version mismatches waived per configuration" |  |
| OLD_ONLY | 79 |  |   unused_desc: "Unused waivers" |  |
| OLD_ONLY | 80 |  |  |  |
| OLD_ONLY | 81 |  | reasons: |  |
| OLD_ONLY | 82 |  |   found_reason: "Version information found in log and file headers" |  |
| OLD_ONLY | 83 |  |   missing_reason: "Version information not found in expected locations" |  |
| OLD_ONLY | 84 |  |   waived_reason: "Waived per project configuration" |  |
| OLD_ONLY | 85 |  |   unused_reason: "Waiver entry not matched" |  |
| OLD_ONLY | 86 |  | ``` |  |
| OLD_ONLY | 87 |  |  |  |
| OLD_ONLY | 88 |  | **当前 Parsing 结果下的预期**: PASS (spef waived) |  |
| OLD_ONLY | 89 |  |  |  |
| OLD_ONLY | 90 |  | --- |  |
| OLD_ONLY | 91 |  |  |  |
| OLD_ONLY | 92 |  | ### 场景 3: Requirement=value>0, Waiver=N/A |  |
| OLD_ONLY | 93 |  |  |  |
| OLD_ONLY | 94 |  | **语义**: Pattern 匹配检查，无 waiver |  |
| OLD_ONLY | 95 |  |  |  |
| OLD_ONLY | 96 |  | ```yaml |  |
| OLD_ONLY | 97 |  | requirements: |  |
| OLD_ONLY | 98 |  |   value: 2 |  |
| OLD_ONLY | 99 |  |   pattern_items: |  |
| OLD_ONLY | 100 |  |     - "netlist: file_path=*/dbs/*; file_name=*.v.gz" |  |
| OLD_ONLY | 101 |  |     - "spef: file_path=*; file_name=*.spef*" |  |
| OLD_ONLY | 102 |  |  |  |
| OLD_ONLY | 103 |  | waivers: |  |
| OLD_ONLY | 104 |  |   value: N/A |  |
| OLD_ONLY | 105 |  |   waive_items: [] |  |
| OLD_ONLY | 106 |  |  |  |
| OLD_ONLY | 107 |  | descriptions: |  |
| OLD_ONLY | 108 |  |   found_desc: "Required version patterns matched and validated" |  |
| OLD_ONLY | 109 |  |   missing_desc: "Expected version patterns not satisfied or missing" |  |
| OLD_ONLY | 110 |  |  |  |
| OLD_ONLY | 111 |  | reasons: |  |
| OLD_ONLY | 112 |  |   found_reason: "Version pattern matched and validated" |  |
| OLD_ONLY | 113 |  |   missing_reason: "Version pattern not satisfied or missing" |  |
| OLD_ONLY | 114 |  | ``` |  |
| OLD_ONLY | 115 |  |  |  |
| OLD_ONLY | 116 |  | **当前 Parsing 结果下的预期**: FAIL (spef 不匹配) |  |
| OLD_ONLY | 117 |  |  |  |
| OLD_ONLY | 118 |  | --- |  |
| OLD_ONLY | 119 |  |  |  |
| OLD_ONLY | 120 |  | ### 场景 4: Requirement=value>0, Waiver=value>0 |  |
| OLD_ONLY | 121 |  |  |  |
| OLD_ONLY | 122 |  | **语义**: Pattern 匹配检查 + waiver 处理 |  |
| OLD_ONLY | 123 |  |  |  |
| OLD_ONLY | 124 |  | ```yaml |  |
| OLD_ONLY | 125 |  | requirements: |  |
| OLD_ONLY | 126 |  |   value: 2 |  |
| OLD_ONLY | 127 |  |   pattern_items: |  |
| OLD_ONLY | 128 |  |     - "netlist: file_path=*/dbs/*; file_name=*.v.gz" |  |
| OLD_ONLY | 129 |  |     - "spef: file_path=*; file_name=*.spef*" |  |
| OLD_ONLY | 130 |  |  |  |
| OLD_ONLY | 131 |  | waivers: |  |
| OLD_ONLY | 132 |  |   value: 1 |  |
| OLD_ONLY | 133 |  |   waive_items: |  |
| OLD_ONLY | 134 |  |     - "spef:*" |  |
| OLD_ONLY | 135 |  |  |  |
| OLD_ONLY | 136 |  | descriptions: |  |
| OLD_ONLY | 137 |  |   found_desc: "Required version patterns matched and validated" |  |
| OLD_ONLY | 138 |  |   missing_desc: "Expected version patterns not satisfied or missing" |  |
| OLD_ONLY | 139 |  |   waived_desc: "Version mismatches waived per configuration" |  |
| OLD_ONLY | 140 |  |   unused_desc: "Unused waivers" |  |
| OLD_ONLY | 141 |  |  |  |
| OLD_ONLY | 142 |  | reasons: |  |
| OLD_ONLY | 143 |  |   found_reason: "Version pattern matched and validated" |  |
| OLD_ONLY | 144 |  |   missing_reason: "Version pattern not satisfied or missing" |  |
| OLD_ONLY | 145 |  |   waived_reason: "Waived per project configuration" |  |
| OLD_ONLY | 146 |  |   unused_reason: "Waiver entry not matched" |  |
| OLD_ONLY | 147 |  | ``` |  |
| OLD_ONLY | 148 |  |  |  |
| OLD_ONLY | 149 |  | **当前 Parsing 结果下的预期**: PASS (spef waived) |  |
| OLD_ONLY | 150 |  |  |  |
| OLD_ONLY | 151 |  | --- |  |
| OLD_ONLY | 152 |  |  |  |
| OLD_ONLY | 153 |  | ## 当前测试推荐 |  |
| OLD_ONLY | 154 |  |  |  |
| OLD_ONLY | 155 |  | 基于 Parsing 结果 (netlist 6/6 ✓, spef 0/6 ✗)： |  |
| OLD_ONLY | 156 |  |  |  |
| OLD_ONLY | 157 |  | **推荐配置**: 场景 2 或 场景 4（需要 `spef:*` waiver 才能 PASS） |  |
| OLD_ONLY | 158 |  |  |  |
| OLD_ONLY | 159 |  | --- |  |
| OLD_ONLY | 160 |  |  |  |
| OLD_ONLY | 161 |  | *Generated by CodeGen Agent* |  |
| OLD_ONLY | 162 |  | *Date: 2026-02-05* |  |
