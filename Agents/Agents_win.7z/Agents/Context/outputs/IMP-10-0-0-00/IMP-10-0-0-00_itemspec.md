# IMP-10-0-0-00 ItemSpec

Description: Confirm the netlist/spef version is correct.
Check Module: 10.0_STA_DCD_CHECK
Role: Senior digital physical implementation expert

## Scope
This specification defines what must be checked semantically for `IMP-10-0-0-00`.
This stage must not parse runtime input files.

- Define semantic intent and check boundaries.
- Define objects and sub-items to validate.
- Define PASS/FAIL and waiver boundary rules.

## Description Interpretation Rules
- Slash notation defaults to logical AND across objects unless explicit `or` is present.
- Explicit `or` denotes alternatives where at least one branch must satisfy the requirement.
- Optional components are modeled as optional sub-items and may be governed by waiver contracts.

## Semantic Targets

### Semantic Target Table
| Target ID | Object | Required Semantic Intent | PASS Condition | FAIL Condition |
| --- | --- | --- | --- | --- |
| T1 | netlist | Validate that `netlist` version-related evidence supports: Confirm the netlist/spef version is correct. | Presence and semantic correctness are both supported by evidence. | Missing evidence or conflicting evidence. |
| T2 | spef | Validate that `spef` version-related evidence supports: Confirm the netlist/spef version is correct. | Presence and semantic correctness are both supported by evidence. | Missing evidence or conflicting evidence. |

### Object/Sub-Item Contract
| Object | Sub-Item | Required | Semantic Meaning | PASS Condition | FAIL Condition |
| --- | --- | --- | --- | --- | --- |
| netlist | `status` | mandatory | Object has explicit load/check status | Evidence confirms `status` semantics. | Missing evidence or conflicting evidence. |
| netlist | `source_reference` | mandatory | Object can be traced to source file and line | Evidence confirms `source_reference` semantics. | Missing evidence or conflicting evidence. |
| netlist | `file_path` | mandatory | Resolved file path for this object | Evidence confirms `file_path` semantics. | Missing evidence or conflicting evidence. |
| netlist | `file_name` | mandatory | File name derived from file path | Evidence confirms `file_name` semantics. | Missing evidence or conflicting evidence. |
| netlist | `version_token` | mandatory | Version-like identifier for object correctness | Evidence confirms `version_token` semantics. | Missing evidence or conflicting evidence. |
| netlist | `generation_time` | optional | Timestamp used for version traceability | Evidence confirms `generation_time` semantics. | Missing evidence or conflicting evidence. |
| netlist | `generator_tool` | optional | Tool generating the netlist | Evidence confirms `generator_tool` semantics. | Missing evidence or conflicting evidence. |
| netlist | `generator_version` | optional | Tool version generating the netlist | Evidence confirms `generator_version` semantics. | Missing evidence or conflicting evidence. |
| netlist | `design_name` | mandatory | Design identifier used for cross-object consistency | Evidence confirms `design_name` semantics. | Missing evidence or conflicting evidence. |
| spef | `status` | mandatory | Object has explicit load/check status | Evidence confirms `status` semantics. | Missing evidence or conflicting evidence. |
| spef | `source_reference` | mandatory | Object can be traced to source file and line | Evidence confirms `source_reference` semantics. | Missing evidence or conflicting evidence. |
| spef | `file_path` | mandatory | Resolved file path for this object | Evidence confirms `file_path` semantics. | Missing evidence or conflicting evidence. |
| spef | `file_name` | mandatory | File name derived from file path | Evidence confirms `file_name` semantics. | Missing evidence or conflicting evidence. |
| spef | `version_token` | mandatory | Version-like identifier for object correctness | Evidence confirms `version_token` semantics. | Missing evidence or conflicting evidence. |
| spef | `generation_time` | optional | Timestamp used for version traceability | Evidence confirms `generation_time` semantics. | Missing evidence or conflicting evidence. |
| spef | `extractor_tool` | optional | Tool generating SPEF extraction | Evidence confirms `extractor_tool` semantics. | Missing evidence or conflicting evidence. |
| spef | `extractor_version` | optional | Tool version for SPEF extraction | Evidence confirms `extractor_version` semantics. | Missing evidence or conflicting evidence. |
| spef | `design_name` | mandatory | Design identifier used for cross-object consistency | Evidence confirms `design_name` semantics. | Missing evidence or conflicting evidence. |

### Cross-Object Consistency Rules
| Rule ID | Expression | Required | PASS Condition | FAIL Condition |
| --- | --- | --- | --- | --- |
| CR1 | netlist.design_name == spef.design_name | true | Both values exist and are equal. | One value missing or values mismatch. |

### Waiver Scope Contract
| Waiver Granularity | Token Format | Effect Scope |
| --- | --- | --- |
| object-level | `<object>:*` | Waive all mandatory sub-items for one object. |
| sub-item-level | `<object>:<sub_item>` | Waive one explicit sub-item only. |

## Check Criteria
- Requirement value observed in item yaml: `N/A`
- Waiver value observed in item yaml: `N/A`
- Any mandatory sub-item missing triggers FAIL unless covered by a valid waiver.
- Any required cross-object rule violation triggers FAIL unless covered by a valid waiver.

### Decision Matrix (Requirement/Waiver)
| Scenario | requirements.value | waivers.value | Decision Rule |
| --- | --- | --- | --- |
| S1 | N/A | N/A | Semantic presence and consistency only, no waiver allowed. |
| S2 | N/A | >0 | Semantic presence and consistency; violations can be waived. |
| S3 | >0 | N/A | Requirement pattern matching without waiver. |
| S4 | >0 | >0 | Requirement pattern matching with waiver handling. |

## Evidence Plan
### Data Source Priority
| Priority | Source | Expected Evidence |
| --- | --- | --- |
| Primary | Runtime log files | Object load status, key commands, top-level design identity. |
| Secondary | Referenced netlist header | Generator tool/version/time provenance. |
| Secondary | Referenced SPEF header | Extractor tool/version/time provenance. |

### Stage Responsibilities
- Stage A (ItemSpec): semantic contract only; no runtime file reads.
- Stage B (ParsingSpec): locate concrete evidence with file path and line number.
- Stage C (FormatSpec): normalize evidence into requirement and waiver formats.

### Mandatory Evidence Fields for Downstream
| Field | Meaning |
| --- | --- |
| `evidence_id` | Required downstream evidence field. |
| `source_file` | Required downstream evidence field. |
| `line_number` | Required downstream evidence field. |
| `raw_line` | Required downstream evidence field. |
| `pattern` | Required downstream evidence field. |
| `extracted_value` | Required downstream evidence field. |

### Knowledge Notes
- score=1.484 source=`skills/IMP-10-0-0-00_skill.md` section=`Description` snippet="Confirm the netlist/spef version is correct."
- score=1.430 source=`skills/IMP-10-0-0-00_skill.md` section=`Suggested retrieval queries` snippet="- IMP-10-0-0-00 checker intent Confirm the netlist/spef version is correct. - physical implementation netlist power_emir spef evidence extraction - input_logs parasitics power_integrity timing_signoff best practices"
- score=1.086 source=`skills/IMP-10-0-0-00_skill.md` section=`Embedded schema` snippet="```yaml skill_schema: item_id: IMP-10-0-0-00 check_module: 10.0_STA_DCD_CHECK intent: verification knowledge_tags: - input_logs - parasitics - power_integrity - timing_signoff candidate_objects: - netlist - power_emir - ..."
- score=1.058 source=`skills/IMP-10-0-0-00_skill.md` section=`Module and Intent` snippet="- Module: `10.0_STA_DCD_CHECK` - Intent: `verification` - Candidate objects: netlist, power_emir, spef - Knowledge tags: input_logs, parasitics, power_integrity, timing_signoff"
- score=1.016 source=`skills/IMP-10-0-0-00_skill.md` section=`Input and Existing Implementation Clues` snippet="- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-00.yaml` - Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLI..."
- score=0.931 source=`skills/IMP-10-0-0-00_skill.md` section=`Keyword clues from existing checker` snippet="- `# Confirm the netlist/spef version is correct.` - `# - Extract netlist file path from read_netlist command` - `# - Open extracted netlist file to capture version timestamp from header (line 3)` - `# - Open extracted S..."
- score=0.848 source=`skills/IMP-10-0-0-00_skill.md` section=`Regex clues from existing checker` snippet="- `read_netlist\\s+([^\\s]+\\.v(?:\\.gz)?)` - `\\[INFO\\]\\s+Skipping SPEF reading as (.+)` - `read_spef\\s+([^\\s]+\\.spef(?:\\.gz)?)` - `#\\s*Parasitics Mode:\\s*(.+)` - `Top level cell is\\s+(\\S+)` - `Program version\\s*=\\s*([\\d\\.\\-..."
- score=0.429 source=`skills/IMP-14-0-0-00_skill.md` section=`Suggested retrieval queries` snippet="- IMP-14-0-0-00 checker intent Confirm set the correct golden netlist. - physical implementation netlist power_emir evidence extraction - power_integrity best practices"

## Embedded Schema
```yaml
itemspec:
  item_id: IMP-10-0-0-00
  description: Confirm the netlist/spef version is correct.
  check_module: 10.0_STA_DCD_CHECK
  role: Senior digital physical implementation expert
  stage_boundary:
    reads_input_files: false
    depends_on_input_snippets: false
  semantic_targets:
  - target_id: T1
    object_name: netlist
    semantic_intent: 'Validate that `netlist` version-related evidence supports: Confirm
      the netlist/spef version is correct.'
    sub_items:
    - name: status
      required: true
      semantics: Object has explicit load/check status
    - name: source_reference
      required: true
      semantics: Object can be traced to source file and line
    - name: file_path
      required: true
      semantics: Resolved file path for this object
    - name: file_name
      required: true
      semantics: File name derived from file path
    - name: version_token
      required: true
      semantics: Version-like identifier for object correctness
    - name: generation_time
      required: false
      semantics: Timestamp used for version traceability
    - name: generator_tool
      required: false
      semantics: Tool generating the netlist
    - name: generator_version
      required: false
      semantics: Tool version generating the netlist
    - name: design_name
      required: true
      semantics: Design identifier used for cross-object consistency
    required_evidence:
    - evidence_id
    - source_file
    - line_number
    - raw_line
    - pattern
    - extracted_value
    pass_when:
    - Presence and semantic correctness are both supported by evidence.
    fail_when:
    - Missing evidence or conflicting evidence.
  - target_id: T2
    object_name: spef
    semantic_intent: 'Validate that `spef` version-related evidence supports: Confirm
      the netlist/spef version is correct.'
    sub_items:
    - name: status
      required: true
      semantics: Object has explicit load/check status
    - name: source_reference
      required: true
      semantics: Object can be traced to source file and line
    - name: file_path
      required: true
      semantics: Resolved file path for this object
    - name: file_name
      required: true
      semantics: File name derived from file path
    - name: version_token
      required: true
      semantics: Version-like identifier for object correctness
    - name: generation_time
      required: false
      semantics: Timestamp used for version traceability
    - name: extractor_tool
      required: false
      semantics: Tool generating SPEF extraction
    - name: extractor_version
      required: false
      semantics: Tool version for SPEF extraction
    - name: design_name
      required: true
      semantics: Design identifier used for cross-object consistency
    required_evidence:
    - evidence_id
    - source_file
    - line_number
    - raw_line
    - pattern
    - extracted_value
    pass_when:
    - Presence and semantic correctness are both supported by evidence.
    fail_when:
    - Missing evidence or conflicting evidence.
  cross_object_rules:
  - rule_id: CR1
    expression: netlist.design_name == spef.design_name
    required: true
    pass_when:
    - Both values exist and are equal.
    fail_when:
    - One value missing or values mismatch.
  waiver_model:
    scopes:
    - granularity: object-level
      token_format: <object>:*
      effect_scope: Waive all mandatory sub-items for one object.
    - granularity: sub-item-level
      token_format: <object>:<sub_item>
      effect_scope: Waive one explicit sub-item only.
  decision_matrix:
  - scenario: S1
    requirements_value: N/A
    waivers_value: N/A
    decision_rule: Semantic presence and consistency only, no waiver allowed.
  - scenario: S2
    requirements_value: N/A
    waivers_value: '>0'
    decision_rule: Semantic presence and consistency; violations can be waived.
  - scenario: S3
    requirements_value: '>0'
    waivers_value: N/A
    decision_rule: Requirement pattern matching without waiver.
  - scenario: S4
    requirements_value: '>0'
    waivers_value: '>0'
    decision_rule: Requirement pattern matching with waiver handling.
  mandatory_evidence_fields:
  - evidence_id
  - source_file
  - line_number
  - raw_line
  - pattern
  - extracted_value
  pass_rule: All mandatory semantic targets and required cross-object rules pass.
  fail_rule: Any mandatory semantic target or required cross-object rule fails without
    valid waiver.
```
