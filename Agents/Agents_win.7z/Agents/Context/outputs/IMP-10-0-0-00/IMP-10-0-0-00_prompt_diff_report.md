# Prompt vs Collateral Diff Report (IMP-10-0-0-00)

## Scope
This report compares:
- legacy prompt contracts and template rules,
- previous collateral style,
- current refactored Context collateral output.

Goal: identify field-level differences and give keep/replace recommendations.

## Sources
- Legacy prompt guide: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CodeX/context/ItemSpec_Generation_Prompt.md`
- Legacy user prompt: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CodeX/context/user_prompt.md`
- Legacy framework rules: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CodeX/context/global_rules.md`
- Legacy collateral sample:
  - `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Work/IMP_10_0_0_00_DryRun/itemspec.md`
  - `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Work/IMP_10_0_0_00_DryRun/parsing_spec.md`
  - `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Work/IMP_10_0_0_00_DryRun/format_spec.md`
- Current collateral output:
  - `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Context/outputs/IMP-10-0-0-00/IMP-10-0-0-00_itemspec.md`
  - `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Context/outputs/IMP-10-0-0-00/IMP-10-0-0-00_parsing_spec.md`
  - `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Agents/Context/outputs/IMP-10-0-0-00/IMP-10-0-0-00_format_spec.md`

## Architecture-Level Diff
| Topic | Legacy Prompt Contract | Current Refactor | Decision |
| --- | --- | --- | --- |
| Collateral boundary | Mostly ItemSpec-centric (Section 1-4 in one document), Parsing/Format later in flow | Three Context outputs: ItemSpec -> ParsingSpec -> FormatSpec | Keep current split |
| Generation style | 5-round CoT progressive generation with resume | Single-pass stage generation with deterministic fallback | Keep current runtime simplicity; keep selective prompt rules from legacy |
| Type semantics | Explicit Type 1/2/3/4 rules in framework prompt | Scenario matrix present, but compact | Keep compact in outputs, add minimal type mapping block |

## Field-Level Diff
| ID | Field | Legacy Prompt / Old Collateral | Current Collateral | Recommendation |
| --- | --- | --- | --- | --- |
| F01 | Role persona | Explicit senior PI engineer role | Present (`Role: Senior digital physical implementation expert`) | Keep |
| F02 | Description interpretation patterns | Explicit rules: slash means AND, explicit OR, optional parts | Not explicit in new ItemSpec | Add back |
| F03 | ItemSpec granularity | Old ItemSpec includes detailed object/sub-item tables (e.g., netlist/spef fields) | New ItemSpec semantic targets are generic and coarse | Replace with hybrid: semantic target + concrete sub-item table |
| F04 | Object precision | Old sample focused on `netlist`, `spef` | New output includes noisy `power_emir` target from skill hints | Replace (filter noisy objects by evidence relevance) |
| F05 | Pattern correspondence | Legacy template asks explicit `pattern_items[i] -> validation item` mapping | New FormatSpec has requirement list only, no index mapping | Add back |
| F06 | Waiver scenario keywords | Legacy prompt requires scenario + reason + matching keywords | New FormatSpec has waiver items but no keyword taxonomy | Add back |
| F07 | Implementation guide | Legacy ItemSpec Section 4 includes data-source inference and extraction strategy | New split moved runtime evidence to ParsingSpec; no explicit extraction strategy checklist | Keep split, add compact strategy subsection in ParsingSpec |
| F08 | Validation/test matrix | Legacy template includes 6 test scenario guidance | New FormatSpec has 4 scenario matrix only and no test-hint block | Add back (as validation_hint subsection) |
| F09 | Type system reference | Legacy `global_rules` defines Type 1/2/3/4 outputs in detail | New docs imply scenario semantics but no explicit type map | Add compact map in FormatSpec schema |
| F10 | Traceability metadata | Legacy rules require source path/line/matched content | New ParsingSpec includes source path + line + extracted values | Keep |
| F11 | No hardcoding principle | Legacy prompt asks to avoid project/tool hardcoding | New ParsingSpec intentionally contains concrete evidence; FormatSpec generalizes partially | Keep principle, tighten normalization rules in FormatSpec |
| F12 | Language requirement | Legacy prompt enforces full English | New collateral is full English | Keep |
| F13 | Scenario expected outcomes | Old FormatSpec sample includes current parsing-based expected PASS/FAIL recommendation | New FormatSpec lacks explicit expected outcome matrix for current evidence | Add back |
| F14 | Violation-name format | Legacy had flexible expression examples | New uses `vio_name_format: "item_name"` for converter compatibility | Keep for now (compatibility), later improve converter parser |

## Gap Impact Assessment
| Priority | Gap | Risk |
| --- | --- | --- |
| P0 | F04 noisy object (`power_emir`) | Wrong check scope and false requirement/waiver design |
| P0 | F05 missing pattern index mapping | CodeGen may misalign requirement item ordering |
| P0 | F13 missing expected outcome matrix | Validation Agent lacks explicit requirement/waiver expectation anchor |
| P1 | F02 missing description interpretation rules | Multi-object descriptions can be misinterpreted |
| P1 | F06 missing waiver keyword taxonomy | Selective waiver matching quality decreases |
| P1 | F08 missing test scenario guidance | Validation coverage can regress |
| P2 | F09 missing compact type map | Weaker explainability and reviewer onboarding |

## Keep/Replace Decision Summary
### Keep
- Three-stage collateral split (ItemSpec -> ParsingSpec -> FormatSpec).
- Per-item folder and ID-prefixed naming.
- Parsing evidence traceability schema.
- English-only output constraint.
- `vio_name_format: "item_name"` until converter parser is upgraded.

### Replace / Add Back
- Add description interpretation rules (slash/or/optional) into ItemSpec generation prompt.
- Replace generic semantic targets with a hybrid model:
  - semantic intent,
  - concrete object/sub-item requirements,
  - required evidence per sub-item.
- Add `pattern_items[i]` correspondence block in FormatSpec.
- Add waiver keyword taxonomy block in FormatSpec.
- Add "expected outcome by requirement/waiver + current evidence" block in FormatSpec.
- Add compact validation hint matrix (legacy 6 scenarios as optional test-hint appendix).
- Add object relevance filter to suppress unsupported skill-hint objects.

## Suggested Prompt Patch List
1. ItemSpec prompt: add "description interpretation patterns" section from legacy prompt.
2. ItemSpec prompt: require object/sub-item table with mandatory/optional tags.
3. ParsingSpec prompt: require `evidence -> sub-item` mapping table.
4. FormatSpec prompt: require explicit `pattern_items index mapping` subsection.
5. FormatSpec prompt: require waiver keyword taxonomy with examples.
6. FormatSpec prompt: require explicit expected PASS/FAIL matrix for current evidence state.
7. Context pipeline: add evidence-weighted object filter before final ItemSpec target list.

## Final Recommendation
Adopt a hybrid contract:
- preserve current 3-document architecture,
- restore high-value legacy prompt semantics (interpretation rules, mapping explicitness, validation expectation matrix),
- keep compatibility-safe `vio_name_format` until `FormatSpecConverter` parsing is upgraded.
