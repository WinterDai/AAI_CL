# IMP-10-0-0-00 ParsingSpec

Description: Confirm the netlist/spef version is correct.
Check Module: 10.0_STA_DCD_CHECK

## Input Resolution
Resolved inputs:
- /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log

Missing inputs:
- (none)

Resolution notes:
- ParsingSpec is generated only after ItemSpec is finalized.
- Runtime evidence collection starts in this stage.

## Evidence Inventory
| Evidence ID | Source File | Line | Pattern | Extracted Values | Raw Line | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| EV1 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 6 | `read_netlist\s+([^\s]+\.v(?:\.gz)?)` | `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | 1.00 |
| EV2 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 6 | `read_netlist\s+([^\s]+)` | `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | 1.00 |
| EV3 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 7 | `\bnetlist\b` | `#% Begin Load netlist data ... (date=11/17 14:24:59, mem=1874.7M)` | `#% Begin Load netlist data ... (date=11/17 14:24:59, mem=1874.7M)` | 1.00 |
| EV4 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 8 | `\bnetlist\b` | `*** Begin netlist parsing (mem=2584.0M) ***` | `*** Begin netlist parsing (mem=2584.0M) ***` | 1.00 |
| EV5 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 9 | `\bnetlist\b` | `Reading verilog netlist '/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz'` | `Reading verilog netlist '/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz'` | 1.00 |
| EV6 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 12 | `\bnetlist\b` | `*** End netlist parsing (cpu=0:00:00.2, real=0:00:00.0, mem=2924.0M) ***` | `*** End netlist parsing (cpu=0:00:00.2, real=0:00:00.0, mem=2924.0M) ***` | 1.00 |
| EV7 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 13 | `\bnetlist\b` | `#% End Load netlist data ... (date=11/17 14:24:59, total cpu=0:00:00.6, real=0:00:00.0, peak res=2395.9M, current mem=2395.9M)` | `#% End Load netlist data ... (date=11/17 14:24:59, total cpu=0:00:00.6, real=0:00:00.0, peak res=2395.9M, current mem=2395.9M)` | 1.00 |
| EV8 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 14 | `Top level cell is\s+(\S+)` | `phy_cmn_phase_align_digtop.` | `Top level cell is phy_cmn_phase_align_digtop.` | 1.00 |
| EV9 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 15 | `\bnetlist\b` | `Building hierarchical netlist for Cell phy_cmn_phase_align_digtop ...` | `Building hierarchical netlist for Cell phy_cmn_phase_align_digtop ...` | 1.00 |
| EV10 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 22 | `\[INFO\]\s+Skipping SPEF reading as (.+)` | `we are writing post-synthesis SDF files` | `[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files` | 1.00 |
| EV11 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 22 | `Skipping SPEF reading as\s+(.+)` | `we are writing post-synthesis SDF files` | `[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files` | 1.00 |
| EV12 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 44 | `Program version\s*=\s*([\d\.\-\w]+)` | `23.15-s108_1` | `Program version = 23.15-s108_1` | 1.00 |
| EV13 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 44 | `Program version\s*=\s*([\w\.-]+)` | `23.15-s108_1` | `Program version = 23.15-s108_1` | 1.00 |
| EV14 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 44 | `\bversion\b` | `Program version = 23.15-s108_1` | `Program version = 23.15-s108_1` | 1.00 |
| EV15 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 62 | `#\s*Parasitics Mode:\s*(.+)` | `No SPEF/RCDB` | `# Parasitics Mode: No SPEF/RCDB` | 1.00 |
| DV1 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 6 | `<derived:source_reference>` | `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log:6` | `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | 0.95 |
| DV2 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 6 | `<derived:file_name_from_file_path>` | `phy_cmn_phase_align_digtop.v.gz` | `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | 0.95 |
| DV3 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz | 2 | `<derived:version_token>` | `23.15-s099_1` | `// Generated by Cadence Genus(TM) Synthesis Solution 23.15-s099_1` | 0.95 |
| DV4 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log | 22 | `<derived:source_reference>` | `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log:22` | `[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files` | 0.95 |

## Referenced Files
| Evidence ID | Source File | Line | Pattern | Extracted Values | Raw Line |
| --- | --- | --- | --- | --- | --- |
| RF1 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz | 2 | `Generated by\s+(.+)` | `Cadence Genus(TM) Synthesis Solution 23.15-s099_1` | `// Generated by Cadence Genus(TM) Synthesis Solution 23.15-s099_1` |
| RF2 | /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz | 3 | `Generated on:\s+(.+)` | `Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC)` | `// Generated on: Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC)` |

## Evidence to Sub-Item Mapping
| Evidence ID | Object | Sub-Item | Required | Mapping Status | Rationale |
| --- | --- | --- | --- | --- | --- |
| EV1 | netlist | `file_path` | true | mapped | Object mapped by lexical match: `netlist`. Sub-item mapped by pattern semantics: `file_path`. |
| EV2 | netlist | `file_path` | true | mapped | Object mapped by lexical match: `netlist`. Sub-item mapped by pattern semantics: `file_path`. |
| EV3 | netlist | `status` | true | mapped | Object mapped by lexical match: `netlist`. Sub-item mapped by pattern semantics: `status`. |
| EV4 | netlist | `status` | true | mapped | Object mapped by lexical match: `netlist`. Sub-item mapped by pattern semantics: `status`. |
| EV5 | netlist | `status` | true | mapped | Object mapped by lexical match: `netlist`. Sub-item mapped by pattern semantics: `status`. |
| EV6 | netlist | `status` | true | mapped | Object mapped by lexical match: `netlist`. Sub-item mapped by pattern semantics: `status`. |
| EV7 | netlist | `status` | true | mapped | Object mapped by lexical match: `netlist`. Sub-item mapped by pattern semantics: `status`. |
| EV8 | netlist | `design_name` | true | mapped_with_fallback | Object fallback applied: `netlist` selected as default. Sub-item mapped by pattern semantics: `design_name`. |
| EV9 | netlist | `status` | true | mapped | Object mapped by lexical match: `netlist`. Sub-item mapped by pattern semantics: `status`. |
| EV10 | spef | `status` | true | mapped | Object mapped by lexical match: `spef`. Sub-item mapped by pattern semantics: `status`. |
| EV11 | spef | `status` | true | mapped | Object mapped by lexical match: `spef`. Sub-item mapped by pattern semantics: `status`. |
| EV12 | netlist | `generator_version` | false | mapped_with_fallback | Object fallback applied: `netlist` selected as default. Sub-item mapped by pattern semantics: `generator_version`. |
| EV13 | netlist | `generator_version` | false | mapped_with_fallback | Object fallback applied: `netlist` selected as default. Sub-item mapped by pattern semantics: `generator_version`. |
| EV14 | netlist | `generator_version` | false | mapped_with_fallback | Object fallback applied: `netlist` selected as default. Sub-item mapped by pattern semantics: `generator_version`. |
| EV15 | spef | `status` | true | mapped | Object mapped by lexical match: `spef`. Sub-item mapped by pattern semantics: `status`. |
| RF1 | netlist | `generator_tool` | false | mapped | Object mapped by lexical match: `netlist`. Sub-item mapped by pattern semantics: `generator_tool`. |
| RF2 | netlist | `generation_time` | false | mapped | Object mapped by lexical match: `netlist`. Sub-item mapped by pattern semantics: `generation_time`. |
| DV1 | netlist | `source_reference` | true | mapped_derived | Derived source_reference from first mapped evidence source and line. |
| DV2 | netlist | `file_name` | true | mapped_derived | Derived file_name from mapped file_path evidence. |
| DV3 | netlist | `version_token` | true | mapped_derived | Derived version_token from mapped version-like evidence. |
| DV4 | spef | `source_reference` | true | mapped_derived | Derived source_reference from first mapped evidence source and line. |

### Object Status Summary
| Object | mandatory_found | mandatory_total | status | blocker_reason |
| --- | --- | --- | --- | --- |
| netlist | 6 | 6 | PASS | none |
| spef | 2 | 6 | PARTIAL | Missing mandatory sub-items: file_path, file_name, version_token, design_name |

## Extraction Gaps
### Mandatory Missing Evidence
| Object | Sub-Item | Gap Type | Detail | Suggested Resolution |
| --- | --- | --- | --- | --- |
| spef | `file_path` | mandatory_missing | No mapped evidence for mandatory sub-item `file_path`. | Provide waiver `spef:*` or add valid evidence. |
| spef | `file_name` | mandatory_missing | No mapped evidence for mandatory sub-item `file_name`. | Provide waiver `spef:*` or add valid evidence. |
| spef | `version_token` | mandatory_missing | No mapped evidence for mandatory sub-item `version_token`. | Provide waiver `spef:*` or add valid evidence. |
| spef | `design_name` | mandatory_missing | No mapped evidence for mandatory sub-item `design_name`. | Provide waiver `spef:*` or add valid evidence. |

### Conflicts and Ambiguities
| Object | Sub-Item | Conflict Type | Candidates | Resolution Hint |
| --- | --- | --- | --- | --- |
| netlist | `status` | conflicting_values | #% Begin Load netlist data ... (date=11/17 14:24:59, mem=1874.7M), #% End Load netlist data ... (date=11/17 14:24:59, total cpu=0:00:00.6, real=0:00:00.0, peak res=2395.9M, current mem=2395.9M), *** Begin netlist parsing (mem=2584.0M) ***, *** End netlist parsing (cpu=0:00:00.2, real=0:00:00.0, mem=2924.0M) ***, Building hierarchical netlist for Cell phy_cmn_phase_align_digtop ..., Reading verilog netlist '/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz' | Prefer value from highest-priority source or earliest explicit command. |
| netlist | `generator_version` | conflicting_values | 23.15-s108_1, Program version = 23.15-s108_1 | Prefer value from highest-priority source or earliest explicit command. |
| spef | `status` | conflicting_values | No SPEF/RCDB, we are writing post-synthesis SDF files | Prefer value from highest-priority source or earliest explicit command. |

### Coverage Summary
- mandatory_coverage_ratio: `8/12`
- objects_with_blockers: `spef`

## Embedded Schema
```yaml
parsing_spec:
  item_id: IMP-10-0-0-00
  description: Confirm the netlist/spef version is correct.
  check_module: 10.0_STA_DCD_CHECK
  stage_boundary:
    reads_input_files: true
    depends_on_itemspec: true
  resolved_inputs:
  - /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
  missing_inputs: []
  evidence_records:
  - evidence_id: EV1
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 6
    pattern: read_netlist\s+([^\s]+\.v(?:\.gz)?)
    extracted_value: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    raw_line: <CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    confidence: 1.0
  - evidence_id: EV2
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 6
    pattern: read_netlist\s+([^\s]+)
    extracted_value: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    raw_line: <CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    confidence: 1.0
  - evidence_id: EV3
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 7
    pattern: \bnetlist\b
    extracted_value: '#% Begin Load netlist data ... (date=11/17 14:24:59, mem=1874.7M)'
    raw_line: '#% Begin Load netlist data ... (date=11/17 14:24:59, mem=1874.7M)'
    confidence: 1.0
  - evidence_id: EV4
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 8
    pattern: \bnetlist\b
    extracted_value: '*** Begin netlist parsing (mem=2584.0M) ***'
    raw_line: '*** Begin netlist parsing (mem=2584.0M) ***'
    confidence: 1.0
  - evidence_id: EV5
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 9
    pattern: \bnetlist\b
    extracted_value: Reading verilog netlist '/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz'
    raw_line: Reading verilog netlist '/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz'
    confidence: 1.0
  - evidence_id: EV6
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 12
    pattern: \bnetlist\b
    extracted_value: '*** End netlist parsing (cpu=0:00:00.2, real=0:00:00.0, mem=2924.0M)
      ***'
    raw_line: '*** End netlist parsing (cpu=0:00:00.2, real=0:00:00.0, mem=2924.0M)
      ***'
    confidence: 1.0
  - evidence_id: EV7
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 13
    pattern: \bnetlist\b
    extracted_value: '#% End Load netlist data ... (date=11/17 14:24:59, total cpu=0:00:00.6,
      real=0:00:00.0, peak res=2395.9M, current mem=2395.9M)'
    raw_line: '#% End Load netlist data ... (date=11/17 14:24:59, total cpu=0:00:00.6,
      real=0:00:00.0, peak res=2395.9M, current mem=2395.9M)'
    confidence: 1.0
  - evidence_id: EV8
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 14
    pattern: Top level cell is\s+(\S+)
    extracted_value: phy_cmn_phase_align_digtop.
    raw_line: Top level cell is phy_cmn_phase_align_digtop.
    confidence: 1.0
  - evidence_id: EV9
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 15
    pattern: \bnetlist\b
    extracted_value: Building hierarchical netlist for Cell phy_cmn_phase_align_digtop
      ...
    raw_line: Building hierarchical netlist for Cell phy_cmn_phase_align_digtop ...
    confidence: 1.0
  - evidence_id: EV10
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 22
    pattern: \[INFO\]\s+Skipping SPEF reading as (.+)
    extracted_value: we are writing post-synthesis SDF files
    raw_line: '[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files'
    confidence: 1.0
  - evidence_id: EV11
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 22
    pattern: Skipping SPEF reading as\s+(.+)
    extracted_value: we are writing post-synthesis SDF files
    raw_line: '[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files'
    confidence: 1.0
  - evidence_id: EV12
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 44
    pattern: Program version\s*=\s*([\d\.\-\w]+)
    extracted_value: 23.15-s108_1
    raw_line: Program version = 23.15-s108_1
    confidence: 1.0
  - evidence_id: EV13
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 44
    pattern: Program version\s*=\s*([\w\.-]+)
    extracted_value: 23.15-s108_1
    raw_line: Program version = 23.15-s108_1
    confidence: 1.0
  - evidence_id: EV14
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 44
    pattern: \bversion\b
    extracted_value: Program version = 23.15-s108_1
    raw_line: Program version = 23.15-s108_1
    confidence: 1.0
  - evidence_id: EV15
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 62
    pattern: '#\s*Parasitics Mode:\s*(.+)'
    extracted_value: No SPEF/RCDB
    raw_line: '# Parasitics Mode: No SPEF/RCDB'
    confidence: 1.0
  - evidence_id: DV1
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 6
    pattern: <derived:source_reference>
    extracted_value: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log:6
    raw_line: <CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    confidence: 0.95
  - evidence_id: DV2
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 6
    pattern: <derived:file_name_from_file_path>
    extracted_value: phy_cmn_phase_align_digtop.v.gz
    raw_line: <CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    confidence: 0.95
  - evidence_id: DV3
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    line_number: 2
    pattern: <derived:version_token>
    extracted_value: 23.15-s099_1
    raw_line: // Generated by Cadence Genus(TM) Synthesis Solution 23.15-s099_1
    confidence: 0.95
  - evidence_id: DV4
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log
    line_number: 22
    pattern: <derived:source_reference>
    extracted_value: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/logs/sta_post_syn.log:22
    raw_line: '[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files'
    confidence: 0.95
  referenced_file_records:
  - evidence_id: RF1
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    line_number: 2
    pattern: Generated by\s+(.+)
    extracted_value: Cadence Genus(TM) Synthesis Solution 23.15-s099_1
    raw_line: // Generated by Cadence Genus(TM) Synthesis Solution 23.15-s099_1
    confidence: 1.0
  - evidence_id: RF2
    source_file: /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz
    line_number: 3
    pattern: Generated on:\s+(.+)
    extracted_value: Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC)
    raw_line: '// Generated on: Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC)'
    confidence: 1.0
  evidence_to_sub_item:
  - evidence_id: EV1
    object: netlist
    sub_item: file_path
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `netlist`. Sub-item mapped by pattern
      semantics: `file_path`.'
  - evidence_id: EV2
    object: netlist
    sub_item: file_path
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `netlist`. Sub-item mapped by pattern
      semantics: `file_path`.'
  - evidence_id: EV3
    object: netlist
    sub_item: status
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `netlist`. Sub-item mapped by pattern
      semantics: `status`.'
  - evidence_id: EV4
    object: netlist
    sub_item: status
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `netlist`. Sub-item mapped by pattern
      semantics: `status`.'
  - evidence_id: EV5
    object: netlist
    sub_item: status
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `netlist`. Sub-item mapped by pattern
      semantics: `status`.'
  - evidence_id: EV6
    object: netlist
    sub_item: status
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `netlist`. Sub-item mapped by pattern
      semantics: `status`.'
  - evidence_id: EV7
    object: netlist
    sub_item: status
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `netlist`. Sub-item mapped by pattern
      semantics: `status`.'
  - evidence_id: EV8
    object: netlist
    sub_item: design_name
    required: true
    mapping_status: mapped_with_fallback
    rationale: 'Object fallback applied: `netlist` selected as default. Sub-item mapped
      by pattern semantics: `design_name`.'
  - evidence_id: EV9
    object: netlist
    sub_item: status
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `netlist`. Sub-item mapped by pattern
      semantics: `status`.'
  - evidence_id: EV10
    object: spef
    sub_item: status
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `spef`. Sub-item mapped by pattern
      semantics: `status`.'
  - evidence_id: EV11
    object: spef
    sub_item: status
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `spef`. Sub-item mapped by pattern
      semantics: `status`.'
  - evidence_id: EV12
    object: netlist
    sub_item: generator_version
    required: false
    mapping_status: mapped_with_fallback
    rationale: 'Object fallback applied: `netlist` selected as default. Sub-item mapped
      by pattern semantics: `generator_version`.'
  - evidence_id: EV13
    object: netlist
    sub_item: generator_version
    required: false
    mapping_status: mapped_with_fallback
    rationale: 'Object fallback applied: `netlist` selected as default. Sub-item mapped
      by pattern semantics: `generator_version`.'
  - evidence_id: EV14
    object: netlist
    sub_item: generator_version
    required: false
    mapping_status: mapped_with_fallback
    rationale: 'Object fallback applied: `netlist` selected as default. Sub-item mapped
      by pattern semantics: `generator_version`.'
  - evidence_id: EV15
    object: spef
    sub_item: status
    required: true
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `spef`. Sub-item mapped by pattern
      semantics: `status`.'
  - evidence_id: RF1
    object: netlist
    sub_item: generator_tool
    required: false
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `netlist`. Sub-item mapped by pattern
      semantics: `generator_tool`.'
  - evidence_id: RF2
    object: netlist
    sub_item: generation_time
    required: false
    mapping_status: mapped
    rationale: 'Object mapped by lexical match: `netlist`. Sub-item mapped by pattern
      semantics: `generation_time`.'
  - evidence_id: DV1
    object: netlist
    sub_item: source_reference
    required: true
    mapping_status: mapped_derived
    rationale: Derived source_reference from first mapped evidence source and line.
  - evidence_id: DV2
    object: netlist
    sub_item: file_name
    required: true
    mapping_status: mapped_derived
    rationale: Derived file_name from mapped file_path evidence.
  - evidence_id: DV3
    object: netlist
    sub_item: version_token
    required: true
    mapping_status: mapped_derived
    rationale: Derived version_token from mapped version-like evidence.
  - evidence_id: DV4
    object: spef
    sub_item: source_reference
    required: true
    mapping_status: mapped_derived
    rationale: Derived source_reference from first mapped evidence source and line.
  object_status_summary:
  - object: netlist
    mandatory_found: 6
    mandatory_total: 6
    status: PASS
    blocker_reason: none
  - object: spef
    mandatory_found: 2
    mandatory_total: 6
    status: PARTIAL
    blocker_reason: 'Missing mandatory sub-items: file_path, file_name, version_token,
      design_name'
  extraction_gaps:
  - object: spef
    sub_item: file_path
    gap_type: mandatory_missing
    detail: No mapped evidence for mandatory sub-item `file_path`.
    suggested_resolution: Provide waiver `spef:*` or add valid evidence.
  - object: spef
    sub_item: file_name
    gap_type: mandatory_missing
    detail: No mapped evidence for mandatory sub-item `file_name`.
    suggested_resolution: Provide waiver `spef:*` or add valid evidence.
  - object: spef
    sub_item: version_token
    gap_type: mandatory_missing
    detail: No mapped evidence for mandatory sub-item `version_token`.
    suggested_resolution: Provide waiver `spef:*` or add valid evidence.
  - object: spef
    sub_item: design_name
    gap_type: mandatory_missing
    detail: No mapped evidence for mandatory sub-item `design_name`.
    suggested_resolution: Provide waiver `spef:*` or add valid evidence.
  conflicts:
  - object: netlist
    sub_item: status
    conflict_type: conflicting_values
    candidates:
    - '#% Begin Load netlist data ... (date=11/17 14:24:59, mem=1874.7M)'
    - '#% End Load netlist data ... (date=11/17 14:24:59, total cpu=0:00:00.6, real=0:00:00.0,
      peak res=2395.9M, current mem=2395.9M)'
    - '*** Begin netlist parsing (mem=2584.0M) ***'
    - '*** End netlist parsing (cpu=0:00:00.2, real=0:00:00.0, mem=2924.0M) ***'
    - Building hierarchical netlist for Cell phy_cmn_phase_align_digtop ...
    - Reading verilog netlist '/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz'
    resolution_hint: Prefer value from highest-priority source or earliest explicit
      command.
  - object: netlist
    sub_item: generator_version
    conflict_type: conflicting_values
    candidates:
    - 23.15-s108_1
    - Program version = 23.15-s108_1
    resolution_hint: Prefer value from highest-priority source or earliest explicit
      command.
  - object: spef
    sub_item: status
    conflict_type: conflicting_values
    candidates:
    - No SPEF/RCDB
    - we are writing post-synthesis SDF files
    resolution_hint: Prefer value from highest-priority source or earliest explicit
      command.
  coverage_summary:
    mandatory_found: 8
    mandatory_total: 12
    mandatory_coverage_ratio: 8/12
```
