# IMP-10-0-0-00 FormatSpec

Description: Confirm the netlist/spef version is correct.
Check Module: 10.0_STA_DCD_CHECK
vio_name_format: "item.get('name', str(item))"

## Pattern Strategy
- `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` -> `*/dbs/*.v.gz`
- `23.15-s108_1` -> `<version_token>`

## Requirement Items
- `*/dbs/*.v.gz`
- `<version_token>`
- `<timestamp>`

## Waiver Items
- `netlist:*`
- `power_emir:*`
- `spef:*`

## Scenario Matrix
### Scenario 1 (req=N/A, waiver=N/A)
- found_desc: "Required evidence extracted and semantically valid"
- missing_desc: "Required evidence missing or semantically invalid"
- found_reason: "Parsing evidence supports checker intent"
- missing_reason: "Parsing evidence does not satisfy checker intent"

### Scenario 2 (req=N/A, waiver>0)
- found_desc: "Required evidence extracted and semantically valid"
- missing_desc: "Required evidence missing or semantically invalid"
- waived_desc: "Violation waived by configured waiver items"
- unused_desc: "Unused waiver entries"
- found_reason: "Parsing evidence supports checker intent"
- missing_reason: "Parsing evidence does not satisfy checker intent"
- waived_reason: "Waiver item matched violation context"
- unused_reason: "Waiver item has no matching violation"

### Scenario 3 (req>0, waiver=N/A)
- found_desc: "Requirement pattern items matched"
- missing_desc: "Requirement pattern items not matched"
- found_reason: "All required pattern comparisons satisfied"
- missing_reason: "At least one required pattern comparison failed"

### Scenario 4 (req>0, waiver>0)
- found_desc: "Requirement pattern items matched"
- missing_desc: "Requirement pattern items not matched"
- waived_desc: "Violation waived by configured waiver items"
- unused_desc: "Unused waiver entries"
- found_reason: "All required pattern comparisons satisfied"
- missing_reason: "At least one required pattern comparison failed"
- waived_reason: "Waiver item matched violation context"
- unused_reason: "Waiver item has no matching violation"

## Embedded Schema
```yaml
format_spec:
  item_id: IMP-10-0-0-00
  vio_name_format: "item.get('name', str(item))"
  stage_boundary:
    reads_input_files: true
    depends_on_itemspec: true
    depends_on_parsing_spec: true
  requirement_items:
    - */dbs/*.v.gz
    - <version_token>
    - <timestamp>
  waiver_items:
    - netlist:*
    - power_emir:*
    - spef:*
```
