# IMP-10-0-0-00 ItemSpec

Description: Confirm the netlist/spef version is correct.
Check Module: 10.0_STA_DCD_CHECK
Role: Senior digital physical implementation expert

## Scope
This specification defines what must be checked semantically. It intentionally does not parse input files in this stage.

## Semantic Targets
| Target ID | Object | Required Semantic Intent | PASS Condition | FAIL Condition |
| --- | --- | --- | --- | --- |
| T1 | netlist | Collect explicit evidence that `netlist` satisfies the checker intent. | Presence and semantic correctness are both supported by evidence. | Missing evidence or conflicting evidence. |
| T2 | power_emir | Collect explicit evidence that `power_emir` satisfies the checker intent. | Presence and semantic correctness are both supported by evidence. | Missing evidence or conflicting evidence. |
| T3 | spef | Collect explicit evidence that `spef` satisfies the checker intent. | Presence and semantic correctness are both supported by evidence. | Missing evidence or conflicting evidence. |

## Check Criteria
- Requirement value observed in item yaml: `N/A`
- Waiver value observed in item yaml: `N/A`
- A checker PASS requires every mandatory semantic target to satisfy its PASS condition.
- A checker FAIL is triggered when any mandatory target fails and no valid waiver contract applies.

## Evidence Plan
- Stage B (ParsingSpec) must locate file-level evidence with line numbers.
- Stage C (FormatSpec) must map extracted evidence into reusable requirement/waiver formats.
- No direct input file reads are allowed in this stage.

## Knowledge Notes
- score=1.484 source=`skills/IMP-10-0-0-00_skill.md` section=`Description` snippet="Confirm the netlist/spef version is correct."
- score=1.430 source=`skills/IMP-10-0-0-00_skill.md` section=`Suggested retrieval queries` snippet="- IMP-10-0-0-00 checker intent Confirm the netlist/spef version is correct. - physical implementation netlist power_emir spef evidence extraction - input_logs parasitics power_integrity timing_signoff best practices"
- score=1.086 source=`skills/IMP-10-0-0-00_skill.md` section=`Embedded schema` snippet="```yaml skill_schema: item_id: IMP-10-0-0-00 check_module: 10.0_STA_DCD_CHECK intent: verification knowledge_tags: - input_logs - parasitics - power_integrity - timing_signoff candidate_objects: - netlist - power_emir - ..."
- score=1.058 source=`skills/IMP-10-0-0-00_skill.md` section=`Module and Intent` snippet="- Module: `10.0_STA_DCD_CHECK` - Intent: `verification` - Candidate objects: netlist, power_emir, spef - Knowledge tags: input_logs, parasitics, power_integrity, timing_signoff"
- score=1.016 source=`skills/IMP-10-0-0-00_skill.md` section=`Input and Existing Implementation Clues` snippet="- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-00.yaml` - Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLI..."
- score=0.931 source=`skills/IMP-10-0-0-00_skill.md` section=`Keyword clues from existing checker` snippet="- `# Confirm the netlist/spef version is correct.` - `# - Extract netlist file path from read_netlist command` - `# - Open extracted netlist file to capture version timestamp from header (line 3)` - `# - Open extracted S..."
- score=0.848 source=`skills/IMP-10-0-0-00_skill.md` section=`Regex clues from existing checker` snippet="- `read_netlist\\s+([^\\s]+\\.v(?:\\.gz)?)` - `\\[INFO\\]\\s+Skipping SPEF reading as (.+)` - `read_spef\\s+([^\\s]+\\.spef(?:\\.gz)?)` - `#\\s*Parasitics Mode:\\s*(.+)` - `Top level cell is\\s+(\\S+)` - `Program version\\s*=\\s*([\\d\\.\\-..."
- score=0.429 source=`skills/IMP-14-0-0-00_skill.md` section=`Suggested retrieval queries` snippet="- IMP-14-0-0-00 checker intent Confirm set the correct golden netlist. - physical implementation netlist power_emir evidence extraction - power_integrity best practices"

## Embedded Schema
```yaml
itemspec:
  item_id: IMP-10-0-0-00
  description: "Confirm the netlist/spef version is correct."
  stage_boundary:
    reads_input_files: false
    depends_on_input_snippets: false
  semantic_targets:
    - target_id: T1
      object_name: netlist
      required_evidence:
        - source_file
        - line_number
        - extracted_value
      pass_when:
        - Required evidence exists and semantics are consistent
      fail_when:
        - Required evidence is missing or inconsistent
    - target_id: T2
      object_name: power_emir
      required_evidence:
        - source_file
        - line_number
        - extracted_value
      pass_when:
        - Required evidence exists and semantics are consistent
      fail_when:
        - Required evidence is missing or inconsistent
    - target_id: T3
      object_name: spef
      required_evidence:
        - source_file
        - line_number
        - extracted_value
      pass_when:
        - Required evidence exists and semantics are consistent
      fail_when:
        - Required evidence is missing or inconsistent
  pass_rule: all mandatory semantic targets satisfy pass_when
  fail_rule: any mandatory semantic target triggers fail_when
```
