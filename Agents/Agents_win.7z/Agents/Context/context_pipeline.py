#!/usr/bin/env python3
"""Context Agent staged pipeline implementation."""

from __future__ import annotations

import json
import re
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

# Add Agents root for direct script execution.
AGENTS_DIR = Path(__file__).resolve().parents[1]
if str(AGENTS_DIR) not in sys.path:
    sys.path.insert(0, str(AGENTS_DIR))

from CodeGen.llm_client import LLMClient, LLMMode, create_client  # type: ignore

try:
    from .io_resolver import ContextIOResolver, EvidenceBundle, ItemContext, stringify_records
    from .template_renderer import render_format_spec, render_itemspec, render_parsing_spec
    from .spec_contracts import (
        DecisionScenario,
        EvidenceMapping,
        EvidenceRecordModel,
        EvidenceSourcePriority,
        ExpectedOutcome,
        ExtractionConflict,
        ExtractionGap,
        FormatSpecContract,
        ItemSpecContract,
        ObjectStatusSummary,
        ParsingSpecContract,
        PatternIndexMapping,
        RequirementItem,
        ScenarioText,
        SemanticTarget,
        SubItemContract,
        WaiverKeywordTaxonomy,
        WaiverScope,
        CrossObjectRule,
    )
    from .retriever import LocalRAGRetriever, RetrievalHit
    from .spec_validators import (
        ensure_id_prefixed_outputs,
        validate_cross_spec_consistency,
        validate_format_spec,
        validate_itemspec,
        validate_parsing_spec,
    )
except ImportError:  # pragma: no cover
    from io_resolver import ContextIOResolver, EvidenceBundle, ItemContext, stringify_records
    from template_renderer import render_format_spec, render_itemspec, render_parsing_spec
    from spec_contracts import (
        DecisionScenario,
        EvidenceMapping,
        EvidenceRecordModel,
        EvidenceSourcePriority,
        ExpectedOutcome,
        ExtractionConflict,
        ExtractionGap,
        FormatSpecContract,
        ItemSpecContract,
        ObjectStatusSummary,
        ParsingSpecContract,
        PatternIndexMapping,
        RequirementItem,
        ScenarioText,
        SemanticTarget,
        SubItemContract,
        WaiverKeywordTaxonomy,
        WaiverScope,
        CrossObjectRule,
    )
    from retriever import LocalRAGRetriever, RetrievalHit
    from spec_validators import (
        ensure_id_prefixed_outputs,
        validate_cross_spec_consistency,
        validate_format_spec,
        validate_itemspec,
        validate_parsing_spec,
    )


DEFAULT_VIO_NAME_FORMAT = "item_name"


@dataclass
class ContextRunConfig:
    item_id: str
    checklist_root: Path
    output_root: Path
    item_yaml_path: Optional[Path] = None

    llm_mode: LLMMode = LLMMode.JEDAI
    jedai_model: str = "claude-opus-4-5"
    api_key: Optional[str] = None
    mocks_dir: Optional[Path] = None

    rag_index_dir: Optional[Path] = None
    rag_top_k: int = 8

    compatibility_mode: bool = False
    max_lines_per_input: int = 3000


@dataclass
class ContextArtifacts:
    item_id: str
    output_dir: Path
    item_yaml_path: Path

    itemspec_path: Path
    parsing_spec_path: Path
    format_spec_path: Path

    compatibility_paths: Dict[str, Path] = field(default_factory=dict)
    manifest_path: Optional[Path] = None


class ContextPipeline:
    """Generate ItemSpec -> ParsingSpec -> FormatSpec in three strict stages."""

    def __init__(self, config: ContextRunConfig):
        self.config = self._normalize_config(config)
        self.context_root = Path(__file__).resolve().parent
        self.prompt_dir = self.context_root / "prompts"

        self.io = ContextIOResolver(
            checklist_root=self.config.checklist_root,
            context_root=self.context_root,
        )
        self.retriever = self._create_retriever(self.config.rag_index_dir)
        self.llm_client = self._create_llm_client()

    @staticmethod
    def _normalize_config(config: ContextRunConfig) -> ContextRunConfig:
        mode = config.llm_mode
        if isinstance(mode, str):
            mode = LLMMode(mode)

        return ContextRunConfig(
            item_id=config.item_id,
            checklist_root=Path(config.checklist_root),
            output_root=Path(config.output_root),
            item_yaml_path=Path(config.item_yaml_path) if config.item_yaml_path else None,
            llm_mode=mode,
            jedai_model=config.jedai_model or "claude-opus-4-5",
            api_key=config.api_key,
            mocks_dir=Path(config.mocks_dir) if config.mocks_dir else None,
            rag_index_dir=Path(config.rag_index_dir) if config.rag_index_dir else None,
            rag_top_k=config.rag_top_k,
            compatibility_mode=bool(config.compatibility_mode),
            max_lines_per_input=int(config.max_lines_per_input),
        )

    def run(self) -> ContextArtifacts:
        item = self.io.load_item_context(item_id=self.config.item_id, item_yaml_path=self.config.item_yaml_path)

        output_dir = (self.config.output_root / item.item_id).resolve()
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Create debug directory for intermediate outputs
        debug_dir = output_dir / "debug"
        debug_dir.mkdir(parents=True, exist_ok=True)
        self._debug_dir = debug_dir
        
        # Write run summary header
        self._write_debug_file("run_summary.md", f"""# Context Agent Run Summary

**Item ID**: {item.item_id}
**LLM Mode**: {self.config.llm_mode.value}
**JEDAI Model**: {self.config.jedai_model if self.config.llm_mode == LLMMode.JEDAI else 'N/A'}
**Timestamp**: {self._get_timestamp()}
**Checklist Root**: {self.config.checklist_root}
**Output Dir**: {output_dir}

---

## Stage Execution Log

""")

        knowledge_hits = self._retrieve_knowledge(item)
        itemspec_contract = self._derive_itemspec_contract(item=item, knowledge_hits=knowledge_hits)
        itemspec_fallback = render_itemspec(itemspec_contract)
        itemspec_text = self._build_itemspec(
            item=item,
            knowledge_hits=knowledge_hits,
            fallback_text=itemspec_fallback,
        )
        if not validate_itemspec(itemspec_text, item.item_id).ok:
            itemspec_text = itemspec_fallback
            self._append_debug_file("run_summary.md", "- **Stage A (ItemSpec)**: Used FALLBACK (validation failed)\n")
        else:
            self._append_debug_file("run_summary.md", "- **Stage A (ItemSpec)**: LLM output accepted\n")
        itemspec_contract = ItemSpecContract.from_embedded_yaml(itemspec_text) or itemspec_contract

        evidence = self.io.extract_evidence(
            context=item,
            max_lines_per_input=self.config.max_lines_per_input,
        )
        parsing_contract = self._derive_parsing_contract(
            item=item,
            evidence=evidence,
            itemspec_contract=itemspec_contract,
        )
        parsing_fallback = render_parsing_spec(parsing_contract)
        parsing_text = self._build_parsing_spec(
            item=item,
            evidence=evidence,
            itemspec_text=itemspec_text,
            fallback_text=parsing_fallback,
        )
        if not validate_parsing_spec(parsing_text, item.item_id).ok:
            parsing_text = parsing_fallback
            self._append_debug_file("run_summary.md", "- **Stage B (ParsingSpec)**: Used FALLBACK (validation failed)\n")
        else:
            self._append_debug_file("run_summary.md", "- **Stage B (ParsingSpec)**: LLM output accepted\n")
        parsing_contract = ParsingSpecContract.from_embedded_yaml(parsing_text) or parsing_contract

        format_contract = self._derive_format_contract(
            item=item,
            evidence=evidence,
            itemspec_contract=itemspec_contract,
            parsing_contract=parsing_contract,
        )
        format_fallback = render_format_spec(format_contract)
        format_text = self._build_format_spec(
            item=item,
            evidence=evidence,
            itemspec_text=itemspec_text,
            parsing_text=parsing_text,
            fallback_text=format_fallback,
        )
        if not validate_format_spec(format_text, item.item_id).ok:
            format_text = format_fallback
            self._append_debug_file("run_summary.md", "- **Stage C (FormatSpec)**: Used FALLBACK (validation failed)\n")
        else:
            self._append_debug_file("run_summary.md", "- **Stage C (FormatSpec)**: LLM output accepted\n")

        cross_outcome = validate_cross_spec_consistency(
            itemspec_markdown=itemspec_text,
            parsing_markdown=parsing_text,
            format_markdown=format_text,
        )
        if not cross_outcome.ok:
            # Deterministic contract-rendered fallback remains the source of truth.
            itemspec_text = itemspec_fallback
            parsing_text = parsing_fallback
            format_text = format_fallback
            self._append_debug_file("run_summary.md", "- **Cross-Spec Validation**: FAILED, reverted all to FALLBACK\n")
            cross_outcome = validate_cross_spec_consistency(
                itemspec_markdown=itemspec_text,
                parsing_markdown=parsing_text,
                format_markdown=format_text,
            )
            if not cross_outcome.ok:
                raise RuntimeError(
                    "Cross-spec consistency validation failed after fallback: "
                    + "; ".join(cross_outcome.issues)
                )
        else:
            self._append_debug_file("run_summary.md", "- **Cross-Spec Validation**: PASSED\n")

        itemspec_path = output_dir / f"{item.item_id}_itemspec.md"
        parsing_path = output_dir / f"{item.item_id}_parsing_spec.md"
        format_path = output_dir / f"{item.item_id}_format_spec.md"

        itemspec_path.write_text(itemspec_text, encoding="utf-8")
        parsing_path.write_text(parsing_text, encoding="utf-8")
        format_path.write_text(format_text, encoding="utf-8")

        id_check = ensure_id_prefixed_outputs(item.item_id, [itemspec_path, parsing_path, format_path])
        if not id_check.ok:
            raise RuntimeError("; ".join(id_check.issues))

        compatibility_paths = self._write_compatibility_copies(
            itemspec_path=itemspec_path,
            parsing_path=parsing_path,
            format_path=format_path,
        )

        manifest_path = self._write_manifest(
            output_dir=output_dir,
            item=item,
            evidence=evidence,
            knowledge_hits=knowledge_hits,
            itemspec_path=itemspec_path,
            parsing_path=parsing_path,
            format_path=format_path,
            compatibility_paths=compatibility_paths,
        )

        return ContextArtifacts(
            item_id=item.item_id,
            output_dir=output_dir,
            item_yaml_path=item.item_yaml_path,
            itemspec_path=itemspec_path,
            parsing_spec_path=parsing_path,
            format_spec_path=format_path,
            compatibility_paths=compatibility_paths,
            manifest_path=manifest_path,
        )

    def _create_retriever(self, rag_index_dir: Optional[Path]) -> Optional[LocalRAGRetriever]:
        if rag_index_dir is None:
            rag_index_dir = self.context_root / "knowledge" / "rag" / "main"
        try:
            if rag_index_dir.exists():
                return LocalRAGRetriever(index_dir=rag_index_dir)
        except Exception:
            return None
        return None

    def _create_llm_client(self) -> Optional[LLMClient]:
        mode = self.config.llm_mode
        print(f"[Context Agent] LLM Mode: {mode.value}", end="")
        
        if mode == LLMMode.JEDAI:
            print(f" (model: {self.config.jedai_model})")
            return create_client(LLMMode.JEDAI, jedai_model=self.config.jedai_model)
        
        if mode == LLMMode.MOCK:
            print("")
            mocks_dir = self.config.mocks_dir
            if mocks_dir is None:
                default_mocks = self.context_root / "mocks"
                if default_mocks.exists():
                    mocks_dir = default_mocks
            if mocks_dir is None:
                return None
            if not Path(mocks_dir).exists():
                return None
            return create_client(LLMMode.MOCK, mocks_dir=Path(mocks_dir))

        if mode == LLMMode.REAL:
            return create_client(LLMMode.REAL, api_key=self.config.api_key)

        if mode == LLMMode.INTERACTIVE:
            return create_client(LLMMode.INTERACTIVE)

        return None

    def _retrieve_knowledge(self, item: ItemContext) -> List[RetrievalHit]:
        if self.retriever is None:
            return []
        query = f"{item.item_id} {item.description}".strip()
        try:
            return self.retriever.search(query=query, top_k=self.config.rag_top_k, item_id=item.item_id)
        except Exception:
            return []

    def _build_itemspec(
        self,
        item: ItemContext,
        knowledge_hits: Sequence[RetrievalHit],
        fallback_text: str,
    ) -> str:
        system_prompt = self._load_prompt(
            "stage_system.md",
            default=(
                "You are a senior digital physical implementation expert. "
                "Write concise, technical Markdown in English."
            ),
        )
        user_prompt = self._load_prompt(
            "itemspec_user.md",
            default="Create an ItemSpec in English.\n{{ITEM_CONTEXT}}\n{{KNOWLEDGE_CONTEXT}}",
        )
        user_prompt = self._inject_tokens(
            user_prompt,
            {
                # Use stage-specific context - NO regex_clues, NO resolved_inputs
                "ITEM_CONTEXT": json.dumps(self._item_summary_for_itemspec(item), indent=2),
                # Filter out regex clues sections from knowledge hits
                "KNOWLEDGE_CONTEXT": self._render_knowledge_hits(
                    knowledge_hits, 
                    exclude_sections=["Regex clues", "regex_clues", "Patterns"]
                ),
            },
        )

        return self._generate_or_fallback(
            stage_name="itemspec",
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            fallback=fallback_text,
            validator=lambda text: validate_itemspec(text, item.item_id),
        )

    def _build_parsing_spec(
        self,
        item: ItemContext,
        evidence: EvidenceBundle,
        itemspec_text: str,
        fallback_text: str,
    ) -> str:
        system_prompt = self._load_prompt(
            "stage_system.md",
            default=(
                "You are a senior digital physical implementation expert. "
                "Write concise, technical Markdown in English."
            ),
        )
        user_prompt = self._load_prompt(
            "parsing_spec_user.md",
            default="Create a ParsingSpec in English.\n{{ITEM_CONTEXT}}\n{{ITEMSPEC}}\n{{EVIDENCE}}",
        )
        user_prompt = self._inject_tokens(
            user_prompt,
            {
                # Use stage-specific context - HAS resolved_inputs, NO regex_clues
                "ITEM_CONTEXT": json.dumps(self._item_summary_for_parsing(item), indent=2),
                "ITEMSPEC": itemspec_text,
                "EVIDENCE": self._render_evidence_bundle(evidence),
            },
        )

        return self._generate_or_fallback(
            stage_name="parsing_spec",
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            fallback=fallback_text,
            validator=lambda text: validate_parsing_spec(text, item.item_id),
        )

    def _build_format_spec(
        self,
        item: ItemContext,
        evidence: EvidenceBundle,
        itemspec_text: str,
        parsing_text: str,
        fallback_text: str,
    ) -> str:
        system_prompt = self._load_prompt(
            "stage_system.md",
            default=(
                "You are a senior digital physical implementation expert. "
                "Write concise, technical Markdown in English."
            ),
        )
        user_prompt = self._load_prompt(
            "format_spec_user.md",
            default=(
                "Create a FormatSpec in English.\n{{ITEM_CONTEXT}}\n{{ITEMSPEC}}\n"
                "{{PARSING_SPEC}}\n{{EVIDENCE}}"
            ),
        )
        user_prompt = self._inject_tokens(
            user_prompt,
            {
                # Use stage-specific context - NO regex_clues, NO resolved_inputs
                "ITEM_CONTEXT": json.dumps(self._item_summary_for_format(item), indent=2),
                "ITEMSPEC": itemspec_text,
                "PARSING_SPEC": parsing_text,
                "EVIDENCE": self._render_evidence_bundle(evidence),
            },
        )

        return self._generate_or_fallback(
            stage_name="format_spec",
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            fallback=fallback_text,
            validator=lambda text: validate_format_spec(text, item.item_id),
        )

    def _generate_or_fallback(
        self,
        stage_name: str,
        system_prompt: str,
        user_prompt: str,
        fallback: str,
        validator,
        max_retries: int = 2,
    ) -> str:
        """
        Generate spec via LLM with self-critique retry loop.
        
        If validation fails, format the validation errors and retry with feedback.
        Falls back to deterministic template after max_retries exhausted.
        
        Args:
            stage_name: Name of the stage (for logging)
            system_prompt: System prompt for LLM
            user_prompt: User prompt for LLM
            fallback: Deterministic fallback template
            validator: Function that takes markdown and returns ValidationOutcome
            max_retries: Maximum number of retry attempts (default 2)
        
        Returns:
            Generated or fallback markdown string
        """
        try:
            from .spec_validators import ValidationOutcome
        except ImportError:
            from spec_validators import ValidationOutcome
        
        # Save LLM input to debug file
        self._save_llm_debug(f"stage_{stage_name}", system_prompt, user_prompt, None)
        
        if self.llm_client is None:
            self._append_debug_file("run_summary.md", f"  - LLM client is None, using fallback\n")
            return fallback

        current_user_prompt = user_prompt
        
        for attempt in range(max_retries + 1):
            attempt_num = attempt + 1
            self._append_debug_file("run_summary.md", f"  - Attempt {attempt_num}/{max_retries + 1} for {stage_name}\n")
            
            try:
                response = self.llm_client.generate(system_prompt=system_prompt, user_prompt=current_user_prompt)
            except Exception as e:
                self._append_debug_file("run_summary.md", f"  - LLM call failed: {str(e)}, using fallback\n")
                return fallback

            # Save LLM output to debug file
            self._save_llm_debug(f"stage_{stage_name}_attempt{attempt_num}", system_prompt, current_user_prompt, response)

            if not response or not response.strip():
                self._append_debug_file("run_summary.md", f"  - LLM response empty, using fallback\n")
                return fallback

            text = response.strip()
            
            # Call validator - it returns ValidationOutcome with detailed feedback
            validation_result = validator(text)
            
            # Handle both bool and ValidationOutcome returns for backward compatibility
            if isinstance(validation_result, bool):
                if validation_result:
                    self._append_debug_file("run_summary.md", f"  - Attempt {attempt_num}: validation PASSED\n")
                    return text
                else:
                    self._append_debug_file("run_summary.md", f"  - Attempt {attempt_num}: validation FAILED (no details)\n")
                    if attempt < max_retries:
                        # Simple retry without detailed feedback
                        current_user_prompt = user_prompt + "\n\n## RETRY\nPrevious attempt failed validation. Please try again."
                    continue
            
            # ValidationOutcome case
            if validation_result.ok:
                self._append_debug_file("run_summary.md", f"  - Attempt {attempt_num}: validation PASSED\n")
                return text
            
            # Validation failed - log details
            issues_summary = "; ".join(validation_result.issues[:3])
            self._append_debug_file("run_summary.md", f"  - Attempt {attempt_num}: validation FAILED - {issues_summary}\n")
            
            if attempt < max_retries:
                # Format validation feedback for retry
                feedback = validation_result.format_for_llm_feedback()
                current_user_prompt = user_prompt + "\n\n" + feedback
                self._append_debug_file("run_summary.md", f"  - Retrying with validation feedback...\n")
            else:
                self._append_debug_file("run_summary.md", f"  - Max retries exhausted, using fallback\n")

        # All retries exhausted - use fallback
        return fallback

    def _derive_itemspec_contract(
        self,
        item: ItemContext,
        knowledge_hits: Sequence[RetrievalHit],
    ) -> ItemSpecContract:
        objects = self._infer_objects(item)
        object_subitems = self._infer_object_subitems(item=item, objects=objects)

        semantic_targets: List[SemanticTarget] = []
        for idx, obj in enumerate(objects, start=1):
            target_id = f"T{idx}"
            semantic_intent = self._semantic_intent_for_object(item=item, obj=obj)
            sub_items = [
                SubItemContract(
                    name=sub_name,
                    required=bool(required),
                    semantics=semantics,
                    pass_condition=f"Evidence confirms `{sub_name}` semantics.",
                    fail_condition="Missing evidence or conflicting evidence.",
                )
                for sub_name, required, semantics in object_subitems.get(obj, [])
            ]
            semantic_targets.append(
                SemanticTarget(
                    target_id=target_id,
                    object_name=obj,
                    semantic_intent=semantic_intent,
                    sub_items=sub_items,
                    pass_when=["Presence and semantic correctness are both supported by evidence."],
                    fail_when=["Missing evidence or conflicting evidence."],
                )
            )

        cross_rules: List[CrossObjectRule] = []
        if len(semantic_targets) >= 2:
            a = semantic_targets[0]
            b = semantic_targets[1]
            a_sub = {x.name for x in a.sub_items}
            b_sub = {x.name for x in b.sub_items}
            if "design_name" in a_sub and "design_name" in b_sub:
                cross_rules.append(
                    CrossObjectRule(
                        rule_id="CR1",
                        expression=f"{a.object_name}.design_name == {b.object_name}.design_name",
                        required=True,
                        pass_when=["Both values exist and are equal."],
                        fail_when=["One value missing or values mismatch."],
                    )
                )

        waiver_scopes = [
            WaiverScope(
                granularity="object-level",
                token_format="<object>:*",
                effect_scope="Waive all mandatory sub-items for one object.",
            ),
            WaiverScope(
                granularity="sub-item-level",
                token_format="<object>:<sub_item>",
                effect_scope="Waive one explicit sub-item only.",
            ),
        ]
        decision_matrix = [
            DecisionScenario("S1", "N/A", "N/A", "Semantic presence and consistency only, no waiver allowed."),
            DecisionScenario("S2", "N/A", ">0", "Semantic presence and consistency; violations can be waived."),
            DecisionScenario("S3", ">0", "N/A", "Requirement pattern matching without waiver."),
            DecisionScenario("S4", ">0", ">0", "Requirement pattern matching with waiver handling."),
        ]
        source_priority = [
            EvidenceSourcePriority("Primary", "Runtime log files", "Object load status, key commands, top-level design identity."),
            EvidenceSourcePriority("Secondary", "Referenced netlist header", "Generator tool/version/time provenance."),
            EvidenceSourcePriority("Secondary", "Referenced SPEF header", "Extractor tool/version/time provenance."),
        ]
        knowledge_lines = []
        for line in self._render_knowledge_hits(knowledge_hits).splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            if stripped.startswith("- "):
                stripped = stripped[2:]
            knowledge_lines.append(stripped)

        return ItemSpecContract(
            item_id=item.item_id,
            description=item.description or "N/A",
            check_module=item.check_module or item.checklist_row.check_module or "N/A",
            interpretation_rules=[
                "Slash notation defaults to logical AND across objects unless explicit `or` is present.",
                "Explicit `or` denotes alternatives where at least one branch must satisfy the requirement.",
                "Optional components are modeled as optional sub-items and may be governed by waiver contracts.",
            ],
            semantic_targets=semantic_targets,
            cross_object_rules=cross_rules,
            waiver_scopes=waiver_scopes,
            decision_matrix=decision_matrix,
            evidence_source_priority=source_priority,
            requirement_value_observed=str(item.requirements_value),
            waiver_value_observed=str(item.waiver_value),
            knowledge_notes=knowledge_lines,
        )

    def _derive_parsing_contract(
        self,
        item: ItemContext,
        evidence: EvidenceBundle,
        itemspec_contract: ItemSpecContract,
    ) -> ParsingSpecContract:
        contract_map: Dict[str, Dict[str, bool]] = {}
        for target in itemspec_contract.semantic_targets:
            rows = contract_map.setdefault(target.object_name, {})
            for sub in target.sub_items:
                rows[sub.name] = bool(sub.required)

        evidence_records: List[EvidenceRecordModel] = []
        evidence_id_to_record: Dict[str, EvidenceRecordModel] = {}
        for idx, rec in enumerate(evidence.input_records, start=1):
            evidence_id = f"EV{idx}"
            extracted = "; ".join(rec.extracted_values) if rec.extracted_values else rec.line_text.strip()
            row = EvidenceRecordModel(
                evidence_id=evidence_id,
                source_file=str(rec.source_file),
                line_number=rec.line_number,
                pattern=rec.pattern,
                extracted_value=extracted,
                raw_line=rec.line_text.strip(),
                confidence=1.0,
            )
            evidence_records.append(row)
            evidence_id_to_record[evidence_id] = row

        referenced_records: List[EvidenceRecordModel] = []
        for idx, rec in enumerate(evidence.referenced_records, start=1):
            evidence_id = f"RF{idx}"
            extracted = "; ".join(rec.extracted_values) if rec.extracted_values else rec.line_text.strip()
            referenced_records.append(
                EvidenceRecordModel(
                    evidence_id=evidence_id,
                    source_file=str(rec.source_file),
                    line_number=rec.line_number,
                    pattern=rec.pattern,
                    extracted_value=extracted,
                    raw_line=rec.line_text.strip(),
                    confidence=1.0,
                )
            )

        all_primary_records: List[EvidenceRecordModel] = list(evidence_records) + list(referenced_records)
        for row in referenced_records:
            evidence_id_to_record[row.evidence_id] = row

        mappings: List[EvidenceMapping] = []
        for row in all_primary_records:
            obj, sub_item, status, rationale = self._map_evidence_to_contract(
                evidence_row=row,
                contract_map=contract_map,
                itemspec_contract=itemspec_contract,
            )
            mappings.append(
                EvidenceMapping(
                    evidence_id=row.evidence_id,
                    object_name=obj,
                    sub_item=sub_item,
                    required=bool(contract_map.get(obj, {}).get(sub_item, False)),
                    mapping_status=status,
                    rationale=rationale,
                )
            )

        derived_records, derived_mappings = self._derive_additional_parsing_evidence(
            mappings=mappings,
            evidence_id_to_record=evidence_id_to_record,
            contract_map=contract_map,
        )
        if derived_records:
            evidence_records.extend(derived_records)
            for row in derived_records:
                evidence_id_to_record[row.evidence_id] = row
            mappings.extend(derived_mappings)

        # Build mandatory coverage by object/sub-item.
        found_required: Dict[Tuple[str, str], bool] = {}
        observed_values: Dict[Tuple[str, str], List[str]] = {}
        for obj_name, sub_map in contract_map.items():
            for sub_name, is_required in sub_map.items():
                if is_required:
                    found_required[(obj_name, sub_name)] = False
                observed_values[(obj_name, sub_name)] = []

        for mapping in mappings:
            if mapping.mapping_status not in {"mapped", "mapped_with_fallback", "mapped_derived"}:
                continue
            rec = evidence_id_to_record.get(mapping.evidence_id)
            if rec is None:
                continue
            key = (mapping.object_name, mapping.sub_item)
            if key in observed_values:
                if rec.extracted_value:
                    observed_values[key].append(rec.extracted_value)
            if key in found_required:
                if rec.extracted_value or rec.raw_line:
                    found_required[key] = True

        object_status_summary: List[ObjectStatusSummary] = []
        extraction_gaps: List[ExtractionGap] = []
        mandatory_found = 0
        mandatory_total = 0
        for obj_name, sub_map in contract_map.items():
            required_subs = [sub for sub, req in sub_map.items() if req]
            total = len(required_subs)
            found = 0
            missing_required: List[str] = []
            for sub_name in required_subs:
                mandatory_total += 1
                if found_required.get((obj_name, sub_name), False):
                    found += 1
                    mandatory_found += 1
                else:
                    missing_required.append(sub_name)
                    extraction_gaps.append(
                        ExtractionGap(
                            object_name=obj_name,
                            sub_item=sub_name,
                            gap_type="mandatory_missing",
                            detail=f"No mapped evidence for mandatory sub-item `{sub_name}`.",
                            suggested_resolution=f"Provide waiver `{obj_name}:*` or add valid evidence.",
                        )
                    )

            if total == 0:
                status = "PASS"
                blocker = "none"
            elif found == total:
                status = "PASS"
                blocker = "none"
            elif found == 0:
                status = "FAIL"
                blocker = "No mandatory sub-item is satisfied."
            else:
                status = "PARTIAL"
                blocker = f"Missing mandatory sub-items: {', '.join(missing_required)}"
            object_status_summary.append(
                ObjectStatusSummary(
                    object_name=obj_name,
                    mandatory_found=found,
                    mandatory_total=total,
                    status=status,
                    blocker_reason=blocker,
                )
            )

        conflicts: List[ExtractionConflict] = []
        for key, values in observed_values.items():
            normalized = sorted({x.strip() for x in values if x.strip()})
            if len(normalized) <= 1:
                continue
            conflicts.append(
                ExtractionConflict(
                    object_name=key[0],
                    sub_item=key[1],
                    conflict_type="conflicting_values",
                    candidates=normalized,
                    resolution_hint="Prefer value from highest-priority source or earliest explicit command.",
                )
            )

        # Preserve missing input files as explicit gaps.
        for missing in evidence.missing_inputs:
            extraction_gaps.append(
                ExtractionGap(
                    object_name="input_resolution",
                    sub_item="input_file",
                    gap_type="missing_input_file",
                    detail=f"Configured input file is missing: {missing}",
                    suggested_resolution="Fix input path in item yaml or provide file in expected location.",
                )
            )

        return ParsingSpecContract(
            item_id=item.item_id,
            description=item.description or "N/A",
            check_module=item.check_module or item.checklist_row.check_module or "N/A",
            resolved_inputs=[str(x) for x in evidence.resolved_inputs],
            missing_inputs=list(evidence.missing_inputs),
            evidence_records=evidence_records,
            referenced_file_records=referenced_records,
            evidence_to_sub_item=mappings,
            object_status_summary=object_status_summary,
            extraction_gaps=extraction_gaps,
            conflicts=conflicts,
            mandatory_found=mandatory_found,
            mandatory_total=mandatory_total,
        )

    def _derive_additional_parsing_evidence(
        self,
        mappings: Sequence[EvidenceMapping],
        evidence_id_to_record: Dict[str, EvidenceRecordModel],
        contract_map: Dict[str, Dict[str, bool]],
    ) -> Tuple[List[EvidenceRecordModel], List[EvidenceMapping]]:
        existing_pairs = {(m.object_name, m.sub_item) for m in mappings if m.mapping_status in {"mapped", "mapped_with_fallback", "mapped_derived"}}

        mapped_records_by_object: Dict[str, EvidenceRecordModel] = {}
        file_path_record_by_object: Dict[str, EvidenceRecordModel] = {}
        version_record_by_object: Dict[str, Tuple[int, str, EvidenceRecordModel]] = {}

        for mapping in mappings:
            if mapping.mapping_status not in {"mapped", "mapped_with_fallback"}:
                continue
            rec = evidence_id_to_record.get(mapping.evidence_id)
            if rec is None:
                continue
            mapped_records_by_object.setdefault(mapping.object_name, rec)
            if mapping.sub_item == "file_path" and rec.extracted_value:
                file_path_record_by_object.setdefault(mapping.object_name, rec)
            token = ""
            if mapping.sub_item in {"generator_version", "extractor_version", "version_token", "generator_tool", "extractor_tool"}:
                token = self._extract_version_token(rec.extracted_value) or self._extract_version_token(rec.raw_line)
            if token:
                score = self._score_version_candidate(mapping=mapping, rec=rec)
                current = version_record_by_object.get(mapping.object_name)
                if current is None or score > current[0]:
                    version_record_by_object[mapping.object_name] = (score, token, rec)

        derived_records: List[EvidenceRecordModel] = []
        derived_mappings: List[EvidenceMapping] = []
        counter = 1

        def emit(obj_name: str, sub_item: str, rec: EvidenceRecordModel, value: str, pattern: str, rationale: str) -> None:
            nonlocal counter
            evidence_id = f"DV{counter}"
            counter += 1
            derived_records.append(
                EvidenceRecordModel(
                    evidence_id=evidence_id,
                    source_file=rec.source_file,
                    line_number=rec.line_number,
                    pattern=pattern,
                    extracted_value=value,
                    raw_line=rec.raw_line,
                    confidence=0.95,
                )
            )
            derived_mappings.append(
                EvidenceMapping(
                    evidence_id=evidence_id,
                    object_name=obj_name,
                    sub_item=sub_item,
                    required=bool(contract_map.get(obj_name, {}).get(sub_item, False)),
                    mapping_status="mapped_derived",
                    rationale=rationale,
                )
            )
            existing_pairs.add((obj_name, sub_item))

        for obj_name, sub_map in contract_map.items():
            first_record = mapped_records_by_object.get(obj_name)
            if first_record is None:
                continue

            if "source_reference" in sub_map and (obj_name, "source_reference") not in existing_pairs:
                source_ref = f"{first_record.source_file}:{first_record.line_number}"
                emit(
                    obj_name=obj_name,
                    sub_item="source_reference",
                    rec=first_record,
                    value=source_ref,
                    pattern="<derived:source_reference>",
                    rationale="Derived source_reference from first mapped evidence source and line.",
                )

            if "file_name" in sub_map and (obj_name, "file_name") not in existing_pairs:
                path_record = file_path_record_by_object.get(obj_name)
                if path_record is not None:
                    base = Path(path_record.extracted_value.split(";")[0].strip().strip("\"'")).name
                    if base:
                        emit(
                            obj_name=obj_name,
                            sub_item="file_name",
                            rec=path_record,
                            value=base,
                            pattern="<derived:file_name_from_file_path>",
                            rationale="Derived file_name from mapped file_path evidence.",
                        )

            if "version_token" in sub_map and (obj_name, "version_token") not in existing_pairs:
                version_pack = version_record_by_object.get(obj_name)
                if version_pack is not None:
                    _, token, token_record = version_pack
                    emit(
                        obj_name=obj_name,
                        sub_item="version_token",
                        rec=token_record,
                        value=token,
                        pattern="<derived:version_token>",
                        rationale="Derived version_token from mapped version-like evidence.",
                    )

        return derived_records, derived_mappings

    @staticmethod
    def _score_version_candidate(mapping: EvidenceMapping, rec: EvidenceRecordModel) -> int:
        score = 0
        evidence_id = mapping.evidence_id.upper()
        line = rec.raw_line.lower()
        pattern = rec.pattern.lower()
        source = rec.source_file.lower()

        if evidence_id.startswith("RF"):
            score += 100
        elif evidence_id.startswith("EV"):
            score += 10
        elif evidence_id.startswith("DV"):
            score += 5

        if mapping.sub_item in {"generator_version", "extractor_version", "version_token"}:
            score += 30
        elif mapping.sub_item in {"generator_tool", "extractor_tool"}:
            score += 10

        if "generated by" in line or "generated by" in pattern:
            score += 20
        if "program version" in line or "program version" in pattern:
            score += 5
        if "/logs/" in source:
            score += 1
        else:
            score += 10
        return score

    def _derive_format_contract(
        self,
        item: ItemContext,
        evidence: EvidenceBundle,
        itemspec_contract: ItemSpecContract,
        parsing_contract: ParsingSpecContract,
    ) -> FormatSpecContract:
        evidence_value_map: Dict[str, str] = {}
        for row in parsing_contract.evidence_records:
            evidence_value_map[row.evidence_id] = row.extracted_value
        for row in parsing_contract.referenced_file_records:
            evidence_value_map[row.evidence_id] = row.extracted_value

        parsed_values_by_key: Dict[Tuple[str, str], List[str]] = {}
        for mapping in parsing_contract.evidence_to_sub_item:
            if mapping.mapping_status not in {"mapped", "mapped_with_fallback", "mapped_derived"}:
                continue
            rec_val = evidence_value_map.get(mapping.evidence_id, "")
            normalized = self._normalize_sub_item_value(mapping.sub_item, rec_val)
            if not normalized:
                continue
            parsed_values_by_key.setdefault((mapping.object_name, mapping.sub_item), []).append(normalized)

        required_pairs: List[Tuple[str, str]] = []
        for target in itemspec_contract.semantic_targets:
            for sub in target.sub_items:
                if sub.required:
                    required_pairs.append((target.object_name, sub.name))

        # Map mandatory fields to requirement items.
        requirement_items: List[RequirementItem] = []
        req_idx = 1
        for obj_name, sub_name in required_pairs:
            related = [
                m for m in parsing_contract.evidence_to_sub_item
                if m.object_name == obj_name and m.sub_item == sub_name and m.mapping_status in {"mapped", "mapped_with_fallback", "mapped_derived"}
            ]
            evidence_ids = [m.evidence_id for m in related]
            candidate_values = [evidence_value_map.get(eid, "") for eid in evidence_ids]
            raw_value = self._select_requirement_value(obj_name=obj_name, sub_name=sub_name, values=candidate_values)
            if raw_value:
                if sub_name == "status":
                    pattern = self._derive_status_pattern(object_name=obj_name, raw_value=raw_value)
                elif sub_name == "design_name":
                    pattern = raw_value
                else:
                    pattern = self._generalize_value(raw_value) or raw_value
            else:
                pattern = self._default_pattern_for_sub_item(
                    object_name=obj_name,
                    sub_item=sub_name,
                    parsed_values_by_key=parsed_values_by_key,
                )
            comparator = self._infer_comparator(pattern=pattern)
            requirement_items.append(
                RequirementItem(
                    requirement_id=f"R{req_idx}",
                    object_name=obj_name,
                    sub_item=sub_name,
                    pattern=pattern,
                    comparator=comparator,
                    source_evidence_ids=evidence_ids[:5],
                )
            )
            req_idx += 1

        if not requirement_items:
            # Keep deterministic behavior even when evidence is empty.
            # Use first object from itemspec_contract or default to netlist
            default_obj = itemspec_contract.semantic_targets[0].object_name if itemspec_contract.semantic_targets else "netlist"
            requirement_items.append(
                RequirementItem(
                    requirement_id="R1",
                    object_name=default_obj,
                    sub_item="file_path",
                    pattern="*",
                    comparator="glob",
                    source_evidence_ids=[],
                )
            )

        pattern_index_mapping = [
            PatternIndexMapping(index=idx, requirement_id=req.requirement_id, target=f"{req.object_name}.{req.sub_item}")
            for idx, req in enumerate(requirement_items)
        ]

        waiver_items = [x for x in item.waive_items if str(x).strip()]
        if not waiver_items:
            obj_names = [t.object_name for t in itemspec_contract.semantic_targets]
            waiver_items = [f"{obj}:*" for obj in obj_names]

        taxonomy: List[WaiverKeywordTaxonomy] = []
        for idx, token in enumerate(waiver_items, start=1):
            token_obj = token.split(":")[0] if ":" in token else token
            scenario = "object_missing" if token.endswith(":*") else "field_exception"
            taxonomy.append(
                WaiverKeywordTaxonomy(
                    scenario=f"{scenario}_{idx}",
                    waiver_item=token,
                    keywords=[token_obj, "waive", "exception", "approved", "configured_waiver"],
                    sample_reason=f"{token_obj} mismatch accepted by stage-specific design review.",
                )
            )

        expected_rows = self._derive_expected_outcomes(item=item, evidence=evidence)
        expected_outcomes = [
            ExpectedOutcome(
                scenario=s,
                requirements_value=req,
                waivers_value=wa,
                decision_rule=rule,
                expected_result_with_current_evidence=result,
            )
            for s, req, wa, rule, result in expected_rows
        ]

        gaps_by_object = sorted({g.object_name for g in parsing_contract.extraction_gaps if g.object_name and g.object_name not in {"input_resolution"}})
        required_waivers_to_pass = [f"{obj}:*" for obj in gaps_by_object]
        req_na = str(item.requirements_value).strip().upper() == "N/A"
        if req_na:
            preferred_scenario = "S2" if required_waivers_to_pass else "S1"
        else:
            preferred_scenario = "S4" if required_waivers_to_pass else "S3"

        return FormatSpecContract(
            item_id=item.item_id,
            description=item.description or "N/A",
            check_module=item.check_module or item.checklist_row.check_module or "N/A",
            vio_name_format=DEFAULT_VIO_NAME_FORMAT,
            pattern_strategy=self._derive_pattern_notes(evidence),
            requirement_items=requirement_items,
            pattern_index_mapping=pattern_index_mapping,
            waiver_items=waiver_items,
            waiver_keyword_taxonomy=taxonomy,
            scenario_config=self._default_scenario_config(),
            expected_outcomes=expected_outcomes,
            preferred_scenario=preferred_scenario,
            required_waivers_to_pass=required_waivers_to_pass,
        )

    def _map_evidence_to_contract(
        self,
        evidence_row: EvidenceRecordModel,
        contract_map: Dict[str, Dict[str, bool]],
        itemspec_contract: ItemSpecContract,
    ) -> Tuple[str, str, str, str]:
        objects = list(contract_map.keys()) or [t.object_name for t in itemspec_contract.semantic_targets] or ["netlist"]
        source_text = evidence_row.source_file.lower()
        merged = " ".join(
            [
                source_text,
                evidence_row.raw_line.lower(),
                evidence_row.pattern.lower(),
                evidence_row.extracted_value.lower(),
            ]
        )

        # 1) object candidate.
        obj = ""
        for candidate in objects:
            if candidate.lower() in merged:
                obj = candidate
                break
        if not obj:
            if ".spef" in merged and "spef" in contract_map:
                obj = "spef"
            elif (".v" in merged or ".sv" in merged or "netlist" in merged) and "netlist" in contract_map:
                obj = "netlist"
        if not obj:
            if (".spef" in source_text or "parasitics" in merged) and "spef" in contract_map:
                obj = "spef"
            elif re.search(r"\.(v|sv)(\.gz)?$", source_text) and "netlist" in contract_map:
                obj = "netlist"
        if not obj:
            obj = objects[0]
            obj_status = "mapped_with_fallback"
            obj_reason = f"Object fallback applied: `{obj}` selected as default."
        else:
            obj_status = "mapped"
            obj_reason = f"Object mapped by lexical match: `{obj}`."

        allowed = contract_map.get(obj, {})
        sub_candidates: List[str] = []
        if "read_netlist" in merged or "read_spef" in merged:
            sub_candidates.extend(["file_path", "file_name", "source_reference", "status"])
        if "top level cell" in merged or "*design" in merged:
            sub_candidates.append("design_name")
        if "generated by" in merged:
            if obj == "netlist":
                sub_candidates.extend(["generator_tool", "generator_version", "version_token"])
            elif obj == "spef":
                sub_candidates.extend(["extractor_tool", "extractor_version", "version_token"])
            else:
                sub_candidates.extend(["generator_tool", "extractor_tool", "version_token"])
        if "program version" in merged or "*version" in merged:
            sub_candidates.extend(["generator_version", "extractor_version", "version_token"])
        if "generated on" in merged or "*date" in merged:
            sub_candidates.extend(["generation_time", "extraction_time"])
        if any(tok in merged for tok in ["skip", "missing", "error", "failed"]):
            sub_candidates.extend(["status", "status_reason"])
        if not sub_candidates:
            sub_candidates.extend(["status", "source_reference", "file_name", "file_path", "version_token"])

        chosen_sub = ""
        for candidate in sub_candidates:
            if candidate in allowed:
                chosen_sub = candidate
                break
        if not chosen_sub:
            if "status" in allowed:
                chosen_sub = "status"
            elif allowed:
                chosen_sub = sorted(allowed.keys())[0]
            else:
                chosen_sub = "unknown"
            status = "mapped_with_fallback" if chosen_sub != "unknown" else "unmapped"
            rationale = f"{obj_reason} Sub-item fallback applied: `{chosen_sub}`."
            return obj, chosen_sub, status, rationale

        rationale = f"{obj_reason} Sub-item mapped by pattern semantics: `{chosen_sub}`."
        return obj, chosen_sub, obj_status, rationale

    @staticmethod
    def _extract_version_token(text: str) -> str:
        value = (text or "").strip()
        if not value:
            return ""
        tokens = re.findall(r"[A-Za-z0-9._-]+", value)
        for token in tokens:
            if "/" in token or "\\" in token:
                continue
            if not re.search(r"\d", token):
                continue
            if not re.search(r"[._-]", token):
                continue
            return token.strip(".,;:")
        return ""

    @staticmethod
    def _default_scenario_config() -> Dict[str, ScenarioText]:
        return {
            "scenario_1": ScenarioText(
                found_desc="Required evidence extracted and semantically valid",
                missing_desc="Required evidence missing or semantically invalid",
                found_reason="Parsing evidence supports checker intent",
                missing_reason="Parsing evidence does not satisfy checker intent",
            ),
            "scenario_2": ScenarioText(
                found_desc="Required evidence extracted and semantically valid",
                missing_desc="Required evidence missing or semantically invalid",
                waived_desc="Violation waived by configured waiver items",
                unused_desc="Unused waiver entries",
                found_reason="Parsing evidence supports checker intent",
                missing_reason="Parsing evidence does not satisfy checker intent",
                waived_reason="Waiver item matched violation context",
                unused_reason="Waiver item has no matching violation",
            ),
            "scenario_3": ScenarioText(
                found_desc="Requirement pattern items matched",
                missing_desc="Requirement pattern items not matched",
                found_reason="All required pattern comparisons satisfied",
                missing_reason="At least one required pattern comparison failed",
            ),
            "scenario_4": ScenarioText(
                found_desc="Requirement pattern items matched",
                missing_desc="Requirement pattern items not matched",
                waived_desc="Violation waived by configured waiver items",
                unused_desc="Unused waiver entries",
                found_reason="All required pattern comparisons satisfied",
                missing_reason="At least one required pattern comparison failed",
                waived_reason="Waiver item matched violation context",
                unused_reason="Waiver item has no matching violation",
            ),
        }

    def _fallback_itemspec(self, item: ItemContext, knowledge_hits: Sequence[RetrievalHit]) -> str:
        objects = self._infer_objects(item)
        object_subitems = self._infer_object_subitems(item=item, objects=objects)
        targets: List[str] = []
        contract_rows: List[str] = []
        schema_targets: List[str] = []

        for idx, obj in enumerate(objects, start=1):
            target_id = f"T{idx}"
            semantic_intent = self._semantic_intent_for_object(item=item, obj=obj)
            targets.append(
                f"| {target_id} | {obj} | {semantic_intent} | "
                f"Presence and semantic correctness are both supported by evidence. | Missing evidence or conflicting evidence. |"
            )
            sub_item_rows: List[str] = []
            for sub_name, required, semantics in object_subitems.get(obj, []):
                required_label = "mandatory" if required else "optional"
                contract_rows.append(
                    f"| {obj} | `{sub_name}` | {required_label} | {semantics} | "
                    f"Evidence confirms `{sub_name}` semantics. | Missing evidence or inconsistent semantics. |"
                )
                sub_item_rows.append(
                    "        - name: " + sub_name + "\n"
                    + "          required: " + ("true" if required else "false") + "\n"
                    + "          semantics: " + json.dumps(semantics)
                )
            schema_targets.append(
                "    - target_id: " + target_id + "\n"
                f"      object_name: {obj}\n"
                "      semantic_intent: " + json.dumps(semantic_intent) + "\n"
                "      sub_items:\n"
                + ("\n".join(sub_item_rows) if sub_item_rows else "        - name: status\n          required: true\n          semantics: \"Object status is explicitly reported\"")
                + "\n"
                "      required_evidence:\n"
                "        - source_file\n"
                "        - line_number\n"
                "        - extracted_value\n"
                "      pass_when:\n"
                "        - Required evidence exists and semantics are consistent\n"
                "      fail_when:\n"
                "        - Required evidence is missing or inconsistent"
            )

        knowledge_md = self._render_knowledge_hits(knowledge_hits)

        return (
            f"# {item.item_id} ItemSpec\n\n"
            f"Description: {item.description or 'N/A'}\n"
            f"Check Module: {item.check_module or item.checklist_row.check_module or 'N/A'}\n"
            f"Role: Senior digital physical implementation expert\n\n"
            "## Scope\n"
            "This specification defines what must be checked semantically. "
            "It intentionally does not parse input files in this stage.\n\n"
            "## Description Interpretation Rules\n"
            "- Slash notation defaults to logical AND across objects unless explicit `or` is present.\n"
            "- Explicit `or` denotes alternatives where at least one branch must satisfy the requirement.\n"
            "- Optional components are modeled as optional sub-items and may be governed by waiver contracts.\n\n"
            "## Semantic Targets\n"
            "| Target ID | Object | Required Semantic Intent | PASS Condition | FAIL Condition |\n"
            "| --- | --- | --- | --- | --- |\n"
            + "\n".join(targets)
            + "\n\n"
            "### Object/Sub-Item Contract\n"
            "| Object | Sub-Item | Required | Semantic Meaning | PASS Condition | FAIL Condition |\n"
            "| --- | --- | --- | --- | --- | --- |\n"
            + ("\n".join(contract_rows) if contract_rows else "| netlist | `file_path` | mandatory | Full path to netlist file. | Evidence confirms file_path. | Path missing or inconsistent. |")
            + "\n\n"
            "## Check Criteria\n"
            f"- Requirement value observed in item yaml: `{item.requirements_value}`\n"
            f"- Waiver value observed in item yaml: `{item.waiver_value}`\n"
            "- A checker PASS requires every mandatory semantic target to satisfy its PASS condition.\n"
            "- A checker FAIL is triggered when any mandatory target fails and no valid waiver contract applies.\n\n"
            "## Evidence Plan\n"
            "- Stage B (ParsingSpec) must locate file-level evidence with line numbers.\n"
            "- Stage C (FormatSpec) must map extracted evidence into reusable requirement/waiver formats.\n"
            "- No direct input file reads are allowed in this stage.\n\n"
            "## Knowledge Notes\n"
            f"{knowledge_md}\n\n"
            "## Embedded Schema\n"
            "```yaml\n"
            "itemspec:\n"
            f"  item_id: {item.item_id}\n"
            f"  description: {json.dumps(item.description or 'N/A')}\n"
            "  stage_boundary:\n"
            "    reads_input_files: false\n"
            "    depends_on_input_snippets: false\n"
            "  semantic_targets:\n"
            + "\n".join(schema_targets)
            + "\n"
            "  pass_rule: all mandatory semantic targets satisfy pass_when\n"
            "  fail_rule: any mandatory semantic target triggers fail_when\n"
            "```\n"
        )

    def _fallback_parsing_spec(self, item: ItemContext, evidence: EvidenceBundle) -> str:
        input_table = stringify_records(evidence.input_records, max_rows=40)
        ref_table = stringify_records(evidence.referenced_records, max_rows=30)

        resolved_block = "\n".join([f"- {p}" for p in evidence.resolved_inputs]) or "- (none)"
        missing_block = "\n".join([f"- {p}" for p in evidence.missing_inputs]) or "- (none)"
        notes_block = "\n".join([f"- {n}" for n in evidence.notes]) or "- (none)"
        resolved_schema = (
            "  resolved_inputs:\n" + "\n".join([f"    - {p}" for p in evidence.resolved_inputs])
            if evidence.resolved_inputs
            else "  resolved_inputs: []"
        )
        missing_schema = (
            "  missing_inputs:\n" + "\n".join([f"    - {p}" for p in evidence.missing_inputs])
            if evidence.missing_inputs
            else "  missing_inputs: []"
        )

        schema_records: List[str] = []
        for idx, rec in enumerate(evidence.input_records[:20], start=1):
            vals = rec.extracted_values or [rec.line_text.strip()]
            scalar = "; ".join(vals).replace("\"", "'")
            schema_records.append(
                "    - evidence_id: EV" + str(idx) + "\n"
                f"      source_file: {rec.source_file}\n"
                f"      line_number: {rec.line_number}\n"
                f"      pattern: {json.dumps(rec.pattern)}\n"
                f"      extracted: {json.dumps(scalar)}"
            )

        mapping_rows: List[str] = []
        mapping_schema: List[str] = []
        for idx, rec in enumerate(evidence.input_records[:20], start=1):
            obj, sub_item, rationale = self._guess_subitem_mapping(record=rec, item=item)
            mapping_rows.append(
                f"| EV{idx} | `{obj}` | `{sub_item}` | {rationale} |"
            )
            mapping_schema.append(
                "    - evidence_id: EV" + str(idx) + "\n"
                + f"      object: {obj}\n"
                + f"      sub_item: {sub_item}\n"
                + "      rationale: " + json.dumps(rationale)
            )

        return (
            f"# {item.item_id} ParsingSpec\n\n"
            f"Description: {item.description or 'N/A'}\n"
            f"Check Module: {item.check_module or item.checklist_row.check_module or 'N/A'}\n\n"
            "## Input Resolution\n"
            "Resolved inputs:\n"
            f"{resolved_block}\n\n"
            "Missing inputs:\n"
            f"{missing_block}\n\n"
            "## Evidence Inventory\n"
            "| Source File | Line | Pattern | Extracted Values | Raw Line |\n"
            "| --- | --- | --- | --- | --- |\n"
            f"{input_table or '| (none) | - | - | - | - |'}\n\n"
            "## Referenced Files\n"
            "| Source File | Line | Pattern | Extracted Values | Raw Line |\n"
            "| --- | --- | --- | --- | --- |\n"
            f"{ref_table or '| (none) | - | - | - | - |'}\n\n"
            "## Evidence to Sub-Item Mapping\n"
            "| Evidence ID | Candidate Object | Candidate Sub-Item | Rationale |\n"
            "| --- | --- | --- | --- |\n"
            + ("\n".join(mapping_rows) if mapping_rows else "| NONE | `unknown` | `unknown` | No evidence records available. |")
            + "\n\n"
            "## Extraction Gaps\n"
            f"{notes_block}\n\n"
            "## Embedded Schema\n"
            "```yaml\n"
            "parsing_spec:\n"
            f"  item_id: {item.item_id}\n"
            "  stage_boundary:\n"
            "    reads_input_files: true\n"
            "    depends_on_itemspec: true\n"
            + resolved_schema
            + "\n"
            + missing_schema
            + "\n  evidence_records:\n"
            + ("\n".join(schema_records) if schema_records else "    - evidence_id: NONE\n      extracted: no_matches")
            + "\n  evidence_to_sub_item:\n"
            + ("\n".join(mapping_schema) if mapping_schema else "    - evidence_id: NONE\n      object: unknown\n      sub_item: unknown\n      rationale: no evidence records")
            + "\n```\n"
        )

    def _fallback_format_spec(self, item: ItemContext, evidence: EvidenceBundle) -> str:
        requirement_items = self._derive_requirement_items(item=item, evidence=evidence)
        waiver_items = self._derive_waiver_items(item=item)
        pattern_notes = self._derive_pattern_notes(evidence)
        pattern_mapping = self._derive_pattern_mapping(item=item, requirement_items=requirement_items)
        waiver_keywords = self._derive_waiver_keyword_taxonomy(item=item, waiver_items=waiver_items)
        expected_rows = self._derive_expected_outcomes(item=item, evidence=evidence)

        req_block = "\n".join([f"- `{x}`" for x in requirement_items]) or "- `*`"
        mapping_block = "\n".join([f"- `pattern_items[{idx}]` -> {target}" for idx, target in pattern_mapping]) or "- `pattern_items[0]` -> primary validation target"
        waiver_block = "\n".join([f"- `{x}`" for x in waiver_items]) or "- `*`"
        waiver_keyword_block = "\n".join(
            [f"- scenario: `{name}` | keywords: `{', '.join(keywords)}` | sample_reason: \"{reason}\"" for name, keywords, reason in waiver_keywords]
        ) or "- scenario: `default` | keywords: `waive, exception` | sample_reason: \"Waiver approved by design review\""
        pattern_block = "\n".join([f"- {x}" for x in pattern_notes]) or "- No explicit reusable pattern could be inferred from current evidence."
        expected_block = "\n".join(
            [f"| {scenario} | {req} | {waiver} | {rule} | {current} |" for scenario, req, waiver, rule, current in expected_rows]
        ) or "| S1 | N/A | N/A | Missing mandatory evidence -> FAIL | UNKNOWN |"

        schema_req = "\n".join([f"    - {x}" for x in requirement_items]) or "    - '*'"
        schema_waiver = "\n".join([f"    - {x}" for x in waiver_items]) or "    - '*'"
        schema_map = "\n".join([f"    - index: {idx}\n      target: {target}" for idx, target in pattern_mapping]) or "    - index: 0\n      target: primary_validation_target"
        schema_type_map = (
            "    type_1: req=N/A, waiver=N/A\n"
            "    type_2: req>0, waiver=N/A\n"
            "    type_3: req>0, waiver>0\n"
            "    type_4: req=N/A, waiver>0"
        )

        return (
            f"# {item.item_id} FormatSpec\n\n"
            f"Description: {item.description or 'N/A'}\n"
            f"Check Module: {item.check_module or item.checklist_row.check_module or 'N/A'}\n"
            f"vio_name_format: \"{DEFAULT_VIO_NAME_FORMAT}\"\n\n"
            "## Pattern Strategy\n"
            f"{pattern_block}\n\n"
            "## Requirement Items\n"
            f"{req_block}\n\n"
            "## Pattern Index Mapping\n"
            f"{mapping_block}\n\n"
            "## Waiver Items\n"
            f"{waiver_block}\n\n"
            "## Waiver Keyword Taxonomy\n"
            f"{waiver_keyword_block}\n\n"
            "## Scenario Matrix\n"
            "### Scenario 1 (req=N/A, waiver=N/A)\n"
            "- found_desc: \"Required evidence extracted and semantically valid\"\n"
            "- missing_desc: \"Required evidence missing or semantically invalid\"\n"
            "- found_reason: \"Parsing evidence supports checker intent\"\n"
            "- missing_reason: \"Parsing evidence does not satisfy checker intent\"\n\n"
            "### Scenario 2 (req=N/A, waiver>0)\n"
            "- found_desc: \"Required evidence extracted and semantically valid\"\n"
            "- missing_desc: \"Required evidence missing or semantically invalid\"\n"
            "- waived_desc: \"Violation waived by configured waiver items\"\n"
            "- unused_desc: \"Unused waiver entries\"\n"
            "- found_reason: \"Parsing evidence supports checker intent\"\n"
            "- missing_reason: \"Parsing evidence does not satisfy checker intent\"\n"
            "- waived_reason: \"Waiver item matched violation context\"\n"
            "- unused_reason: \"Waiver item has no matching violation\"\n\n"
            "### Scenario 3 (req>0, waiver=N/A)\n"
            "- found_desc: \"Requirement pattern items matched\"\n"
            "- missing_desc: \"Requirement pattern items not matched\"\n"
            "- found_reason: \"All required pattern comparisons satisfied\"\n"
            "- missing_reason: \"At least one required pattern comparison failed\"\n\n"
            "### Scenario 4 (req>0, waiver>0)\n"
            "- found_desc: \"Requirement pattern items matched\"\n"
            "- missing_desc: \"Requirement pattern items not matched\"\n"
            "- waived_desc: \"Violation waived by configured waiver items\"\n"
            "- unused_desc: \"Unused waiver entries\"\n"
            "- found_reason: \"All required pattern comparisons satisfied\"\n"
            "- missing_reason: \"At least one required pattern comparison failed\"\n"
            "- waived_reason: \"Waiver item matched violation context\"\n"
            "- unused_reason: \"Waiver item has no matching violation\"\n\n"
            "## Expected Outcomes\n"
            "| Scenario | requirements.value | waivers.value | Decision Rule | Expected Result with Current Evidence |\n"
            "| --- | --- | --- | --- | --- |\n"
            f"{expected_block}\n\n"
            "## Embedded Schema\n"
            "```yaml\n"
            "format_spec:\n"
            f"  item_id: {item.item_id}\n"
            f"  vio_name_format: {json.dumps(DEFAULT_VIO_NAME_FORMAT)}\n"
            "  stage_boundary:\n"
            "    reads_input_files: true\n"
            "    depends_on_itemspec: true\n"
            "    depends_on_parsing_spec: true\n"
            "  type_map:\n"
            f"{schema_type_map}\n"
            "  requirement_items:\n"
            f"{schema_req}\n"
            "  pattern_index_mapping:\n"
            f"{schema_map}\n"
            "  waiver_items:\n"
            f"{schema_waiver}\n"
            "```\n"
        )

    def _write_compatibility_copies(self, itemspec_path: Path, parsing_path: Path, format_path: Path) -> Dict[str, Path]:
        if not self.config.compatibility_mode:
            return {}

        compatibility: Dict[str, Path] = {}
        mapping = {
            "itemspec": self.config.output_root / "itemspec.md",
            "parsing_spec": self.config.output_root / "parsing_spec.md",
            "format_spec": self.config.output_root / "format_spec.md",
        }
        sources = {
            "itemspec": itemspec_path,
            "parsing_spec": parsing_path,
            "format_spec": format_path,
        }

        self.config.output_root.mkdir(parents=True, exist_ok=True)
        for key, target in mapping.items():
            shutil.copyfile(sources[key], target)
            compatibility[key] = target.resolve()

        return compatibility

    def _get_timestamp(self) -> str:
        """Get current timestamp for debug logging."""
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _write_debug_file(self, filename: str, content: str) -> None:
        """Write content to debug file."""
        if hasattr(self, '_debug_dir') and self._debug_dir:
            filepath = self._debug_dir / filename
            filepath.write_text(content, encoding="utf-8")

    def _append_debug_file(self, filename: str, content: str) -> None:
        """Append content to debug file."""
        if hasattr(self, '_debug_dir') and self._debug_dir:
            filepath = self._debug_dir / filename
            with open(filepath, "a", encoding="utf-8") as f:
                f.write(content)

    def _save_llm_debug(self, stage: str, system_prompt: str, user_prompt: str, response: Optional[str]) -> None:
        """Save LLM input/output to debug files."""
        # Save input
        input_content = f"""# {stage} LLM Input

## System Prompt

```
{system_prompt}
```

## User Prompt

```
{user_prompt}
```
"""
        self._write_debug_file(f"{stage}_input.md", input_content)
        
        # Save output
        output_content = f"""# {stage} LLM Output

{response if response else "(No response - using fallback)"}
"""
        self._write_debug_file(f"{stage}_output.md", output_content)

    def _write_manifest(
        self,
        output_dir: Path,
        item: ItemContext,
        evidence: EvidenceBundle,
        knowledge_hits: Sequence[RetrievalHit],
        itemspec_path: Path,
        parsing_path: Path,
        format_path: Path,
        compatibility_paths: Dict[str, Path],
    ) -> Path:
        manifest = {
            "item_id": item.item_id,
            "item_yaml": str(item.item_yaml_path),
            "check_module": item.check_module or item.checklist_row.check_module,
            "description": item.description,
            "llm_mode": self.config.llm_mode.value,
            "compatibility_mode": self.config.compatibility_mode,
            "outputs": {
                "itemspec": str(itemspec_path),
                "parsing_spec": str(parsing_path),
                "format_spec": str(format_path),
            },
            "compatibility_outputs": {k: str(v) for k, v in compatibility_paths.items()},
            "input_resolution": {
                "resolved": [str(p) for p in evidence.resolved_inputs],
                "missing": evidence.missing_inputs,
            },
            "evidence_counts": {
                "input_records": len(evidence.input_records),
                "referenced_records": len(evidence.referenced_records),
                "referenced_files": len(evidence.referenced_files),
            },
            "knowledge_hits": [
                {
                    "score": hit.score,
                    "source_file": hit.source_file,
                    "section": hit.section,
                }
                for hit in knowledge_hits
            ],
        }

        manifest_path = output_dir / f"{item.item_id}_context_manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        return manifest_path

    def _derive_requirement_items(self, item: ItemContext, evidence: EvidenceBundle) -> List[str]:
        explicit = [x for x in item.pattern_items if str(x).strip()]
        if explicit:
            return explicit

        derived: List[str] = []
        for rec in list(evidence.input_records) + list(evidence.referenced_records):
            for value in rec.extracted_values:
                normalized = self._generalize_value(value)
                if normalized and normalized not in derived:
                    derived.append(normalized)
                if len(derived) >= 10:
                    return derived

        if derived:
            return derived

        objects = self._infer_objects(item, evidence=evidence)
        return [f"{obj}: status=expected" for obj in objects[:4]]

    def _derive_waiver_items(self, item: ItemContext) -> List[str]:
        if item.waive_items:
            return [x for x in item.waive_items if str(x).strip()]

        objects = self._infer_objects(item)
        if not objects:
            return ["*"]
        return [f"{obj}:*" for obj in objects[:3]]

    def _derive_pattern_notes(self, evidence: EvidenceBundle) -> List[str]:
        notes: List[str] = []
        for rec in evidence.input_records[:30]:
            for value in rec.extracted_values:
                generalized = self._generalize_value(value)
                if generalized:
                    notes.append(f"`{value}` -> `{generalized}`")
        unique: List[str] = []
        seen: set[str] = set()
        for note in notes:
            if note in seen:
                continue
            seen.add(note)
            unique.append(note)
        return unique[:12]

    def _generalize_value(self, raw: str) -> str:
        value = (raw or "").strip().strip('"\'')
        if not value:
            return ""

        # Paths
        normalized = ""
        if "/" in value or "\\" in value:
            normalized = value.replace("\\", "/")
            path_like = (
                normalized.startswith("/")
                or bool(re.match(r"^[A-Za-z]:/", normalized))
                or bool(re.search(r"\.[A-Za-z0-9]{1,6}(\.gz)?$", normalized))
            )
            if not path_like:
                normalized = ""

        if normalized:
            name = normalized.split("/")[-1]
            parent = normalized.split("/")[-2] if len(normalized.split("/")) >= 2 else ""
            name_lower = name.lower()
            if name_lower.endswith(".v.gz"):
                name_pattern = "*.v.gz"
            elif name_lower.endswith(".sv.gz"):
                name_pattern = "*.sv.gz"
            elif name_lower.endswith(".spef.gz"):
                name_pattern = "*.spef.gz"
            elif name_lower.endswith(".spef"):
                name_pattern = "*.spef"
            else:
                ext = Path(name).suffix
                name_pattern = f"*{ext}" if ext else "*"
            if parent and re.fullmatch(r"[A-Za-z0-9_.-]+", parent):
                return f"*/{parent}/{name_pattern}"
            return f"*/{name_pattern}"

        # Version-like token
        if re.fullmatch(r"\d+[\w\.-]*", value) and re.search(r"[._-]", value):
            return "<version_token>"

        # Timestamp-like token
        if re.search(r"\d{4}", value) and re.search(r"\d{1,2}:\d{2}", value):
            return "<timestamp>"

        if len(value) > 2 and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value):
            return f"<{value.lower()}>"

        return ""

    @staticmethod
    def _normalize_sub_item_value(sub_item: str, value: str) -> str:
        normalized = (value or "").strip().strip("\"'")
        if not normalized:
            return ""
        if ";" in normalized:
            normalized = normalized.split(";")[0].strip()
        if sub_item == "design_name":
            normalized = normalized.rstrip(".,;:")
        return normalized

    def _select_requirement_value(self, obj_name: str, sub_name: str, values: Sequence[str]) -> str:
        normalized_values = [self._normalize_sub_item_value(sub_name, v) for v in values]
        normalized_values = [v for v in normalized_values if v]
        if not normalized_values:
            return ""

        if sub_name == "design_name":
            clean_values = [v for v in normalized_values if not v.endswith(".")]
            if clean_values:
                return clean_values[0]
        if sub_name == "version_token":
            for value in normalized_values:
                token = self._extract_version_token(value)
                if token:
                    return token
        if sub_name == "status":
            descriptive = [v for v in normalized_values if len(v) >= 6]
            if descriptive:
                return descriptive[0]
        return normalized_values[0]

    def _default_pattern_for_sub_item(
        self,
        object_name: str,
        sub_item: str,
        parsed_values_by_key: Dict[Tuple[str, str], List[str]],
    ) -> str:
        if sub_item == "source_reference":
            return "*/logs/*.log:*"
        if sub_item == "file_path":
            if object_name == "netlist":
                return "*/dbs/*.v.gz"
            if object_name == "spef":
                return "*.spef*"
            return "*"
        if sub_item == "file_name":
            if object_name == "netlist":
                return "*.v.gz"
            if object_name == "spef":
                return "*.spef*"
            return "*"
        if sub_item == "version_token":
            return "<version_token>"
        if sub_item == "design_name":
            return "<design_name>"
        if sub_item == "status":
            if object_name == "netlist":
                return "<netlist_status>"
            if object_name == "spef":
                return "<spef_status>"
            return "<status_text>"
        return "<value>"

    @staticmethod
    def _infer_comparator(pattern: str) -> str:
        value = (pattern or "").strip()
        if not value:
            return "regex"
        if value.startswith("<") and value.endswith(">"):
            return "regex"
        regex_signals = (".*", "\\b", "\\s", "(?i)", "^", "$", "[", "]", "+", "|")
        if any(sig in value for sig in regex_signals):
            return "regex"
        if "*" in value or "?" in value:
            return "glob"
        return "exact"

    @staticmethod
    def _derive_status_pattern(object_name: str, raw_value: str) -> str:
        text = (raw_value or "").strip()
        lower = text.lower()
        if object_name == "spef":
            if "skipping spef reading as" in lower and " as " in lower:
                return text.split(" as ", 1)[-1].strip()
            if "skip" in lower or "no spef" in lower or "sdf" in lower:
                return text
            if text:
                return text
            return "<spef_status>"
        if object_name == "netlist":
            if "netlist" in lower:
                return "(?i).*netlist.*"
            if text:
                return text
            return "<netlist_status>"
        return "<status_text>"

    def _infer_objects(self, item: ItemContext, evidence: Optional[EvidenceBundle] = None) -> List[str]:
        description_tokens: List[str] = []
        for token in re.findall(r"[A-Za-z0-9_/-]+", item.description or ""):
            for part in token.replace("/", " ").replace("-", " ").split():
                norm = self._normalize_object(part)
                if norm and norm not in description_tokens:
                    description_tokens.append(norm)

        score: Dict[str, int] = {}
        candidates = list(item.candidate_objects) + description_tokens
        for raw in candidates:
            norm = self._normalize_object(raw)
            if not norm:
                continue
            score.setdefault(norm, 0)
            if norm in description_tokens:
                score[norm] += 4

        clue_text = " ".join(item.regex_clues + item.keyword_clues + item.input_files_raw).lower()
        for obj in list(score.keys()):
            if obj in clue_text:
                score[obj] += 2

        if evidence is not None:
            evidence_text = " ".join(
                [rec.line_text.lower() for rec in evidence.input_records[:80]]
                + [rec.line_text.lower() for rec in evidence.referenced_records[:40]]
            )
            for obj in list(score.keys()):
                if obj in evidence_text:
                    score[obj] += 3

        # Keep high-confidence objects, then keep description objects as fallback.
        ranked = sorted(score.items(), key=lambda kv: (-kv[1], kv[0]))
        selected = [name for name, sc in ranked if sc >= 4]
        if not selected:
            selected = [name for name, _ in ranked if name in description_tokens]
        if not selected:
            selected = [name for name, _ in ranked[:2]]
        if not selected:
            selected = ["netlist"]  # Default to netlist as fallback

        return selected[:6]

    def _infer_object_subitems(self, item: ItemContext, objects: Sequence[str]) -> Dict[str, List[Tuple[str, bool, str]]]:
        """Generate sub-items per object based on semantic type (from OBJECT_TYPE_TEMPLATES)."""
        try:
            from .spec_contracts import get_subitems_for_object
        except ImportError:
            from spec_contracts import get_subitems_for_object
        
        contract: Dict[str, List[Tuple[str, bool, str]]] = {}
        
        for obj in objects:
            # Get sub-items based on object's semantic type
            contract[obj] = get_subitems_for_object(obj)

        return contract

    def _semantic_intent_for_object(self, item: ItemContext, obj: str) -> str:
        desc = item.description or "checker intent"
        if "version" in desc.lower():
            return f"Validate that `{obj}` version-related evidence supports: {desc}"
        return f"Validate that `{obj}` evidence supports: {desc}"

    def _guess_subitem_mapping(self, record: Any, item: ItemContext) -> Tuple[str, str, str]:
        line = record.line_text.lower()
        pattern = record.pattern.lower()
        values = [v.lower() for v in (record.extracted_values or [])]
        merged = " ".join([line, pattern] + values)

        obj = "netlist"  # Default to netlist
        if "spef" in merged:
            obj = "spef"
        elif "netlist" in merged or ".v" in merged:
            obj = "netlist"
        else:
            inferred = self._infer_objects(item)
            obj = inferred[0] if inferred else "netlist"

        sub_item = "status"
        rationale = "Default mapping based on generic status evidence."
        if "read_netlist" in merged or ".v" in merged:
            sub_item = "file_path"
            rationale = "Path-like evidence from read_netlist command."
        elif "read_spef" in merged or ".spef" in merged:
            sub_item = "file_path"
            rationale = "Path-like evidence from read_spef command."
        elif "top level cell" in merged:
            sub_item = "design_name"
            rationale = "Design identity evidence from top-level cell message."
        elif "program version" in merged:
            sub_item = "tool_version"
            rationale = "Tool version extracted from STA log metadata."
        elif "generated by" in merged:
            sub_item = "generator_tool"
            rationale = "Tool signature extracted from file header."
        elif "generated on" in merged or "*date" in merged:
            sub_item = "generation_time"
            rationale = "Timestamp evidence from file/header metadata."
        elif "skip" in merged or "missing" in merged or "error" in merged:
            sub_item = "status_reason"
            rationale = "Failure/missing indicator requiring waiver or failure handling."

        return obj, sub_item, rationale

    def _derive_pattern_mapping(self, item: ItemContext, requirement_items: Sequence[str]) -> List[Tuple[int, str]]:
        mapping: List[Tuple[int, str]] = []
        if item.pattern_items:
            for idx, _ in enumerate(item.pattern_items):
                target = requirement_items[idx] if idx < len(requirement_items) else f"validation_target_{idx + 1}"
                mapping.append((idx, target))
            return mapping

        for idx, req in enumerate(requirement_items[:8]):
            mapping.append((idx, req))
        return mapping

    def _derive_waiver_keyword_taxonomy(
        self, item: ItemContext, waiver_items: Sequence[str]
    ) -> List[Tuple[str, List[str], str]]:
        objects = self._infer_objects(item)
        desc_tokens = [t for t in re.findall(r"[A-Za-z0-9_]+", (item.description or "").lower()) if len(t) > 2]
        common = ["waive", "exception", "approved"]
        taxonomy: List[Tuple[str, List[str], str]] = []

        for obj in objects[:4]:
            keywords = [obj] + common
            if "version" in desc_tokens:
                keywords.append("version")
            if obj == "spef":
                keywords.extend(["post-synthesis", "no_parasitics"])
            reason = f"{obj} mismatch accepted by stage-specific design review."
            taxonomy.append((f"{obj}_waiver", keywords[:6], reason))

        # Keep explicit waiver items visible.
        for w in waiver_items[:4]:
            name = w.replace(":", "_").replace("*", "all")
            taxonomy.append((f"configured_{name}", [w, "configured_waiver"], "Configured waiver item provided by item yaml."))

        dedup: List[Tuple[str, List[str], str]] = []
        seen: set[str] = set()
        for name, keys, reason in taxonomy:
            if name in seen:
                continue
            seen.add(name)
            dedup.append((name, keys, reason))
        return dedup[:8]

    def _derive_expected_outcomes(
        self, item: ItemContext, evidence: EvidenceBundle
    ) -> List[Tuple[str, str, str, str, str]]:
        lines = " ".join([rec.line_text.lower() for rec in evidence.input_records])
        has_missing_indicator = any(tok in lines for tok in ["skip", "missing", "error", "not found", "failed"])
        has_evidence = bool(evidence.input_records)

        if not has_evidence:
            return [
                ("S1", "N/A", "N/A", "Mandatory evidence missing -> FAIL", "UNKNOWN"),
                ("S2", "N/A", ">0", "Waiver can downgrade missing violations", "UNKNOWN"),
                ("S3", ">0", "N/A", "Unmatched required patterns -> FAIL", "UNKNOWN"),
                ("S4", ">0", ">0", "Pattern mismatch can be waived if matched", "UNKNOWN"),
            ]

        s1 = "FAIL" if has_missing_indicator else "PASS"
        s2 = "PASS" if has_missing_indicator else "PASS"
        s3 = "FAIL" if has_missing_indicator else "PASS"
        s4 = "PASS" if has_missing_indicator else "PASS"

        return [
            ("S1", "N/A", "N/A", "Missing mandatory evidence -> FAIL", s1),
            ("S2", "N/A", ">0", "Mandatory miss can be waived", s2),
            ("S3", ">0", "N/A", "Required pattern mismatch -> FAIL", s3),
            ("S4", ">0", ">0", "Pattern mismatch can be waived", s4),
        ]

    @staticmethod
    def _normalize_object(text: str) -> str:
        stop = {
            "confirm", "correct", "version", "check", "the", "and", "for", "with",
            "from", "that", "all", "are", "is", "none", "have", "been", "during",
        }
        token = re.sub(r"[^A-Za-z0-9_]+", "_", text.strip().lower()).strip("_")
        if not token or len(token) < 3 or token in stop:
            return ""
        return token

    # =========================================================================
    # Stage-Specific Context Methods (per design doc 核心原则 2)
    # =========================================================================

    def _describe_input_types(self, input_files_raw: List[str]) -> List[str]:
        """Convert raw input file specs to abstract type descriptions.
        
        Per design doc 核心原则 2: ItemSpec should not see concrete file paths.
        """
        type_hints = []
        for raw in input_files_raw:
            lower = raw.lower()
            if "log" in lower or ".log" in lower:
                type_hints.append("STA/synthesis log file")
            elif "rpt" in lower or "report" in lower:
                type_hints.append("QoR/timing report file")
            elif "tcl" in lower:
                type_hints.append("Tcl script file")
            elif "sdc" in lower:
                type_hints.append("SDC constraint file")
            elif "lib" in lower or ".db" in lower:
                type_hints.append("Liberty/DB library file")
            elif "lef" in lower:
                type_hints.append("LEF technology file")
            elif "spef" in lower or "spf" in lower:
                type_hints.append("Parasitic extraction file (SPEF/SPF)")
            elif ".v" in lower or "netlist" in lower:
                type_hints.append("Verilog netlist file")
            elif "gds" in lower or "oasis" in lower:
                type_hints.append("Layout file (GDS/OASIS)")
            else:
                type_hints.append("Design data file")
        return list(set(type_hints))  # Remove duplicates

    def _item_summary_for_itemspec(self, item: ItemContext) -> Dict[str, Any]:
        """ItemSpec stage - NO regex_clues, NO resolved_inputs, NO concrete file paths.
        
        Per design doc 核心原则 2: ItemSpec 不做什么:
        - 预设 Type (生成时才确定)
        - 给出具体 pattern (那是 parsing 的事)
        - 分析具体值 (那是 format 的事)
        """
        return {
            "item_id": item.item_id,
            "description": item.description,
            "check_module": item.check_module or item.checklist_row.check_module,
            "requirements_value": item.requirements_value,
            "waiver_value": item.waiver_value,
            "candidate_objects": item.candidate_objects,
            # Abstract data source types only - NO concrete paths
            "data_source_types": self._describe_input_types(item.input_files_raw),
        }

    def _item_summary_for_parsing(self, item: ItemContext) -> Dict[str, Any]:
        """ParsingSpec stage - HAS resolved_inputs for file reading, NO regex_clues.
        
        Per design doc: ParsingSpec reads actual files to derive extraction patterns.
        Regex clues should NOT be provided - they should be derived from evidence.
        """
        return {
            "item_id": item.item_id,
            "description": item.description,
            "check_module": item.check_module or item.checklist_row.check_module,
            "resolved_inputs": [str(p) for p in item.input_files_resolved],
            "missing_inputs": item.missing_input_files,
            # NO regex_clues - ParsingSpec derives patterns from ItemSpec + evidence
        }

    def _item_summary_for_format(self, item: ItemContext) -> Dict[str, Any]:
        """FormatSpec stage - minimal context, relies on ItemSpec + ParsingSpec.
        
        Per design doc: FormatSpec validates pattern format and cross-project reusability.
        """
        return {
            "item_id": item.item_id,
            "description": item.description,
            "check_module": item.check_module or item.checklist_row.check_module,
            # NO regex_clues, NO resolved_inputs - uses output from previous stages
        }

    def _item_summary(self, item: ItemContext) -> Dict[str, Any]:
        """Legacy method - kept for backward compatibility. Use stage-specific methods."""
        return {
            "item_id": item.item_id,
            "description": item.description,
            "check_module": item.check_module or item.checklist_row.check_module,
            "requirements_value": item.requirements_value,
            "pattern_items": item.pattern_items,
            "waiver_value": item.waiver_value,
            "waive_items": item.waive_items,
            "item_yaml": str(item.item_yaml_path),
            "input_files_raw": item.input_files_raw,
            "resolved_inputs": [str(p) for p in item.input_files_resolved],
            "missing_inputs": item.missing_input_files,
            "candidate_objects": item.candidate_objects,
            "regex_clues": item.regex_clues[:15],
        }

    def _render_knowledge_hits(
        self, 
        hits: Sequence[RetrievalHit], 
        max_hits: int = 8,
        exclude_sections: Optional[List[str]] = None
    ) -> str:
        """Render knowledge hits with optional section filtering.
        
        For ItemSpec stage, we filter out 'Regex clues' sections to enforce
        design doc 核心原则 2: ItemSpec should not see patterns.
        """
        if not hits:
            return "- No RAG hit available."
        
        exclude_sections = exclude_sections or []

        lines: List[str] = []
        for hit in hits[:max_hits]:
            # Skip hits from excluded sections
            if exclude_sections and any(excl.lower() in hit.section.lower() for excl in exclude_sections):
                continue
            
            text = " ".join(hit.text.split())
            if len(text) > 220:
                text = text[:220] + "..."
            lines.append(
                f"- score={hit.score:.3f} source=`{hit.source_file}` section=`{hit.section}` snippet={json.dumps(text)}"
            )
        
        return "\n".join(lines) if lines else "- No relevant knowledge available."

    def _render_evidence_bundle(self, evidence: EvidenceBundle) -> str:
        records = stringify_records(evidence.input_records, max_rows=40)
        refs = stringify_records(evidence.referenced_records, max_rows=25)
        resolved = "\n".join([f"- {p}" for p in evidence.resolved_inputs]) or "- (none)"
        missing = "\n".join([f"- {p}" for p in evidence.missing_inputs]) or "- (none)"
        notes = "\n".join([f"- {x}" for x in evidence.notes]) or "- (none)"
        return (
            "Resolved inputs:\n"
            + resolved
            + "\n\nMissing inputs:\n"
            + missing
            + "\n\nInput evidence table:\n"
            + (records or "| (none) | - | - | - | - |")
            + "\n\nReferenced evidence table:\n"
            + (refs or "| (none) | - | - | - | - |")
            + "\n\nNotes:\n"
            + notes
        )

    def _load_prompt(self, filename: str, default: str) -> str:
        path = self.prompt_dir / filename
        if path.exists():
            return path.read_text(encoding="utf-8")
        return default

    @staticmethod
    def _inject_tokens(template: str, values: Dict[str, str]) -> str:
        text = template
        for key, value in values.items():
            text = text.replace("{{" + key + "}}", value)
        return text
