#!/usr/bin/env python3
"""Local lexical RAG retriever for Context Agent."""

from __future__ import annotations

import json
import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "has", "have", "if", "in", "into",
    "is", "it", "its", "of", "on", "or", "that", "the", "their", "this", "to", "used", "using", "with",
    "what", "when", "where", "which", "why",
}
TOKEN_RE = re.compile(r"[A-Za-z0-9_]+")
ITEM_ID_RE = re.compile(r"[A-Z]+-IMP-\d+-\d+-\d+-\d+|IMP-\d+-\d+-\d+-\d+")


@dataclass
class RetrievalHit:
    score: float
    source_file: str
    section: str
    text: str


class LocalRAGRetriever:
    def __init__(self, index_dir: Path):
        self.index_dir = Path(index_dir)
        self._index = self._load_json(self.index_dir / "index.json")
        self._chunks = self._load_chunks(self.index_dir / "chunks.jsonl")

    @staticmethod
    def _load_json(path: Path) -> Dict:
        return json.loads(path.read_text(encoding="utf-8"))

    @staticmethod
    def _load_chunks(path: Path) -> Dict[int, Dict]:
        chunks: Dict[int, Dict] = {}
        with path.open("r", encoding="utf-8") as fh:
            for line in fh:
                row = json.loads(line)
                chunks[int(row["chunk_id"])] = row
        return chunks

    @staticmethod
    def _tokenize(text: str) -> List[str]:
        return [
            token.lower()
            for token in TOKEN_RE.findall(text)
            if len(token) > 1 and token.lower() not in STOPWORDS
        ]

    def search(self, query: str, top_k: int = 8, item_id: str = "") -> List[RetrievalHit]:
        combined = f"{item_id} {query}".strip()

        idf = self._index.get("idf", {})
        postings = self._index.get("postings", {})
        norms = self._index.get("doc_norms", [])

        q_tf = Counter(self._tokenize(combined))
        if not q_tf:
            return []

        max_tf = max(q_tf.values())
        q_weights: Dict[str, float] = {}
        q_norm_sq = 0.0
        for term, cnt in q_tf.items():
            if term not in idf:
                continue
            w = (0.5 + 0.5 * (cnt / max_tf)) * float(idf[term])
            q_weights[term] = w
            q_norm_sq += w * w

        q_norm = math.sqrt(q_norm_sq) if q_norm_sq > 0 else 1.0

        scores = defaultdict(float)
        for term, q_w in q_weights.items():
            for doc_id, d_w in postings.get(term, []):
                scores[int(doc_id)] += q_w * float(d_w)

        query_item_ids = [m.group(0).lower() for m in ITEM_ID_RE.finditer(combined.upper())]

        ranked: List[RetrievalHit] = []
        for doc_id, raw_score in scores.items():
            d_norm = float(norms[doc_id]) if doc_id < len(norms) else 1.0
            sim = raw_score / (q_norm * (d_norm if d_norm > 0 else 1.0))
            chunk = self._chunks.get(doc_id, {})
            source_file = str(chunk.get("source_file", ""))
            text = str(chunk.get("text", ""))

            source_lower = source_file.lower()
            text_lower = text.lower()
            for query_item in query_item_ids:
                if query_item in source_lower:
                    sim += 0.35
                elif query_item in text_lower:
                    sim += 0.15

            ranked.append(
                RetrievalHit(
                    score=sim,
                    source_file=source_file,
                    section=str(chunk.get("section", "")),
                    text=text,
                )
            )

        ranked.sort(key=lambda h: h.score, reverse=True)
        return ranked[:top_k]
