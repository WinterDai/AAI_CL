# stage_itemspec LLM Output

# ItemSpec: IMP-10-0-0-00

## Scope

This checker item verifies that the netlist and SPEF files used in STA (Static Timing Analysis) are the correct versions. The check confirms version metadata (timestamps, program versions, generation dates) extracted from the netlist and SPEF file headers match expected values or are properly recorded for review.

**Applicable context:**
- STA/DCD signoff verification stage
- Post-synthesis timing analysis runs
- Design handoff checkpoints

**Boundaries:**
- This item focuses on version confirmation, not functional correctness of netlist/SPEF content
- SPEF may be optional if explicitly skipped in the flow

---

## Description Interpretation Rules

### Slash Notation Handling
- `netlist/spef` = logical AND: both netlist AND spef version must be confirmed
- Exception: if log indicates SPEF reading is explicitly skipped, spef becomes optional

### Explicit Alternatives
- "or" keyword not present in description; treat all objects as required unless runtime evidence shows intentional skip

### Optional Components Handling
- SPEF is conditionally optional if log contains `[INFO] Skipping SPEF reading as` pattern
- Netlist is always mandatory
- `power_emir` listed as candidate but not explicitly required by description; treat as informational

---

## Semantic Targets

### Semantic Target Table

| Target ID | Description | Source Pattern | Validation Goal |
|-----------|-------------|----------------|-----------------|
| T1 | Netlist file path | `read_netlist\s+([^\s]+\.v(?:\.gz)?)` | Extract netlist file used |
| T2 | Netlist version/timestamp | Header line in netlist file | Confirm version metadata |
| T3 | SPEF file path | `read_spef\s+([^\s]+\.spef(?:\.gz)?)` | Extract SPEF file used |
| T4 | SPEF skip indication | `\[INFO\]\s+Skipping SPEF reading as (.+)` | Detect intentional skip |
| T5 | SPEF version metadata | Header fields: DATE, DESIGN_FLOW, Generated on | Confirm SPEF version |
| T6 | Top-level cell | `Top level cell is\s+(\S+)` | Cross-reference design identity |
| T7 | Program version | `Program version\s*=\s*([\d\.\-\w]+)` | Tool version context |

### Object/Sub-item Contract Table

| Object | Mandatory/Optional | Pass Semantics | Fail Semantics |
|--------|-------------------|----------------|----------------|
| netlist | Mandatory | File path extracted AND version metadata captured | Path not found OR version unreadable |
| spef | Conditional | File path extracted AND version metadata captured, OR skip explicitly logged | Path expected but not found, no skip indication |
| power_emir | Optional/Informational | If present, record metadata | Absence does not cause failure |

---

## Check Criteria

### Pass Conditions
1. Netlist file path successfully extracted from log
2. Netlist version/timestamp metadata captured from file header
3. Either:
   - SPEF file path extracted AND version metadata captured, OR
   - SPEF skip explicitly indicated in log with reason recorded
4. Top-level cell name matches expected design (if reference available)

### Fail Conditions
1. No netlist path found in log
2. Netlist file header unreadable or missing version info
3. SPEF neither loaded nor explicitly skipped
4. Critical metadata fields empty or malformed

### Edge Cases
- Compressed files (`.gz`): must handle gzip decompression for header reading
- Multiple `read_netlist`/`read_spef` commands: use last occurrence
- Missing timestamp fields: flag as warning, not hard fail

---

## Evidence Plan

### Primary Evidence Sources
| Evidence ID | Source Type | Target File/Pattern | Purpose |
|-------------|-------------|---------------------|---------|
| E1 | STA log | `sta_post_syn.log` | Extract file paths and skip indications |
| E2 | Netlist header | Extracted `.v` file, lines 1-10 | Capture version timestamp |
| E3 | SPEF header | Extracted `.spef` file, header section | Capture DATE, DESIGN_FLOW, Generated on |

### Evidence Collection Strategy
1. Parse STA log for `read_netlist` and `read_spef` commands
2. Check for SPEF skip pattern
3. If netlist path found, open file and extract header metadata
4. If SPEF path found, open file and extract header metadata
5. Record all version strings with line numbers as evidence locations

### Snippet Requirements
- Include 3-5 lines of context around each extracted value
- Record exact line numbers for traceability

---

## Embedded Schema

```yaml
itemspec:
  item_id: "IMP-10-0-0-00"
  check_module: "10.0_STA_DCD_CHECK"
  description: "Confirm the netlist/spef version is correct."
  intent: "verification"
  
  semantic_targets:
    - id: "T1"
      name: "netlist_path"
      pattern: 'read_netlist\s+([^\s]+\.v(?:\.gz)?)'
      required: true
    - id: "T2"
      name: "netlist_version"
      source: "extracted_netlist_header"
      required: true
    - id: "T3"
      name: "spef_path"
      pattern: 'read_spef\s+([^\s]+\.spef(?:\.gz)?)'
      required: conditional
    - id: "T4"
      name: "spef_skip"
      pattern: '\[INFO\]\s+Skipping SPEF reading as (.+)'
      required: false
    - id: "T5"
      name: "spef_version"
      source: "extracted_spef_header"
      required: conditional
    - id: "T6"
      name: "top_cell"
      pattern: 'Top level cell is\s+(\S+)'
      required: false
    - id: "T7"
      name: "program_version"
      pattern: 'Program version\s*=\s*([\d\.\-\w]+)'
      required: false

  objects:
    - name: "netlist"
      mandatory: true
      sub_items:
        - name: "file_path"
          mandatory: true
        - name: "version_timestamp"
          mandatory: true
    - name: "spef"
      mandatory: conditional
      condition: "not spef_skip_detected"
      sub_items:
        - name: "file_path"
          mandatory: true
        - name: "version_metadata"
          mandatory: true
    - name: "power_emir"
      mandatory: false
      sub_items: []

  pass_criteria:
    - "netlist.file_path extracted"
    - "netlist.version_timestamp captured"
    - "spef.file_path extracted OR spef_skip logged"
    - "if spef loaded: spef.version_metadata captured"

  fail_criteria:
    - "netlist.file_path not found"
    - "netlist.version_timestamp unreadable"
    - "spef neither loaded nor skipped"

  evidence_sources:
    - id: "E1"
      file: "${CHECKLIST_ROOT}/IP_project_folder/logs/sta_post_syn.log"
      purpose: "Extract file paths and runtime status"
    - id: "E2"
      file: "dynamic:netlist_path"
      purpose: "Extract netlist header version"
    - id: "E3"
      file: "dynamic:spef_path"
      purpose: "Extract SPEF header version"

  requirements_value: "N/A"
  waiver_value: "N/A"
```
