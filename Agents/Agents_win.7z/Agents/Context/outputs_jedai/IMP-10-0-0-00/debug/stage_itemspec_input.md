# stage_itemspec LLM Input

## System Prompt

```
You are a senior digital physical implementation expert.
Return only Markdown in English.
Do not use Chinese.
Keep technical content concise and operational.
Respect stage boundaries exactly:
- ItemSpec stage must not read runtime input files.
- ParsingSpec stage reads resolved input files and records evidence locations.
- FormatSpec stage depends on ItemSpec + ParsingSpec + valid evidence snippets.

```

## User Prompt

```
Create the ItemSpec for one checker item.

Requirements:
- Output must be Markdown in English.
- Title must include item ID.
- Include exactly these sections:
  - ## Scope
  - ## Description Interpretation Rules
  - ## Semantic Targets
  - ## Check Criteria
  - ## Evidence Plan
  - ## Embedded Schema
- Include one YAML code block under "## Embedded Schema" with key `itemspec`.
- This stage must not parse runtime input files.
- In `## Description Interpretation Rules`, include:
  - slash notation default = logical AND across objects unless explicit "or"
  - explicit alternatives with "or"
  - optional components handling
- In `## Semantic Targets`, include both:
  - semantic target table
  - object/sub-item contract table (mandatory/optional + pass/fail semantics).

Item context:
{
  "item_id": "IMP-10-0-0-00",
  "description": "Confirm the netlist/spef version is correct.",
  "check_module": "10.0_STA_DCD_CHECK",
  "requirements_value": "N/A",
  "pattern_items": [],
  "waiver_value": "N/A",
  "waive_items": [],
  "item_yaml": "C:\\Users\\wentao\\Desktop\\AAI\\Main_work\\ACL\\checker-agent-dev\\CHECKLIST\\Check_modules\\10.0_STA_DCD_CHECK\\inputs\\items\\IMP-10-0-0-00.yaml",
  "input_files_raw": [
    "${CHECKLIST_ROOT}/IP_project_folder/logs/sta_post_syn.log"
  ],
  "resolved_inputs": [
    "C:\\Users\\wentao\\Desktop\\AAI\\Main_work\\ACL\\checker-agent-dev\\CHECKLIST\\IP_project_folder\\logs\\sta_post_syn.log"
  ],
  "missing_inputs": [],
  "candidate_objects": [
    "netlist",
    "power_emir",
    "spef"
  ],
  "regex_clues": [
    "read_netlist\\s+([^\\s]+\\.v(?:\\.gz)?)",
    "\\[INFO\\]\\s+Skipping SPEF reading as (.+)",
    "read_spef\\s+([^\\s]+\\.spef(?:\\.gz)?)",
    "#\\s*Parasitics Mode:\\s*(.+)",
    "Top level cell is\\s+(\\S+)",
    "Program version\\s*=\\s*([\\d\\.\\-\\w]+)",
    "Generated on:\\s*(.+?)\\s+\\w+\\s+\\((.+?)\\)",
    "Generated on:\\s*(.+?)$",
    "DATE\\s+",
    "DESIGN_FLOW\\s+"
  ]
}

Offline knowledge context:
- score=1.484 source=`skills/IMP-10-0-0-00_skill.md` section=`Description` snippet="Confirm the netlist/spef version is correct."
- score=1.430 source=`skills/IMP-10-0-0-00_skill.md` section=`Suggested retrieval queries` snippet="- IMP-10-0-0-00 checker intent Confirm the netlist/spef version is correct. - physical implementation netlist power_emir spef evidence extraction - input_logs parasitics power_integrity timing_signoff best practices"
- score=1.086 source=`skills/IMP-10-0-0-00_skill.md` section=`Embedded schema` snippet="```yaml skill_schema: item_id: IMP-10-0-0-00 check_module: 10.0_STA_DCD_CHECK intent: verification knowledge_tags: - input_logs - parasitics - power_integrity - timing_signoff candidate_objects: - netlist - power_emir - ..."
- score=1.058 source=`skills/IMP-10-0-0-00_skill.md` section=`Module and Intent` snippet="- Module: `10.0_STA_DCD_CHECK` - Intent: `verification` - Candidate objects: netlist, power_emir, spef - Knowledge tags: input_logs, parasitics, power_integrity, timing_signoff"
- score=1.016 source=`skills/IMP-10-0-0-00_skill.md` section=`Input and Existing Implementation Clues` snippet="- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-00.yaml` - Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLI..."
- score=0.931 source=`skills/IMP-10-0-0-00_skill.md` section=`Keyword clues from existing checker` snippet="- `# Confirm the netlist/spef version is correct.` - `# - Extract netlist file path from read_netlist command` - `# - Open extracted netlist file to capture version timestamp from header (line 3)` - `# - Open extracted S..."
- score=0.848 source=`skills/IMP-10-0-0-00_skill.md` section=`Regex clues from existing checker` snippet="- `read_netlist\\s+([^\\s]+\\.v(?:\\.gz)?)` - `\\[INFO\\]\\s+Skipping SPEF reading as (.+)` - `read_spef\\s+([^\\s]+\\.spef(?:\\.gz)?)` - `#\\s*Parasitics Mode:\\s*(.+)` - `Top level cell is\\s+(\\S+)` - `Program version\\s*=\\s*([\\d\\.\\-..."
- score=0.429 source=`skills/IMP-14-0-0-00_skill.md` section=`Suggested retrieval queries` snippet="- IMP-14-0-0-00 checker intent Confirm set the correct golden netlist. - physical implementation netlist power_emir evidence extraction - power_integrity best practices"

```
