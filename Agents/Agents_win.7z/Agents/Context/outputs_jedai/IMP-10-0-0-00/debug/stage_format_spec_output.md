# stage_format_spec LLM Output

(No response - using fallback)
