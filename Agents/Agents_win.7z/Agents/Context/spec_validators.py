#!/usr/bin/env python3
"""Validation helpers for Context Agent collateral."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, List, Sequence, Tuple

try:
    from .spec_contracts import (
        FormatSpecContract,
        ItemSpecContract,
        ParsingSpecContract,
        collect_itemspec_subitem_contract,
        collect_required_itemspec_subitems,
    )
except ImportError:  # pragma: no cover
    from spec_contracts import (
        FormatSpecContract,
        ItemSpecContract,
        ParsingSpecContract,
        collect_itemspec_subitem_contract,
        collect_required_itemspec_subitems,
    )


CJK_RE = re.compile(r"[\u4e00-\u9fff]")


@dataclass
class ValidationOutcome:
    """Validation result with detailed check information for LLM feedback."""
    ok: bool
    issues: List[str] = field(default_factory=list)
    checked_items: List[Tuple[str, bool, str]] = field(default_factory=list)
    # Each tuple: (check_name, passed, detail)
    
    def format_for_llm_feedback(self) -> str:
        """Format validation results for LLM retry feedback."""
        lines = ["## VALIDATION FAILED - Please Fix\n"]
        
        # Show all checked items with pass/fail status
        lines.append(f"### Checked Items ({len(self.checked_items)} total)\n")
        for check_name, passed, detail in self.checked_items:
            status = "✓" if passed else "✗"
            lines.append(f"- {status} **{check_name}**: {detail}")
        
        # Highlight specific issues to fix
        if self.issues:
            lines.append("\n### Issues to Fix\n")
            for issue in self.issues:
                lines.append(f"- ✗ {issue}")
        
        lines.append("\n### Your Task")
        lines.append("Fix the issues marked with ✗ and regenerate the complete spec.")
        lines.append("Ensure the embedded YAML uses exact field names as specified in the system prompt.")
        
        return "\n".join(lines)


def validate_itemspec(markdown: str, item_id: str) -> ValidationOutcome:
    return _validate_spec(
        markdown=markdown,
        item_id=item_id,
        required_headings=[
            "## Scope",
            "## Description Interpretation Rules",
            "## Semantic Targets",
            "## Check Criteria",
            "## Evidence Plan",
            "## Embedded Schema",
        ],
        require_vio_format=False,
        required_yaml_root="itemspec",
    )


def validate_parsing_spec(markdown: str, item_id: str) -> ValidationOutcome:
    return _validate_spec(
        markdown=markdown,
        item_id=item_id,
        required_headings=[
            "## Input Resolution",
            "## Evidence Inventory",
            "## Referenced Files",
            "## Evidence to Sub-Item Mapping",
            "## Extraction Gaps",
            "## Embedded Schema",
        ],
        require_vio_format=False,
        required_yaml_root="parsing_spec",
    )


def validate_format_spec(markdown: str, item_id: str) -> ValidationOutcome:
    return _validate_spec(
        markdown=markdown,
        item_id=item_id,
        required_headings=[
            "## Pattern Strategy",
            "## Requirement Items",
            "## Pattern Index Mapping",
            "## Waiver Items",
            "## Waiver Keyword Taxonomy",
            "## Scenario Matrix",
            "## Expected Outcomes",
            "## Embedded Schema",
        ],
        require_vio_format=True,
        required_yaml_root="format_spec",
    )


def validate_cross_spec_consistency(
    itemspec_markdown: str,
    parsing_markdown: str,
    format_markdown: str,
) -> ValidationOutcome:
    issues: List[str] = []

    itemspec = ItemSpecContract.from_embedded_yaml(itemspec_markdown)
    parsing = ParsingSpecContract.from_embedded_yaml(parsing_markdown)
    format_spec = FormatSpecContract.from_embedded_yaml(format_markdown)
    if itemspec is None:
        issues.append("Cross-spec validation failed: unable to parse ItemSpec embedded schema.")
    if parsing is None:
        issues.append("Cross-spec validation failed: unable to parse ParsingSpec embedded schema.")
    if format_spec is None:
        issues.append("Cross-spec validation failed: unable to parse FormatSpec embedded schema.")
    if issues:
        return ValidationOutcome(ok=False, issues=issues)

    allowed = collect_itemspec_subitem_contract(itemspec)
    required_pairs = set(collect_required_itemspec_subitems(itemspec))

    mapped_required_pairs = set()
    for row in parsing.evidence_to_sub_item:
        if row.object_name not in allowed:
            issues.append(f"ParsingSpec mapping uses unknown object `{row.object_name}`.")
            continue
        if row.sub_item not in allowed[row.object_name]:
            issues.append(
                f"ParsingSpec mapping `{row.object_name}.{row.sub_item}` is not defined in ItemSpec contract."
            )
            continue
        if row.mapping_status in {"mapped", "mapped_with_fallback", "mapped_derived"} and row.required:
            mapped_required_pairs.add((row.object_name, row.sub_item))

    gap_pairs = set()
    for gap in parsing.extraction_gaps:
        if gap.object_name in allowed and gap.sub_item in allowed[gap.object_name]:
            gap_pairs.add((gap.object_name, gap.sub_item))

    for pair in required_pairs:
        if pair not in mapped_required_pairs and pair not in gap_pairs:
            issues.append(
                "ParsingSpec must report every missing mandatory sub-item as extraction gap: "
                f"`{pair[0]}.{pair[1]}`."
            )

    requirement_ids = set()
    requirement_by_pair = {}
    for req in format_spec.requirement_items:
        if req.requirement_id in requirement_ids:
            issues.append(f"FormatSpec duplicate requirement_id: `{req.requirement_id}`.")
        requirement_ids.add(req.requirement_id)
        if req.object_name not in allowed:
            issues.append(f"FormatSpec requirement uses unknown object `{req.object_name}`.")
            continue
        if req.sub_item not in allowed[req.object_name]:
            issues.append(
                f"FormatSpec requirement `{req.object_name}.{req.sub_item}` is not defined in ItemSpec contract."
            )
        requirement_by_pair[(req.object_name, req.sub_item)] = req

    for pair in required_pairs:
        req = requirement_by_pair.get(pair)
        if req is None:
            issues.append(
                "FormatSpec must include requirement item for every mandatory ItemSpec pair: "
                f"`{pair[0]}.{pair[1]}`."
            )
            continue
        pat = (req.pattern or "").strip()
        if not pat or pat == "<missing>":
            issues.append(
                "FormatSpec requirement pattern must be concrete for mandatory pair: "
                f"`{pair[0]}.{pair[1]}`."
            )
        if pair[1] == "design_name" and pat.endswith("."):
            issues.append(
                "FormatSpec design_name pattern should be normalized and must not end with punctuation: "
                f"`{pair[0]}.{pair[1]}`."
            )
        if req.comparator == "exact" and not req.source_evidence_ids:
            issues.append(
                "FormatSpec exact comparator requires concrete source evidence for mandatory pair: "
                f"`{pair[0]}.{pair[1]}`."
            )
        if pair[1] == "status" and pat in {"<status_text>", "<value>"}:
            issues.append(
                "FormatSpec status pattern is too generic for mandatory pair: "
                f"`{pair[0]}.{pair[1]}`."
            )

    for row in format_spec.pattern_index_mapping:
        if row.requirement_id not in requirement_ids:
            issues.append(
                f"FormatSpec pattern_index_mapping references unknown requirement_id `{row.requirement_id}`."
            )

    expected = {x.scenario for x in format_spec.expected_outcomes}
    for scenario in ["S1", "S2", "S3", "S4"]:
        if scenario not in expected:
            issues.append(f"FormatSpec expected_outcomes missing scenario `{scenario}`.")

    return ValidationOutcome(ok=not issues, issues=issues)


def ensure_id_prefixed_outputs(item_id: str, paths: Sequence[Path]) -> ValidationOutcome:
    issues: List[str] = []
    for path in paths:
        name = path.name
        if not name.startswith(f"{item_id}_"):
            issues.append(f"Output file name does not include ID prefix: {name}")
    return ValidationOutcome(ok=not issues, issues=issues)


def _validate_spec(
    markdown: str,
    item_id: str,
    required_headings: Iterable[str],
    require_vio_format: bool,
    required_yaml_root: str,
) -> ValidationOutcome:
    issues: List[str] = []
    checked_items: List[Tuple[str, bool, str]] = []

    # Check 1: Non-empty content
    if not markdown.strip():
        issues.append("Spec is empty.")
        checked_items.append(("Non-empty content", False, "Spec is empty"))
        return ValidationOutcome(ok=False, issues=issues, checked_items=checked_items)
    checked_items.append(("Non-empty content", True, "Spec has content"))

    # Check 2: Title includes item ID
    title_line = markdown.strip().splitlines()[0].strip()
    if item_id not in title_line:
        issues.append(f"Title must include item ID {item_id}.")
        checked_items.append(("Title includes item ID", False, f"Expected '{item_id}' in title"))
    else:
        checked_items.append(("Title includes item ID", True, f"Found '{item_id}' in title"))

    # Check 3: Pure English (no CJK)
    if CJK_RE.search(markdown):
        issues.append("Spec must be pure English; CJK characters detected.")
        checked_items.append(("Pure English", False, "CJK characters detected"))
    else:
        checked_items.append(("Pure English", True, "No CJK characters"))

    # Check 4: Has YAML block
    if "```yaml" not in markdown:
        issues.append("Spec must include an embedded YAML block.")
        checked_items.append(("Embedded YAML block", False, "No ```yaml block found"))
    else:
        checked_items.append(("Embedded YAML block", True, "Found ```yaml block"))

    # Check 5: YAML root key and parsing
    root_parsers = {
        "itemspec": ItemSpecContract.from_embedded_yaml,
        "parsing_spec": ParsingSpecContract.from_embedded_yaml,
        "format_spec": FormatSpecContract.from_embedded_yaml,
    }
    parser = root_parsers.get(required_yaml_root)
    if parser is None:
        issues.append(f"Unknown required yaml root `{required_yaml_root}`.")
        checked_items.append(("YAML root key", False, f"Unknown root '{required_yaml_root}'"))
    else:
        parsed = parser(markdown)
        if parsed is None:
            issues.append(f"Embedded YAML root `{required_yaml_root}` is missing or invalid.")
            checked_items.append(("YAML root key", False, f"Root key '{required_yaml_root}' missing or invalid YAML structure"))
        else:
            checked_items.append(("YAML root key", True, f"Found and parsed '{required_yaml_root}'"))

    # Check 6: Required sections
    required_headings_list = list(required_headings)
    for heading in required_headings_list:
        if heading not in markdown:
            issues.append(f"Missing required section: {heading}")
            checked_items.append((f"Section {heading}", False, "Section not found"))
        else:
            checked_items.append((f"Section {heading}", True, "Section present"))

    # Check 7: vio_name_format (FormatSpec only)
    if require_vio_format:
        if "vio_name_format:" not in markdown:
            issues.append("FormatSpec must define 'vio_name_format:'.")
            checked_items.append(("vio_name_format field", False, "Field not found in YAML"))
        else:
            checked_items.append(("vio_name_format field", True, "Field present"))

    return ValidationOutcome(ok=not issues, issues=issues, checked_items=checked_items)
