# stage_format_spec_attempt1 LLM Output

# FormatSpec: IMP-10-0-0-00

## Pattern Strategy

| Strategy Aspect | Decision | Rationale |
|-----------------|----------|-----------|
| Pattern Scope | Cross-project reusable | Patterns must work across different projects and tool versions |
| File Path Pattern | Glob with wildcards | Match any path containing expected directory structure |
| Tool Pattern | Partial match on tool family | Match tool name without hardcoding specific version |
| Version Pattern | Regex for semantic versioning | Match version formats like `X.Y-suffix` |
| Timestamp Pattern | Existence check | Validate timestamp presence without format restriction |

## Requirement Items

| Requirement ID | Object | Sub-Item | Pattern | Comparator | Evidence Source |
|----------------|--------|----------|---------|------------|-----------------|
| REQ1 | netlist | file_path | `*/dbs/*.v.gz` | glob | EV1 |
| REQ2 | netlist | file_name | `*.v.gz` | glob | EV2 |
| REQ3 | netlist | design_name | `*` | glob | EV3 |
| REQ4 | netlist | generator_tool | `*Synthesis*` | glob | EV4 |
| REQ5 | netlist | generator_version | `[0-9]+\.[0-9]+.*` | regex | EV5 |
| REQ6 | netlist | generation_time | `.+` | regex | EV6 |
| REQ7 | spef | file_path | `*.spef*` | glob | - |
| REQ8 | spef | file_name | `*.spef*` | glob | - |
| REQ9 | spef | design_name | `*` | glob | - |
| REQ10 | spef | extractor_tool | `*` | glob | - |
| REQ11 | spef | extractor_version | `[0-9]+\.[0-9]+.*` | regex | - |
| REQ12 | spef | extraction_time | `.+` | regex | - |

## Pattern Index Mapping

| Index | Requirement ID | Target | Description |
|-------|----------------|--------|-------------|
| 0 | REQ1 | netlist.file_path | Netlist file path in dbs directory |
| 1 | REQ2 | netlist.file_name | Compressed Verilog filename |
| 2 | REQ3 | netlist.design_name | Top-level design name |
| 3 | REQ4 | netlist.generator_tool | Synthesis tool identifier |
| 4 | REQ5 | netlist.generator_version | Tool version string |
| 5 | REQ6 | netlist.generation_time | Generation timestamp |
| 6 | REQ7 | spef.file_path | SPEF file path |
| 7 | REQ8 | spef.file_name | SPEF filename |
| 8 | REQ9 | spef.design_name | SPEF design scope |
| 9 | REQ10 | spef.extractor_tool | Extraction tool name |
| 10 | REQ11 | spef.extractor_version | Extractor version |
| 11 | REQ12 | spef.extraction_time | Extraction timestamp |

## Waiver Items

| Waiver Token | Scope | Effect |
|--------------|-------|--------|
| `spef:*` | Object-level | Waive all SPEF sub-items when SPEF loading is skipped |
| `spef:file_path` | Sub-item | Waive SPEF file path only |
| `netlist:*` | Object-level | Waive all netlist sub-items if netlist not applicable |

## Waiver Keyword Taxonomy

| Scenario | Waiver Item | Keywords | Sample Reason |
|----------|-------------|----------|---------------|
| object_skipped | `spef:*` | `skip`, `Skipping SPEF`, `not loaded`, `N/A`, `post-synthesis` | SPEF loading skipped per project configuration |
| object_skipped | `netlist:*` | `skip`, `not loaded`, `N/A` | Netlist not applicable for this check phase |
| extraction_failed | `spef:extractor_tool` | `unknown`, `not found`, `missing header` | Extractor tool info not available in SPEF header |
| extraction_failed | `netlist:generator_tool` | `unknown`, `not found`, `missing header` | Generator tool info not available in netlist header |

## Scenario Matrix

### Scenario 1: Existence Check Only (req=N/A, waiver=N/A)

| Condition | Description | Reason |
|-----------|-------------|--------|
| found_desc | All mandatory sub-items extracted for object | Evidence successfully parsed from source files |
| missing_desc | One or more mandatory sub-items not extracted | Source file missing or parsing failed |
| found_reason | File loaded and header metadata accessible | STA log contains load command and referenced file readable |
| missing_reason | File not loaded or header not parseable | Load command absent or file inaccessible |

### Scenario 2: Existence with Waiver (req=N/A, waiver>0)

| Condition | Description | Reason |
|-----------|-------------|--------|
| found_desc | All mandatory sub-items extracted for object | Evidence successfully parsed from source files |
| missing_desc | One or more mandatory sub-items not extracted | Source file missing or parsing failed |
| waived_desc | Missing sub-items covered by waiver token | Waiver explicitly allows skipping this object |
| unused_desc | Waiver token defined but all items extracted | Extraction succeeded despite waiver availability |
| waived_reason | Object loading explicitly skipped per configuration | Log indicates intentional skip (e.g., post-synthesis mode) |
| unused_reason | Waiver not needed as extraction completed | All evidence found in source files |

### Scenario 3: Pattern Matching (req>0, waiver=N/A)

| Condition | Description | Reason |
|-----------|-------------|--------|
| found_desc | Extracted value matches requirement pattern | Value conforms to expected format |
| missing_desc | Extracted value does not match pattern | Value format unexpected or corrupted |
| found_reason | Tool/version/path follows standard conventions | EDA tool output follows documented format |
| missing_reason | Non-standard format or extraction error | Custom tool configuration or parsing issue |

### Scenario 4: Pattern with Waiver (req>0, waiver>0)

| Condition | Description | Reason |
|-----------|-------------|--------|
| found_desc | Extracted value matches requirement pattern | Value conforms to expected format |
| missing_desc | Extracted value does not match pattern | Value format unexpected or corrupted |
| waived_desc | Pattern mismatch covered by waiver | Known deviation accepted per project policy |
| unused_desc | Waiver defined but pattern matched | Standard format used despite waiver availability |
| waived_reason | Accepted deviation from standard format | Project uses non-standard tool configuration |
| unused_reason | Waiver not needed as pattern matched | Extracted value follows expected conventions |

## Expected Outcomes

| Scenario | Requirements | Waivers | Decision Rule |
|----------|--------------|---------|---------------|
| S1 | N/A | N/A | PASS if all mandatory sub-items extracted for both netlist and spef |
| S2 | N/A | >0 | PASS if all mandatory sub-items extracted OR covered by waiver |
| S3 | >0 | N/A | PASS if all extracted values match their requirement patterns |
| S4 | >0 | >0 | PASS if all values match patterns OR mismatches covered by waiver |

## Embedded Schema

```yaml
format_spec:
  item_id: "IMP-10-0-0-00"
  description: "Confirm the netlist/spef version is correct."
  check_module: "10.0_STA_DCD_CHECK"
  vio_name_format: "item_name"
  requirement_items:
    - requirement_id: REQ1
      object_name: netlist
      sub_item: file_path
      pattern: "*/dbs/*.v.gz"
      comparator: glob
      source_evidence_ids: [EV1]
    - requirement_id: REQ2
      object_name: netlist
      sub_item: file_name
      pattern: "*.v.gz"
      comparator: glob
      source_evidence_ids: [EV2]
    - requirement_id: REQ3
      object_name: netlist
      sub_item: design_name
      pattern: "*"
      comparator: glob
      source_evidence_ids: [EV3]
    - requirement_id: REQ4
      object_name: netlist
      sub_item: generator_tool
      pattern: "*Synthesis*"
      comparator: glob
      source_evidence_ids: [EV4]
    - requirement_id: REQ5
      object_name: netlist
      sub_item: generator_version
      pattern: "[0-9]+\\.[0-9]+.*"
      comparator: regex
      source_evidence_ids: [EV5]
    - requirement_id: REQ6
      object_name: netlist
      sub_item: generation_time
      pattern: ".+"
      comparator: regex
      source_evidence_ids: [EV6]
    - requirement_id: REQ7
      object_name: spef
      sub_item: file_path
      pattern: "*.spef*"
      comparator: glob
      source_evidence_ids: []
    - requirement_id: REQ8
      object_name: spef
      sub_item: file_name
      pattern: "*.spef*"
      comparator: glob
      source_evidence_ids: []
    - requirement_id: REQ9
      object_name: spef
      sub_item: design_name
      pattern: "*"
      comparator: glob
      source_evidence_ids: []
    - requirement_id: REQ10
      object_name: spef
      sub_item: extractor_tool
      pattern: "*"
      comparator: glob
      source_evidence_ids: []
    - requirement_id: REQ11
      object_name: spef
      sub_item: extractor_version
      pattern: "[0-9]+\\.[0-9]+.*"
      comparator: regex
      source_evidence_ids: []
    - requirement_id: REQ12
      object_name: spef
      sub_item: extraction_time
      pattern: ".+"
      comparator: regex
      source_evidence_ids: []
  pattern_index_mapping:
    - index: 0
      requirement_id: REQ1
      target: "netlist.file_path"
    - index: 1
      requirement_id: REQ2
      target: "netlist.file_name"
    - index: 2
      requirement_id: REQ3
      target: "netlist.design_name"
    - index: 3
      requirement_id: REQ4
      target: "netlist.generator_tool"
    - index: 4
      requirement_id: REQ5
      target: "netlist.generator_version"
    - index: 5
      requirement_id: REQ6
      target: "netlist.generation_time"
    - index: 6
      requirement_id: REQ7
      target: "spef.file_path"
    - index: 7
      requirement_id: REQ8
      target: "spef.file_name"
    - index: 8
      requirement_id: REQ9
      target: "spef.design_name"
    - index: 9
      requirement_id: REQ10
      target: "spef.extractor_tool"
    - index: 10
      requirement_id: REQ11
      target: "spef.extractor_version"
    - index: 11
      requirement_id: REQ12
      target: "spef.extraction_time"
  waiver_items:
    - "spef:*"
    - "spef:file_path"
    - "spef:file_name"
    - "spef:design_name"
    - "spef:extractor_tool"
    - "spef:extractor_version"
    - "spef:extraction_time"
    - "netlist:*"
  waiver_keyword_taxonomy:
    - scenario: object_skipped
      waiver_item: "spef:*"
      keywords: ["skip", "Skipping SPEF", "not loaded", "N/A", "post-synthesis"]
      sample_reason: "SPEF loading skipped per project configuration"
    - scenario: object_skipped
      waiver_item: "netlist:*"
      keywords: ["skip", "not loaded", "N/A"]
      sample_reason: "Netlist not applicable for this check phase"
    - scenario: extraction_failed
      waiver_item: "spef:extractor_tool"
      keywords: ["unknown", "not found", "missing header"]
      sample_reason: "Extractor tool info not available in SPEF header"
    - scenario: extraction_failed
      waiver_item: "netlist:generator_tool"
      keywords: ["unknown", "not found", "missing header"]
      sample_reason: "Generator tool info not available in netlist header"
  expected_outcomes:
    - scenario: S1
      requirements_value: "N/A"
      waivers_value: "N/A"
      decision_rule: "PASS if all mandatory sub-items extracted for both netlist and spef"
    - scenario: S2
      requirements_value: "N/A"
      waivers_value: ">0"
      decision_rule: "PASS if all mandatory sub-items extracted OR covered by waiver"
    - scenario: S3
      requirements_value: ">0"
      waivers_value: "N/A"
      decision_rule: "PASS if all extracted values match their requirement patterns"
    - scenario: S4
      requirements_value: ">0"
      waivers_value: ">0"
      decision_rule: "PASS if all values match patterns OR mismatches covered by waiver"
```
