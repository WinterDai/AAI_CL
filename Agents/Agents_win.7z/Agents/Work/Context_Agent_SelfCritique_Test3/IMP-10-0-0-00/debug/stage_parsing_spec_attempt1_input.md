# stage_parsing_spec_attempt1 LLM Input

## System Prompt

```
You are a senior digital physical implementation expert.
Return only Markdown in English.
Do not use Chinese.
Keep technical content concise and operational.

## Stage Boundaries

- ItemSpec stage must not read runtime input files.
- ParsingSpec stage reads resolved input files and records evidence locations.
- FormatSpec stage depends on ItemSpec + ParsingSpec + valid evidence snippets.

## Critical Rules

### ItemSpec Stage Rules:
- Derive check objects from the checker DESCRIPTION (e.g., "netlist/spef" → objects: netlist, spef)
- Define sub-items based on OBJECT SEMANTIC TYPE (see Object Type Templates below)
- Do NOT include regex patterns - only define WHAT to extract, not HOW
- Specify data source for each sub-item based on input_files context

### ParsingSpec Stage Rules:
- Extract ALL sub-items defined in ItemSpec for each object
- If you extract a file path, you MUST read that file to extract metadata from its header
- Mark extraction status: ✓ (success) or ERROR (failed)
- Provide object-level summary: "netlist 6/6 ✓" or "spef 0/6 ✗"

### FormatSpec Stage Rules:
- Patterns must be cross-project REUSABLE
- CORRECT: `*.v.gz`, `*/dbs/*`, `*Synthesis*`
- WRONG: `*block_A*`, `*Genus 23.15*`, specific project paths or file names
- Do NOT hardcode specific extracted values into patterns

## Object Type Templates

Choose sub-items based on object semantic type:

### Type A: EDA-Generated Files (netlist, gds, def, lef_macro)
| Sub-Item | Semantic | Required |
|----------|----------|----------|
| file_path | Full path to the file | YES |
| file_name | Filename extracted from path | YES |
| design_name | Top-level design/module name | YES |
| generator_tool | EDA tool that created the file | YES |
| generator_version | Tool version string | YES |
| generation_time | File creation timestamp | YES |

### Type B: Parasitic Files (spef, spf)
| Sub-Item | Semantic | Required |
|----------|----------|----------|
| file_path | Full path to the file | YES |
| file_name | Filename extracted from path | YES |
| design_name | Top-level design/module name | YES |
| extractor_tool | Parasitic extraction tool name | YES |
| extractor_version | Extraction tool version | YES |
| extraction_time | SPEF creation timestamp | YES |

### Type C: Library Files (liberty, lef_tech, db)
| Sub-Item | Semantic | Required |
|----------|----------|----------|
| library_path | Full path to library file | YES |
| library_name | Library identifier | YES |
| library_version | Version string | YES |
| corner | PVT corner (fast/slow/typical) | NO |
| process_node | Technology node | NO |

### Type D: Constraint Files (sdc, upf, cpf)
| Sub-Item | Semantic | Required |
|----------|----------|----------|
| file_path | Full path to constraint file | YES |
| file_name | Filename | YES |
| design_scope | Design/module scope | NO |
| content_hash | Integrity hash if available | NO |

## Validation Rules (What the Validator Checks)

### Single-Spec Validation:
1. Title must include item ID
2. Must be pure English (no CJK characters)
3. Must include embedded YAML block with correct root key (`itemspec`, `parsing_spec`, or `format_spec`)
4. Must include all required sections for the stage

### Cross-Spec Validation:
1. ParsingSpec objects must be defined in ItemSpec
2. ParsingSpec sub_items must be defined in ItemSpec
3. Every mandatory sub-item must have mapping or extraction_gap
4. FormatSpec requirement_items must cover all mandatory pairs
5. FormatSpec patterns must not be empty or `<missing>`
6. FormatSpec expected_outcomes must include scenarios S1-S4

## Expected YAML Field Names (Parser Requirements)

The parser expects these EXACT field names in embedded YAML:

### ItemSpec YAML:
```yaml
itemspec:
  item_id: string
  description: string
  check_module: string
  semantic_targets:
    - target_id: string
      object_name: string        # NOT "name" or "object_id"
      semantic_intent: string
      sub_items:
        - name: string
          required: boolean
          semantics: string      # NOT "semantic"
```

### ParsingSpec YAML:
```yaml
parsing_spec:
  item_id: string
  description: string
  check_module: string
  resolved_inputs: [string]
  evidence_records:
    - evidence_id: string
      source_file: string
      line_number: integer
      extracted_value: string
  evidence_to_sub_item:
    - evidence_id: string
      object_name: string        # Use "object_name"
      sub_item: string
      required: boolean
      mapping_status: string     # "mapped", "mapped_with_fallback", "not_applicable"
      rationale: string
  extraction_gaps:
    - object_name: string
      sub_item: string
      gap_type: string
      detail: string
```

### FormatSpec YAML:
```yaml
format_spec:
  item_id: string
  description: string
  check_module: string
  vio_name_format: string
  requirement_items:
    - requirement_id: string
      object_name: string
      sub_item: string
      pattern: string
      comparator: string
  expected_outcomes:
    - scenario: string           # Must include S1, S2, S3, S4
      requirements_value: string
      waivers_value: string
      decision_rule: string
```

```

## User Prompt

```
Create the ParsingSpec for one checker item.

Requirements:
- Output must be Markdown in English.
- Title must include item ID.
- Include exactly these sections:
  - ## Input Resolution
  - ## Evidence Inventory
  - ## Referenced Files
  - ## Evidence to Sub-Item Mapping
  - ## Object Status Summary
  - ## Extraction Gaps
  - ## Embedded Schema
- Include one YAML code block under "## Embedded Schema" with key `parsing_spec`.
- Record evidence with source path + line number + extracted values.

## CRITICAL: Must Read Referenced Files

**If you extract a file path from the log/report, you MUST read that file and extract metadata from its header.**

Example workflow:
1. Log contains: `read_netlist /path/to/design.v.gz`
2. You MUST read the netlist file header to extract: generator_tool, generator_version, generation_time
3. Include these extractions in Evidence Inventory with source = "netlist file header"

## Sub-Item Extraction (Follow ItemSpec Definition)

Extract ALL sub-items as defined in the ItemSpec for each object. The sub-items vary by object type:

- **EDA-Generated Files**: file_path, file_name, design_name, generator_tool, generator_version, generation_time
- **Parasitic Files (SPEF)**: file_path, file_name, design_name, extractor_tool, extractor_version, extraction_time
- **Library Files**: library_path, library_name, library_version, corner, process_node
- **Constraint Files**: file_path, file_name, design_scope

### Splitting Compound Values (IMPORTANT)

When extracting from headers like "Generated by Cadence Genus 23.15-s099_1":
- Extract as TWO separate values:
  - `generator_tool` = "Cadence Genus"
  - `generator_version` = "23.15-s099_1"
- The ItemSpec defines them as separate sub-items, so you MUST split them

## Object Status Summary Section (REQUIRED)

Include a summary table with extraction counts based on ItemSpec definition:

| Object | Status | Extracted | Total | Missing Sub-Items |
|--------|--------|-----------|-------|-------------------|
| netlist | ✓ | 6 | 6 | (none) |
| spef | ✗ | 0 | 6 | all (SPEF skipped) |
| liberty | ✓ | 4 | 5 | corner |

Format: "netlist 6/6 ✓" or "spef 0/6 ✗"

## Evidence to Sub-Item Mapping

Map each evidence row to:
- candidate object (use `object_name` field)
- candidate sub-item
- extraction status (✓ or ERROR)
- mapping rationale

## Expected YAML Structure

```yaml
parsing_spec:
  item_id: "{{ITEM_ID}}"
  description: "{{DESCRIPTION}}"
  check_module: "{{CHECK_MODULE}}"
  resolved_inputs:
    - "/path/to/input/file.log"
  evidence_records:
    - evidence_id: EV1
      source_file: "/path/to/sta.log"
      line_number: 42
      pattern: "read_netlist"
      extracted_value: "/path/to/design.v.gz"
      raw_line: "read_netlist /path/to/design.v.gz"
    - evidence_id: EV2
      source_file: "/path/to/design.v.gz"  # Referenced file
      line_number: 3
      pattern: "Generated by"
      extracted_value: "Cadence Genus"     # Tool only
      raw_line: "// Generated by Cadence Genus 23.15-s099_1"
    - evidence_id: EV3
      source_file: "/path/to/design.v.gz"
      line_number: 3
      pattern: "version"
      extracted_value: "23.15-s099_1"      # Version only
      raw_line: "// Generated by Cadence Genus 23.15-s099_1"
  evidence_to_sub_item:
    - evidence_id: EV1
      object_name: netlist                  # Use "object_name" not "object"
      sub_item: file_path
      required: true
      mapping_status: mapped
      rationale: "Path extracted from read_netlist command"
    - evidence_id: EV2
      object_name: netlist
      sub_item: generator_tool              # Separate mapping for tool
      required: true
      mapping_status: mapped
      rationale: "Tool name extracted from netlist header"
    - evidence_id: EV3
      object_name: netlist
      sub_item: generator_version           # Separate mapping for version
      required: true
      mapping_status: mapped
      rationale: "Version extracted from netlist header"
  object_status_summary:
    - object_name: netlist
      mandatory_found: 6
      mandatory_total: 6
      status: PASS
  extraction_gaps:
    - object_name: spef
      sub_item: file_path
      gap_type: not_extracted
      detail: "SPEF loading was skipped in STA log"
      suggested_resolution: "Add waiver for spef:*"
```

Item context:
{
  "item_id": "IMP-10-0-0-00",
  "description": "Confirm the netlist/spef version is correct.",
  "check_module": "10.0_STA_DCD_CHECK",
  "resolved_inputs": [
    "C:\\Users\\wentao\\Desktop\\AAI\\Main_work\\ACL\\checker-agent-dev\\CHECKLIST\\IP_project_folder\\logs\\sta_post_syn.log"
  ],
  "missing_inputs": []
}

ItemSpec:
# ItemSpec: IMP-10-0-0-00

## Scope

This ItemSpec defines the semantic extraction contract for checker item **IMP-10-0-0-00**, which validates that netlist and SPEF file versions are correct. The check targets two distinct object types: EDA-generated netlist files and parasitic extraction (SPEF) files.

## Description Interpretation Rules

| Rule | Interpretation |
|------|----------------|
| Slash notation `netlist/spef` | Logical AND - both netlist AND spef must be validated |
| "version is correct" | Requires extraction of tool name, version string, and timestamp for comparison |
| Implicit completeness | All instances of each object type found in logs must be checked |

## Data Sources

| Data Source Type | Primary Information | Secondary Information |
|------------------|--------------------|-----------------------|
| STA/synthesis log file | `read_netlist` commands with file paths, `read_parasitics` commands with SPEF paths | Tool invocation context |
| Verilog netlist (referenced) | Header comments with generator tool, version, timestamp | Module/design name |
| SPEF file (referenced) | Header section with extractor tool, version, extraction timestamp | Design scope |

**Extraction Strategy:**
1. Parse STA log to locate file load commands
2. Extract file paths from commands
3. Read referenced files to extract metadata from headers

## Semantic Targets

### Object Classification

| Object | Semantic Type | Template |
|--------|---------------|----------|
| netlist | EDA-Generated File | Type A |
| spef | Parasitic File | Type B |

### Target Summary

| Target ID | Object Name | Semantic Intent |
|-----------|-------------|-----------------|
| T1 | netlist | Validate that netlist version evidence supports correctness verification |
| T2 | spef | Validate that SPEF version evidence supports correctness verification |

### Sub-Item Contracts

#### T1: netlist (Type A - EDA-Generated File)

| Sub-Item | Required | Semantics | Data Source |
|----------|----------|-----------|-------------|
| file_path | YES | Full path to the netlist file | STA log read_netlist command |
| file_name | YES | Filename extracted from path | Derived from file_path |
| design_name | YES | Top-level module name | Netlist file header |
| generator_tool | YES | EDA tool name that created the netlist | Netlist file header |
| generator_version | YES | Tool version string | Netlist file header |
| generation_time | YES | Netlist creation timestamp | Netlist file header |

#### T2: spef (Type B - Parasitic File)

| Sub-Item | Required | Semantics | Data Source |
|----------|----------|-----------|-------------|
| file_path | YES | Full path to the SPEF file | STA log read_parasitics command |
| file_name | YES | Filename extracted from path | Derived from file_path |
| design_name | YES | Top-level design name | SPEF file header |
| extractor_tool | YES | Parasitic extraction tool name | SPEF file header |
| extractor_version | YES | Extraction tool version string | SPEF file header |
| extraction_time | YES | SPEF creation timestamp | SPEF file header |

## Check Criteria

| Criterion | Description |
|-----------|-------------|
| Completeness | All 6 sub-items extracted for each netlist instance |
| Completeness | All 6 sub-items extracted for each spef instance |
| Traceability | Each extracted value linked to source file and line number |
| Consistency | Version format follows expected tool-specific patterns |

## Evidence Plan

| Evidence Type | Object | Sub-Items Covered | Source |
|---------------|--------|-------------------|--------|
| File load command | netlist | file_path | STA log |
| File load command | spef | file_path | STA log |
| Header metadata | netlist | design_name, generator_tool, generator_version, generation_time | Netlist file |
| Header metadata | spef | design_name, extractor_tool, extractor_version, extraction_time | SPEF file |

## Embedded Schema

```yaml
itemspec:
  item_id: "IMP-10-0-0-00"
  description: "Confirm the netlist/spef version is correct."
  check_module: "10.0_STA_DCD_CHECK"
  semantic_targets:
    - target_id: T1
      object_name: "netlist"
      semantic_intent: "Validate that netlist version evidence supports correctness verification"
      sub_items:
        - name: "file_path"
          required: true
          semantics: "Full path to the netlist file"
        - name: "file_name"
          required: true
          semantics: "Filename extracted from path"
        - name: "design_name"
          required: true
          semantics: "Top-level module name from netlist"
        - name: "generator_tool"
          required: true
          semantics: "EDA tool name that created the netlist"
        - name: "generator_version"
          required: true
          semantics: "Tool version string"
        - name: "generation_time"
          required: true
          semantics: "Netlist creation timestamp"
    - target_id: T2
      object_name: "spef"
      semantic_intent: "Validate that SPEF version evidence supports correctness verification"
      sub_items:
        - name: "file_path"
          required: true
          semantics: "Full path to the SPEF file"
        - name: "file_name"
          required: true
          semantics: "Filename extracted from path"
        - name: "design_name"
          required: true
          semantics: "Top-level design name from SPEF"
        - name: "extractor_tool"
          required: true
          semantics: "Parasitic extraction tool name"
        - name: "extractor_version"
          required: true
          semantics: "Extraction tool version string"
        - name: "extraction_time"
          required: true
          semantics: "SPEF creation timestamp"
  cross_object_rules:
    - rule_id: "COR-1"
      description: "Both netlist and spef must be validated for complete check"
      objects: ["netlist", "spef"]
      relationship: "AND"
  waiver_model:
    scopes:
      - granularity: "object-level"
        token_format: "<object>:*"
        effect_scope: "Waive all sub-items for one object"
      - granularity: "sub-item-level"
        token_format: "<object>:<sub_item>"
        effect_scope: "Waive specific sub-item for one object"
```

Evidence context:
Resolved inputs:
- C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log

Missing inputs:
- (none)

Input evidence table:
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 7 | `read_netlist\s+([^\s]+\.v(?:\.gz)?)` | `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` |
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 7 | `read_netlist\s+([^\s]+)` | `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` |
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 8 | `\bnetlist\b` | `-` | `[INFO] Reading netlist file...` |
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 11 | `\bnetlist\b` | `-` | `[INFO] Decompressing and parsing netlist...` |
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 14 | `Top level cell is\s+(\S+)` | `phy_cmn_phase_align_digtop.` | `Top level cell is phy_cmn_phase_align_digtop.` |
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 24 | `\[INFO\]\s+Skipping SPEF reading as (.+)` | `we are writing post-synthesis SDF files` | `[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files` |
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 24 | `Skipping SPEF reading as\s+(.+)` | `we are writing post-synthesis SDF files` | `[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files` |

Referenced evidence table:
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\dbs\phy_cmn_phase_align_digtop.v.gz | 2 | `Generated by\s+(.+)` | `Cadence Genus(TM) Synthesis Solution 23.15-s099_1` | `// Generated by Cadence Genus(TM) Synthesis Solution 23.15-s099_1` |
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\dbs\phy_cmn_phase_align_digtop.v.gz | 3 | `Generated on:\s+(.+)` | `Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC)` | `// Generated on: Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC)` |

Notes:
- (none)

```
