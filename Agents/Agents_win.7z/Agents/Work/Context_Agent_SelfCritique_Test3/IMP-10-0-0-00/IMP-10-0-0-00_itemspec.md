# ItemSpec: IMP-10-0-0-00

## Scope

This ItemSpec defines the semantic extraction contract for checker item **IMP-10-0-0-00**, which validates that netlist and SPEF file versions are correct. The check targets two distinct object types: EDA-generated netlist files and parasitic extraction (SPEF) files.

## Description Interpretation Rules

| Rule | Interpretation |
|------|----------------|
| Slash notation `netlist/spef` | Logical AND - both netlist AND spef must be validated |
| "version is correct" | Requires extraction of tool name, version string, and timestamp for comparison |
| Implicit completeness | All instances of each object type found in logs must be checked |

## Data Sources

| Data Source Type | Primary Information | Secondary Information |
|------------------|--------------------|-----------------------|
| STA/synthesis log file | `read_netlist` commands with file paths, `read_parasitics` commands with SPEF paths | Tool invocation context |
| Verilog netlist (referenced) | Header comments with generator tool, version, timestamp | Module/design name |
| SPEF file (referenced) | Header section with extractor tool, version, extraction timestamp | Design scope |

**Extraction Strategy:**
1. Parse STA log to locate file load commands
2. Extract file paths from commands
3. Read referenced files to extract metadata from headers

## Semantic Targets

### Object Classification

| Object | Semantic Type | Template |
|--------|---------------|----------|
| netlist | EDA-Generated File | Type A |
| spef | Parasitic File | Type B |

### Target Summary

| Target ID | Object Name | Semantic Intent |
|-----------|-------------|-----------------|
| T1 | netlist | Validate that netlist version evidence supports correctness verification |
| T2 | spef | Validate that SPEF version evidence supports correctness verification |

### Sub-Item Contracts

#### T1: netlist (Type A - EDA-Generated File)

| Sub-Item | Required | Semantics | Data Source |
|----------|----------|-----------|-------------|
| file_path | YES | Full path to the netlist file | STA log read_netlist command |
| file_name | YES | Filename extracted from path | Derived from file_path |
| design_name | YES | Top-level module name | Netlist file header |
| generator_tool | YES | EDA tool name that created the netlist | Netlist file header |
| generator_version | YES | Tool version string | Netlist file header |
| generation_time | YES | Netlist creation timestamp | Netlist file header |

#### T2: spef (Type B - Parasitic File)

| Sub-Item | Required | Semantics | Data Source |
|----------|----------|-----------|-------------|
| file_path | YES | Full path to the SPEF file | STA log read_parasitics command |
| file_name | YES | Filename extracted from path | Derived from file_path |
| design_name | YES | Top-level design name | SPEF file header |
| extractor_tool | YES | Parasitic extraction tool name | SPEF file header |
| extractor_version | YES | Extraction tool version string | SPEF file header |
| extraction_time | YES | SPEF creation timestamp | SPEF file header |

## Check Criteria

| Criterion | Description |
|-----------|-------------|
| Completeness | All 6 sub-items extracted for each netlist instance |
| Completeness | All 6 sub-items extracted for each spef instance |
| Traceability | Each extracted value linked to source file and line number |
| Consistency | Version format follows expected tool-specific patterns |

## Evidence Plan

| Evidence Type | Object | Sub-Items Covered | Source |
|---------------|--------|-------------------|--------|
| File load command | netlist | file_path | STA log |
| File load command | spef | file_path | STA log |
| Header metadata | netlist | design_name, generator_tool, generator_version, generation_time | Netlist file |
| Header metadata | spef | design_name, extractor_tool, extractor_version, extraction_time | SPEF file |

## Embedded Schema

```yaml
itemspec:
  item_id: "IMP-10-0-0-00"
  description: "Confirm the netlist/spef version is correct."
  check_module: "10.0_STA_DCD_CHECK"
  semantic_targets:
    - target_id: T1
      object_name: "netlist"
      semantic_intent: "Validate that netlist version evidence supports correctness verification"
      sub_items:
        - name: "file_path"
          required: true
          semantics: "Full path to the netlist file"
        - name: "file_name"
          required: true
          semantics: "Filename extracted from path"
        - name: "design_name"
          required: true
          semantics: "Top-level module name from netlist"
        - name: "generator_tool"
          required: true
          semantics: "EDA tool name that created the netlist"
        - name: "generator_version"
          required: true
          semantics: "Tool version string"
        - name: "generation_time"
          required: true
          semantics: "Netlist creation timestamp"
    - target_id: T2
      object_name: "spef"
      semantic_intent: "Validate that SPEF version evidence supports correctness verification"
      sub_items:
        - name: "file_path"
          required: true
          semantics: "Full path to the SPEF file"
        - name: "file_name"
          required: true
          semantics: "Filename extracted from path"
        - name: "design_name"
          required: true
          semantics: "Top-level design name from SPEF"
        - name: "extractor_tool"
          required: true
          semantics: "Parasitic extraction tool name"
        - name: "extractor_version"
          required: true
          semantics: "Extraction tool version string"
        - name: "extraction_time"
          required: true
          semantics: "SPEF creation timestamp"
  cross_object_rules:
    - rule_id: "COR-1"
      description: "Both netlist and spef must be validated for complete check"
      objects: ["netlist", "spef"]
      relationship: "AND"
  waiver_model:
    scopes:
      - granularity: "object-level"
        token_format: "<object>:*"
        effect_scope: "Waive all sub-items for one object"
      - granularity: "sub-item-level"
        token_format: "<object>:<sub_item>"
        effect_scope: "Waive specific sub-item for one object"
```