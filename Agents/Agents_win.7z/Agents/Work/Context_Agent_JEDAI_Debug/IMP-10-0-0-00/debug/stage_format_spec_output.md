# stage_format_spec LLM Output

# FormatSpec: IMP-10-0-0-00

vio_name_format: "item_name"

## Pattern Strategy

This checker validates netlist and SPEF version metadata for STA flows. The pattern strategy addresses two distinct scenarios:

1. **Netlist validation**: Full 6-sub-item extraction with patterns for file paths, synthesis tool, version, and timestamp
2. **SPEF validation**: Conditional - may be skipped in post-synthesis flows; patterns for parasitic extractor metadata when present

Pattern design focuses on:
- Generic file extension patterns (`*.v.gz`, `*.spef*`)
- Tool family patterns (`*Genus*`, `*Synthesis*`) without version hardcoding
- Path structure patterns (`*/dbs/*`, `*/logs/*`) for cross-project reuse

## Requirement Items

| Index | Object | Sub-Item | Pattern | Description |
|-------|--------|----------|---------|-------------|
| 0 | netlist | file_path | `*/dbs/*.v.gz` | Netlist file in database directory |
| 1 | netlist | file_name | `*.v.gz` | Compressed Verilog netlist |
| 2 | netlist | design_name | `*` | Any valid design name |
| 3 | netlist | generator_tool | `*Synthesis*` | Synthesis tool identifier |
| 4 | netlist | generator_version | `*.*-*` | Version with major.minor-patch format |
| 5 | netlist | generation_time | `* * * *:*:* *` | Timestamp pattern |
| 6 | spef | file_path | `*.spef*` | SPEF file path |
| 7 | spef | file_name | `*.spef*` | SPEF filename |
| 8 | spef | design_name | `*` | Design name in SPEF |
| 9 | spef | extractor_tool | `*Extract*` | Parasitic extractor tool |
| 10 | spef | extractor_version | `*.*` | Extractor version |
| 11 | spef | extraction_time | `* * * *:*:* *` | Extraction timestamp |

## Pattern Index Mapping

```
pattern_items[0] -> netlist.file_path validation (path structure)
pattern_items[1] -> netlist.file_name validation (extension)
pattern_items[2] -> netlist.design_name validation (existence)
pattern_items[3] -> netlist.generator_tool validation (tool family)
pattern_items[4] -> netlist.generator_version validation (version format)
pattern_items[5] -> netlist.generation_time validation (timestamp format)
pattern_items[6] -> spef.file_path validation (path structure)
pattern_items[7] -> spef.file_name validation (extension)
pattern_items[8] -> spef.design_name validation (existence)
pattern_items[9] -> spef.extractor_tool validation (tool family)
pattern_items[10] -> spef.extractor_version validation (version format)
pattern_items[11] -> spef.extraction_time validation (timestamp format)
```

## Waiver Items

| Index | Waiver Pattern | Applicable Object | Rationale |
|-------|----------------|-------------------|-----------|
| 0 | `*post-synthesis*` | spef | SPEF skipped in post-synthesis SDF flow |
| 1 | `*SDF*flow*` | spef | SDF-based timing, no SPEF required |
| 2 | `*Skipping*SPEF*` | spef | Explicit SPEF skip in log |

## Waiver Keyword Taxonomy

| Scenario | Keywords | Sample Waiver Reason |
|----------|----------|---------------------|
| Post-synthesis flow | `post-synthesis`, `SDF`, `synthesis timing` | "SPEF not applicable for post-synthesis SDF timing analysis" |
| Early flow stage | `pre-layout`, `synthesis only`, `no parasitic` | "Parasitic extraction not yet performed" |
| Intentional skip | `Skipping SPEF`, `SPEF disabled`, `no SPEF` | "SPEF reading explicitly disabled per flow configuration" |
| Alternative format | `DSPF`, `RSPF`, `alternative parasitic` | "Using alternative parasitic format instead of SPEF" |

## Scenario Matrix

### Scenario 1: req=N/A, waiver=N/A (Existence Check Only)

| Field | Value |
|-------|-------|
| found_desc | All mandatory objects (netlist, spef) have extracted sub-items |
| missing_desc | One or more mandatory objects missing required sub-items |
| found_reason | Extraction successful, version metadata documented |
| missing_reason | Extraction failed or file not accessible |

### Scenario 2: req=N/A, waiver>0 (Existence + Waiver Handling)

| Field | Value |
|-------|-------|
| found_desc | Mandatory objects extracted or appropriately waived |
| missing_desc | Objects missing without valid waiver |
| found_reason | Extraction complete or waiver applied |
| missing_reason | Neither extraction nor waiver covers missing data |
| waived_desc | SPEF extraction waived due to post-synthesis flow |
| unused_desc | Waiver defined but object was successfully extracted |
| waived_reason | Log indicates intentional SPEF skip |
| unused_reason | Waiver not needed as extraction succeeded |

### Scenario 3: req>0, waiver=N/A (Pattern Matching)

| Field | Value |
|-------|-------|
| found_desc | Extracted values match defined patterns |
| missing_desc | Extracted values do not match patterns or extraction failed |
| found_reason | File paths, tool names, versions conform to expected formats |
| missing_reason | Unexpected format or missing mandatory sub-items |

### Scenario 4: req>0, waiver>0 (Pattern + Waiver)

| Field | Value |
|-------|-------|
| found_desc | Values match patterns or are covered by waiver |
| missing_desc | Values fail patterns without applicable waiver |
| found_reason | Pattern match or valid waiver applied |
| missing_reason | Pattern mismatch and no waiver coverage |
| waived_desc | Pattern mismatch waived per documented exception |
| unused_desc | Waiver available but pattern matched |
| waived_reason | Known exception documented in waiver |
| unused_reason | Pattern validation passed without waiver |

## Expected Outcomes

### Requirement/Waiver Combination Matrix

| Requirement | Waiver | Expected Outcome |
|-------------|--------|------------------|
| N/A | N/A | PASS if all mandatory objects extracted |
| N/A | >0 | PASS if extracted or waived |
| >0 | N/A | PASS if patterns match |
| >0 | >0 | PASS if patterns match or waived |

### Current Evidence Assessment

Based on ParsingSpec evidence:

| Object | Extraction | Pattern Match | Waiver Applicable | Expected Result |
|--------|------------|---------------|-------------------|-----------------|
| netlist | 6/6 ✓ | ✓ (all patterns) | N/A | **PASS** |
| spef | 0/6 ✗ | N/A | ✓ (post-synthesis) | **PASS** (waived) |

**Overall Expected Outcome**: **PASS** with waiver applied for SPEF

Rationale:
- Netlist: Complete extraction (6/6), file path matches `*/dbs/*.v.gz`, tool matches `*Synthesis*`
- SPEF: Explicitly skipped per log line 24 "Skipping SPEF reading as we are writing post-synthesis SDF files" - matches waiver pattern `*post-synthesis*`

## Embedded Schema

```yaml
format_spec:
  item_id: IMP-10-0-0-00
  description: "Confirm the netlist/spef version is correct."
  check_module: 10.0_STA_DCD_CHECK
  vio_name_format: "item_name"
  
  pattern_items:
    - "netlist: file_path=*/dbs/*.v.gz; file_name=*.v.gz; design_name=*; generator_tool=*Synthesis*; generator_version=*.*-*; generation_time=* * * *:*:* *"
    - "spef: file_path=*.spef*; file_name=*.spef*; design_name=*; extractor_tool=*Extract*; extractor_version=*.*; extraction_time=* * * *:*:* *"
  
  pattern_index_mapping:
    - index: 0
      object: netlist
      sub_items:
        - name: file_path
          pattern: "*/dbs/*.v.gz"
          alt_patterns: ["*/*.v.gz", "*.v.gz"]
        - name: file_name
          pattern: "*.v.gz"
          alt_patterns: ["*.v"]
        - name: design_name
          pattern: "*"
        - name: generator_tool
          pattern: "*Synthesis*"
          alt_patterns: ["*Genus*", "*DC*", "*Design Compiler*"]
        - name: generator_version
          pattern: "*.*-*"
          alt_patterns: ["*.*.*", "*-*"]
        - name: generation_time
          pattern: "* * * *:*:* *"
          alt_patterns: ["*-*-* *:*:*", "*/*/*"]
    - index: 1
      object: spef
      sub_items:
        - name: file_path
          pattern: "*.spef*"
          alt_patterns: ["*.spef.gz", "*.SPEF"]
        - name: file_name
          pattern: "*.spef*"
        - name: design_name
          pattern: "*"
        - name: extractor_tool
          pattern: "*Extract*"
          alt_patterns: ["*StarRC*", "*QRC*", "*Quantus*"]
        - name: extractor_version
          pattern: "*.*"
        - name: extraction_time
          pattern: "* * * *:*:* *"
  
  waive_items:
    - pattern: "*post-synthesis*"
      applies_to: spef
      reason: "SPEF not applicable for post-synthesis SDF timing flow"
    - pattern: "*SDF*flow*"
      applies_to: spef
      reason: "SDF-based timing analysis does not require SPEF"
    - pattern: "*Skipping*SPEF*"
      applies_to: spef
      reason: "Explicit SPEF skip documented in STA log"
  
  waiver_keyword_taxonomy:
    post_synthesis_flow:
      keywords: ["post-synthesis", "SDF", "synthesis timing"]
      sample_reason: "SPEF not applicable for post-synthesis SDF timing analysis"
    early_flow_stage:
      keywords: ["pre-layout", "synthesis only", "no parasitic"]
      sample_reason: "Parasitic extraction not yet performed"
    intentional_skip:
      keywords: ["Skipping SPEF", "SPEF disabled", "no SPEF"]
      sample_reason: "SPEF reading explicitly disabled per flow configuration"
    alternative_format:
      keywords: ["DSPF", "RSPF", "alternative parasitic"]
      sample_reason: "Using alternative parasitic format instead of SPEF"
  
  scenario_matrix:
    scenario_1:
      req: "N/A"
      waiver: "N/A"
      found_desc: "All mandatory objects (netlist, spef) have extracted sub-items"
      missing_desc: "One or more mandatory objects missing required sub-items"
      found_reason: "Extraction successful, version metadata documented"
      missing_reason: "Extraction failed or file not accessible"
    scenario_2:
      req: "N/A"
      waiver: ">0"
      found_desc: "Mandatory objects extracted or appropriately waived"
      missing_desc: "Objects missing without valid waiver"
      found_reason: "Extraction complete or waiver applied"
      missing_reason: "Neither extraction nor waiver covers missing data"
      waived_desc: "SPEF extraction waived due to post-synthesis flow"
      unused_desc: "Waiver defined but object was successfully extracted"
      waived_reason: "Log indicates intentional SPEF skip"
      unused_reason: "Waiver not needed as extraction succeeded"
    scenario_3:
      req: ">0"
      waiver: "N/A"
      found_desc: "Extracted values match defined patterns"
      missing_desc: "Extracted values do not match patterns or extraction failed"
      found_reason: "File paths, tool names, versions conform to expected formats"
      missing_reason: "Unexpected format or missing mandatory sub-items"
    scenario_4:
      req: ">0"
      waiver: ">0"
      found_desc: "Values match patterns or are covered by waiver"
      missing_desc: "Values fail patterns without applicable waiver"
      found_reason: "Pattern match or valid waiver applied"
      missing_reason: "Pattern mismatch and no waiver coverage"
      waived_desc: "Pattern mismatch waived per documented exception"
      unused_desc: "Waiver available but pattern matched"
      waived_reason: "Known exception documented in waiver"
      unused_reason: "Pattern validation passed without waiver"
  
  expected_outcomes:
    combination_matrix:
      - req: "N/A"
        waiver: "N/A"
        outcome: "PASS if all mandatory objects extracted"
      - req: "N/A"
        waiver: ">0"
        outcome: "PASS if extracted or waived"
      - req: ">0"
        waiver: "N/A"
        outcome: "PASS if patterns match"
      - req: ">0"
        waiver: ">0"
        outcome: "PASS if patterns match or waived"
    current_evidence_assessment:
      netlist:
        extraction: "6/6 complete"
        pattern_match: true
        waiver_applicable: false
        expected_result: "PASS"
      spef:
        extraction: "0/6 skipped"
        pattern_match: null
        waiver_applicable: true
        waiver_match: "*post-synthesis*"
        expected_result: "PASS (waived)"
      overall_outcome: "PASS"
      rationale: "Netlist fully extracted and validated; SPEF appropriately waived for post-synthesis flow"
  
  validation_rules:
    - rule: "netlist_mandatory"
      condition: "netlist extraction must be 6/6"
      failure_action: "FAIL"
    - rule: "spef_conditional"
      condition: "spef extraction 6/6 OR valid waiver"
      failure_action: "FAIL if neither condition met"
    - rule: "pattern_validation"
      condition: "extracted values match patterns when req>0"
      failure_action: "FAIL unless waived"
```
