# stage_format_spec LLM Input

## System Prompt

```
You are a senior digital physical implementation expert.
Return only Markdown in English.
Do not use Chinese.
Keep technical content concise and operational.

## Stage Boundaries

- ItemSpec stage must not read runtime input files.
- ParsingSpec stage reads resolved input files and records evidence locations.
- FormatSpec stage depends on ItemSpec + ParsingSpec + valid evidence snippets.

## Critical Rules

### ItemSpec Stage Rules:
- Each object MUST define exactly 6 sub-items:
  - file_path, file_name, design_name
  - generator_tool (or extractor_tool for SPEF)
  - generator_version (or extractor_version for SPEF)
  - generation_time (or extraction_time for SPEF)
- ALL 6 sub-items are MANDATORY unless explicitly waived
- Do NOT include regex patterns - only define WHAT to extract, not HOW
- Specify data source for each sub-item (e.g., "STA log" or "netlist file header")

### ParsingSpec Stage Rules:
- **MUST read any file paths that are extracted** (e.g., if netlist path extracted from log, read netlist file header)
- Extract ALL 6 sub-items defined in ItemSpec for each object
- Mark extraction status: ✓ (success) or ERROR (failed)
- Provide object-level summary: "netlist 6/6 ✓" or "spef 0/6 ✗"

### FormatSpec Stage Rules:
- Patterns must be cross-project REUSABLE
- CORRECT: `*.v.gz`, `*/dbs/*`, `*Synthesis*`
- WRONG: `*block_A*`, `*Genus 23.15*`, specific project paths or file names
- Do NOT hardcode specific extracted values into patterns

```

## User Prompt

```
Create the FormatSpec for one checker item.

Requirements:
- Output must be Markdown in English.
- Title must include item ID.
- Include exactly these sections:
  - ## Pattern Strategy
  - ## Requirement Items
  - ## Pattern Index Mapping
  - ## Waiver Items
  - ## Waiver Keyword Taxonomy
  - ## Scenario Matrix
  - ## Expected Outcomes
  - ## Embedded Schema
- Include line `vio_name_format: "item_name"`.

## CRITICAL: Pattern Design Rules

Patterns MUST be cross-project REUSABLE. Do NOT hardcode project-specific values.

| Pattern Type | CORRECT | WRONG |
|--------------|---------|-------|
| File extension | `*.v.gz`, `*.spef*` | `design_block_A.v.gz` |
| Path pattern | `*/dbs/*`, `*/logs/*` | `/Users/john/project_X/*` |
| Tool pattern | `*Synthesis*`, `*Genus*` | `Genus 23.15-s099_1` |
| Version pattern | `*.*-*` | `23.15-s099_1` |

## Aggregated Requirement Format

Use aggregated format for pattern_items:
```yaml
pattern_items:
  - "netlist: file_path=*/dbs/*.v.gz; file_name=*.v.gz; generator_tool=*Synthesis*"
  - "spef: file_path=*.spef*; file_name=*.spef*"
```

## Four Scenario Framework

Include four scenario sections with fields:
- Scenario 1: req=N/A, waiver=N/A (existence check only)
- Scenario 2: req=N/A, waiver>0 (existence + waiver handling)
- Scenario 3: req>0, waiver=N/A (pattern matching)
- Scenario 4: req>0, waiver>0 (pattern + waiver)

Each scenario includes:
- found_desc, missing_desc
- found_reason, missing_reason
- waived_desc, unused_desc (for waiver scenarios)
- waived_reason, unused_reason (for waiver scenarios)

- Include one YAML code block under "## Embedded Schema" with key `format_spec`.
- In `## Pattern Index Mapping`, provide explicit mapping:
  - `pattern_items[i] -> validation target`.
- In `## Waiver Keyword Taxonomy`, provide scenario keywords and sample waiver reasons.
- In `## Expected Outcomes`, provide expected PASS/FAIL under requirement/waiver combinations
  and annotate expected outcome under current parsing evidence.

Item context:
{
  "item_id": "IMP-10-0-0-00",
  "description": "Confirm the netlist/spef version is correct.",
  "check_module": "10.0_STA_DCD_CHECK",
  "requirements_value": "N/A",
  "pattern_items": [],
  "waiver_value": "N/A",
  "waive_items": [],
  "item_yaml": "C:\\Users\\wentao\\Desktop\\AAI\\Main_work\\ACL\\checker-agent-dev\\CHECKLIST\\Check_modules\\10.0_STA_DCD_CHECK\\inputs\\items\\IMP-10-0-0-00.yaml",
  "input_files_raw": [
    "${CHECKLIST_ROOT}/IP_project_folder/logs/sta_post_syn.log"
  ],
  "resolved_inputs": [
    "C:\\Users\\wentao\\Desktop\\AAI\\Main_work\\ACL\\checker-agent-dev\\CHECKLIST\\IP_project_folder\\logs\\sta_post_syn.log"
  ],
  "missing_inputs": [],
  "candidate_objects": [
    "netlist",
    "power_emir",
    "spef"
  ],
  "regex_clues": [
    "read_netlist\\s+([^\\s]+\\.v(?:\\.gz)?)",
    "\\[INFO\\]\\s+Skipping SPEF reading as (.+)",
    "read_spef\\s+([^\\s]+\\.spef(?:\\.gz)?)",
    "#\\s*Parasitics Mode:\\s*(.+)",
    "Top level cell is\\s+(\\S+)",
    "Program version\\s*=\\s*([\\d\\.\\-\\w]+)",
    "Generated on:\\s*(.+?)\\s+\\w+\\s+\\((.+?)\\)",
    "Generated on:\\s*(.+?)$",
    "DATE\\s+",
    "DESIGN_FLOW\\s+"
  ]
}

ItemSpec:
# ItemSpec: IMP-10-0-0-00

## Scope

This checker verifies that the netlist and SPEF files loaded in STA (Static Timing Analysis) are the correct versions by extracting and documenting their metadata including file paths, generator/extractor tools, versions, and timestamps.

## Description Interpretation Rules

1. **Slash notation "netlist/spef"**: Logical AND - both netlist AND spef objects must be checked
2. **"version is correct"**: Requires extraction of complete version metadata (tool, version, timestamp) for manual or automated verification
3. **Optional components**: `power_emir` is a candidate object but may not be present in all flows; extraction should be attempted but absence is not a failure
4. **Evidence completeness**: All 6 sub-items per object are mandatory for version confirmation

## Data Sources

| Priority | Data Source | Expected Content |
|----------|-------------|------------------|
| Primary | STA log | file_path, file_name, design_name, load status for netlist and SPEF |
| Secondary | Netlist file header | generator_tool, generator_version, generation_time |
| Secondary | SPEF file header | extractor_tool, extractor_version, extraction_time |

## Semantic Targets

### Target Objects

| Object | Description | Mandatory |
|--------|-------------|-----------|
| netlist | Verilog netlist file loaded in STA | Yes |
| spef | SPEF parasitic file loaded in STA | Yes |
| power_emir | Power/EMIR related file if present | No |

### Object/Sub-Item Contract Table

| Object | Sub-Item | Semantic | Required | Data Source |
|--------|----------|----------|----------|-------------|
| netlist | file_path | Full path to netlist file | **MANDATORY** | STA log (read_netlist command) |
| netlist | file_name | Filename extracted from path | **MANDATORY** | Derived from file_path |
| netlist | design_name | Top-level module name | **MANDATORY** | STA log or netlist file header |
| netlist | generator_tool | Synthesis tool name | **MANDATORY** | Netlist file header |
| netlist | generator_version | Synthesis tool version | **MANDATORY** | Netlist file header |
| netlist | generation_time | Netlist creation timestamp | **MANDATORY** | Netlist file header |
| spef | file_path | Full path to SPEF file | **MANDATORY** | STA log (read_spef command) |
| spef | file_name | Filename extracted from path | **MANDATORY** | Derived from file_path |
| spef | design_name | Top-level design name | **MANDATORY** | STA log or SPEF file header |
| spef | extractor_tool | Parasitic extraction tool name | **MANDATORY** | SPEF file header |
| spef | extractor_version | Extraction tool version | **MANDATORY** | SPEF file header |
| spef | extraction_time | SPEF creation timestamp | **MANDATORY** | SPEF file header |

## Check Criteria

1. **Extraction completeness**: All 6 sub-items must be successfully extracted for each object
2. **File accessibility**: Extracted file paths must point to readable files
3. **Version documentation**: Tool versions and timestamps must be captured for audit trail
4. **Design consistency**: Design name should be consistent across netlist and SPEF

## Evidence Plan

| Evidence Type | Source | Purpose |
|---------------|--------|---------|
| Log snippet | STA log | Show read_netlist and read_spef commands with file paths |
| Header snippet | Netlist file | Show generator tool, version, and timestamp |
| Header snippet | SPEF file | Show extractor tool, version, and timestamp |
| Summary table | Generated | Consolidated version information for all objects |

## Embedded Schema

```yaml
itemspec:
  item_id: IMP-10-0-0-00
  description: "Confirm the netlist/spef version is correct."
  check_module: 10.0_STA_DCD_CHECK
  
  objects:
    - name: netlist
      mandatory: true
      sub_items:
        - name: file_path
          semantic: "Full path to netlist file"
          required: true
          data_source: "STA log - read_netlist command"
        - name: file_name
          semantic: "Filename extracted from path"
          required: true
          data_source: "Derived from file_path"
        - name: design_name
          semantic: "Top-level module name"
          required: true
          data_source: "STA log or netlist file header"
        - name: generator_tool
          semantic: "Synthesis tool that created netlist"
          required: true
          data_source: "Netlist file header"
        - name: generator_version
          semantic: "Synthesis tool version"
          required: true
          data_source: "Netlist file header"
        - name: generation_time
          semantic: "Netlist creation timestamp"
          required: true
          data_source: "Netlist file header"
    
    - name: spef
      mandatory: true
      sub_items:
        - name: file_path
          semantic: "Full path to SPEF file"
          required: true
          data_source: "STA log - read_spef command"
        - name: file_name
          semantic: "Filename extracted from path"
          required: true
          data_source: "Derived from file_path"
        - name: design_name
          semantic: "Top-level design name in SPEF"
          required: true
          data_source: "STA log or SPEF file header"
        - name: extractor_tool
          semantic: "Parasitic extraction tool name"
          required: true
          data_source: "SPEF file header"
        - name: extractor_version
          semantic: "Extraction tool version"
          required: true
          data_source: "SPEF file header"
        - name: extraction_time
          semantic: "SPEF creation timestamp"
          required: true
          data_source: "SPEF file header"
  
  input_files:
    - type: sta_log
      purpose: "Extract file paths and design names"
      triggers_secondary_read: true
    - type: netlist_file
      purpose: "Extract generator metadata from header"
      access_method: "Path extracted from STA log"
    - type: spef_file
      purpose: "Extract extractor metadata from header"
      access_method: "Path extracted from STA log"
  
  check_criteria:
    - "All 6 sub-items extracted for netlist object"
    - "All 6 sub-items extracted for spef object"
    - "File paths are valid and accessible"
    - "Version metadata captured for audit"
```

ParsingSpec:
# ParsingSpec: IMP-10-0-0-00

## Input Resolution

| Input Type | Resolved Path | Status |
|------------|---------------|--------|
| STA log | `C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log` | ✓ Accessible |
| Netlist file | `C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\dbs\phy_cmn_phase_align_digtop.v.gz` | ✓ Accessible (referenced from log) |
| SPEF file | N/A | ✗ Skipped per log |

## Evidence Inventory

| Source File | Line | Extracted Value | Context Snippet |
|-------------|------|-----------------|-----------------|
| sta_post_syn.log | 7 | `/Users/daiwt/.../phy_cmn_phase_align_digtop.v.gz` | `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` |
| sta_post_syn.log | 14 | `phy_cmn_phase_align_digtop` | `Top level cell is phy_cmn_phase_align_digtop.` |
| sta_post_syn.log | 24 | `we are writing post-synthesis SDF files` | `[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files` |
| phy_cmn_phase_align_digtop.v.gz | 2 | `Cadence Genus(TM) Synthesis Solution 23.15-s099_1` | `// Generated by Cadence Genus(TM) Synthesis Solution 23.15-s099_1` |
| phy_cmn_phase_align_digtop.v.gz | 3 | `Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC)` | `// Generated on: Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC)` |

## Referenced Files

| File Type | Path | Access Method | Read Status |
|-----------|------|---------------|-------------|
| Netlist | `phy_cmn_phase_align_digtop.v.gz` | Extracted from STA log line 7 | ✓ Header parsed |
| SPEF | N/A | Skipped per STA log line 24 | ✗ Not loaded |

## Evidence to Sub-Item Mapping

| Evidence Source | Line | Extracted Value | Object | Sub-Item | Status | Rationale |
|-----------------|------|-----------------|--------|----------|--------|-----------|
| sta_post_syn.log | 7 | `/Users/daiwt/.../phy_cmn_phase_align_digtop.v.gz` | netlist | file_path | ✓ | read_netlist command provides full path |
| sta_post_syn.log | 7 | `phy_cmn_phase_align_digtop.v.gz` | netlist | file_name | ✓ | Derived from file_path basename |
| sta_post_syn.log | 14 | `phy_cmn_phase_align_digtop` | netlist | design_name | ✓ | "Top level cell is" indicates design name |
| phy_cmn_phase_align_digtop.v.gz | 2 | `Cadence Genus(TM) Synthesis Solution` | netlist | generator_tool | ✓ | "Generated by" header field |
| phy_cmn_phase_align_digtop.v.gz | 2 | `23.15-s099_1` | netlist | generator_version | ✓ | Version extracted from tool string |
| phy_cmn_phase_align_digtop.v.gz | 3 | `Nov 18 2025 15:58:15 IST` | netlist | generation_time | ✓ | "Generated on:" header field |
| sta_post_syn.log | 24 | `Skipping SPEF reading` | spef | file_path | ERROR | SPEF explicitly skipped |
| sta_post_syn.log | 24 | N/A | spef | file_name | ERROR | No SPEF loaded |
| sta_post_syn.log | 24 | N/A | spef | design_name | ERROR | No SPEF loaded |
| N/A | N/A | N/A | spef | extractor_tool | ERROR | No SPEF file to read |
| N/A | N/A | N/A | spef | extractor_version | ERROR | No SPEF file to read |
| N/A | N/A | N/A | spef | extraction_time | ERROR | No SPEF file to read |

## Object Status Summary

| Object | Status | Extracted | Total | Missing Sub-Items |
|--------|--------|-----------|-------|-------------------|
| netlist | ✓ | 6 | 6 | (none) |
| spef | ✗ | 0 | 6 | file_path, file_name, design_name, extractor_tool, extractor_version, extraction_time |

**Summary**: netlist 6/6 ✓ | spef 0/6 ✗ (SPEF skipped per log)

## Extraction Gaps

| Object | Sub-Item | Gap Reason | Remediation |
|--------|----------|------------|-------------|
| spef | all 6 sub-items | STA log explicitly states "Skipping SPEF reading as we are writing post-synthesis SDF files" | Expected for post-synthesis STA flow; SPEF not applicable |

**Note**: SPEF extraction failure is expected behavior for post-synthesis timing analysis. The log confirms this is intentional, not an error condition.

## Embedded Schema

```yaml
parsing_spec:
  item_id: IMP-10-0-0-00
  description: "Confirm the netlist/spef version is correct."
  check_module: 10.0_STA_DCD_CHECK
  
  input_resolution:
    - type: sta_log
      resolved_path: "C:\\Users\\wentao\\Desktop\\AAI\\Main_work\\ACL\\checker-agent-dev\\CHECKLIST\\IP_project_folder\\logs\\sta_post_syn.log"
      status: accessible
    - type: netlist_file
      resolved_path: "C:\\Users\\wentao\\Desktop\\AAI\\Main_work\\ACL\\checker-agent-dev\\CHECKLIST\\IP_project_folder\\dbs\\phy_cmn_phase_align_digtop.v.gz"
      status: accessible
      access_method: "extracted from STA log line 7"
    - type: spef_file
      resolved_path: null
      status: skipped
      reason: "STA log line 24 indicates SPEF reading skipped"
  
  objects:
    - name: netlist
      extraction_status: complete
      extracted_count: 6
      total_count: 6
      sub_items:
        - name: file_path
          value: "/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz"
          source: "sta_post_syn.log"
          line: 7
          status: extracted
        - name: file_name
          value: "phy_cmn_phase_align_digtop.v.gz"
          source: "sta_post_syn.log"
          line: 7
          derivation: "basename of file_path"
          status: extracted
        - name: design_name
          value: "phy_cmn_phase_align_digtop"
          source: "sta_post_syn.log"
          line: 14
          status: extracted
        - name: generator_tool
          value: "Cadence Genus(TM) Synthesis Solution"
          source: "phy_cmn_phase_align_digtop.v.gz"
          line: 2
          status: extracted
        - name: generator_version
          value: "23.15-s099_1"
          source: "phy_cmn_phase_align_digtop.v.gz"
          line: 2
          status: extracted
        - name: generation_time
          value: "Nov 18 2025 15:58:15 IST"
          source: "phy_cmn_phase_align_digtop.v.gz"
          line: 3
          status: extracted
    
    - name: spef
      extraction_status: skipped
      extracted_count: 0
      total_count: 6
      skip_reason: "SPEF reading explicitly skipped per STA log - post-synthesis SDF flow"
      skip_evidence:
        source: "sta_post_syn.log"
        line: 24
        message: "Skipping SPEF reading as we are writing post-synthesis SDF files"
      sub_items:
        - name: file_path
          value: null
          status: not_applicable
        - name: file_name
          value: null
          status: not_applicable
        - name: design_name
          value: null
          status: not_applicable
        - name: extractor_tool
          value: null
          status: not_applicable
        - name: extractor_version
          value: null
          status: not_applicable
        - name: extraction_time
          value: null
          status: not_applicable
  
  evidence_snippets:
    - id: ev_netlist_path
      source: "sta_post_syn.log"
      line: 7
      content: "<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz"
      maps_to: ["netlist.file_path", "netlist.file_name"]
    - id: ev_design_name
      source: "sta_post_syn.log"
      line: 14
      content: "Top level cell is phy_cmn_phase_align_digtop."
      maps_to: ["netlist.design_name"]
    - id: ev_spef_skip
      source: "sta_post_syn.log"
      line: 24
      content: "[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files"
      maps_to: ["spef.skip_reason"]
    - id: ev_generator_info
      source: "phy_cmn_phase_align_digtop.v.gz"
      line: 2
      content: "// Generated by Cadence Genus(TM) Synthesis Solution 23.15-s099_1"
      maps_to: ["netlist.generator_tool", "netlist.generator_version"]
    - id: ev_generation_time
      source: "phy_cmn_phase_align_digtop.v.gz"
      line: 3
      content: "// Generated on: Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC)"
      maps_to: ["netlist.generation_time"]
  
  extraction_gaps:
    - object: spef
      sub_items: ["file_path", "file_name", "design_name", "extractor_tool", "extractor_version", "extraction_time"]
      reason: "SPEF reading skipped - post-synthesis SDF flow"
      severity: expected
      remediation: "None required - expected for post-synthesis timing"
```

Evidence context:
Resolved inputs:
- C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log

Missing inputs:
- (none)

Input evidence table:
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 7 | `read_netlist\s+([^\s]+\.v(?:\.gz)?)` | `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` |
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 7 | `read_netlist\s+([^\s]+)` | `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` | `<CMD> read_netlist /Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/IP_project_folder/dbs/phy_cmn_phase_align_digtop.v.gz` |
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 8 | `\bnetlist\b` | `-` | `[INFO] Reading netlist file...` |
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 11 | `\bnetlist\b` | `-` | `[INFO] Decompressing and parsing netlist...` |
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 14 | `Top level cell is\s+(\S+)` | `phy_cmn_phase_align_digtop.` | `Top level cell is phy_cmn_phase_align_digtop.` |
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 24 | `\[INFO\]\s+Skipping SPEF reading as (.+)` | `we are writing post-synthesis SDF files` | `[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files` |
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\logs\sta_post_syn.log | 24 | `Skipping SPEF reading as\s+(.+)` | `we are writing post-synthesis SDF files` | `[INFO] Skipping SPEF reading as we are writing post-synthesis SDF files` |

Referenced evidence table:
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\dbs\phy_cmn_phase_align_digtop.v.gz | 2 | `Generated by\s+(.+)` | `Cadence Genus(TM) Synthesis Solution 23.15-s099_1` | `// Generated by Cadence Genus(TM) Synthesis Solution 23.15-s099_1` |
| C:\Users\wentao\Desktop\AAI\Main_work\ACL\checker-agent-dev\CHECKLIST\IP_project_folder\dbs\phy_cmn_phase_align_digtop.v.gz | 3 | `Generated on:\s+(.+)` | `Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC)` | `// Generated on: Nov 18 2025 15:58:15 IST (Nov 18 2025 10:28:15 UTC)` |

Notes:
- (none)

```
