# stage_itemspec LLM Output

# ItemSpec: IMP-10-0-0-00

## Scope

This checker verifies that the netlist and SPEF files loaded in STA (Static Timing Analysis) are the correct versions by extracting and documenting their metadata including file paths, generator/extractor tools, versions, and timestamps.

## Description Interpretation Rules

1. **Slash notation "netlist/spef"**: Logical AND - both netlist AND spef objects must be checked
2. **"version is correct"**: Requires extraction of complete version metadata (tool, version, timestamp) for manual or automated verification
3. **Optional components**: `power_emir` is a candidate object but may not be present in all flows; extraction should be attempted but absence is not a failure
4. **Evidence completeness**: All 6 sub-items per object are mandatory for version confirmation

## Data Sources

| Priority | Data Source | Expected Content |
|----------|-------------|------------------|
| Primary | STA log | file_path, file_name, design_name, load status for netlist and SPEF |
| Secondary | Netlist file header | generator_tool, generator_version, generation_time |
| Secondary | SPEF file header | extractor_tool, extractor_version, extraction_time |

## Semantic Targets

### Target Objects

| Object | Description | Mandatory |
|--------|-------------|-----------|
| netlist | Verilog netlist file loaded in STA | Yes |
| spef | SPEF parasitic file loaded in STA | Yes |
| power_emir | Power/EMIR related file if present | No |

### Object/Sub-Item Contract Table

| Object | Sub-Item | Semantic | Required | Data Source |
|--------|----------|----------|----------|-------------|
| netlist | file_path | Full path to netlist file | **MANDATORY** | STA log (read_netlist command) |
| netlist | file_name | Filename extracted from path | **MANDATORY** | Derived from file_path |
| netlist | design_name | Top-level module name | **MANDATORY** | STA log or netlist file header |
| netlist | generator_tool | Synthesis tool name | **MANDATORY** | Netlist file header |
| netlist | generator_version | Synthesis tool version | **MANDATORY** | Netlist file header |
| netlist | generation_time | Netlist creation timestamp | **MANDATORY** | Netlist file header |
| spef | file_path | Full path to SPEF file | **MANDATORY** | STA log (read_spef command) |
| spef | file_name | Filename extracted from path | **MANDATORY** | Derived from file_path |
| spef | design_name | Top-level design name | **MANDATORY** | STA log or SPEF file header |
| spef | extractor_tool | Parasitic extraction tool name | **MANDATORY** | SPEF file header |
| spef | extractor_version | Extraction tool version | **MANDATORY** | SPEF file header |
| spef | extraction_time | SPEF creation timestamp | **MANDATORY** | SPEF file header |

## Check Criteria

1. **Extraction completeness**: All 6 sub-items must be successfully extracted for each object
2. **File accessibility**: Extracted file paths must point to readable files
3. **Version documentation**: Tool versions and timestamps must be captured for audit trail
4. **Design consistency**: Design name should be consistent across netlist and SPEF

## Evidence Plan

| Evidence Type | Source | Purpose |
|---------------|--------|---------|
| Log snippet | STA log | Show read_netlist and read_spef commands with file paths |
| Header snippet | Netlist file | Show generator tool, version, and timestamp |
| Header snippet | SPEF file | Show extractor tool, version, and timestamp |
| Summary table | Generated | Consolidated version information for all objects |

## Embedded Schema

```yaml
itemspec:
  item_id: IMP-10-0-0-00
  description: "Confirm the netlist/spef version is correct."
  check_module: 10.0_STA_DCD_CHECK
  
  objects:
    - name: netlist
      mandatory: true
      sub_items:
        - name: file_path
          semantic: "Full path to netlist file"
          required: true
          data_source: "STA log - read_netlist command"
        - name: file_name
          semantic: "Filename extracted from path"
          required: true
          data_source: "Derived from file_path"
        - name: design_name
          semantic: "Top-level module name"
          required: true
          data_source: "STA log or netlist file header"
        - name: generator_tool
          semantic: "Synthesis tool that created netlist"
          required: true
          data_source: "Netlist file header"
        - name: generator_version
          semantic: "Synthesis tool version"
          required: true
          data_source: "Netlist file header"
        - name: generation_time
          semantic: "Netlist creation timestamp"
          required: true
          data_source: "Netlist file header"
    
    - name: spef
      mandatory: true
      sub_items:
        - name: file_path
          semantic: "Full path to SPEF file"
          required: true
          data_source: "STA log - read_spef command"
        - name: file_name
          semantic: "Filename extracted from path"
          required: true
          data_source: "Derived from file_path"
        - name: design_name
          semantic: "Top-level design name in SPEF"
          required: true
          data_source: "STA log or SPEF file header"
        - name: extractor_tool
          semantic: "Parasitic extraction tool name"
          required: true
          data_source: "SPEF file header"
        - name: extractor_version
          semantic: "Extraction tool version"
          required: true
          data_source: "SPEF file header"
        - name: extraction_time
          semantic: "SPEF creation timestamp"
          required: true
          data_source: "SPEF file header"
  
  input_files:
    - type: sta_log
      purpose: "Extract file paths and design names"
      triggers_secondary_read: true
    - type: netlist_file
      purpose: "Extract generator metadata from header"
      access_method: "Path extracted from STA log"
    - type: spef_file
      purpose: "Extract extractor metadata from header"
      access_method: "Path extracted from STA log"
  
  check_criteria:
    - "All 6 sub-items extracted for netlist object"
    - "All 6 sub-items extracted for spef object"
    - "File paths are valid and accessible"
    - "Version metadata captured for audit"
```
