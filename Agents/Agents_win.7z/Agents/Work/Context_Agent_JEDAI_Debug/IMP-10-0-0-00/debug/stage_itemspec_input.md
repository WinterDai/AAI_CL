# stage_itemspec LLM Input

## System Prompt

```
You are a senior digital physical implementation expert.
Return only Markdown in English.
Do not use Chinese.
Keep technical content concise and operational.

## Stage Boundaries

- ItemSpec stage must not read runtime input files.
- ParsingSpec stage reads resolved input files and records evidence locations.
- FormatSpec stage depends on ItemSpec + ParsingSpec + valid evidence snippets.

## Critical Rules

### ItemSpec Stage Rules:
- Each object MUST define exactly 6 sub-items:
  - file_path, file_name, design_name
  - generator_tool (or extractor_tool for SPEF)
  - generator_version (or extractor_version for SPEF)
  - generation_time (or extraction_time for SPEF)
- ALL 6 sub-items are MANDATORY unless explicitly waived
- Do NOT include regex patterns - only define WHAT to extract, not HOW
- Specify data source for each sub-item (e.g., "STA log" or "netlist file header")

### ParsingSpec Stage Rules:
- **MUST read any file paths that are extracted** (e.g., if netlist path extracted from log, read netlist file header)
- Extract ALL 6 sub-items defined in ItemSpec for each object
- Mark extraction status: ✓ (success) or ERROR (failed)
- Provide object-level summary: "netlist 6/6 ✓" or "spef 0/6 ✗"

### FormatSpec Stage Rules:
- Patterns must be cross-project REUSABLE
- CORRECT: `*.v.gz`, `*/dbs/*`, `*Synthesis*`
- WRONG: `*block_A*`, `*Genus 23.15*`, specific project paths or file names
- Do NOT hardcode specific extracted values into patterns

```

## User Prompt

```
Create the ItemSpec for one checker item.

Requirements:
- Output must be Markdown in English.
- Title must include item ID.
- Include exactly these sections:
  - ## Scope
  - ## Description Interpretation Rules
  - ## Data Sources
  - ## Semantic Targets
  - ## Check Criteria
  - ## Evidence Plan
  - ## Embedded Schema
- Include one YAML code block under "## Embedded Schema" with key `itemspec`.
- This stage must not parse runtime input files.
- Do NOT include regex patterns - only define WHAT to extract, not HOW.

## Sub-Item Definition (CRITICAL)

For EACH check object (e.g., netlist, spef), define exactly these 6 sub-items:

| Sub-Item | Semantic | Required | Data Source |
|----------|----------|----------|-------------|
| `file_path` | Full path to the file | **MANDATORY** | STA log |
| `file_name` | Filename extracted from path | **MANDATORY** | Derived from file_path |
| `design_name` | Top-level design/module name | **MANDATORY** | STA log or file header |
| `generator_tool` | Tool that created the file | **MANDATORY** | File header |
| `generator_version` | Tool version | **MANDATORY** | File header |
| `generation_time` | When the file was created | **MANDATORY** | File header |

For SPEF objects, use `extractor_tool`, `extractor_version`, `extraction_time` instead.

## Data Sources Section

Include a table specifying where each sub-item should be extracted from:

| Priority | Data Source | Expected Content |
|----------|-------------|------------------|
| Primary | STA log | file_path, file_name, design_name, load status |
| Secondary | Netlist file header | generator_tool, generator_version, generation_time |
| Secondary | SPEF file header | extractor_tool, extractor_version, extraction_time |

## Other Requirements

- In `## Description Interpretation Rules`, include:
  - slash notation default = logical AND across objects unless explicit "or"
  - explicit alternatives with "or"
  - optional components handling
- In `## Semantic Targets`, include both:
  - semantic target table
  - object/sub-item contract table (ALL 6 sub-items per object, all mandatory).

Item context:
{
  "item_id": "IMP-10-0-0-00",
  "description": "Confirm the netlist/spef version is correct.",
  "check_module": "10.0_STA_DCD_CHECK",
  "requirements_value": "N/A",
  "pattern_items": [],
  "waiver_value": "N/A",
  "waive_items": [],
  "item_yaml": "C:\\Users\\wentao\\Desktop\\AAI\\Main_work\\ACL\\checker-agent-dev\\CHECKLIST\\Check_modules\\10.0_STA_DCD_CHECK\\inputs\\items\\IMP-10-0-0-00.yaml",
  "input_files_raw": [
    "${CHECKLIST_ROOT}/IP_project_folder/logs/sta_post_syn.log"
  ],
  "resolved_inputs": [
    "C:\\Users\\wentao\\Desktop\\AAI\\Main_work\\ACL\\checker-agent-dev\\CHECKLIST\\IP_project_folder\\logs\\sta_post_syn.log"
  ],
  "missing_inputs": [],
  "candidate_objects": [
    "netlist",
    "power_emir",
    "spef"
  ],
  "regex_clues": [
    "read_netlist\\s+([^\\s]+\\.v(?:\\.gz)?)",
    "\\[INFO\\]\\s+Skipping SPEF reading as (.+)",
    "read_spef\\s+([^\\s]+\\.spef(?:\\.gz)?)",
    "#\\s*Parasitics Mode:\\s*(.+)",
    "Top level cell is\\s+(\\S+)",
    "Program version\\s*=\\s*([\\d\\.\\-\\w]+)",
    "Generated on:\\s*(.+?)\\s+\\w+\\s+\\((.+?)\\)",
    "Generated on:\\s*(.+?)$",
    "DATE\\s+",
    "DESIGN_FLOW\\s+"
  ]
}

Offline knowledge context:
- score=1.484 source=`skills/IMP-10-0-0-00_skill.md` section=`Description` snippet="Confirm the netlist/spef version is correct."
- score=1.430 source=`skills/IMP-10-0-0-00_skill.md` section=`Suggested retrieval queries` snippet="- IMP-10-0-0-00 checker intent Confirm the netlist/spef version is correct. - physical implementation netlist power_emir spef evidence extraction - input_logs parasitics power_integrity timing_signoff best practices"
- score=1.086 source=`skills/IMP-10-0-0-00_skill.md` section=`Embedded schema` snippet="```yaml skill_schema: item_id: IMP-10-0-0-00 check_module: 10.0_STA_DCD_CHECK intent: verification knowledge_tags: - input_logs - parasitics - power_integrity - timing_signoff candidate_objects: - netlist - power_emir - ..."
- score=1.058 source=`skills/IMP-10-0-0-00_skill.md` section=`Module and Intent` snippet="- Module: `10.0_STA_DCD_CHECK` - Intent: `verification` - Candidate objects: netlist, power_emir, spef - Knowledge tags: input_logs, parasitics, power_integrity, timing_signoff"
- score=1.016 source=`skills/IMP-10-0-0-00_skill.md` section=`Input and Existing Implementation Clues` snippet="- Item YAML: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLIST/Check_modules/10.0_STA_DCD_CHECK/inputs/items/IMP-10-0-0-00.yaml` - Checker script: `/Users/daiwt/Documents/AAI/ACL/PJ1/New_dev/20260129/CHECKLI..."
- score=0.931 source=`skills/IMP-10-0-0-00_skill.md` section=`Keyword clues from existing checker` snippet="- `# Confirm the netlist/spef version is correct.` - `# - Extract netlist file path from read_netlist command` - `# - Open extracted netlist file to capture version timestamp from header (line 3)` - `# - Open extracted S..."
- score=0.848 source=`skills/IMP-10-0-0-00_skill.md` section=`Regex clues from existing checker` snippet="- `read_netlist\\s+([^\\s]+\\.v(?:\\.gz)?)` - `\\[INFO\\]\\s+Skipping SPEF reading as (.+)` - `read_spef\\s+([^\\s]+\\.spef(?:\\.gz)?)` - `#\\s*Parasitics Mode:\\s*(.+)` - `Top level cell is\\s+(\\S+)` - `Program version\\s*=\\s*([\\d\\.\\-..."
- score=0.429 source=`skills/IMP-14-0-0-00_skill.md` section=`Suggested retrieval queries` snippet="- IMP-14-0-0-00 checker intent Confirm set the correct golden netlist. - physical implementation netlist power_emir evidence extraction - power_integrity best practices"

```
