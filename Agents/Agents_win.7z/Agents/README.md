# Checker Agent 系统文档

> **版本**: v1.0 | **日期**: 2026-02-06

---

## 1. 系统概述

Checker Agent 系统是一个自动化代码生成与验证框架，用于生成 EDA 工具的检查脚本。系统采用多 Agent 协作架构，实现从语义理解到代码验证的完整流水线。

### 1.1 系统架构

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         Orchestrator Agent                               │
│                      (系统协调器 - 流水线控制)                            │
└────────────────────────────────┬────────────────────────────────────────┘
                                 │
         ┌───────────────────────┼───────────────────────┐
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│  Context Agent  │───▶│  CodeGen Agent  │───▶│ Validation Agent│
│  (语义理解)      │    │  (代码生成)      │    │  (验证审计)      │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
   parsing_spec.md         imp_logic.py          validation_report.md
   format_spec.md          imp_config.py         codegen_feedback.json
                           universal_runner.py
```

### 1.2 目录结构

```
Agents/
├── Orchestrator/           # 系统协调器
│   └── orchestrator.py     # 流水线控制
├── Context/                # 语义理解 Agent (占空)
│   └── (placeholder)
├── CodeGen/                # 代码生成 Agent
│   ├── orchestrator.py     # CodeGen 主流程
│   ├── llm_client.py       # LLM 抽象层
│   ├── prompts.py          # Prompt 模板
│   ├── code_extractor.py   # 代码提取
│   ├── assembler.py        # 代码组装
│   └── sanity_runner.py    # Sanity 验证
├── Validation/             # 验证 Agent
│   ├── auditor.py          # Auditor 主类
│   ├── schemas.py          # 数据结构
│   ├── auditor_prompts.py  # Prompt 模板
│   ├── executor.py         # 测试执行
│   ├── reviewer.py         # 评审循环
│   └── validators/         # 原子单元验证器
└── Framework/              # Checker 框架层
    ├── unified_checker.py  # 统一 Checker
    ├── check_module.py     # 检查模块
    ├── waiver_module.py    # Waiver 模块
    └── output_builder.py   # 输出构建器
```

---

## 2. Agent 详细说明

### 2.1 Context Agent (暂时占空)

**职责**: 从 ItemSpec 和示例文件中提取语义信息，生成 Spec 文件

**产物**:
- `parsing_spec.md`: 定义如何解析输入文件
- `format_spec.md`: 定义 violation name 格式和 pattern 契约

**当前状态**: 占空，使用预置 Spec 文件

---

### 2.2 CodeGen Agent

**职责**: 根据 Spec 生成三个代码原子单元

**核心组件**:

| 文件 | 功能 |
|------|------|
| `orchestrator.py` | 8步流程控制 |
| `llm_client.py` | LLM 抽象 (Mock/Real/Interactive) |
| `prompts.py` | System/User Prompt 模板 |
| `code_extractor.py` | 从 LLM 响应提取代码 |
| `assembler.py` | 组装完整 Checker |
| `sanity_runner.py` | 分阶段 Sanity 验证 |

**8步流程**:
1. 加载 item.yaml
2. 解析 input_files
3. LLM 生成 parsing_logic
4. Parsing Sanity 验证
5. LLM 生成 check_logic + vio_name
6. Check Sanity 验证
7. 组装完整代码
8. 最终验证

**产物**:
- `imp_logic.py`: 三个原子单元函数
- `imp_config.py`: Type 配置
- `universal_runner.py`: 可执行 Checker

---

### 2.3 Validation Agent (Auditor Pattern)

**职责**: 验证 CodeGen 生成的代码，生成反馈

**Auditor 四阶段**:

| 阶段 | 类型 | 功能 |
|------|------|------|
| Phase 1 | LLM | 分析 Spec + Code |
| Phase 2 | LLM | 智能生成测试用例 |
| Phase 3 | 程序 | 执行测试 (executor) |
| Phase 4 | LLM | 评审 + 生成反馈 |

**核心组件**:

| 文件 | 功能 |
|------|------|
| `auditor.py` | Auditor 主类 |
| `schemas.py` | 数据结构定义 |
| `auditor_prompts.py` | 3阶段 Prompt |
| `executor.py` | 测试执行器 |
| `reviewer.py` | 评审循环 |
| `validators/` | 原子单元验证器 |

**产物**:
- `validation_report.md`: 审计报告
- `codegen_feedback.json`: 给 CodeGen 的反馈

---

### 2.4 Orchestrator Agent

**职责**: 协调完整流水线

**流程**:
```
Context (占空) → CodeGen → Validation
                    ↑          │
                    └──失败回退──┘
```

**配置项**:
```python
PipelineConfig(
    item_id="IMP-10-0-0-00",
    work_dir=Path("./work"),
    format_spec_path=Path("format_spec.md"),
    input_files=[Path("input.log")],
    llm_mode=LLMMode.MOCK,
    max_codegen_retries=3,
    max_validation_retries=1
)
```

---

## 3. 使用指南

### 3.1 快速开始

```python
from Orchestrator import OrchestratorAgent, PipelineConfig
from CodeGen.llm_client import LLMMode
from pathlib import Path

# 配置
config = PipelineConfig(
    item_id="IMP-10-0-0-00",
    work_dir=Path("./output"),
    format_spec_path=Path("format_spec.md"),
    input_files=[Path("timing_report.log")],
    llm_mode=LLMMode.MOCK,
    mocks_dir=Path("./mocks")
)

# 运行
orchestrator = OrchestratorAgent(config)
result = orchestrator.run()

# 结果
if result.success:
    print("Pipeline passed!")
else:
    print(f"Failed at stage: {result.stage}")
```

### 3.2 单独使用 CodeGen

```python
from CodeGen.orchestrator import CodeGenOrchestrator
from CodeGen.llm_client import create_client, LLMMode
from pathlib import Path

client = create_client(LLMMode.MOCK, mocks_dir=Path("mocks"))
codegen = CodeGenOrchestrator(work_dir=Path("."), llm_client=client)
result = codegen.run(item_yaml_path=Path("item.yaml"))
```

### 3.3 单独使用 Validation

```python
from Validation import AuditorAgent
from CodeGen.llm_client import create_client, LLMMode
from pathlib import Path

client = create_client(LLMMode.MOCK, mocks_dir=Path("mocks"))
auditor = AuditorAgent(checker_dir=Path("."), llm_client=client)
report = auditor.run(format_spec_path=Path("format_spec.md"))
auditor.save_report(report, Path("audit_report.md"))
```

---

## 4. Framework Layer

### 4.1 三层架构

```
Layer 1: Checker 顶层 (固化)
    └── 输入提取 + 类型分发 + 输出控制

Layer 2: Type 模块 (固化)
    └── Type 1-4 逻辑实现

Layer 3: 原子单元 (LLM 生成)
    └── _parse_input_files
    └── _judge_item
    └── _build_vio_name
```

### 4.2 Type 定义

| Type | Requirement | Waiver | 字段 |
|------|-------------|--------|------|
| Type 1 | N/A | N/A | found, missing |
| Type 2 | >0 | N/A | found, missing, extra |
| Type 3 | >0 | >0 | + waived, unused_waivers |
| Type 4 | N/A | >0 | found, missing + waived, unused_waivers |

---

## 5. 产物清单

| 阶段 | 产物 | 格式 |
|------|------|------|
| Context | `parsing_spec.md` | Markdown |
| Context | `format_spec.md` | Markdown |
| CodeGen | `imp_logic.py` | Python |
| CodeGen | `imp_config.py` | Python |
| CodeGen | `universal_runner.py` | Python |
| CodeGen | `sanity_item.yaml` | YAML |
| Validation | `validation_report.md` | Markdown |
| Validation | `codegen_feedback.json` | JSON |
| Orchestrator | `pipeline_result.json` | JSON |

---

## 6. 开发状态

| Phase | 描述 | 状态 |
|-------|------|------|
| Phase 1 | 基础设施 | ✅ 完成 |
| Phase 1.5 | 架构设计 | ✅ 完成 |
| Phase 2 | Context Agent | ⏸️ 暂缓 |
| Phase 2A | Framework Layer | ✅ 完成 |
| Phase 3 | CodeGen Agent | ✅ 完成 |
| Phase 4 | Validation Agent | ✅ 完成 |
| Phase 5 | 系统集成 | 🔄 进行中 |

---

## 7. 依赖

```
google-generativeai>=0.3.0  # Gemini API
PyYAML>=6.0                 # YAML 解析
```

---

## 8. 许可证

Internal Use Only - AAI Team
