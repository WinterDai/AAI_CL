# IMP-5-0-0-13 - Confirm scan is successfully inserted and non-scannable flops have been peer reviewed and waived?

## Overview
- Category: TODO
- Input Files: TODO
- Description: TODO

## Check Logic

### Input Parsing
TODO: Describe how to parse the input files

### Detection Logic
TODO: Describe PASS/FAIL logic

## Configuration Examples

### Type 1: Boolean Check
TODO: Add example

### Type 2: Value Check
TODO: Add example

### Type 3: Value Check with Waiver
TODO: Add example

### Type 4: Boolean Check with Waiver
TODO: Add example

## Testing
TODO: Add test instructions
